import chai from 'chai';
import chaiPromised from 'chai-as-promised';
import supertest from 'supertest-as-promised';
const request = supertest(global.Promise)('http://localhost:7070/api/user');
import {User, Task} from '../src/models/index';
chai.use(chaiPromised);
const should = chai.should();

/*
describe('Tag', () => {
  describe('create', () => {
    it('should create new tag', () => {
      return request
        .post('/newTag')
        .send({
          name: '����'
        })
        .then((res) => {
          console.log(res.body);
          res.shoud.have.property('statusCode').equal(200);
          res.body.should.have.property('data');
          res.body.data.should.have.property('_id');
          res.body.data.should.not.have.property('default');
        });
    });
  });

});
  */