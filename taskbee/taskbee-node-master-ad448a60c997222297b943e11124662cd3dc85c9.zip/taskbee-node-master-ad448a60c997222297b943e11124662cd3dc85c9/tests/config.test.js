var mongoose = require('mongoose');
mongoose.models = {};
mongoose.modelSchemas = {};
if (!mongoose.connection.db) {
  mongoose.connect('mongodb://localhost/heart', function() {
    /* Drop the DB */
    mongoose.connection.db.dropDatabase();
  });
}
else {
  mongoose.connection.db.dropDatabase();
}
