import chai from 'chai';
import chaiPromised from 'chai-as-promised';
import supertest from 'supertest-as-promised';
import * as fake from './utils/fakeUser';
const request = supertest(global.Promise)('http://localhost:7070/api');

import {User, Task, Tag, Message} from '../src/models/index';

import io from 'socket.io-client';

chai.use(chaiPromised);
const should = chai.should();
const URL = 'http://localhost:3000';
const OPTIONS ={
  transports: ['websocket'],
  'force new connection': true
};

let TOKEN, TOKEN2;
let ID, IDTAKER;
let TAGID;
let TASKID;
let client, clientTaker;

let mockTask = {
  description: 'adasdaasdasdsdasdasdasdaasds',
  secret: 'asdasdasdasdasd',
  startTime: Date.now(),
  dueTime: Date.now() + 1000 * 60 * 60 *3,
  reward: 3,
  tags: []
};

const mockTag = 'play';

describe('Messages', () => {
  before(async function () {
    const {token, id} = await fake.createFakeWithId();
    const {token: tokenTaker, id: idTaker} = await fake.createFakeTakerWithId();
    TOKEN = token;
    TOKEN2 = tokenTaker;
    ID = id;
    IDTAKER = idTaker;
  });

  it('should connect', (done) => {
    client = io.connect(URL, OPTIONS);
    client.on('connect', (data) => {
      client.emit('bearer', TOKEN);
    });
    client.on('message', (data) => {
      console.log(data);
    });
    client.on('error', (data) => {
      console.log(data);
    });
    client.on('bearer', (data) => {
      console.log(data);
      done();
    });
  });


  it('should connect second instance', (done) => {
    clientTaker = io.connect(URL, OPTIONS);
    clientTaker.on('connect', (data) => {
      clientTaker.emit('bearer', TOKEN2);
    });
    clientTaker.on('message', (data) => {
      console.log(data);
    });
    clientTaker.on('error', (data) => {
      console.log(data);
    });
    clientTaker.on('bearer', (data) => {
      console.log(data);
      done();
    });
  });

  it('message should be sent by taker', (done) => {
    clientTaker.emit('message', {to: ID, message: 'asdasdasd'}, function(data){
      data.statusCode.should.equal(200);
      done();
    });
  });


  after(async function(){
    return await fake.removeFakes();
  });
});