import {User} from '../../src/models/index';
import jwt from 'jsonwebtoken';
import supertest from 'supertest-as-promised';
const request = supertest(global.Promise)('http://localhost:7070/api/user');

// testtt
const fakeUser = {
  phone: '13788888887',
  password: 'testtt',
  username: 'xiaobai',
  signature: 'xiaoxiaoxiao'
};

const fakeUserTaker = {
  phone: '13788888888',
  password: 'testtt',
  username: 'dabai',
  signature: 'dadadadada'
};

const realpassword = '$2a$10$lpgge/RMhYhX25f5pqPhSO5wBOD/mO0I40MmyqpK7d51znOxPvk/W';

// return a promise
export async function createFake() {
  let user = new User(fakeUser);
  const result = await user.save();
  const res = await request
    .post('/login')
    .send({
      phone: fakeUser.phone,
      password: 'testtt'
    });
  return res.body.token;
}

export async function createFakeWithId() {
  let user = new User(fakeUser);
  const result = await user.save();
  const res = await request
    .post('/login')
    .send({
      phone: fakeUser.phone,
      password: 'testtt'
    });
  return {
    token: res.body.token,
    id: res.body.data._id
  };
}
export async function createFakeTakerWithId() {
  let user = new User(fakeUserTaker);
  const result = await user.save();
  const res = await request
    .post('/login')
    .send({
      phone: fakeUserTaker.phone,
      password: 'testtt'
    });
  return {
    token: res.body.token,
    id: res.body.data._id
  };
}



export async function createFakeTaker() {
  let user = new User(fakeUserTaker);
  const result = await user.save();
  const res = await request
    .post('/login')
    .send({
      phone: fakeUserTaker.phone,
      password: 'testtt'
    });
  return res.body.token;
}

export async function removeFakes() {
  await User.remove({phone: fakeUser.phone});
  await User.remove({phone: fakeUserTaker.phone});
}

export const {phone} = fakeUser;