import debugFunc from 'debug';
const debug = debugFunc('controllers:misc');
import Errors from 'throw.js';
import nodemailer from 'nodemailer';
import smtpTransport from 'nodemailer-smtp-transport';
import * as check from '../utils/check';
import wrap from '../utils/wrap';
import {User, Sms, Task, Post, Vote, Pollen} from '../models/index';



export const transporter = nodemailer.createTransport(smtpTransport({
  port: 465,
  secure: true,
  host: 'smtp.mxhichina.com',
  auth: {
    user: 'noreply@taskbee.cn',
    pass: '7UHVW$bj3Rs7v@K4V$pvAYhnab4B0RQF'
  }
}));


// 取消收藏任务
export const report = wrap(async function report(req, res, next) {
  debug("report");
  const {type, itemId, message} = req.body;
  const userId = req.user.id;

  let item;
  let mailOptions;

  const user = await User.findById(userId, {phone: true, username: true}).exec();
  switch(type) {
    case 0: // 花粉
      item = await Post.findById(postId, {content: true}).exec();
      if (!item) {
        return next(new Errors.notAcceptable('花粉不存在'));
      }
      mailOptions = {
        from: 'noreply@taskbee.cn',
        to: 'xiaobu@taskbee.cn',
        subject: '［举报］花粉',
        text: message + '/' + user.username + ' / ' + user.phone + ' / ' + item.content + ' / ' + item._id,
      };
      break;
    case 1: // 任务
      item = await Task.findById(itemId, {description: true}).exec();
      if (!item) {
        return next(new Errors.notAcceptable('任务不存在'));
      }
      mailOptions = {
        from: 'noreply@taskbee.cn',
        to: 'xiaobu@taskbee.cn',
        subject: '［举报］任务',
        text: message + '/' + user.username + ' / ' + user.phone + ' / ' + item.description + ' / ' + item._id,
      };
      break;
    case 2: // 用户
      item = await User.findById(itemId, {username: true, signature: true, avatar: true}).exec();
      if (!item) {
        return next(new Errors.notAcceptable('用户不存在'));
      }
      mailOptions = {
        from: 'noreply@taskbee.cn',
        to: 'xiaobu@taskbee.cn',
        subject: '［举报］用户',
        text: message + '/' + user.username + ' / ' + user.phone + ' / ' + item.username + ' / ' + item.signature + ' / ' + item.avatar + ' / ' + item._id,
      };
      break;
    default:
      return next(new Errors.notAcceptable('举报类型错误'));
      break;
  }


  transporter.sendMail(mailOptions, function mailBack(error) {
    if (error) {
      debug(error);
      console.log('[NEW EVENT] EMAIL SEND ERROR' );
    }
  });
  // 返回部分数据
  res.json({data: true});

});

export function feedbackFunc(req, res, next) {
  debug(req.body);
  debug(req.user);
  const {email, feedback} = req.body;
  if (!check.feedback(feedback)) {
    return next(new Errors.notAcceptable('内容不合适', 'feedback'));
  }
  if (req.user && req.user.id) {
    User.findById(req.user.id, {phone: true, username: true, realname: true}).lean().exec(function(err, user) {
      if (err) return next(new Errors.serviceUnavailable('系统错误，请加蜂房交流QQ群：478227215'));
      const mailOptions = {
        from: 'noreply@taskbee.cn',
        to: 'xiaobu@taskbee.cn',
        subject: '蜂房用户反馈，请另起邮件回复',
        text: `邮箱：${email}
手机：${user.phone}
用户名： ${user.username}
真实姓名： ${user.realname}
反馈：${feedback}`,
      };
      transporter.sendMail(mailOptions, function mailBack(error) {
        if (error) {
          debug(error);
          return next(new Errors.serviceUnavailable('发送失败，请稍后再试，或加蜂房交流QQ群：478227215'));
        }
        res.json({data: true});
      });
    });
  } else {
    const mailOptions = {
      from: 'noreply@taskbee.cn',
      to: 'xiaobu@taskbee.cn',
      subject: '蜂房用户反馈，请另起邮件回复',
      text: email + ' / ' + feedback,
    };
    transporter.sendMail(mailOptions, function mailBack(error) {
      if (error) {
        debug(error);
        return next(new Errors.serviceUnavailable('发送失败，请稍后再试，或加蜂房交流QQ群：478227215'));
      }
      res.json({data: true});
    });
  }
}

