import debugFunc from 'debug';
import Errors from 'throw.js';
import wrap from '../utils/wrap';
import * as check from '../utils/check';
import {Redpocket, User} from '../models/index';
import sendSms, {hasRedPocket, hasRedPocketNew} from '../utils/sms';

const debug = debugFunc('controllers:redpocket');
const SECRET = 'VAkVfLXby85I9VVCmak66T/3B6yRgHuF7OQGv/LVFzn0Wovqn1IBSvze9c8Sx3LlKgzab6TsAfy40rUmsG9DTQ==';

export const openPocket = wrap(async function openPocket(req, res, next) {
  const {pocketId} = req.body;
  const userId = req.user.id;
  if (!check.objectId(pocketId)) {
    return next(new Errors.notAcceptable('红包不存在'));
  }
  const pocket = await Redpocket.findById(pocketId).lean().exec();
  if (!pocket) {
    return next(new Errors.notAcceptable('红包不存在'));
  }
  if (pocket.state > 0) {
    return next(new Errors.notAcceptable('该红包已经被兑换'));
  }
  if (pocket.limitPhone) {
    const user = await User.findById(userId, {phone: true}).lean().exec();
    if (pocket.limitPhone !== user.phone) {
      return next(new Errors.notAcceptable('这个红包不属于您'));
    }
  }
  await Redpocket.update({_id: pocket._id}, {$set: {user: userId, state: 1}});
  await User.update({_id: userId}, {$inc: {money: pocket.price}});
  res.json({data: pocket});
});

/*
  TEST
 */
export const createPocket = wrap(async function createPocket(req, res) {

  if (req.body && req.body.xiaobu === SECRET) {
    const {title, price} = req.body;
    const pocket = new Redpocket({title, price});
    await pocket.save();
    res.json({data: pocket._id});
    console.log('[RED POCKET] create', req.ip);
  } else {
    res.status(404).json({message: '这里什么都没有啦！'});
  }
});

export const createLimitPocket = wrap(async function createLimitPocket(req, res) {

  if (req.body && req.body.xiaobu === SECRET) {
    const {limitPhone} = req.body;
    if (limitPhone.length !== 11) {
      res.status(404).json({message: '这里什么都没有啦！'});
    }
    const pocket = new Redpocket({title: '感谢您的反馈，欢迎您继续支持', price: 3, limitPhone});
    await pocket.save();
    const user = await User.findOne({phone: limitPhone}, {phone: true, username: true}).lean().exec();
    let toSend;
    if (user) {
      toSend = hasRedPocket(user.phone, user.username, pocket._id);
    } else {
      console.log('NOT REGISTERED');
      toSend = hasRedPocketNew(limitPhone, pocket._id);
    }
    const result = await sendSms(toSend);
    debug(result.data.open_sms_sendmsg_response);
    if (result.data.error_response) {
      console.log('[SMS ERROR]', result.data.error_response);
    }
    res.json({data: pocket._id});

    console.log('[RED POCKET] create', req.ip);
  } else {
    res.status(404).json({message: '这里什么都没有啦！'});
  }
});

export const getAllPockets = wrap(async function getAllPockets(req, res) {
  if (req.body && req.body.xiaobu === SECRET) {
    const pockets = await Redpocket.find();
    res.json({data: pockets});
    console.log('[RED POCKET] find', req.ip);
  } else {
    res.status(404).json({message: '这里什么都没有啦！'});
  }
});
