import debugFunc from 'debug';
import Errors from 'throw.js';
import wrap from '../utils/wrap';
import * as check from '../utils/check';
import {Redpocket, User, Task} from '../models/index';
import sendSms, {hasRedPocket, hasRedPocketNew} from '../utils/sms';

const debug = debugFunc('controllers:event');
const SECRET = 'VAkVfLXby85I9VVCmak66T/3B6yRgHuF7OQGv/LVFzn0Wovqn1IBSvze9c8Sx3LlKgzab6TsAfy40rUmsG9DTQ==';

export const giveEvent = wrap(async function giveEvent(req, res) {
  if (req.body && req.body.xiaobu === SECRET && req.body.phone) {
    const {phone} = req.body;
    const result = await User.update({phone}, {$set: {accountType: 1}});
    res.json({data: phone});
    console.log('[GIVE EVENT USER] create', req.ip);
  } else {
    res.status(404).json({message: '这里什么都没有啦！'});
  }
});


export const confirmTask = wrap(async function confirmTask(req, res) {
  if (req.body && req.body.xiaobu === SECRET && req.body.taskId) {
    const {taskId} = req.body;
    const result = await Task.update({_id: taskId}, {$set: {state: 0}});
    res.json({data: taskId});
    console.log('[EVENT CONFIRM]', req.ip);
  } else {
    res.status(404).json({message: '这里什么都没有啦！'});
  }
});

export const cancelTask = wrap(async function cancelTask(req, res, next) {
  debug("CANCEL TASK PUB");
  if (req.body && req.body.xiaobu === SECRET && req.body.taskId) {
    const {taskId} = req.body;
    const task = await Task.findById(taskId, {state: true, tasker: true, publisher: true, reward: true}).exec();
    if (!task) {
      return next(new Errors.notAcceptable('无法找到任务'));
    }
    // 发布者取消
    task.state = 5;
    task.finishTime = Date.now();
    await task.save();
    // 任务被取消，更新接受者和发布者任务列表
    const user = await User.findById(task.publisher, {username: true}).lean().exec();
    if (task.tasker) {
      const taskerId = task.tasker.toString();
      const sysMessage = new SysMessage({
        to: task.tasker,
        href: taskId,
        message: '管理员取消了一个您接手的任务',
        type: 'task',
      });
      if (isOnline(taskerId)) {
        sysMessage.hasRead = true;
        sendSysMessage(taskerId, sysMessage);
      } else {
        // 提醒任务发布者
        const tasker = await User.findById(task.tasker, {pushId: true}).lean().exec();
        sendNoti(tasker.pushId, sysMessage.message);
      }
      sysMessage.save();
      User.update({_id: task.tasker}, {$pull: {taskTaken: taskId}}).exec();
      // 钱
      User.update({_id: task.publisher}, {$pull: {taskPublish: taskId}, $inc: {score: -6, money: task.reward}}).exec();
    } else {
      User.update({_id: task.publisher}, {$pull: {taskPublish: taskId}, $inc: {money: task.reward}}).exec();
    }
  } else {
    res.status(404).json({message: '这里什么都没有啦！'});
  }
  res.json({data: 'ok'});
});
