import {Order, Withdraw, User} from '../models/index';
import debugFunc from 'debug';
import Errors from 'throw.js';
import wrap from '../utils/wrap';
import * as check from '../utils/check';
import {sign, mergeToStringWithoutSort} from '../utils/agaySign';
import {transporter} from './misc';

const debug = debugFunc('controllers:order');

let NOTIFY_URL;
let RETURN_URL;

if (process.env.NODE_ENV === 'production') {
  NOTIFY_URL = 'http://aligay.taskbee.cn/agay/notify';
  RETURN_URL = 'https://taskbee.cn/me/wallet';
} else {
  NOTIFY_URL = 'http://agay.taskbee.cn/agay/notify';
  RETURN_URL = 'http://localhost:8080/me/wallet';
}

// 务必保证前后端同步
const AVAILABLE_ORDERS = [
  {
    title: '蜂房-给钱包存钱 - 1元尝鲜',
    price: 1,
  },
  {
    title: '蜂房-给钱包存钱 - 10元',
    price: 10,
  },
  {
    title: '蜂房-给钱包存钱 - 30元',
    price: 30,
  },
  {
    title: '蜂房-给钱包存钱 - 任性50元',
    price: 50,
  },
  {
    title: '蜂房-给钱包存钱 - 小土豪100元',
    price: 100,
  },
  {
    title: '蜂房-给钱包存钱 - 大土豪300元',
    price: 300,
  }

];

// 处理用户的充值订单
// order type: 1
export const startOrder = wrap(async function startOrder(req, res, next) {
  const {orderId} = req.body;
  const userId = req.user.id;
  const order = AVAILABLE_ORDERS[orderId];

  if (order === undefined) {
    return (next(new Errors.notAcceptable('请选择正确的单号')));
  }
  order.user = userId;
  const newOrder = new Order(order);
  await newOrder.save();
  console.log('[order]NEW', newOrder);
  res.json({data: newOrder});
});

export const getOrderDetail = wrap(async function orderDetail(req, res, next) {
  const {orderId} = req.query;
  const userId = req.user.id;
  // 创建订单属性
  const newOrder = await Order.findOne({_id: orderId, user: userId}).lean().exec();
  if (!newOrder) {
    return next(new Errors.notAcceptable('找不到订单'));
  }
  if (newOrder.state < 3) {
    const feedId = sign({
      service: 'create_partner_trade_by_buyer',
      partner: '2088112817052311',
      _input_charset: 'utf-8',
      notify_url: NOTIFY_URL,
      return_url: RETURN_URL,
      out_trade_no: newOrder._id, // 订单号，mongodb对应id
      subject: newOrder.title,
      payment_type: '1',
      logistics_type: 'DIRECT',
      logistics_fee: '0',
      logistics_payment: 'SELLER_PAY',
      price: newOrder.price,
      quantity: 1,
      seller_email: 'chnxiaobu@gmail.com',
      body: '感谢您使用蜂房，如有任何意见或建议，欢迎联系xiaobu@taskbee.cn',
      show_url: 'https://taskbee.cn',
      discount: 0,
      receive_name: '蜂房用户',
      receive_address: '出门左转蜂房',
      receive_zip: '23333',
      receive_mobile: '10000000000',
    });
    newOrder.link = 'https://mapi.alipay.com/gateway.do?' + mergeToStringWithoutSort(feedId);
  }
  res.json({data: newOrder,});
});

export const getOrders = wrap(async function getOrders(req, res) {
  const {id} = req.user;
  const orders = await Order.find({user: id}, {title: false, user: false}).sort({_id: -1}).lean().exec();
  res.json({data: orders});
});

export const getWithdraws = wrap(async function getWithdraws(req, res) {
  const {id} = req.user;
  const orders = await Withdraw.find({user: id}).sort({_id: -1}).lean().exec();
  res.json({data: orders});
});

// 记录用户的提款请求
export const withdraw = wrap(async function withdraw(req, res, next) {
  const {email, realname} = req.body;
  const money = parseInt(req.body.money, 10);
  const userId = req.user.id;
  const user = await User.findById(userId, {money: true, username: true, phone: true}).lean().exec();
  if (money < 10 || money > user.money) {
    return next(new Errors.notAcceptable('金额应大于10且不超过您的余额', 'money'));
  }
  if (!email) {
    return next(new Errors.notAcceptable('请输入支付宝账户', 'email'));
  }
  if (!realname) {
    return next(new Errors.notAcceptable('请输入真名', 'realname'));
  }
  const newWithdraw = new Withdraw({
    user: user._id,
    price: money,
    realname,
    email,
  });
  // 先扣钱
  await User.update({_id: user._id}, {$inc: {money: -money}});
  await newWithdraw.save();
  res.json({data: true});
  // 给我发一封男人的邮件
  const mailOptions = {
    from: 'noreply@taskbee.cn',
    to: 'xiaobu@taskbee.cn',
    subject: '蜂房提款请求',
    text: `支付宝：${email}
金额：${money}
真名：${realname}
用户昵称：${user.username}
电话：${user.phone}
    `,
  };
  transporter.sendMail(mailOptions, function sendMoney(error) {
    if (error) {
      console.log('[EMAIL ERROR] ' + error);
      console.log(mailOptions.text);
    }
  });
});


// 处理用户的充值订单
// order type: 1
/*
export const test = wrap(async function newTag(req, res, next) {
  console.log('run');
  const {orderId, email} = req.query;
  const order = AVAILABLE_ORDERS[orderId];

  // 创建订单属性
  const feedId = sign({
    service: 'create_partner_trade_by_buyer',
    partner: '2088112817052311',
    _input_charset: 'utf-8',
    notify_url: 'http://agay.taskbee.cn/agay/notify',
    return_url: 'https://taskbee.cn/me/wallet',
    out_trade_no: 'testtesttrade' + orderId, // 订单号，mongodb对应id
    subject: 'TEST ORDER',
    payment_type: '1',
    logistics_type: 'DIRECT',
    logistics_fee: '0',
    logistics_payment: 'SELLER_PAY',
    price: 0.01,
    quantity: 1,
    seller_email: 'chnxiaobu@gmail.com',
    body: '感谢您使用蜂房，如有任何意见或建议，欢迎联系xiaobu@taskbee.cn',
    show_url: 'https://taskbee.cn',
    discount: 0,
    receive_name: '蜂房用户',
    receive_address: '出门左转蜂房',
    receive_zip: '23333',
    receive_mobile: '10000000000',
  });

  const finalLink = 'https://mapi.alipay.com/gateway.do?' + mergeToStringWithoutSort(feedId);
  res.type('text/html');
  res.end(`<a href=${finalLink}>test</a>`);
});
*/
