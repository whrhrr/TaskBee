import {Message} from '../models/index';
import debugFunc from 'debug';
import Errors from 'throw.js';
import wrap from '../utils/wrap';
import * as check from '../utils/check';

const debug = debugFunc('controllers:message');

export const send = wrap(async function send(req, res, next) {
  const {to, message} = req.body;
  if (!to) {
    return next(new Errors.notAcceptable('请指定发信人'));
  }
  if (to === req.user) {
    return next(new Errors.notAcceptable('不能发给自己'));
  }
  if (!check.message(message)) {
    return next(new Errors.notAcceptable('消息不合适'));
  }
  const message = new Message({
    from: req.user,
    to,
    message
  });
  const saved = await message.save();
  res.json({data: saved});
});

export const getNew = wrap(async function getNew(req, res, next) {
  const id = req.user;
  const messages = Message.update({
    $or: [{to: req.user}, {from: req.user}],
    {hasRead: true}
    },
    {$set: {hasRead: false}}).exec();
  res.json({data: messages});
});