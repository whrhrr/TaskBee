import {Tag} from '../models/index';
import debugFunc from 'debug';
import Errors from 'throw.js';
import wrap from '../utils/wrap';
import * as check from '../utils/check';

const debug = debugFunc('controllers:tag');
/*
  [TODO]: 测试
 */
/*
  创建新标签
 */
export const newTag = wrap(async function newTag(req, res, next) {
  let {name} = req.body;
  name = name.trim();
  if (!check.tagName(name)) {
    return next(new Errors.notAcceptable('标签名不合适'));
  }
  // 不存在则创建，存在则直接返回标签
  let tag = await Tag.findOne({name}).select({name: 1}).exec();
  if (!tag) {
    tag = new Tag({name});
    await tag.save();
  }
  res.json({data: tag});
});

// 获取前50个标签
export const getTags = wrap(async function getTags(req, res) {
  const tags = await Tag.find({}).select({name: true}).limit(50).sort({count: -1}).lean().exec();
  res.json({data: tags});
});


// 再获取余下所有的。。标签
export const getTagsMore = wrap(async function getTagsMore(req, res) {
  const tags = await Tag.find({}).skip(50).sort({count: -1}).exec();
  res.json({data: tags});
});
