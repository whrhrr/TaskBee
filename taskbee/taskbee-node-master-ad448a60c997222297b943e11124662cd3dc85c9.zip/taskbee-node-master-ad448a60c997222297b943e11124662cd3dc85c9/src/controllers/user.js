import {User, Sms, Task, Vote, Pollen, SysMessage} from '../models/index';
import debugFunc from 'debug';
import Errors from 'throw.js';
import * as check from '../utils/check';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import wrap from '../utils/wrap';
import sendSms, {sendNoti, sendNotiWithFallback, verifyStr, takeTaskStr} from '../utils/sms';
import easyImage from 'easyimage';
import fs from 'fs';
import {SECRET, HOST_URL, TOKEN_EXPIRE} from '../config';
import {projectionBrief} from '../models/task';
import {projectionBriefUser, projectionVeryBriefUser, projectionExcludeUser} from '../models/user';
import {projectionBriefPost} from '../models/post';
import qiniu from 'qiniu';
import {validateHeader} from '../utils/qiniusign';
import {isOnline, sendStatus, sendSysMessage} from '../socket';


// async export 还不支持
const {default: determineFav} = require('../utils/dataProcessor');


const debug = debugFunc('controllers:user');


const SMS_MIN_WAIT = 1000 * 90;
const SMS_MAX_DURATION = 1000 * 60 * 15;
const SMS_COOL_DOWN = 1000 * 60 * 60 * 12;
const SMS_MAX_SEND = 4;

// 恶心的解决2次请求问题方法，一个非常小的缓存
const loadTmp = new Map();
setInterval(function clearTmp() {
  if (loadTmp.size > 0) {
    loadTmp.delete(loadTmp.keys[0]);
  }
}, 50000);

function limitLength(map, length = 5) {
  if (map.size > length) {
    map.delete(map.keys[0]);
  }
}

export const setPushId = wrap(async function setPushId(req, res) {
  const userId = req.user.id;
  const {pushId} = req.body;
  debug('userId', userId);
  debug('pushId', pushId);
  await User.update({_id: userId}, {$set: {pushId}});
  res.json({data: true});
});

// 通过cookie载入用户的数据 (unsafe)
export const load = wrap(async function load(req, res, next) {
  /*
    这里需要进行发起者判断
    防止客户端恶意获取token内容
   */
  const bearer = req.cookies.Bearer;
  if (loadTmp.has(bearer)) {
    const value = loadTmp.get(bearer);
    if (value === 'ERROR') {
      return next(new Errors.unauthorized('请重新登录'));
    }
    res.type('json');
    res.end(value);
  } else {
    jwt.verify(bearer, SECRET, async function(err, decoded) {
      if (err) {
        loadTmp.set(bearer, 'ERROR');
        limitLength(loadTmp);
        return next(new Errors.unauthorized('请重新登录'));
      }
      debug('decoded', decoded);
      const id = decoded.id;
      const user = await User.findById(id, projectionExcludeUser).lean().exec();
      debug('complete');
      if (user) {
        // 设置新的token
        const token = jwt.sign({id: user._id}, SECRET, {expiresIn: TOKEN_EXPIRE});
        const value = JSON.stringify({token, data: user});
        res.type('json');
        res.end(value);
        loadTmp.set(bearer, value);
        limitLength(loadTmp);
      } else {
        return next(new Errors.unauthorized('请重新登录'));
      }
    });
  }
});

export const login = wrap(async function login(req, res, next) {
  debug('logining');
  debug(req.body);
  const {phone, password} = req.body;
  debug(phone, typeof phone);
  if (!check.phone(phone)) {
    return next(new Errors.notAcceptable('手机号不符合规范', 'phone'));
  }
  if (!check.password(password)) {
    return next(new Errors.notAcceptable('密码不合适', 'password'));
  }
  debug('password checked');
  let user = await User.findOne({phone}, {password: true}).exec();
  debug(user);
  if (!user) {
    return next(new Errors.unauthorized('用户不存在', 'phone'));
  }
  const match = await user.comparePassword(password);
  if (!match) {
    return next(new Errors.unauthorized('密码错误', 'password'));
  }
  user = await User.findById(user._id, projectionExcludeUser).lean().exec();
  // create and return jwt (is id sufficient?)
  const token = jwt.sign({id: user._id}, SECRET, {expiresIn: TOKEN_EXPIRE});
  res.cookie('Bearer', token, { expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14), httpOnly: true });
  res.json({token, data: user});
});


export const getCode = wrap(async function getCode(req, res, next) {
  debug('get sms code');
  const {phone, forget} = req.body;
  if (!check.phone(phone)) {
    return next(new Errors.notAcceptable('手机号不合适', 'phone'));
  }
  const isExistPhone = await User.count({phone}, {limit: 1}).exec();
  if (!forget && isExistPhone) {
    return next(new Errors.notAcceptable('该手机号已经注册', 'phone'));
  }
  if (forget && !isExistPhone) {
    return next(new Errors.notAcceptable('该手机号未注册', 'phone'));
  }
  let tmpSms;
  // 找到数据库中记录
  tmpSms = await Sms.findOne({phone}, {requestCount: false}).exec();
  const now = Date.now();
  if (tmpSms) {
    // 数据库中已经有记录
    if (now - tmpSms.lastAt.getTime() < SMS_MIN_WAIT) {
      return next(new Errors.forbidden('请稍后再试', 'verify'));
    }
    if (tmpSms.sendCount > SMS_MAX_SEND) {
      // 最大发送记录
      if (now - tmpSms.genAt.getTime() > SMS_COOL_DOWN) {
        // 过热冷却，生成全新注册码
        tmpSms.sendCount = 0;
        tmpSms.requestCount = 0;
      }
      else return next(new Errors.forbidden('已达半日上限', 'verify'));
    }
  } else {
    tmpSms = new Sms({phone});
  }
  // 生成新验证码
  tmpSms.code = Sms.genCode();
  tmpSms.genAt = now;
  console.log('sms', req.ip);
  console.log(tmpSms.code);
  if (process.env.NODE_ENV !== 'production') {
    tmpSms.lastAt = now;
    tmpSms.sendCount++;
    await tmpSms.save();
    return res.json({data: true});
  }
  const result = await sendSms(verifyStr(phone, tmpSms.code, req.ip));
  if (result.data.open_sms_sendmsg_response && result.data.open_sms_sendmsg_response.result.code !== 1) {
    return next(new Errors.serviceUnavailable('发送失败，请稍后再试', 'verify'));
  }

  // 发送验证码

  res.json({data: true});
  tmpSms.lastAt = now;
  tmpSms.sendCount++;
  await tmpSms.save();
  debug(tmpSms.code);
});

export const testCode = wrap(async function getCode(req, res, next) {
  debug('get sms code');
  const {phone, forget} = req.query;
  let result = await sendSms(verifyStr(phone, '123123'));
  result = await sendSms(takeTaskStr(phone));
  debug(result.data);
  if (result.data.error_response) {
    return next(new Errors.serviceUnavailable(result.data.msg, result.data.error));
  }
  res.json({data: true});
});


export const verifyCode = wrap(async function verifyCode(req, res, next) {
  debug('verifying');
  const {phone, code} = req.body;
  if (!check.code(code)) {
    return next(new Errors.notAcceptable('验证码不合适 ', 'verify'));
  }
  const tmpSms = await Sms.findOne({phone}, {code: true, lastAt: true, requestCount: true}).exec();
  if (!tmpSms) {
    return next(new Errors.notAcceptable('请先获取验证码 ', 'verify'));
  }
  if (tmpSms.requestCount > 8){
    // 防止恶意注, 最多请求10次
    return next(new Errors.unauthorized('请一天后再试 ', 'verify'));
  }
  if (!tmpSms.code) {
    return next(new Errors.notAcceptable('请先获取验证码 ', 'verify'));
  }
  if (Date.now() - tmpSms.lastAt.getTime() > SMS_MAX_DURATION) {
    return next(new Errors.notAcceptable('请重新获取验证码', 'verify'));
  }
  if (code !== tmpSms.code) {
    // 到这里次数＋1
    tmpSms.requestCount++;
    await tmpSms.save();
    if (tmpSms.requestCount > 6){
      // 提醒防止被禁止24小时
      return next(new Errors.unauthorized('验证码错误, 即将锁定', 'verify'));
    }
    return next(new Errors.unauthorized('验证码错误 ', 'verify'));
  }
  const token = jwt.sign({phone, code: tmpSms.code}, SECRET);
  debug("token got");
  res.json({token});
});


export const register = wrap(async function register(req, res, next) {
  debug("registering");
  if (!req.user) {
    return next(new Errors.unauthorized('无效的验证码', 'verify'));
  }
  const {phone, code} = req.user;
  const tmpSms = await Sms.findOne({phone}, {code}).exec();
  if (!tmpSms || !tmpSms.code) {
    return next(new Errors.notAcceptable('请先获取验证码'));
  }
  if (code !== tmpSms.code) {
    return next(new Errors.unauthorized('验证码错误'));
  }
  // 验证码用过一次不能再用了!
  tmpSms.code = Sms.genCode();
  await tmpSms.save();

  const {username, password} = req.body;
  let {gender} = req.body;
  if (!check.username(username)) {
    return next(new Errors.notAcceptable('昵称不合适', 'username'));
  }
  if (!check.password(password)) {
    return next(new Errors.notAcceptable('密码不合适', 'password'));
  }
  gender = parseInt(gender, 10);
  if (!check.gender(gender)) {
    return next(new Errors.notAcceptable('性别不合适', 'gender'));
  }
  const isExistUsername = await User.count({username}, {limit: 1}).exec();
  if (isExistUsername) {
    return next(new Errors.notAcceptable('昵称已被占用', 'username'));
  }
  let user = new User({phone, password, username, gender});
  debug("user save");
  await user.save();
  debug("user save complete");
  const token = jwt.sign({id: user._id}, SECRET, {expiresIn: TOKEN_EXPIRE});
  debug("token got");
  user = user.toObject();
  delete user.password;
  res.cookie('Bearer', token, { expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14), httpOnly: true });
  res.json({token, data: user});
});

export const newPassword = wrap(async function newPassword(req, res, next) {
  debug("new password");
  if (!req.user) {
    return next(new Errors.unauthorized('无效的验证码'));
  }
  const {password} = req.body;
  const {phone, code} = req.user;

  if (!check.password(password)) {
    return next(new Errors.notAcceptable('密码不合适', 'password'));
  }
  const tmpSms = await Sms.findOne({phone}, {code}).exec();
  if (!tmpSms || !tmpSms.code) {
    return next(new Errors.notAcceptable('请先获取验证码 '));
  }
  if (code !== tmpSms.code) {
    return next(new Errors.unauthorized('验证码错误 '));
  }
  // 验证码用过一次不能再用了!
  tmpSms.code = Sms.genCode();
  await tmpSms.save();
  const user = await User.findOne({phone}, {_id: true}).exec();
  if (!user) {
    return next(new Errors.notAcceptable('用户不存在 '));
  }
  user.password = password;
  await user.save();
  res.json({data: true});
});


export const test = wrap(async function test(req, res, next) {
  debug("test");
  res.json({lalal:'ttt'});
});


export const upload = multer({
  dest: './tmp/avatars',
  limits: {
    fileSize: 1024 * 15 * 1024
  },
  fileFilter: (req, file, cb) => {
    const mime = file.mimetype;
    cb(null, mime === 'image/jpeg' || mime === 'image/png');
  }
}).single('avatar');


export const uploadAvatar = wrap(async function uploadAvatar(req, res, next) {
  const meId = req.user.id;
  const putPolicy = new qiniu.rs.PutPolicy('heartrunner');
  putPolicy.callbackUrl = HOST_URL + '/api/user/notify/' + meId;
  putPolicy.callbackBody = 'key=$(key)&width=$(imageInfo.width)&height=$(imageInfo.height)';
  res.json({data: putPolicy.token()});
});

// 提醒
export const notify = wrap(async function notify(req, res, next) {
  const {authorization} = req.headers;
  const {userId} = req.params;
  if (!validateHeader(authorization, req.path, req.rawBody)) {
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  const {key} = req.body;
  const user = await User.findById(userId, {avatar: true}).lean().exec();
  if (!user) {
    debug('没找到');
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  if (!user.avatar) {
    // 如果没有过头像
    await User.update({_id: user._id}, {$set: {avatar: key}, $inc: {score: 20}});
  } else {
    await User.update({_id: user._id}, {$set: {avatar: key}});
  }
  res.json({data: key});
});

/* 老得上传
export const uploadAvatar = wrap(async function uploadAvatar(req, res, next) {
  debug('uploadAvatar');
  debug(req.file);
  debug(req.files);
  if (req.file) {
    const {path} = req.file;
    const {id} = req.user;
    const avatarPath = '/public/avatars/' + id + '.jpeg';
    // 转换成jpeg
    let newfile = await easyImage.resize({
      src: path,
      dst: './public/avatars/' + id + '.jpeg',
      width: 128,
      height: 128,
      x: 0,
      y: 0,
      quality: 92,
      ignoreAspectRatio: true
    });

    debug(newfile);
    debug(req.user);
    // [TODO 确定是否需要findById]
    const user = await User.findByIdAndUpdate(req.user.id, {$set: {avatar: avatarPath}}, {select: {avatar: true}}).exec();
    debug(user);
    res.json({data: avatarPath});
    // 删除未处理文件
    fs.unlink(path);
  } else {
    return next(new Errors.notAcceptable('图片格式不合适'));
  }
});
*/

export const changeSig = wrap(async function changeSig(req, res, next) {
  let {signature} = req.body;
  if (signature) signature = signature.replace(/[\r\n]/g, '');
  if (!check.signature(signature)) {
    return next(new Errors.notAcceptable('签名不合适', 'input'));
  }
  await User.update({_id: req.user.id}, {$set: {signature}}).exec();
  res.json({data: signature});
});

/*
  [TODO] 测试
 */
export const changeName = wrap(async function changeName(req, res, next) {
  let {realname} = req.body;
  if (realname) realname = realname.replace(/[\r\n]/g, '');
  if (!check.username(realname)) {
    return next(new Errors.notAcceptable('姓名不合适', 'input'));
  }
  await User.update({_id: req.user.id}, {$set: {realname}}).exec();
  res.json({data: realname});
});

/*
  [TODO] 测试
 */
export const changeGender = wrap(async function changeGender(req, res, next) {
  let {gender} = req.body;
  gender = parseInt(gender, 10);
  if (!check.gender(gender)) {
    return next(new Errors.notAcceptable('性别不合适', 'input'));
  }
  await User.update({_id: req.user.id}, {$set: {gender}}).exec();
  res.json({data: gender});
});

/*
  [TODO] 测试
 */
/*
export const changeSchool = wrap(async function changeSchool(req, res, next) {
  let {schoolId} = req.body;
  schoolId = parseInt(schoolId, 10);
  debug('schoolId', schoolId);
  if (!check.schoolId(schoolId)) {
    return next(new Errors.notAcceptable('校区不合适', 'input'));
  }
  await User.update({_id: req.user.id}, {$set: {schoolId}}).exec();
  const token = jwt.sign({id: req.user.id, schoolId: schoolId}, SECRET, {expiresIn: TOKEN_EXPIRE});
  res.cookie('Bearer', token, { expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14), httpOnly: true });
  res.json({data: schoolId, token});
});
*/

/*
  [TODO] 测试
 */
// Date
// reminder it is mutating!
function isToday(date) {
  const tmp = new Date(date);
  return tmp.setHours(0, 0, 0, 0) === (new Date()).setHours(0, 0, 0, 0);
}
function isYesterday(date) {
  const tmp = new Date(date);
  const da = new Date();
  da.setDate(da.getDate() - 1);
  return tmp.setHours(0, 0, 0, 0) === da.setHours(0, 0, 0, 0);
}
export const sign = wrap(async function sign(req, res, ) {
  const {id} = req.user;
  const user = await User.findById(id, {signTime: true}).lean().exec();
  if (user.signTime && isToday(user.signTime)) {
    // 今天已经签到过了，不能再签，前端拿回家重新显示
    return res.json({data: true});
  }
  const updateQuery = {
    $set: {signTime: new Date()},
    $inc: {score: 1},
  };
  debug(user.signTime);
  if (user.signTime && isYesterday(user.signTime)) {
    // 连续签到
    updateQuery.$inc.signCount = 1;
  } else {
    debug('not yesterday');
    updateQuery.$set.signCount = 1;
  }
  debug(updateQuery);
  await User.update({_id: id}, updateQuery).exec();
  res.json({data: true});
});


/*
  [TODO] 测试，socketio
 */
export function logout(req, res) {
  // 登出
  if (req.user) {
    const userId = req.user.id;
    User.update({_id: userId}, {$set: {pushId: null}}).exec();
  }
  res.clearCookie('Bearer');
  res.json({data: true});
}

/*
  getters
 */

// 获取用户信息
export const getUsers = wrap(async function getUsers(req, res, next) {
  const {users} = req.query;
  if (!Array.isArray(users)) {
    return next(new Errors.notAcceptable('仅接受数组'));
  }
  const feteched = await User.find({
    '_id': { $in: users}
  }, {avatar: true, username: true}).lean().exec();
  res.json({data: feteched});
});

// 获取用户信息 (用户名，头像)
export const getOneUser = wrap(async function getOneUser(req, res, next) {
  const {user} = req.query;
  if (!check.objectId(user)) {
    return next(new Errors.notAcceptable('无效的ID'));
  }
  const fetched = await User.findOne({
    '_id': user
  }, {avatar: true, username: true, gender: true,}).lean().exec();
  res.json({data: fetched});
});

// 获取用户详细信息（用户名，头像，性别，签名，蜂蜜，任务数量, 用户评价
export const getUserDetail = wrap(async function getUserDetail(req, res, next) {
  const {user} = req.query;
  if (!check.objectId(user)) {
    return next(new Errors.notAcceptable('无效的ID'));
  }

  const fetched = await Promise.all([
    User.findOne({
      _id: user
    }, {accountType: 1, voteScore: true, voteCount: true, avatar: true, username: true, gender: true, signature: true, score: true, countTotalTaken: true, countTotalPublish: true}).lean().exec(),
    Vote.find({user}).limit(15).sort({_id: -1}).lean().populate('from', projectionVeryBriefUser).exec(),
  ]);
  if (fetched[0] && req.user && req.user.id !== fetched[0]._id) {
    debug('liked or friended');
    const meId = req.user.id;
    // 已经登陆判断是否被用户喜欢
    const liked = await User.find({
      _id: fetched[0]._id, liked: meId
    }).limit(1).count().exec();
    const friended = await User.find({
      _id: meId, friends: fetched[0]._id
    }).limit(1).count().exec();
    fetched[0].liked = liked;
    fetched[0].friended = friended;
  }
  res.json({data: fetched[0], votes: fetched[1]});
});


// 获得我正在进行的任务
export const getScore = wrap(async function getTasks(req, res) {
  const userId = req.user.id;
  debug('userId', userId);
  const user = await User.findById(userId, {score: true, money: true}).lean().exec();
  res.json({data: user});
});

// 获得我正在进行的任务
export const getTasks = wrap(async function getTasks(req, res) {
  const userId = req.user.id;
  debug('userId', userId);
  const user = await User.findById(userId, {taskPublish: true, taskTaken: true}).lean()
    .populate({
      path: 'taskPublish', select: projectionBrief,
      populate: { path: 'publisher', select: projectionBriefUser, model: 'User'}
    }).populate({
      path: 'taskTaken',
      select: projectionBrief,
      populate: { path: 'publisher', select: projectionBriefUser, model: 'User'}
    }).exec();
  // mutate
  await determineFav(user.taskPublish, userId);
  await determineFav(user.taskTaken, userId);
  res.json({data: user});
});

export const getTasksFav = wrap(async function getTasksFav(req, res, next) {
  const userId = req.user.id;
  const {start} = req.query;
  const span = parseInt(req.query.span, 10);
  if (!check.positiveInteger(span)) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  const user = await User.findById(userId, {taskFav: true}).lean().exec();
  debug(user);
  const query = {
    _id: {$in: user.taskFav},
  };
  if (start) {
    query._id.$lt = start;
  }
  debug(query);
  const result = await Task.find(query, projectionBrief).limit(span).sort({_id: -1}).lean()
  .populate('publisher', projectionBriefUser).exec();
  debug(result);
  // 既然都是fav了， 还不快点加个❤️
  result.forEach( task => task.faved = true);
  res.json({data: {taskFav: result}});
});

const needCanVote = {
  ...projectionBrief,
  canVote: true,
};
export const getTasksHistory = wrap(async function getTasksHistory(req, res) {
  // 从task列表中读取历史记录
  const userId = req.user.id;
  const {start} = req.query;
  const span = parseInt(req.query.span, 10);
  if (!check.positiveInteger(span)) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  const query = {state: {$gte: 3}, $or: [{tasker: userId}, {publisher: userId}]}; // 尚未完成
  if (start) {
    query._id = { $lt: start};
  }
  const result = await Task.find(query, needCanVote).limit(span).sort({_id: -1}).lean()
  .populate('publisher', projectionBriefUser).exec();
  // mutate
  await determineFav(result, userId);
  res.json({data: {taskHistory: result}} );
});

/*
  新蜂房 － 下方都没测试
 */

export const getMyPollens = wrap(async function getMyPollens(req, res) {
  // 从task列表中读取历史记录
  const userId = req.user.id;
  const {start} = req.query;
  const span = parseInt(req.query.span, 10);
  if (!check.positiveInteger(span)) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  const query = {from: userId}; // 尚未完成
  if (start) {
    query.createdAt = { $lt: start};
  }
  const pollens = await Pollen.find(query, {createdAt: true, type: true, postId: true, loc: true}).sort({createdAt: -1}).populate({path: 'from', select: projectionBriefUser, model: 'User'}).populate({path: 'postId',
    select: projectionBriefPost,
    populate: {path: 'from', select: projectionBriefUser, model: 'User'}
  }).limit(span).lean().exec();
  res.json({data: pollens});
});

export const like = wrap(async function like(req, res) {
  // 喜欢对面
  const {toLike} = req.body;
  const userId = req.user.id;
  const targetUser = await User.findById(toLike, {pushId: true, liked: true, username: true, friends: true}).lean().exec();
  if (!targetUser) {
    return next(new Errors.notAcceptable('用户不存在', 1));
  }
  if (targetUser.liked.indexOf(userId) < 0) {
    // 没有喜欢过，更新
    await User.update({_id: targetUser._id}, {$push: {liked: userId}, $inc: {likedCount: 1}});
    // 判断我是否被他喜欢
    const currentUser = await User.findById(userId, {pushId: true, liked: true, username: true}).lean().exec();
    if (!currentUser) return next(new Errors.notAcceptable('用户不存在', 1)); // wtf no user???
    if (currentUser.liked.indexOf(toLike) > -1) {
      // 我被对方喜欢
      if (targetUser.friends.indexOf(userId) === -1) {
        // 并且对方没有我的好友
        await Promise.all([
          User.update({_id: currentUser._id}, {$push: {friends: toLike}}),
          User.update({_id: targetUser._id}, {$push: {friends: userId}}),
        ]);
        const sysMessage2 = new SysMessage({
          to: targetUser._id,
          href: currentUser._id,
          type: 'friend',
          message: '您已经和' + currentUser.username + '成为好友',
        });
        if (isOnline(targetUser._id)) {
          sysMessage2.hasRead = true;
          sendSysMessage(targetUser._id, sysMessage2);
        } else {
          sendNoti(targetUser.pushId, sysMessage2.message);
        }
        sysMessage2.save();
      }

      return res.json({data: 'friend'});
    }
    res.json({data: true});
  } else {
    // 已经喜欢过，取消喜欢
    await User.update({_id: targetUser._id}, {$pull: {liked: userId}, $inc: {likedCount: -1}});
    res.json({data: false});
  }
});

// deprecated
export const unfriend = wrap(async function unfriend(req, res) {
  const {toUnfriend} = req.body;
  const userId = req.user.id;
  const targetUser = await User.findById(toUnfriend, {friends: true}).lean().exec();
  if (!targetUser) {
    return next(new Errors.notAcceptable('用户不存在', 1));
  }
  // 先不喜欢 再删除好友 防止出问题
  await User.update({_id: targetUser}, {$pull: {liked: userId}, $inc: {likedCount: -1}});
  await User.update({_id: userId}, {$pull: {friends: toUnfriend}});
  res.json({data: true});
});

// 获取我的好友
export const getFriends = wrap(async function getFriends(req, res, next) {
  const meId = req.user.id;
  const me = await User.findOne({_id: meId}, {friends: true}).populate('friends', projectionBriefUser).lean().exec();
  res.json({data: me.friends});
});
