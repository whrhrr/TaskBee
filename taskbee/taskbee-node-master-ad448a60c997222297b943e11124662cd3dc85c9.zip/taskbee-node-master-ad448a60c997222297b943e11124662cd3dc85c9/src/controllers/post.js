import debugFunc from 'debug';
import Errors from 'throw.js';
import * as check from '../utils/check';
import {User, Post, Pollen, SysMessage} from '../models/index';
import wrap from '../utils/wrap';
import {projectionBriefUser, projectionVeryBriefUser} from '../models/user';
import qiniu from 'qiniu';
import {validateHeader} from '../utils/qiniusign';
import {isOnline, sendStatus, sendSysMessage} from '../socket';
import {HOST_URL} from '../config';
import {sendNoti, sendNotiWithFallba} from '../utils/sms';

import {projectionBriefPost, projectionDetailPost} from '../models/post';
import maxLength from '../utils/maxLength';
// import * as config from '../config.js';

// qiniu.conf.ACCESS_KEY = config.QACCESS_KEY;
// qiniu.conf.SECRET_KEY = config.QSECRET_KEY;
const debug = debugFunc('controllers:post');
/*
  都没写测试！！！！
 */
// 生成随机点
function randomGeo(center, radius) {
  const y0 = center[1];
  const x0 = center[0];
  const rd = radius / 111300; // about 111300 meters in one degree

  const u1 = Math.random();
  const v1 = Math.random();

  const w1 = rd * Math.sqrt(u1);
  const t1 = 2 * Math.PI * v1;
  const x1 = w1 * Math.cos(t1);
  const y1 = w1 * Math.sin(t1);

  // Adjust the x-coordinate for the shrinking of the east-west distances
  const xp = x1 / Math.cos(y0);

  const newlat = y1 + y0;
  const newlon = xp + x0;

  return [newlon, newlat];
}

// 创建任务 蜂蜜-1
function isToday(date) {
  const tmp = new Date(date);
  return tmp.setHours(0, 0, 0, 0) === (new Date()).setHours(0, 0, 0, 0);
}
function isYesterday(date) {
  const tmp = new Date(date);
  const da = new Date();
  da.setDate(da.getDate() - 1);
  return tmp.setHours(0, 0, 0, 0) === da.setHours(0, 0, 0, 0);
}


export const create = wrap(async function create(req, res, next) {
  debug('CREATE POST');
  debug(req.body);
  let {description} = req.body;
  const {pos} = req.body;
  if (!Array.isArray(pos)) {
    return next(new Errors.notAcceptable('地理位置错误'));
  }
  // 更新用户的地理位置
  const puber = req.user.id;
  const user = await User.findById(puber, {score: true, accountType: true, signTime: true}).exec();
  /*
  if (user.score <= 0) {
    return next(new Errors.notAcceptable('您已经没有蜂蜜了，不能发新消息'));
  }
  */
  if (description) description = description.replace(/[\r\n]/g, '');
  else return next(new Errors.notAcceptable('至少1个字～', 'description'));
  if (description.length < 1) {
    return next(new Errors.notAcceptable('至少1个字～', 'description'));
  }
  if (description.length > 280) {
    return next(new Errors.notAcceptable('字数太多啦~', 'description'));
  }
  const createdAt = Date.now();
  const post = new Post({
    content: description,
    from: user._id,
    createdAt,
    involves: [puber],
    loc: {
      type: 'Point',
      coordinates: pos,
    }
  });
  const pollen = new Pollen({
    postId: post._id,
    left: 10,
    type: 0, // 原创
    from: user._id,
    createdAt,
    loc: {
      type: 'Point',
      coordinates: pos,
    }
  });
  // 存入数据库
  await Promise.all([
    user.update({$push: {readPost: post._id}, $set: {'loc.coordinates': pos}}).exec(), // {$inc: {score: -1}, 不要减少蜂蜜了
    post.save(),
    pollen.save()
  ]);



  const putPolicy = new qiniu.rs.PutPolicy('heartrunner');
  putPolicy.callbackUrl = HOST_URL + '/api/post/notify/' + post._id;
  // putPolicy.callbackBodyType = 'application/json';
  putPolicy.callbackBody = 'key=$(key)&width=$(imageInfo.width)&height=$(imageInfo.height)';


  if (user.signTime && isToday(user.signTime)) {
    // 已经签过到，无需签到步骤
    return res.json({data: putPolicy.token()});
  }

  const updateQuery = {
    $set: {signTime: new Date()},
    $inc: {score: 1},
  };

  debug(user.signTime);
  if (user.signTime && isYesterday(user.signTime)) {
    // 连续签到
    updateQuery.$inc.signCount = 1;
  } else {
    debug('not yesterday');
    updateQuery.$set.signCount = 1;
  }
  debug(updateQuery);
  await User.update({_id: user._id}, updateQuery).exec();

  return res.json({data: putPolicy.token(), signed: true});


  // 官方发布，推送给所有用户
  /*
  if (user.accountType === 2) {
    // 官方账号，推送给所有人
    debug('官方账号');
    User.update({}, {$push: {readPost: post._id, pollens: pollen._id}}, {multi: true}).exec();
  }
  */
});

export const getNearby = wrap(async function getNearby(req, res, next) {
  let { long, lati} = req.query;
  if (isNaN(long) || isNaN(lati)) {
    return next(new Errors.notAcceptable('地理位置错误', 1));
  }
  long = parseFloat(long);
  lati = parseFloat(lati);
  const nearbyArea = {center: [long, lati], radius: 5 / 6378.1, unique: true, spherical: true};
  let pollens;
  let deadPollens;
  if (req.user) {
    const puber = req.user.id;
    // 用户存在
    const user = await User.findById(puber, {readPost: true}).lean().exec();

    if (!user) {
      return next(new Errors.notAcceptable('用户不存在'));
    }
    // 取活的花粉和死的花粉
    pollens = await Pollen.find({left: {$gt: 0}, from: {$ne: user._id}, takers: { $ne: user._id}, postId: {$nin: user.readPost}},
    {postId: true, loc: true}).where('loc').within().circle(nearbyArea).lean().exec();
    deadPollens = await Pollen.find({left: {$gt: 0}, $or: [{from: {$eq: puber}}, {takers: { $eq: puber}}, {postId: {$in: user.readPost}}]},
    {postId: true, loc: true}).where('loc').within().circle(nearbyArea).limit(60).lean().exec();
  } else {
    pollens = await Pollen.find({left: {$gt: 0}}, {type: true, loc: true}).where('loc').within().circle(nearbyArea).limit(99).lean().exec();
    deadPollens = [];
  }

  res.json({data: {
    pollens,
    deadPollens
  }});
});

export const storage = wrap(async function storage(req, res, next) {
  const puber = req.user.id;
  const user = await User.findById(puber, {pollens: true}).lean().exec();
  if (!user) {
    return next(new Errors.notAcceptable('用户不存在'));
  }
  const realPollens = await Pollen.find({
    _id: {$in: user.pollens},
  }, {type: true, postId: true, from: true, loc: true}
  ).populate({path: 'from', select: projectionBriefUser, model: 'User'}).populate({path: 'postId',
    select: projectionBriefPost,
    populate: {path: 'from', select: projectionBriefUser, model: 'User'}
  }).lean().exec();
  res.json({data: realPollens});
});

// TODO 需要游客查看
export const collect = wrap(async function collect(req, res, next) {
  const {pos} = req.body;
  if (!Array.isArray(pos)) {
    return next(new Errors.notAcceptable('地理位置错误'));
  }
  // 更新用户的地理位置
  const puber = req.user.id;
  debug('collect', puber);
  const user = await User.findById(puber, {pollens: true, readPost: true}).lean().exec();
  if (!user) {
    return next(new Errors.notAcceptable('用户不存在'));
  }

  if (user.pollens.length > 30) {
    // 花粉太多
    return next(new Errors.notAcceptable('花粉太多装不下啦，传播掉一点吧'));
  }
  // 首先，收集1050m 范围内不来自自己、自己未采集过、未读过的
  const pollens = await Pollen.find({left: {$gt: 0}, from: {$ne: user._id}, takers: { $ne: user._id}, postId: {$nin: user.readPost}},
    {postId: true, loc: true}).where('loc').near({
      center: { coordinates: pos, type: 'Point' },
      maxDistance: 3000, // 3km
      spherical: true,
    }).lean().exec();

  // 然后要剔除同一来源的消息

  // 将花粉按postId分类
  const postsMap = {};
  pollens.forEach(pollen => {
    const id = pollen.postId.toString();
    if (!postsMap[id]) postsMap[id] = [];
    postsMap[id].push(pollen);
  });

  // 都是没读过的
  const unreadPost = Object.keys(postsMap);
  // 只取没有读过的花粉的id
  const collectIds = unreadPost.map((id) => {
    // 只取未读消息的第一个
    return postsMap[id][0]._id;
  });

  // 先更新好
  await Promise.all([
    User.update({_id: user._id}, {
      $push: {
        pollens: { $each: collectIds},
        readPost: {$each: unreadPost, $slice: -2000}
      },
      $set: {'loc.coordinates': pos}
    }), // 最多存100条提升效率
    Pollen.update({_id: {$in: collectIds}}, {$push: {takers: user._id}, $inc: {left: -1}}, {multi: true}),
    Post.update({_id: {$in: unreadPost}}, {$inc: {readerCount: 1}, $push: {readers: user._id}}, {multi: true}),
  ]);
  debug('colledted:', collectIds);
  // 把积攒的花粉都传回来呗. 最多40个
  const realPollens = await Pollen.find({
    _id: {$in: collectIds},
  }, {type: true, postId: true, from: true, loc: true}
  ).populate({path: 'from', select: projectionBriefUser, model: 'User'}).populate({path: 'postId',
    select: projectionBriefPost,
    populate: {path: 'from', select: projectionBriefUser, model: 'User'}
  }).lean().exec();

  res.json({data: realPollens});
});

// 丢弃消息
export const abandon = wrap(async function abandon(req, res, next) {
  const {id} = req.body;
  const userId = req.user.id;
  await User.update({_id: userId}, {$pull: {pollens: id}});
  res.json({data: true});
});

// 传播消息
export const cast  = wrap(async function cast(req, res, next) {
  const {id, pos} = req.body;
  if (!Array.isArray(pos)) {
    return next(new Errors.notAcceptable('地理位置错误'));
  }
  const userId = req.user.id;
  // 只能传自己有的
  const pollen = await Pollen.findOne({_id: id, takers: userId, spreaders: {$ne: userId}}, {postId: true}).lean().exec();
  if (!pollen) {
    return next(new Errors.notAcceptable('找不到花粉了'));
  }
  const createdAt = Date.now();
  // 近一些
  const newPollen = new Pollen({
    postId: pollen.postId,
    left: 2,
    type: 1, // 复制
    from: userId,
    createdAt,
    loc: {
      type: 'Point',
      coordinates: randomGeo(pos, 200 + Math.random() * 800),
    }
  });

  const post = await Post.findById(pollen.postId, {content: true, from: true, involves: true});
  if (post.involves.indexOf(userId) < 0) {
    await Post.update({_id: pollen.postId}, {$push: {involves: userId}});
  }
  /*
    const user = await User.findById(userId, {username: true});
    debug(user);
    if (!post.from.equals(userId)) {
      // 推送提醒
      const sysMessage = new SysMessage({
        to: post.from,
        href: pollen.postId.toString(),
        message: user.username + ' 传播了您的花粉' + maxLength(post.content),
        type: 'postComment', // 暂时就这一个啦 TODO
      });
      if (isOnline(post.from)) {
        sysMessage.hasRead = true;
        sendSysMessage(post.from, sysMessage);
      }
      sysMessage.save();
    }
  */

  await Promise.all([
    newPollen.save(),
    Pollen.update({_id: pollen._id}, {$push: {spreaders: userId}}),
    Post.update({_id: pollen.postId}, {$inc: {spreadCount: 1}, $push: {spreadBy: userId}}),
    User.update({_id: userId}, {$pull: {pollens: id}, $set: {'loc.coordinates': pos}}),
  ]);

  res.json({data: [newPollen]});
});


// 七牛notify
export const notify =  wrap(async function notify(req, res, next) {
  const {authorization} = req.headers;
  const {postId} = req.params;
  if (!validateHeader(authorization, req.path, req.rawBody)) {
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  const {key, width, height} = req.body;
  const post = await Post.findById(postId, {imgs: true}).lean().exec();
  if (!post) {
    debug('没找到');
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  if (post.imgs.length > 2) { // 定义了最大照片,最多3张
    debug('满了');
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  res.json({data: true});
  await Post.update({_id: post._id}, {$push: {imgs: {
    key,
    width: parseInt(width),
    height: parseInt(height),
  }}});
});


export const loadPollen = wrap(async function loadPollen(req, res) {
  const {pollenId} = req.query;
  const realPollen = await Pollen.findById(pollenId, {type: true, postId: true, from: true, loc: true}
  ).populate({path: 'from', select: projectionBriefUser, model: 'User'}).populate({path: 'postId',
    select: {loc: true, content: true, from: true, imgs: true, readerCount: true, comments: true, createdAt: true},
    populate: {path: 'from', select: projectionBriefUser, model: 'User'}
  }).lean().exec();
  res.json({data: realPollen});
});

export const loadPost = wrap(async function loadPost(req, res) {
  const {postId} = req.query;
  const realPost = await Post.findById(postId,
   projectionDetailPost)
  .populate('comments.to comments.from', projectionVeryBriefUser)
  .populate({path: 'from', select: projectionBriefUser, model: 'User'})
  .populate('spreadBy', {avatar: true})
  .lean().exec();
  res.json({data: realPost});
});

export const newComment = wrap(async function newComment(req, res, next) {
  debug('NEW COMMENT');
  const {postId, to, body} = req.body;
  const from = req.user.id;
  const post = await Post.findById(postId, {content: true, from: true, involves: true}).lean().exec();
  if (!post) {
    return next(new Errors.notAcceptable('找不到状态', 0));
  }
  const fromUser = await User.findById(from, {username: true});
  if (post.involves.indexOf(from) < 0) {
    // 之前没有参加
    await Post.update({_id: post._id}, {$push: {involves: from}});
  }
  let toUser;
  if (to) {
    toUser = await User.findById(to, {pushId: true, avatar: true, username: true}).lean().exec();
    if (!toUser) {
      return next(new Errors.notAcceptable('用户不存在'));
    }
    if (to !== from ) {
      const sysMessage = new SysMessage({
        to: toUser._id,
        href: postId,
        message: fromUser.username + ' @了您在花粉' + maxLength(post.content) + '：' + maxLength(body),
        type: 'postComment',
      });
      if (isOnline(to)) {
        sysMessage.hasRead = true;
        sendSysMessage(to, sysMessage);
      } else {
        sendNoti(toUser.pushId, sysMessage.message);
      }
      sysMessage.save();
    }
  } else {
    post.involves.forEach( async function(personId) {
      if (personId === from) return;
      const sysMessage = new SysMessage({
        to: personId,
        href: postId,
        message: fromUser.username + ' 评论了花粉：'+ maxLength(post.content) +'：' + maxLength(body),
        type: 'postComment',
      });
      if (isOnline(personId)) {
        sysMessage.hasRead = true;
        sendSysMessage(personId, sysMessage);
      } else {
        const publisher = await User.findById(personId, {pushId: true}).lean().exec();
        sendNoti(publisher.pushId, sysMessage.message);
      }
      sysMessage.save();
    });
  }

  const insertDate = new Date();
  await Post.update({_id: postId}, {
    $inc: {commentCount: 1},
    $push: {comments: {
      from,
      to,
      body,
      date: insertDate
    }}});
  // return newly posted comment
  if (toUser) delete toUser.pushId;
  res.json({data: {
    to: toUser,
    body,
    date: insertDate
  }});
});

// 最热门的花粉排行
/*

  start: 之前的总数
  span: 载入的数量

 */
export const hotestPost = wrap(async function hotestPost(req, res) {
  const start = parseInt(req.query.start || 0, 10);
  const span = parseInt(req.query.span, 10);
  if (!check.positiveInteger(span)) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  if (!check.positiveInteger(start)) {
    return next(new Errors.notAcceptable('start错误', 1));
  }

  const query = {
    createdAt: {$gt: Date.now() - 1000 * 60 * 60 * 24 * 7},
    // spreadCount: {$gt: 1},
  };

  const realPost = await Post.find(query,
   projectionBriefPost)
  .limit(span).skip(start)
  .sort({spreadCount: -1})
  // .populate('comments.to comments.from', projectionVeryBriefUser)
  .populate({path: 'from', select: projectionBriefUser, model: 'User'})
  .populate('spreadBy', {avatar: true})
  .lean().exec();
  res.json({data: realPost});
});
