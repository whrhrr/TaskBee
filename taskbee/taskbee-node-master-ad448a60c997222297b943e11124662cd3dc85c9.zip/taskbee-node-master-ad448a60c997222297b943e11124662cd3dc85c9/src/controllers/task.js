import debugFunc from 'debug';
import Errors from 'throw.js';
import * as check from '../utils/check';
import easyImage from 'easyimage';
import wrap from '../utils/wrap';
import jwt from 'jsonwebtoken';
import {User, Tag, Task, Vote, SysMessage} from '../models/index';
import {toObjectId} from '../utils/db';
import {isOnline, sendSysMessage} from '../socket';
import sendSms, {sendNoti, sendNotiWithFallback, sendNotiAndSms, verifyStr, takeTaskStr, taskerCompleteStr, taskerAbandonStr} from '../utils/sms';
import {projectionBrief} from '../models/task';
import {projectionBriefUser, projectionVeryBriefUser} from '../models/user';
import qiniu from 'qiniu';
import {validateHeader} from '../utils/qiniusign';
import {HOST_URL} from '../config';

import nodemailer from 'nodemailer';
import smtpTransport from 'nodemailer-smtp-transport';

import maxLength from '../utils/maxLength';

export const transporter = nodemailer.createTransport(smtpTransport({
  port: 465,
  secure: true,
  host: 'smtp.mxhichina.com',
  auth: {
    user: 'noreply@taskbee.cn',
    pass: '7UHVW$bj3Rs7v@K4V$pvAYhnab4B0RQF'
  }
}));

// async export 还不支持
const {default: determineFav} = require('../utils/dataProcessor');
const debug = debugFunc('controllers:task');

const MAX_TASK = 10;


// 七牛notify
export const notify =  wrap(async function notify(req, res, next) {
  const {authorization} = req.headers;
  const {postId} = req.params;
  if (!validateHeader(authorization, req.path, req.rawBody)) {
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  const {key, width, height} = req.body;
  const post = await Task.findById(postId, {imgs: true}).lean().exec();
  if (!post) {
    debug('没找到');
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  if (post.imgs.length > 3) { // 定义了最大照片
    debug('满了');
    return res.status(404).json({message: '这里什么都没有啦！'});
  }
  res.json({data: true});
  await Task.update({_id: post._id}, {$push: {imgs: {
    key,
    width: parseInt(width),
    height: parseInt(height),
  }}});
});

export const passEvent = wrap(async function createEvent(req, res, next) {
  const {secret, id} = req.body;
  if (secret === 'jiongjiongjiongxiaobu') {
    const task = await Task.findOne({_id: id}, {state: true}).lean().exec();
    debug(task);
    if (task.state === 6) {
      await Task.update({_id: task._id}, {state: 0});
      return res.json({data: true});
    }
  }
  res.json({data: false});
});

// 创建活动
export const createEvent = wrap(async function createEvent(req, res, next) {
  debug('CREATE EVENT');
  debug(req.body);
  const {description, dueTime, startTime, pos} = req.body;
  const puber = req.user.id;
  const user = await User.findById(puber, {phone: true, username: true, accountType: true, score: true, money: true}).exec();

  if (user.accountType < 1) {
    return next(new Errors.notAcceptable('您还不能发布活动，建议提交一个反馈来申请活动权限～'));
  }

  if (!check.description(description)) {
    return next(new Errors.notAcceptable('说明不合适', 'description'));
  }
  if (!check.startTime(startTime)) {
    return next(new Errors.notAcceptable('开始时间在30分钟前～1个月内', 'startTime'));
  }
  if (!check.dueTime(dueTime, startTime)) {
    return next(new Errors.notAcceptable('截止时间在当前时间后2个月内', 'dueTime'));
  }
  if (!Array.isArray(pos)) {
    return next(new Errors.notAcceptable('地理位置错误'));
  }
  // 活动
  const task = new Task({publisher: puber, description, dueTime, startTime, type: 1,
    reward: 0,
    state: 0, // 不用审核
    loc: {
      type: 'Point',
      coordinates: pos,
    },
  });

  await Promise.all([
    user.update({$push: {taskPublish: task._id}, $inc: {countTotalPublish: 1}}).exec(),
    task.save(),
  ]);

  const putPolicy = new qiniu.rs.PutPolicy('heartrunner');
  putPolicy.callbackUrl = HOST_URL + '/api/task/notify/' + task._id;
  // putPolicy.callbackBodyType = 'application/json';
  putPolicy.callbackBody = 'key=$(key)&width=$(imageInfo.width)&height=$(imageInfo.height)';
  res.json({data: putPolicy.token()});

  const mailOptions = {
    from: 'noreply@taskbee.cn',
    to: 'xiaobu@taskbee.cn',
    subject: '新活动申请',
    text: user.username + ' / ' + user.phone + ' / ' + description + ' / ' + startTime + ' / ' + task._id,
  };
  transporter.sendMail(mailOptions, function mailBack(error) {
    if (error) {
      debug(error);
      console.log('[NEW EVENT] EMAIL SEND ERROR\n' + user.username + ' / ' + description + ' / ' + startTime + ' / ' + task._id );
    }
  });
});


// 创建任务 蜂蜜-1
export const create = wrap(async function create(req, res, next) {
  debug('CREATE TASK');
  debug(req.body);
  const {secret, dueTime, startTime, tags, pos} = req.body;
  let {description, reward} = req.body;
  if (description) description = description.replace(/[\r\n]/g, '');
  reward = parseInt(reward, 10);
  const puber = req.user.id;
  // const school = req.user.schoolId;
  const user = await User.findById(puber, {gender: true, taskPublish: true, score: true, money: true}).exec();
  if (user.score <= 0) {
    return next(new Errors.notAcceptable('您已经没有蜂蜜了，不能发任务'));
  }
  if (user.taskPublish.length) {
    // 只能有10个在进行中的任务
    const taskPubCount = await Task.count({_id: {$in: user.taskPublish}, state: 0 }).exec();
    if (taskPubCount === MAX_TASK) {
      return next(new Errors.notAcceptable('已经有很多任务啦，休息一下'));
    }
  }

  debug(user);
  if (!check.description(description)) {
    return next(new Errors.notAcceptable('说明不合适', 'description'));
  }
  if (!check.secret(secret)) {
    return next(new Errors.notAcceptable('私密说明不合适', 'secret'));
  }
  if (!check.startTime(startTime)) {
    return next(new Errors.notAcceptable('开始时间在30分钟前～1个月内', 'startTime'));
  }
  if (!check.dueTime(dueTime, startTime)) {
    return next(new Errors.notAcceptable('截止时间在当前时间后2个月内', 'dueTime'));
  }
  if (!check.reward(reward)) {
    return next(new Errors.notAcceptable('奖赏请输入一个正整数', 'reward'));
  }
  if (reward > user.money) {
    return next(new Errors.notAcceptable('钱包内余额不足', 'reward'));
  }
  if (!check.tags(tags)) {
    return next(new Errors.notAcceptable('最多6个标签', 'tags'));
  }
  if (!Array.isArray(pos)) {
    return next(new Errors.notAcceptable('地理位置错误'));
  }
  // 根据tag Id读取tags
  let realTags = [];
  if (tags) {
    realTags  = await Tag.find({_id: {$in: tags}}, {_id: false, name: true}).limit(tags.length).lean().exec();
    if (realTags.length !== tags.length) {
      return next(new Errors.notAcceptable('有无效的标签', 'tags'));
    }
    realTags = realTags.map( tag => tag.name);
  }

  const task = new Task({
    publisher: puber,
    description, secret, dueTime, startTime, reward,
    tags: realTags,
    involves: [puber],
    loc: {
      type: 'Point',
      coordinates: pos,
    }
  });

  await Promise.all([
    user.update({$push: {taskPublish: task._id}, $inc: {countTotalPublish: 1, score: -2, money: -reward}}).exec(),
    task.save(),
    Tag.update({_id: {$in: tags}}, {$inc: {count: 1}}).exec(),
  ]);

  const putPolicy = new qiniu.rs.PutPolicy('heartrunner');
  putPolicy.callbackUrl = HOST_URL + '/api/task/notify/' + task._id;
  // putPolicy.callbackBodyType = 'application/json';
  putPolicy.callbackBody = 'key=$(key)&width=$(imageInfo.width)&height=$(imageInfo.height)';
  res.json({data: putPolicy.token()});
  // res.json({data: task});
});

// 接受任务 - 我是接单人， 我需要发布者的数据
// 接受任务 增加1蜂蜜
export const take = wrap(async function take(req, res, next) {
  debug('TAKE TASK');
  const {taskId} = req.body;
  const tasker = req.user.id;
  // 因为需要查找任务， 不需要检测task是否合理
  const task = await Task.findById(taskId, {state: true, description: true, publisher: true, historyTaskers: true, involves: true}).exec();
  if (!task) {
    return next(new Errors.notAcceptable('无法找到任务'));
  }
  if (task.publisher.equals(tasker)) {
    return next(new Errors.notAcceptable('不能接受自己的任务'));
  }
  if (task.state === 1) {
    return next(new Errors.notAcceptable('此任务已经被接单'));
  }
  if (task.state > 1) {
    return next(new Errors.notAcceptable('此任务已经完成'));
  }
  if (task.historyTaskers.some( historyId => historyId.equals(tasker))) {
    return next(new Errors.notAcceptable('抱歉，您曾经放弃了这个任务，不能再接手了'));
  }
  const user = await User.findById(tasker, {score: true, taskTaken: true, username: true, gender: true}).exec();
  if (user.score <= -5) {
    return next(new Errors.notAcceptable('您已经没有蜂蜜了，不能接手任务'));
  }
  if (user.taskTaken.length) {
    // 只能有10个在进行中的任务
    const taskTakenCount = await Task.count({_id: {$in: user.taskTaken}, state: 1});
    if (taskTakenCount === MAX_TASK) {
      return next(new Errors.notAcceptable('已经接了很多任务啦，休息一下'));
    }
  }
  task.state = 1;
  task.tasker = tasker;
  task.takeTime = Date.now();
  if (task.involves.indexOf(tasker) < 0) {
    task.involves.push(tasker);
  }
  await task.save();
  // 接手任务加1蜂蜜
  await user.update({$push: {taskTaken: task._id}, $inc: {countTotalTaken: 1, score: 1}});
  // 返回部分数据
  // TODO需要的任务数据
  const publisher = await User.findById(task.publisher, {username: true, avatar: true, score: true, gender: true, signature: true, realname: true, pushId: true, phone: true}).lean().exec();
  res.json({data: publisher});
  const puberId = task.publisher.toString();
  const sysMessage = new SysMessage({
    to: task.publisher,
    href: taskId,
    type: 'task',
    message: user.username + ' 接手了任务' + maxLength(task.description),
  });
  if (isOnline(puberId)) {
    sysMessage.hasRead = true;
    sendSysMessage(puberId, sysMessage);
  } else {
  // 通知发布人
    sendNotiAndSms(publisher.pushId, sysMessage.message, takeTaskStr(publisher.phone, user.username));
  }
  sysMessage.save();
});

// 接受者确认任务完成
export const confirmTasker = wrap(async function confirmTasker(req, res, next) {
  debug("CONFIRM TAKER");
  const {taskId} = req.body;
  const tasker = req.user.id;

  const task = await Task.findById(taskId, {description: true,state: true, tasker: true, publisher: true}).exec();
  if (!task) {
    return next(new Errors.notAcceptable('无法找到任务'));
  }
  if (!task.tasker.equals(tasker)) {
    return next(new Errors.unauthorized('不是任务接受者'));
  }
  if (task.state > 2) {
    return next(new Errors.notAcceptable('任务已经完成'));
  }
  const user = await User.findById(tasker, {username: true}).lean().exec();
  task.state = 2;
  task.taskerConfirmTime = Date.now();
  await task.save();
  // 返回部分数据
  res.json({data: task});
  const puberId = task.publisher.toString();
  const sysMessage = new SysMessage({
    to: task.publisher,
    href: taskId,
    message: user.username + ' 完成了任务' + maxLength(task.description),
    type: 'task',
  });
  if (isOnline(puberId)) {
    sysMessage.hasRead = true;
    sendSysMessage(puberId, sysMessage);
  } else {
    const publisher = await User.findById(task.publisher, {phone: true, pushId: true}).lean().exec();
    sendNotiAndSms(publisher.pushId, sysMessage.message, taskerCompleteStr(publisher.phone, user.username));
  }
  sysMessage.save();
});

// 发布者确认任务完成
// 发布者 蜂蜜+1 接收者 蜂蜜+1
export const confirmPuber = wrap(async function confirmPuber(req, res, next) {
  debug("CONFIRM TAKER");
  const {taskId} = req.body;
  const puber = req.user.id;

  const task = await Task.findById(taskId, {description: true, state: true, tasker: true, publisher: true, canVote: true, reward: true}).exec();
  if (!task) {
    return next(new Errors.notAcceptable('无法找到任务'));
  }
  if (!task.publisher.equals(puber)) {
    return next(new Errors.unauthorized('不是任务发布者'));
  }
  if (task.state > 3) {
    return next(new Errors.notAcceptable('任务已经完成'));
  }
  if (task.state < 1) {
    return next(new Errors.notAcceptable('请等待接单'));
  }
  task.state = 3;
  task.finishTime = Date.now();
  task.canVote.push(task.tasker);
  task.canVote.push(task.publisher);
  await task.save();
  // 任务完成，更新接受者和发布者任务列表
  await User.update({_id: task.publisher}, {$pull: {taskPublish: taskId}, $inc: {score: 1}});
  await User.update({_id: task.tasker}, {$pull: {taskTaken: taskId}, $inc: {score: 1, money: task.reward }});
  // 返回部分数据
  res.json({data: task});
  const taskerId = task.tasker.toString();
  const user = await User.findById(puber, {username: true}).lean().exec();
  const sysMessage = new SysMessage({
    to: task.tasker,
    href: taskId,
    message: user.username + ' 确认完成了任务' + maxLength(task.description),
    type: 'task',
  });
  if (isOnline(taskerId)) {
    sysMessage.hasRead = true;
    sendSysMessage(taskerId, sysMessage);
  } else {
    const tasker = await User.findById(task.tasker, {pushId: true}).lean().exec();
    sendNoti(tasker.pushId, sysMessage.message);
  }
  sysMessage.save();
});

// 任务接受者取消任务
// 先减去 蜂蜜 －6
export const cancelTasker = wrap(async function cancelTasker(req, res, next) {
  debug("CANCEL TASK TAKER");
  const {taskId} = req.body;
  const tasker = req.user.id;
  const task = await Task.findById(taskId, {description: true, state: true, tasker: true, publisher: true, historyTaskers: true, canPunish: true}).exec();
  if (!task) {
    return next(new Errors.notAcceptable('无法找到任务'));
  }
  if (!task.tasker.equals(tasker)) {
    return next(new Errors.unauthorized('不是任务接受者'));
  }
  if (task.state !== 1) {
    return next(new Errors.notAcceptable('已经完成，不能取消'));
  }
  await User.update({_id: task.tasker}, {$pull: {taskTaken: taskId}, $inc: {score: -6}});
  task.state = 0;
  task.historyTaskers.push(tasker);
  task.tasker = null;
  task.takeTime = null;
  task.canPunish.push(taskId);
  await task.save();
  // 任务完成，更新接受者和发布者任务列表
  /*
    sms提醒任务发布者
   */
  // 返回部分数据
  res.json({data: task});
  const puberId = task.publisher.toString();
  const user = await User.findById(tasker, {username: true}).lean().exec();
  const sysMessage = new SysMessage({
    to: task.publisher,
    href: taskId,
    message: user.username + ' 放弃了任务' + maxLength(task.description),
    type: 'task',
  });
  if (isOnline(puberId)) {
    sysMessage.hasRead = true;
    sendSysMessage(puberId, sysMessage);
  } else {
    // 提醒任务发布者
    const publisher = await User.findById(task.publisher, {phone: true, pushId: true}).lean().exec();
    sendNotiAndSms(publisher.pushId, sysMessage.message, taskerAbandonStr(publisher.phone, user.username));
  }
  sysMessage.save();
});

// 任务发布者取消任务
// 先减去蜂蜜 －6
export const cancelPuber = wrap(async function cancelPuber(req, res, next) {
  debug("CANCEL TASK PUB");
  const {taskId} = req.body;
  const puber = req.user.id;
  const task = await Task.findById(taskId, {description: true, state: true, tasker: true, publisher: true, reward: true}).exec();
  if (!task) {
    return next(new Errors.notAcceptable('无法找到任务'));
  }
  if (!task.publisher.equals(puber)) {
    return next(new Errors.unauthorized('不是任务发布者'));
  }
  debug(task);
  if (task.state > 2) {
    return next(new Errors.notAcceptable('已经完成，不能取消'));
  }
  // 发布者取消
  task.state = 5;
  task.finishTime = Date.now();
  await task.save();
  // 任务被取消，更新接受者和发布者任务列表
  const user = await User.findById(puber, {username: true}).lean().exec();
  if (task.tasker) {
    const taskerId = task.tasker.toString();
    const sysMessage = new SysMessage({
      to: task.tasker,
      href: taskId,
      message: user.username + ' 取消了任务'+ maxLength(task.description),
      type: 'task',
    });
    if (isOnline(taskerId)) {
      sysMessage.hasRead = true;
      sendSysMessage(taskerId, sysMessage);
    } else {
      // 提醒任务发布者
      const tasker = await User.findById(task.tasker, {pushId: true}).lean().exec();
      sendNoti(tasker.pushId, sysMessage.message);
    }
    sysMessage.save();
    User.update({_id: task.tasker}, {$pull: {taskTaken: taskId}}).exec();
    // 钱
    User.update({_id: task.publisher}, {$pull: {taskPublish: taskId}, $inc: {score: -6, money: task.reward}}).exec();
  } else {
    User.update({_id: task.publisher}, {$pull: {taskPublish: taskId}, $inc: {money: task.reward}}).exec();
  }

  // 返回部分数据
  res.json({data: task});
});

// 发表评价
export const vote = wrap(async function vote(req, res, next) {
  debug("VOTE THE OTHER");
  const {taskId, message} = req.body;
  const score = parseInt(req.body.score, 10);
  const userId = req.user.id;

  if (!(score >= 0 && score <= 5)) {
    return next(new Errors.notAcceptable('分数不合适'));
  }
  if (message.length > 280) {
    return next(new Errors.notAcceptable('评价太长啦'));
  }
  const task = await Task.findById(taskId, {state: true, tasker: true, publisher: true, canVote: true}).lean().exec();
  if (!task) {
    return next(new Errors.notAcceptable('抱歉，无法找到对应任务'));
  }
  if (task.state < 3) {
    return next(new Errors.notAcceptable('抱歉，还不能评价'));
  }
  if (!task.canVote.some(id => id.equals(userId))) {
    return next(new Errors.notAcceptable('抱歉，不能评价这个任务'));
  }
  // 判断被评价方
  let toVote;
  let fromVote;
  let type;
  if (task.publisher.equals(userId)) {
    // 是发布者，评价接单人
    toVote = task.tasker;
    fromVote = task.publisher;
    type = true;
  } else if (task.tasker.equals(userId)) {
    // 是接单人，评价发布者
    toVote = task.publisher;
    fromVote = task.tasker;
    type = false;
  } else {
    return next(new Errors.notAcceptable('迷的错误，这单不能评价了'));
  }
  const voteStore = new Vote({
    user: toVote,
    from: fromVote,
    message,
    score,
    type
  });
  await Promise.all([
    voteStore.save(),
    User.update({_id: toVote}, {$inc: {voteScore: score, voteCount: 1, score: score - 3}}).exec(),
    Task.update({_id: taskId}, {$pull: {canVote: userId}}).exec(),
  ]);
  // 返回部分数据
  const user = await User.findById(fromVote, {username: true}).lean().exec();
  let sysMes = user.username + ' 给了您' + score + '星评价';
  if (message && message.length) {
    sysMes += '，并评价' + maxLength(message);
  }
  res.json({data: true});
  const sysMessage = new SysMessage({
    to: toVote,
    href: toVote,
    message: sysMes,
    type: 'vote',
  });
  if (isOnline(toVote)) {
    sysMessage.hasRead = true;
    sendSysMessage(toVote, sysMessage);
  }  else {
    // 提醒被评论者
    const notiUser = await User.findById(toVote, {pushId: true}).lean().exec();
    sendNoti(notiUser.pushId, sysMessage.message);
  }
  sysMessage.save();
});

// 收藏任务
export const fav = wrap(async function fav(req, res, next) {
  debug("FAV TASK");
  const {taskId} = req.body;
  const userId = req.user.id;
  const task = await Task.findById(taskId, {publisher: true, description: true, involves: true});
  const user = await User.findById(userId, {username: true});
  if (!task) return next(new Errors.notAcceptable('找不到任务'));
  // 用户必然存在
  const isFaved = await User.count({_id: userId, taskFav: {$elemMatch: {$eq: taskId}}}).exec();
  if (!isFaved) {
    if (task.involves.indexOf(userId) < 0) { //之前没参加
      await Task.update({_id: taskId}, {$inc: {favs: 1}, $push: {favBy: userId, involves: userId}});
    } else {
      await Task.update({_id: taskId}, {$inc: {favs: 1}, $push: {favBy: userId}});
    }
    await User.update({_id: userId}, {$push: {taskFav: taskId}});
    if (!task.publisher.equals(userId)) {
      // 推送提醒
      const sysMessage = new SysMessage({
        to: task.publisher,
        href: taskId,
        message: user.username + ' 点赞了您的任务' + maxLength(task.description),
        type: 'task',
      });
      if (isOnline(task.publisher)) {
        sysMessage.hasRead = true;
        sendSysMessage(task.publisher, sysMessage);
      }//  else {
        // 提醒被评论者
        //const notiUser = await User.findById(task.publisher, {pushId: true}).lean().exec();
        //sendNoti(notiUser.pushId, sysMessage.message);
      //}
      sysMessage.save();
    }
  }
  res.json({data: true});
});

// 取消收藏任务
export const unFav = wrap(async function unFav(req, res, next) {
  debug("UN FAV TASK");
  const {taskId} = req.body;
  const userId = req.user.id;
  // 用户必然存在
  const isFaved = await User.count({_id: userId, taskFav: {$elemMatch: {$eq: taskId}}}).exec();
  if (isFaved) {
    await Task.update({_id: taskId}, {$inc: {favs: -1}, $pull: {favBy: userId}});
    await User.update({_id: userId}, {$pull: {taskFav: taskId}});
  }
  // 返回部分数据
  res.json({data: true});
});

export const newComment = wrap(async function newComment(req, res, next) {
  debug('NEW COMMENT');
  const {taskId, to, body} = req.body;
  const from = req.user.id;
  const task = await Task.findById(taskId, {description: true, publisher: true, involves: true}).lean().exec();
  if (!task) {
    return next(new Errors.notAcceptable('找不到任务', 0));
  }
  const fromUser = await User.findById(from, {username: true});
  if (task.involves.indexOf(from) < 0) {
    // 之前没有参加
    await Task.update({_id: task._id}, {$push: {involves: from}});
  }
  let toUser;
  if (to) {
    toUser = await User.findById(to, {avatar: true, pushId: true, username: true}).lean().exec();
    if (!toUser) {
      return next(new Errors.notAcceptable('用户不存在'));
    }
    if (to !== from ) {
      const sysMessage = new SysMessage({
        to: toUser._id,
        href: taskId,
        message: fromUser.username + ' @了您在任务' + maxLength(task.description) + '：' + maxLength(body),
        type: 'comment',
      });
      if (isOnline(to)) {
        sysMessage.hasRead = true;
        sendSysMessage(to, sysMessage);
      } else {
        sendNoti(toUser.pushId, sysMessage.message);
      }
      sysMessage.save();
    }
  } else {
    task.involves.forEach( async function(personId) {
      if (personId === from) return;
      const sysMessage = new SysMessage({
        to: personId,
        href: taskId,
        message: fromUser.username + ' 评论了任务' + maxLength(task.description) + '：'  + maxLength(body),
        type: 'comment',
      });

      if (isOnline(personId)) {
        debug('send sys');
        sysMessage.hasRead = true;
        sendSysMessage(personId, sysMessage);
      } else {
        debug('send not');
        const publisher = await User.findById(personId, {pushId: true}).lean().exec();
        sendNoti(publisher.pushId, sysMessage.message);
      }
      sysMessage.save();
    });

  }

  const insertDate = new Date();
  await Task.update({_id: taskId}, {
    $push: {comments: {
      from,
      to,
      body,
      date: insertDate
    }},
    $inc: {commentCount: 1},
  });
  // return newly posted comment
  if (toUser) delete toUser.pushId;
  res.json({data: {
    to: toUser,
    body,
    date: insertDate
  }});
});

/*

  getters

*/

// 获取最新的task 暂时无视学校
export const getTasks = wrap(async function getTasks(req, res, next) {
  const {tag} = req.query;
  let { long, lati} = req.query;
  debug('long', long, 'lati', lati);
  const span = parseInt(req.query.span, 10);
  // 先不检查了
  if (!check.positiveInteger(span)) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  if (isNaN(long) || isNaN(lati)) {
    return next(new Errors.notAcceptable('地理位置错误', 1));
  }
  long = parseFloat(long);
  lati = parseFloat(lati);
  const query = {
    $or: [
      {state: 0},
      {state: {$in: [1, 2]}, dueTime: {$gt: Date.now()}},
      {state: 3, finishTime: { $lt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7)}, dueTime: { $gt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1) }},
      {state: 4, dueTime: { $gt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3) }}, // 3天
      //{state: 3, dueTime: { $gt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1) }}, //保留7天
    ]
    // {state: {$in: [3, 5]}, finishTime: { $lt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7) }}, // 7天
    // {state: 4, dueTime: { $lt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7) }}, // 7天
  }; // 尚未完成

  if (tag) {
    query.tags = tag;
  }

  debug(req.query);
  debug(query);
  const result = await Task.find(query, projectionBrief).where('loc').near({
    center: { coordinates: [long, lati], type: 'Point' },
    maxDistance: 1000 * 10,
    spherical: true,
  }).sort({ state: 1, _id: -1}).lean().populate('publisher', projectionBriefUser).exec();
  if (req.user && req.user.id) {
    // mutate
    await determineFav(result, req.user.id);
  }
  res.json({data: result});
});

import {projectionTaskDetail, projectionTaskDetailWithSecret} from '../models/task';

export const getTaskDetail = wrap(async function getTaskDetail(req, res, next) {
  const {taskId} = req.query;
  if (!check.objectId(taskId)) {
    return next(new Errors.notAcceptable('任务不存在'));
  }
  const userId = req.user ? req.user.id : null;
  // 判断是否是任务接受者或着发布者
  let result = await Task.findById(taskId, {publisher: true, tasker: true}).lean().exec();
  debug(req.user);
  debug(result);
  if (!result) {
    return next(new Errors.notAcceptable('任务不存在'));
  }
  if (userId) {
    if (result.tasker && result.tasker.equals(userId)) {
      // 是接手人
      result = await Task.findById(taskId, projectionTaskDetailWithSecret).lean()
        .populate('comments.to comments.from', projectionVeryBriefUser)
        .populate('publisher', {phone: true, username: true, avatar: true, score: true, gender: true, signature: true, realname: true})
        .populate('favBy', {avatar: true})
        .exec();
    } else if (result.publisher && result.publisher.equals(userId)) {
      // 是发布人
      result = await Task.findById(taskId, projectionTaskDetailWithSecret).lean()
        .populate('comments.to comments.from', projectionVeryBriefUser)
        .populate('publisher', {username: true, avatar: true, score: true, gender: true, signature: true})
        .populate('tasker', {phone: true, username: true, avatar: true, score: true, gender: true})
        .populate('favBy', {avatar: true})
        .exec();
    } else {
      result = await Task.findById(taskId, projectionTaskDetail).lean()
        .populate('comments.to comments.from', projectionVeryBriefUser)
        .populate('publisher', {username: true, avatar: true, score: true, gender: true, signature: true})
        .populate('favBy', {avatar: true})
        .exec();
    }
  } else {
    result = await Task.findById(taskId, projectionTaskDetail).lean()
      .populate('comments.to comments.from', projectionVeryBriefUser)
      .populate('publisher', {username: true, avatar: true, score: true, gender: true, signature: true})
      .populate('favBy', {avatar: true})
      .exec();
  }
  if (userId) await determineFav([result], userId);

  res.json({data: result});
});



/*
  举报
 */

// 取消收藏任务
export const report = wrap(async function report(req, res, next) {
  debug("report");
  const {taskId, message} = req.body;
  const userId = req.user.id;

  const user = await User.findById(userId, {phone: true, username: true}).exec();
  const task = await Task.findById(taskId, {description: true}).exec();
  if (!task) {
    return next(new Errors.notAcceptable('任务不存在'));
  }
  const mailOptions = {
    from: 'noreply@taskbee.cn',
    to: 'xiaobu@taskbee.cn',
    subject: '任务举报',
    text: user.username + ' / ' + user.phone + ' / ' + task.description + ' / ' + task._id,
  };
  transporter.sendMail(mailOptions, function mailBack(error) {
    if (error) {
      debug(error);
      console.log('[NEW EVENT] EMAIL SEND ERROR' );
    }
  });
  // 返回部分数据
  res.json({data: true});
});


/*
  TEST ONLY
 */

export const timeoutTasks = wrap(async function timeoutTasks(req, res) {
  const now = new Date();
  const task = await Task.find({state: 4}, {publisher: 1}).exec();
  console.log(task);
  task.forEach( task => {
    console.log('update');
    User.update({_id: task.publisher}, {$pull: {taskPublish: task._id}}).exec();
  });
  // await User.update({_id: task.publisher}, {$pull: {taskPublish: taskId}});
  res.json({data: true});
});
