import crypto from 'crypto';
import * as config from '../config.js';

const {QACCESS_KEY, QSECRET_KEY} = config;
function hmacSha1(encodedFlags, secretKey) {
  const hmac = crypto.createHmac('sha1', secretKey);
  hmac.update(encodedFlags);
  return hmac.digest('base64');
}

export function validateHeader(header) {
  if (header.indexOf('QBox') < 0) {
    return false;
  }
  header = header.substring(5);
  const auth = header.split(':');
  if (auth.length !== 2 || auth[0] !== QACCESS_KEY) {
    return false;
  }
  return true;
}
