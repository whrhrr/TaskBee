import mongoose from 'mongoose';

// const passwordRe = /^[a-zA-Z0-9@]{6,16}$/;
const emailRe = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/i;

export function email(email) {
  return emailRe.test(email);
}

export function password(password) {
  return password && password.length > 7 && password.length <= 60;
}

// 1~20位
export function username(username) {
  return username && (username.length <= 20 && username.length > 1);
}

export function gender(gend) {
  return gend === 0 || gend === 1 || gend === 2;
}

export function signature(sig) {
  return sig && (sig.length < 33);
}

export function phone(phoneNum) {
  return phoneNum && (phoneNum.length === 11);
}
export function code(code) {
  return code && (code.length > 4);
}

export function description(desc) {
  return desc && (desc.length > 5 && desc.length <= 280);
}

export function secret(desc) {
  return (!desc || desc.length <= 280);
}

export function startTime(time) {
  // 最近一天前，最远一个月
  const now = Date.now();
  return time + 1000 * 60 * 60 * 24 > now && time < now + 1000 * 60 * 60 * 24 * 30;
}

export function dueTime(time, startTime) {
  // 最少30分钟（前端控制），最多两个月
  const now = Date.now();
  return time > now && time > startTime && time < now + 1000 * 60 * 60 * 24 * 30 * 2;
}

export function reward(amount) {
  return (typeof amount === 'number') && (amount % 1) === 0 && amount >= 0;
}

export function positiveInteger(amount) {
  return (typeof amount === 'number') && (amount % 1) === 0 && amount >= 0;
}

export function tags(tagss) {
  return !tagss || Array.isArray(tagss) && tagss.length < 6;
}

export function objectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

export function tagName(name) {
  return name.length > 1 && name.length < 6;
}

export function message(msg) {
  return msg && msg.length > 0 && msg.length <= 280;
}

export function feedback(fedbc) {
  return fedbc && fedbc.length > 0 && fedbc.length <= 700;
}

export function schoolId(id) {
  return id === 0 || id === 1;
}
