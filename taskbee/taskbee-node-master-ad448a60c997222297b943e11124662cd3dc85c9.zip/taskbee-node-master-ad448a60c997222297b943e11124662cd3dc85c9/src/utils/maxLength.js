function maxLength(length) {
  return (str) => {
    if (str.length <= length) {
      return ' ' + str + ' ';
    }
    return ' ' + str.substring(0, str.length - 3) + '... ';
  };
}

export default maxLength(12);
