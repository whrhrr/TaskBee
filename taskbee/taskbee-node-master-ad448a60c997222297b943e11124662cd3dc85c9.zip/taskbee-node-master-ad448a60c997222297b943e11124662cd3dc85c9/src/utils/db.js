import mongoose from 'mongoose';
export function arrayToObjectId(array) {
  return array.map(mongoose.Types.ObjectId);
}
export function toObjectId(str) {
  console.log(str);
  return mongoose.Types.ObjectId(str);
}