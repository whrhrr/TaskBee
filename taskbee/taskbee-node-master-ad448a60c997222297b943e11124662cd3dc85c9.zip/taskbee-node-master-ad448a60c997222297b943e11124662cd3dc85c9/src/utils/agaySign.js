import fs from 'fs';
import crypto from 'crypto';
import request from 'urllib';

const priKey = fs.readFileSync('./src/utils/agay.pem').toString('ascii');
const pubKey = fs.readFileSync('./src/utils/apubgay.pem').toString('ascii');

export function mergeToString(obj) {
  const keys = Object.keys(obj).sort();
  let str = '';
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    str = str + key + '=' + obj[key] + '&' ;
  }
  str = str + keys[keys.length - 1] + '=' + obj[keys[keys.length - 1]];
  return str;
}

export function mergeToStringWithoutSort(obj) {
  const keys = Object.keys(obj);
  let str = '';
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    str = str + key + '=' + encodeURIComponent(obj[key]) + '&';
  }
  str = str + keys[keys.length - 1] + '=' + encodeURIComponent(obj[keys[keys.length - 1]]);
  return str;
}

export function mergeToStringWithoutSign(obj) {
  const keys = Object.keys(obj).filter( key => key !== 'sign' && key !== 'sign_type' ).sort();
  let str = '';
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    str = str + key + '=' + obj[key] + '&' ;
  }
  str = str + keys[keys.length - 1] + '=' + obj[keys[keys.length - 1]];
  return str;
}


export function sign(obj) {
  const newObj = {
    ...obj
  };
  const str = mergeToString(newObj);
  const signStr = crypto.createSign('RSA-SHA1').update(str, 'utf8');
  newObj.sign = signStr.sign(priKey, 'base64');
  newObj.sign_type = 'RSA';
  // const signStr = crypto.createHash('md5').update(str, 'utf8');
  // newObj.sign = signStr.digest('hex');
  // newObj.sign_type = 'MD5';
  return newObj;
}

// 验证签名
export function verify(newObj) {
  const str = mergeToStringWithoutSign(newObj);
  const verifyStr = crypto.createVerify('RSA-SHA1').update(str, 'utf8');
  const signed = verifyStr.verify(pubKey, newObj.sign, 'base64');
  return signed;
}

// 验证 notify_id (promise)
export function isFromAgay(notifyId) {
  const url = 'https://mapi.alipay.com/gateway.do?service=notify_verify&partner=2088112817052311&notify_id=' + notifyId;
  return request.request(url, {
    method: 'GET'
  });
}
