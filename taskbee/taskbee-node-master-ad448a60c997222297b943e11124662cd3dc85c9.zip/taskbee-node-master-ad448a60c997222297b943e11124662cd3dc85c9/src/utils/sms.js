/*

  推送以及短信通知模块

 */
import request from 'urllib';
import aliSign from './aliSign';
import debugFunc from 'debug';
const debug = debugFunc('utils:sms&push');

import JPush from 'jpush-sdk';

const client = JPush.buildClient('9759c0f61e173daed1698319', '756872e1a89a859f7425fa35');

const limitCount = 8;
const limitTime = 180;

const appCertificate = {
  appKey: '23257397',
  appSecret: '2ce3c0ed0e9469bb408c8b496e0dd843'
};

const signer = new aliSign(appCertificate);


export default function sendSms(requestJSON) {
  const data = signer.sign({
    method: 'taobao.open.sms.sendmsg',
    send_message_request: requestJSON
  });
  return request.request('http://gw.api.taobao.com/router/rest', {
    method: 'POST',
    dataType: 'json',
    data
  });
}

/*
  发送推送， 若无推送，则发送消息
 */
export function sendNotiWithFallback(pushId, message, requestJSON) {
  if (pushId) {
    client.push().setPlatform(JPush.ALL)
    .setAudience(JPush.registration_id(pushId))
    .setNotification(message)
    .send((err) => {
      if (err) {
          console.log('[JPush fail]', err.message);
      }
    });
  } else {
    sendSms(requestJSON).then(result => {
      if (result.data.error_response) {
        // 若短信发送失败，呵呵达
        console.log('[SMS ERROR]', result.data.error_response);
      }
    });
  }
}

export function sendNotiAndSms(pushId, message, requestJSON) {
  if (pushId) {
    client.push().setPlatform(JPush.ALL)
    .setAudience(JPush.registration_id(pushId))
    .setNotification(message)
    .send((err) => {
      if (err) {
          console.log('[JPush fail]', err.message);
      }
    });
  }
  if (process.env.NODE_ENV === 'production') {
    sendSms(requestJSON).then(result => {
      if (result.data.error_response) {
        // 若短信发送失败，呵呵达
        console.log('[SMS ERROR]', result.data.error_response);
      }
    });
  }
}

export function sendNoti(pushId, message) {
  if (pushId) {
    client.push().setPlatform(JPush.ALL)
    .setAudience(JPush.registration_id(pushId))
    .setNotification(message)
    .send((err) => {
      if (err) {
          console.log('[JPush fail]', err.message);
      }
    });
  }
}

// legacy
export function regVerifyStr(name, code) {
  return `${name}您的注册验证码为${code}，1小时有效。${name}团队欢迎您的加入！`;
}

export function verifyStr(mobile, code, ip) {
  return JSON.stringify({
    context: {
      code
    },
    template_id: 277,
    signature_id: 410,
    mobile,
    device_id: ip,
    device_limit: 50,
    device_limit_in_time: 60 * 60 * 24,
    domain: 'register'
  });
}

export function takeTaskStr(mobile, username) {
  return JSON.stringify({
    context: {
      user: username || '某位同学',
      link: 'https://taskbee.cn'
    },
    template_id: 278,
    signature_id: 410,
    mobile
  });
}

export function taskerCompleteStr(mobile, username) {
  return JSON.stringify({
    context: {
      user: username || '某位同学',
      link: 'https://taskbee.cn'
    },
    template_id: 1825,
    signature_id: 410,
    mobile
  });
}

export function taskerAbandonStr(mobile, username) {
  return JSON.stringify({
    context: {
      user: username || '某位同学',
      link: 'https://taskbee.cn'
    },
    template_id: 1826,
    signature_id: 410,
    mobile
  });
}

export function hasNotifications(mobile, username, count) {
  return JSON.stringify({
    context: {
      user: username || 'Hi',
      link: 'https://taskbee.cn',
      count,
    },
    template_id: 1827,
    signature_id: 410,
    mobile
  });
}

export function hasRedPocket(mobile, username, code) {
  return JSON.stringify({
    context: {
      user: username || 'Hi',
      link: 'https://taskbee.cn',
      code,
    },
    template_id: 1844,
    signature_id: 410,
    mobile
  });
}
export function hasRedPocketNew(mobile, code) {
  return JSON.stringify({
    context: {
      link: 'https://taskbee.cn',
      code,
    },
    template_id: 1872,
    signature_id: 410,
    mobile
  });
}

export function girlSms(mobile, name) {
  return JSON.stringify({
    context: {
      name,
      link: '欢迎下载安卓及iOSv1.9版本 https://taskbee.cn/ ',
    },
    template_id: 3218,
    signature_id: 410,
    mobile
  });
}

