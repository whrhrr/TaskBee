import crypto from 'crypto';
import debugFunc from 'debug';
const debug = debugFunc('utils:aliSign');

export default class aliSign {
  constructor ({appKey, appSecret}) {
    this.appKey = appKey;
    this.appSecret = appSecret;
  }

  sign(obj) {
    // 签名当前object
    // 返回一个新的obj
    // 增加timestamp、key、serect参数
    const time = new Date();
    const timestamp = time.getFullYear()  + "-" +
      ("0" + (time.getMonth() + 1)).slice(-2) + "-" +
      ("0" + time.getDate()).slice(-2) + ' '  +
      ("0" + time.getHours()).slice(-2)   + ":" +
      ("0" + time.getMinutes()).slice(-2) + ":" +
      ("0" + time.getSeconds()).slice(-2);

    const newObj = {
      ...obj,
      timestamp,
      app_key: this.appKey,
      format: 'json',
      v: '2.0',
      sign_method: 'hmac'
    };

    const signStr = Object.keys(newObj).sort().reduce((prev, curr) =>
      prev + curr + newObj[curr]
      , '');
    debug(signStr);
    // 签名(必须指定utf8 string)妈个鸡
    const sign =  crypto.createHmac('md5', this.appSecret).update(signStr, 'utf8').digest('hex').toUpperCase();
    debug(sign);
    newObj.sign = sign;
    return newObj;
  }
}
