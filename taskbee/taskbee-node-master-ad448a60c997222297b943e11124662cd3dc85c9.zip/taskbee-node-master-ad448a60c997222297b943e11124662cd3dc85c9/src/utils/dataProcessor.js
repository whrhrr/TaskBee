import {User} from '../models/index';

// 为了减少内存消耗，这里使用了mutate的方法，请注意
export default async function determineFav(tasks, userId) {
  const user = await User.findById(userId, {_id: 0, taskFav: 1}).lean().exec();
  const {taskFav} = user;
  for (let j = 0; j < tasks.length && taskFav.length > 0; j++) {
    const task = tasks[j];
    for (let i = 0; i < taskFav.length; i++) {
      if (taskFav[i].equals(task._id)) {
        task.faved = true;
        taskFav.splice(i, 1); // 移除这个fav，已减少判断次数
        break;
      }
    }
  }
}
