import gaychat from 'wechat';
import express from 'express';
let router = express.Router();

const config = {
  token: 'jiongjubu!@#$',
  appid: 'wxfffba96f903dfd21'
};

let lastMessages = [];

router.use('/wechat', gaychat(config, function (req, res, next) {

  let message = req.weixin;
  console.log(message);
  if (message.Content&&message.Content.length){
    if (lastMessages.length===5){
      lastMessages = lastMessages.slice(1);
    }
    lastMessages.push(message.Content);
  }
  switch (message.MsgType){
    case 'event':
      res.reply([
        {
          title: '有什么发生了？？？',
          description: '在这里会显示上5条用户的发言',
        },
      ]);
      break;
    default:
      if(lastMessages.length){
        res.reply(lastMessages.map((content) => {
          return {
            title: content,
          };

        }));
      }

      break;
  }
}));

export default router;
