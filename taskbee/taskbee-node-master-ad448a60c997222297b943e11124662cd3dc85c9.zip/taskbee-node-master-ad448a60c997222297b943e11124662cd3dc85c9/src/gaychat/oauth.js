import config from '../config';
import oauth from 'wechat-oauth';
import express from 'express';
let router = express.Router();
const client = new oauth(config.appId, config.appSecret);


router.get('/', (req, res) => {
  let url = client.getAuthorizeURL('http://heart.tianyu.xyz/api/gayauth/gayauth', '1', 'snsapi_userinfo');
  console.log('redirect url');
  res.redirect(url);
});



router.get('/gayauth', (req, res) => {
  console.log('gaychat oauth');
  let code = req.query.code;

  let resultA;
  client.getAccessToken(code , (err, result) => {
    console.log('got token', err || result);
    resultA = result;
    client.getUser(result.data.openid, (err, result) => {
      console.log('got user', err || result);
      resultA = result;
      res.end(
        Object.keys(result).map((key)=> {
          return `${key} : ${result[key]} \n`
        }).reduce((prev, next) => prev + next)
      )
    });
  });
  //res.end('ooooops');
});

export default router;