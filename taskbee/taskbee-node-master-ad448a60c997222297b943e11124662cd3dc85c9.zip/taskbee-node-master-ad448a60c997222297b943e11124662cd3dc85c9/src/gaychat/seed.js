import gaypi from './api';

const menu = {
  "button":[
    {
      "type":"view",
      "name":"进入心途",
      "url":"http://heart.tianyu.xyz/"
    },
    {
      "name":"菜单",
      "sub_button":[
        {
          "type":"view",
          "name":"搜索",
          "url":"http://www.soso.com/"
        },
        {
          "type":"click",
          "name":"赞一下我们",
          "key":"V1001_GOOD"
        }]
    }]
};

if(false){  //control seed
  gaypi.getRecords({
    "starttime" : 123456789,
    "endtime" : 987654321,
    "pagesize" : 10,
    "pageindex" : 1,
  }, (err, result) => {
    console.log('getRecords', err||result);
  });

  gaypi.createMenu(menu, (err, result) => {
    console.log('createMenu', err||result);
  });

  gaypi.getFollowers((err, result) => {
    console.log('getFollowers', err||result);
  });
}

export default 0;