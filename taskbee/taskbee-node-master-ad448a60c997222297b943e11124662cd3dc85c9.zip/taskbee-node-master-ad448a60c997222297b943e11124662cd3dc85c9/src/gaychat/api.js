import gaypi from 'wechat-api';
import config from '../config';
export default new gaypi(config.appId, config.appSecret)
//WATCH OUT!!!! secret in code