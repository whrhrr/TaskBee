//controllers for socketio
import {Message, User, SysMessage} from '../models/index';
import debugFunc from 'debug';
import Errors from 'throw.js';
import wrap from '../utils/wrap';
import * as check from '../utils/check';
import {userMap, sendTo} from '../socket';
import {sendNoti, sendNotiWithFallba} from '../utils/sms';

const debug = debugFunc('socket-middleware:message');

export function send(socket) {
  return wrap(async function(data, callback) {
    try {
      debug(data);
      let {message} = data;
      const {to} = data;
      message = message.trim();
      const {id: from} = socket.user;
      debug(userMap, to, from);

      if (!to) {
        // return sendTo(userMap[from], {message: })
        throw new Errors.notAcceptable('请指定发信人');
      }
      if (to === from) {
        throw new Errors.notAcceptable('不能发给自己');
      }
      if (!check.message(message)) {
        throw new Errors.notAcceptable('没有消息或者消息太长');
      }
      let storeMessage;
      const createdAt = Date.now();
      if (userMap[to]) {
        storeMessage = new Message({
          from,
          to,
          message,
          createdAt,
          hasRead: true
        });
        // 发送给接收者
        sendTo(to, {from, message, createdAt});
      } else {
        storeMessage = new Message({
          from,
          to,
          message,
          createdAt
        });
        // 用户不在线辣！ 发提醒！
        const user = await User.findOne({_id: to}, {pushId: true, lastNotiTime: true}).lean().exec();
        if (user && user.pushId && (createdAt - user.lastNotiTime > 60 * 1000 * 60)) { // 1小时推送一次
          const count = await Message.find({
            to: user._id,
            hasRead: false
          }).count();
          sendNoti(user.pushId, '有收到' + (count + 1) + '新私信，来看看嘛~');
          User.update({_id: user._id}, {$set: {lastNotiTime: createdAt}}).exec();
        }
      }
      callback({statusCode: 200, to, message, createdAt});
      await storeMessage.save();
    } catch (ex) {
      callback(ex);
    }
  });
}

export function getNew(socket) {
  return wrap(async function getNewAsync(data, callback) {
    debug('getNew', data);
    const {id} = socket.user;
    const messages = await Message.find({
      to: id,
      hasRead: false
    }, {from: true, message: true, to: true, createdAt: true}).lean().exec();
    if (messages.length) {
      // 让我们手动来populate，返回独立的用户数据
      const userSet = new Set();
      const messageIds = [];
      messages.forEach( msg => {
        userSet.add(msg.from.toString());
        messageIds.push(msg._id);
        delete msg._id;
      });
      const users = await User.find({_id: {$in: [...userSet]} }, {avatar: true, username: true, gender: true}).lean().exec();
      callback({result: {messages, users}} );
      await Message.update({_id: {$in: messageIds}}, {$set: {hasRead: true}}, {multi: true} ).exec();
    } else {
      callback({result: null});
    }
  });
}

export function getNewSystem(socket) {
  return wrap(async function getNewSystemAsync(data, callback) {
    debug('getNewSys', data);
    const {id} = socket.user;
    const messages = await SysMessage.find({
      to: id,
      hasRead: false
    }).sort({_id: -1}).lean().exec();
    if (messages.length) {
      callback({data: messages} );
      const messageIds = messages.map( message => message._id);
      await SysMessage.update({_id: {$in: messageIds}}, {$set: {hasRead: true}}, {multi: true} ).exec();
    } else {
      callback({data: []});
    }
  });
}
