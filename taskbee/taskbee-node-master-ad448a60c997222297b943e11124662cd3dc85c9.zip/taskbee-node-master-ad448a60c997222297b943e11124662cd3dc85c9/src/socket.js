import socketIo from 'socket.io';
import debugFunc from 'debug';
import jwt from 'jsonwebtoken';
import {SECRET} from './config';
import * as messageMiddlewares from './middlewares/socket-message';

const debug = debugFunc('socket:base');
const userMap = Object.create(null);

const io = socketIo({path: '/ws'});
io.on('connection', (socket) => {
  debug('[socket]on connection');
  // websocket用户登录
  socket.auth = false;
  setTimeout(() => {
    if (!socket.auth) {
      debug('长时间没有登陆，断线 %s', socket.id);
      socket.disconnect('unauthorized');
    }
  }, 1000 * 24);

  socket.on('bearer', (data) => {
    // if (socket.auth) return;
    debug('[socket]on bearer');
    jwt.verify(data, SECRET, (err, decoded) => {
      if (err) {
        socket.emit('bearer', {message: '验证出错', data: err, errorCode: -1}, () => {
          debug('unauthorized');
          socket.disconnected('unauthorized');
        });
      } else {
        debug('decoded', decoded);
        const {id: userId} = decoded;
        if (!userId) {
          socket.emit('bearer', {message: '没有id', errorCode: -1}, () => {
            socket.disconnected('unauthorized');
          });
        }
        userMap[userId] = socket.id;
        socket.user = decoded;
        socket.auth = true;
        socket.emit('bearer', {data: true});
      }
    });
  });

  socket.on('disconnect', () => {
    debug('[socket]disconnect');
    if (socket.user) delete userMap[socket.user.id];
  });

  // 客户端发送
  socket.on('message', messageMiddlewares.send(socket));
  // 客户端请求新消息
  socket.on('getNew', messageMiddlewares.getNew(socket));
  socket.on('getNewSystem', messageMiddlewares.getNewSystem(socket));
  /*
   socket路由
   {from, to, content}
  */
  socket.on('error', function(err) {
    debug('error', err);
  });
});

// 先发送，不管收没收到
export function sendTo(userId, data) {
  debug('sendTo called');
  io.to(userMap[userId]).emit('message', data);
}

// 发送任务状态变动的信息
export function sendStatus(userId, data) {
  debug('sendStatus called');
  io.to(userMap[userId]).emit('status', data);
}

// 发送系统消息
export function sendSysMessage(userId, innerData) {
  debug('sendSystem called');
  io.to(userMap[userId]).emit('sysMessage', {
    statusCode: 200,
    data: innerData,
  });
}


export function isOnline(userId) {
  debug('userMap', userMap);
  return userMap[userId] !== undefined;
}

export default io;
export {userMap};
