import mongoose from 'mongoose';
const {Schema} = mongoose;

const pollen = new Schema({
  postId: {
    type: Schema.Types.ObjectId,
    ref: 'Post',
    index: true,
  }, // 花粉对应的状态
  left: {
    type: Number,
    index: true,
  }, // 花粉剩余被采集数量
  type: {
    type: Number,
    default: 0,
    index: true,
  },
  /*
    0 - 原创报道的
    1 - 转发的花粉
    2 - ? 还没想好
  */
  from: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    index: true,
  }, // 转发或发布的
  createdAt: {
    type: Date
  },
  loc: {
    type: {type: String, enum: 'Point', default: 'Point'},
    coordinates: { type: [Number], default: [121.2103, 31.28826]},
  },
  takers: {
    type: [
      {
        type: Schema.Types.ObjectId,
        ref: 'User',
      }
    ],
    index: true,
  },
  spreaders: {
    type: [
      {
        type: Schema.Types.ObjectId,
        ref: 'User',
      }
    ],
  }

});

pollen.index({loc: '2dsphere'});

export default mongoose.model('Pollen', pollen);
