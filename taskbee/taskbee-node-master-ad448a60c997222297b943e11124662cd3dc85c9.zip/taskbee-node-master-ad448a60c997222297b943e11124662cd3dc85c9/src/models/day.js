import mongoose from '../db';

let daySchema = mongoose.Schema({
  day: { type: Number, index: true },
  text: String,
  date: Number
});

daySchema.methods.write = (text) =>{
  this.text = text;
};

daySchema.index({day: 1});

let Day = mongoose.model('Day', daySchema);
export default Day;

const INIT_DATE = (new Date(2013,4,24)).getTime(); //GMT +8
const DAY_SPAN = 1000*60*60*24;
/*

 Init data

 */
async function setDays(){
  console.log('update database');
  let now = Date.now();
  const currentTime = now - now % DAY_SPAN;

  let lastDate;
  try{
    lastDate = await Day.findOne().sort({ field: 'asc', day: -1 }).limit(1);
  }
  catch (err){
    console.log('fucking', err);
  }

  let initDate, i;
  if(lastDate){
    initDate = lastDate.date + DAY_SPAN;
    i = lastDate.day + 1;
  }
  else{
    initDate = INIT_DATE;
    i = 1;
  }
  let days = (currentTime - initDate) / DAY_SPAN + 1;
  console.log(days);
  for(let j=0; j<days; j++){
    console.log('new day: ', j+i);
    let day = new Day({
      day: j+i,
      text: '',
      date: initDate + j * DAY_SPAN
    });
    day.save()
    .then(() => {
        //saved
      })
    .catch((err) =>{
      console.log(err);
    });
  }

}

setDays();


setInterval(setDays, 1000 * 60 * 5);