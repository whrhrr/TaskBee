import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import debugFunc from 'debug';
const debug = debugFunc('models:user');
const {Schema} = mongoose;

const userSchema = new Schema({
  // 手机号码
  phone: {
    type: String,
    unique: true,
    index: true
  },
  // 用户名 最长10字符
  username: {
    type: String,
    index: true,
    unique: true
  },
  // 密码
  password: {
    type: String,
    select: false
  },
  /* 邮箱不用了
  email: {
    type: String,
    unique: true
  },
  */
 /*
  男 0
  女 1
  其他 2
  */
  gender: {
    type: Number,
    default: 0
  },
  avatar: String,
  telephone: String,
  realname: String,
  signature: {
    type: String,
    default: ''
  },
  wechatId: String,
  schoolId: {
    type: Number,
    default: 0
  },
  score: {
    type: Number,
    default: 5,
  },
  money: {
    type: Number,
    default: 0
  },
  // 发布的任务（限定最大数量）
  taskPublish: [{type: Schema.Types.ObjectId, ref: 'Task'}],
  /*
  countPublish: {
    type: Number,
    default: 0
  },
  */
  // 接受的任务
  taskTaken: [{type: Schema.Types.ObjectId, ref: 'Task'}],
  /*
  countTaken: {
    type: Number,
    default: 0
  },
  */
  // 我收藏的任务，就直接堆再这里把
  taskFav: [{type: Schema.Types.ObjectId, ref: 'Task'}],
  countFav: {
    type: Number,
    default: 0
  },
  // 接受的任务总数（显示公共个人信息）
  countTotalTaken: {
    type: Number,
    default: 0
  },
  // 发布的任务总数（显示公共个人信息）
  countTotalPublish: {
    type: Number,
    default: 0
  },
  // 用户评价
  voteScore: {
    type: Number,
    default: 0,
  },
  voteCount: {
    type: Number,
    default: 0,
  },

  /*
    签到
   */
  signCount: {
    type: Number,
    default: 0,
  },
  signTime: {
    type: Date
  },

  /*
    用户位置
   */
  loc: {
    type: {type: String, enum: 'Point', default: 'Point'},
    coordinates: { type: [Number], default: [121.2103, 31.28826]},
  },
  /*
    好友
   */
  friends: {
    type: [
      {type: String, ref: 'User'}
    ],
    default: [],
  },

  liked: {
    type: [
      {type: String, ref: 'User'}
    ],
    default: [],
  },

  likedCount: {
    type: Number,
    default: 0,
  },

  /*
    用户收集的花粉！
  */
  pollens: [{
    type: Schema.Types.ObjectId, ref: 'Pollen'
  }],

  // 读过的消息
  readPost: [{
    type: Schema.Types.ObjectId,
  }],

  /*
    账号类型
    0 - 普通用户
    1 - 社团用户
    2 - 官方账号
  */

  accountType: {
    type: Number,
    default: 0,
  },

  // App推送消息记录ID
  pushId: String,

  /*
    暂时的短信消息提醒的东西
  */

  // 发送烦人提醒
  lastNotiTime: { // 记录上次发送数量提醒的时间 （两种提醒： 系统消息以及私信总数提醒；私信数提醒）
    type: Number
  },
  // 提醒创建时间记录
  lastNotiCreatedTime: {
    type: Number
  },
});

userSchema.pre('save', function hashPassword(next) {
  // this对应着userSchema,所以这里不能用=>
  debug(this.isModified('password'));
  if (this.isModified('password') || this.isNew) {
    bcrypt.genSalt(10, (err, salt) => {
      if (err) {
        return next(err);
      }
      debug('start hash');
      bcrypt.hash(this.password, salt, (errBcrypt, hash) => {
        if (errBcrypt) {
          return next(errBcrypt);
        }
        this.password = hash;
        next();
      });
    });
  } else {
    return next();
  }
});

userSchema.methods.comparePassword = function(passw) {
  return new Promise((solve, reject) => {
    // this 对应user
    bcrypt.compare(passw, this.password, (err, isMatch) => {
      if (err) {
        debug('compare password error');
        reject(err);
      }
      solve(isMatch);
    });
  });
};

const userModel = mongoose.model('User', userSchema);
userSchema.methods.exist = function(userId) {
  return userModel.count({_id: userId}, {limit: 1}).exec();
};
export const projectionBriefUser = {username: true, avatar: true, score: true, gender: true};
export const projectionVeryBriefUser = {username: true, avatar: true, gender: true};
export const projectionExcludeUser = {wechatId: false, pollens: false, password: false, readPost: false, liked: false, friends: false};

export default userModel;
