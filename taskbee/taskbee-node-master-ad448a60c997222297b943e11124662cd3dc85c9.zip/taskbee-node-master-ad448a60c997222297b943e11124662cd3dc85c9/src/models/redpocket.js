import mongoose from 'mongoose';
const {Schema} = mongoose;

const redpocketSchema = new Schema({
  title: String, // 红包文字
  price: Number, // 红包价格
  state: {
    type: Number, // 红包状态
    default: 0,
    index: true,
  },
  /*
  0 - 未兑换
  1 - 已经兑换
   */
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    index: true,
  },
  limitPhone: {
    type: String,
  }
});

export default mongoose.model('Redpocket', redpocketSchema);
