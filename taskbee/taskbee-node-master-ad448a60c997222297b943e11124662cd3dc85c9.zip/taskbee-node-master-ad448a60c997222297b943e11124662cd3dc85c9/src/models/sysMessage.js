// 暂时不需要
import mongoose from 'mongoose';
const {Schema} = mongoose;

const sysMessageSchema = new Schema({
  to: {type: Schema.Types.ObjectId, ref: 'User', index: true},
  message: String,
  href: String, // 跳转到的地方 不包含类型的路径
  type: String, // 系统消息的类型
  /*
    pollen - 花粉
   */
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 60 * 60 * 24 * 180 //7天后自动删除
  },
  hasRead: {
    type: Boolean,
    default: false,
    index: true
  }
});

export default mongoose.model('SysMessage', sysMessageSchema);
