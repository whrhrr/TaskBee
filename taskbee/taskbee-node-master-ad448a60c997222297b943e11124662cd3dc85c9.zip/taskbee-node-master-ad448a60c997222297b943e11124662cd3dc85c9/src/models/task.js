import mongoose from 'mongoose';
const {Schema} = mongoose;

import commentSchema from './comment';

const taskSchema = new Schema({
  description: String,
  secret: {
    type: String
  },
  startTime: {
    type: Date,
    default: Date.now
  },
  dueTime: {
    type: Date,
    default: Date.now,
    index: true // 超时修改state
  },
  // 金钱奖励 需要index
  reward: {
    type: Number,
    default: 0,
    index: true
  },
  takeTime: {
    type: Date
  },
  taskerConfirmTime: {
    type: Date
  },
  finishTime: {
    type: Date,
    index: true // 显示已完成的任务一段时间
  },

  // 任务标签
  tags: [{type: String, index: true}],
  /*
    阶段 需要index
    0 等待
    1 已被抢单
    2 接单者完成
    3 已完成
    4 超时
    5 发布者取消
    6 等待审核
   */
  state: {
    type: Number,
    default: 0,
    index: true
  },
  // 任务所在校区 （目前就嘉定）
  school: {
    type: Number,
    index: true,
    default: 0
  },
  // 任务发布人
  publisher: {type: Schema.Types.ObjectId, ref: 'User'},
  // 任务进行人
  tasker: {type: Schema.Types.ObjectId, ref: 'User'},
  historyTaskers: [{type: Schema.Types.ObjectId, ref: 'User'}],
  favs: {
    type: Number,
    default: 0,
  },
  // 被点赞的
  favBy: [{type: Schema.Types.ObjectId, ref: 'User'}],
  // 可以进行评分的人
  canVote: [{type: Schema.Types.ObjectId, ref: 'User'}],
  // 可以进行惩罚的人
  canPunish: [{type: Schema.Types.ObjectId, ref: 'User'}],
  // 查看了任务的人
  // visited: [{type: Schema.Types.ObjectId, ref: 'User'}],
  // 给分数投票的人
  // voted: [{type: Schema.Types.ObjectId, ref: 'User'}]
  // 地理位置，不在本阶段中
  comments: [commentSchema],
  commentCount: {type: Number, default: 0},
  visits: {
    type: Number,
    default: 0
  },
  imgs: {type: Array, default: []},
  loc: {
    type: {type: String, enum: 'Point', default: 'Point'},
    coordinates: { type: [Number], default: [121.2103, 31.28826]},
  },
  /*
   任务类型
   0 - 普通任务
   1 - 活动
  */
  type: {
    type: Number,
    default: 0,
  },
  /*
    参与者
   */
  involves: [{type: String, ref: 'User'}],
});

taskSchema.index({loc: '2dsphere'});

export default mongoose.model('Task', taskSchema);

export const projectionBrief = {
  publisher: true,
  description: true,
  // tags: true,
  state: true,
  reward: true,
  dueTime: true,
  startTime: true,
  tasker: true,
  loc: true,
  imgs: true,
  favs: true,
  type: true,
  commentCount: true,
};

export const projectionTaskDetail = {
  canPunish: false,
  historyTaskers: false,
  tags: false,
  secrete: false,
  favBy: {$slice: -30},
};

export const projectionTaskDetailWithSecret = {
  ...projectionTaskDetail,
  secrete: false,
  favBy: {$slice: -30},

};
