import mongoose from 'mongoose';
const {Schema} = mongoose;

const messageSchema = new Schema({
  from: {type: Schema.Types.ObjectId, ref: 'User', index: true},
  to: {type: Schema.Types.ObjectId, ref: 'User', index: true},
  message: String,
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 60 * 60 * 24 * 180 // 180天后自动删除
  },
  hasRead: {
    type: Boolean,
    default: false,
    index: true
  }
});

export default mongoose.model('Message', messageSchema);
