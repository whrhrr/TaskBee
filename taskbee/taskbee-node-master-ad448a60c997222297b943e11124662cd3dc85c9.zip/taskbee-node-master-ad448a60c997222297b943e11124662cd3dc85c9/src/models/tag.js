import mongoose from 'mongoose';
const {Schema} = mongoose;

let tagSchema = new Schema({
  name: {
    type: String,
    index: true,
    unique: true
  },
  default: {
    type: Boolean,
    default: false
  },
  count: {
    type: Number,
    default: 0,
    index: true,
  }
});

export default mongoose.model('Tag', tagSchema);
