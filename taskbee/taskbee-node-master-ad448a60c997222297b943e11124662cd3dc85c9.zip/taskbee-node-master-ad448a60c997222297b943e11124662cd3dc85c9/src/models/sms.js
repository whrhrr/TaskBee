import mongoose from 'mongoose';
const {Schema} = mongoose;
import debugFunc from 'debug';
const debug = debugFunc('model:sms');

let smsSchema = new Schema({
  phone: {
    type: String,
    uniqe: true,
    index: true
  },
  code: String,
  genAt: {
    type: Date,
    default: Date.now
  },
  lastAt: {
    type: Date,
    default: Date.now
  },
  sendCount: {
    type: Number,
    default: 0
  },
  requestCount: {
    type: Number,
    default: 0 //test
  }
});

smsSchema.statics.genCode = function() {
  let random = Math.floor(Math.random() * 100000).toString();
  random = '0'.repeat(5 - random.length) + random;
  debug('Code:' + random);
  return random;
};


export default mongoose.model('Sms', smsSchema);