import mongoose from 'mongoose';
const {Schema} = mongoose;

const withdrawSchema = new Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    index: true,
  },
  price: Number, // 价格
  createdDate: {
    type: Date, // 订单创建时间
    default: Date.now,
  },
  email: {
    type: String, // 付款邮箱
  },
  realname: {
    type: String,
  },
});

export default mongoose.model('Withdraw', withdrawSchema);
