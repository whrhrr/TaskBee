import mongoose from 'mongoose';
const {Schema} = mongoose;

import commentSchema from './comment';

const postSchema = new Schema({
  content: String,
  from: {type: Schema.Types.ObjectId, ref: 'User'},
  imgs: { type: Array, default: [] },
  readers: {
    type: [
      {type: String, ref: 'User'}
    ],
    index: true,
  },
  readerCount: {
    type: Number,
    default: 0,
  },
  spreadCount: {
    type: Number,
    default: 0,
    index: true,
  },
  spreadBy: [{type: Schema.Types.ObjectId, ref: 'User'}],
  comments: [commentSchema],
  commentCount: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    index: true,
  },
  loc: {
    type: {type: String, enum: 'Point', default: 'Point'},
    coordinates: { type: [Number], default: [121.2103, 31.28826]},
  },
  involves: [{type: String, ref: 'User'}],
});

export const projectionBriefPost = {
  loc: true,
  content: true,
  from: true,
  imgs: true,
  readerCount: true,
  commentCount: true,
  createdAt: true,
  spreadCount: true,
};

export const projectionDetailPost = {
  loc: true,
  content: true,
  from: true,
  imgs: true,
  readerCount: true,
  commentCount: true,
  comments: true,
  createdAt: true,
  spreadCount: true,
  spreadBy: {$slice: -30},
};

export default mongoose.model('Post', postSchema);
