import mongoose from 'mongoose';
const {Schema} = mongoose;

const voteSchema = new Schema({
  user: {type: Schema.Types.ObjectId, ref: 'User', index: true},
  from: {type: Schema.Types.ObjectId, ref: 'User'},
  message: String,
  score: Number,
  type: Boolean, // true - tasker / false - publisher
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.model('Vote', voteSchema);
