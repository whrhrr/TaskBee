import mongoose from 'mongoose';
const {Schema} = mongoose;

export default new Schema({
  from: {type: Schema.Types.ObjectId, ref: 'User'},
  to: {type: Schema.Types.ObjectId, ref: 'User'},
  body: String,
  date: {
    type: Date,
    default: Date.now
  }
});
