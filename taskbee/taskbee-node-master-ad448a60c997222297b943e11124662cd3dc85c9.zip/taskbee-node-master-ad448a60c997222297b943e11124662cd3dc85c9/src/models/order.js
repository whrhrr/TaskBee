import mongoose from 'mongoose';
const {Schema} = mongoose;

const orderSchema = new Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    index: true,
  },
  title: String, // 订单名称
  price: Number, // 价格
  state: {
    type: Number, // 订单状态
    default: 0,
    index: true,
  },
  createdDate: {
    type: Date, // 订单创建时间
    default: Date.now,
  },
  email: {
    type: String, // 付款邮箱
  },
  tradeNo: {
    type: String,
  },
});

export default mongoose.model('Order', orderSchema);

/*

各种状态 根据notify
TRADE_FINISHED  交易完成  true（触发通知）
TRADE_SUCCESS 支付成功  true（触发通知）
WAIT_BUYER_PAY  交易创建  true（触发通知）
TRADE_CLOSED  交易关闭  true（触发通知）

 */


/*
state:
0 - 订单在数据库中创建
1 - WAIT_BUYER_PAY
2 - WAIT_SELLER_SEND_GOODS ( 由TRADE_SUCCESS触发）
3 - WAIT_BUYER_CONFIRM_GOODS （由TRADE_FINISHED触发）
4 - TRADE_FINISHED
5 - TRADE_CLOSED
*/
