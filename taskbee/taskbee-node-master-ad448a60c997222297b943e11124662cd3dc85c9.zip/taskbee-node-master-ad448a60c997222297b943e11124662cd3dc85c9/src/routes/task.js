import express from 'express';
import auth, {authUser, authOrNot} from '../middlewares/auth';
import * as taskController from '../controllers/task';
import bodyParser from 'body-parser';
const jsonParser = bodyParser.json();
const urlParaser = bodyParser.urlencoded({
  extended: true
});
import cookieParser from '../middlewares/cookie';

const router = express.Router();

router.post('/create', auth, authUser, jsonParser, taskController.create);
router.post('/createEvent', auth, authUser, jsonParser, taskController.createEvent);
router.post('/passEvent', jsonParser, taskController.passEvent);
router.post('/take', auth, authUser, jsonParser, taskController.take);
router.post('/confirmTasker', auth, authUser, jsonParser, taskController.confirmTasker);
router.post('/confirmPuber', auth, authUser, jsonParser, taskController.confirmPuber);
router.post('/cancelTasker', auth, authUser, jsonParser, taskController.cancelTasker);
router.post('/cancelPuber', auth, authUser, jsonParser, taskController.cancelPuber);
router.post('/fav', auth, authUser, jsonParser, taskController.fav);
router.post('/unFav', auth, authUser, jsonParser, taskController.unFav);
router.post('/newComment', auth, authUser, jsonParser, taskController.newComment);
router.post('/vote', auth, authUser, jsonParser, taskController.vote);


// router.post('/report', auth, authUser, jsonParser, taskController.report);

/*
  Getters
 */
router.get('/tasks', cookieParser, authOrNot, taskController.getTasks);
router.get('/taskDetail', cookieParser, authOrNot, taskController.getTaskDetail);

// router.get('/timeout', taskController.timeoutTasks);
router.post('/notify/:postId', urlParaser, taskController.notify);


export default router;
