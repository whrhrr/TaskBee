import express from 'express';
import * as orderController from '../controllers/order';
import * as redpocketController from '../controllers/redpocket';
import bodyParser from 'body-parser';
import auth, {authUser, authOrNot} from '../middlewares/auth';
import cookieParser from '../middlewares/cookie';
const jsonParser = bodyParser.json();

const router = express.Router();
router.post('/create', auth, authUser, jsonParser, orderController.startOrder);
router.post('/withdraw', auth, authUser, jsonParser, orderController.withdraw);
router.post('/redpocket', auth, authUser, jsonParser, redpocketController.openPocket);

router.get('/orders', cookieParser, auth, authUser, orderController.getOrders);
router.get('/withdraws', cookieParser, auth, authUser, orderController.getWithdraws);
router.get('/orderDetail', cookieParser, auth, authUser, orderController.getOrderDetail);


// test only
router.post('/createPockeshit', jsonParser, redpocketController.createPocket);
router.post('/createLimitPockeshit', jsonParser, redpocketController.createLimitPocket);
router.post('/getAllPockeshits', jsonParser, redpocketController.getAllPockets);

export default router;
