import express from 'express';
import * as eventController from '../controllers/event';
import bodyParser from 'body-parser';
const jsonParser = bodyParser.json();

const router = express.Router();
router.post('/giveEvent', jsonParser, eventController.giveEvent);
router.post('/confirmTask', jsonParser, eventController.confirmTask);
router.post('/cancelTask', jsonParser, eventController.cancelTask);

export default router;
