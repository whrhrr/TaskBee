import express from 'express';
import * as miscController from '../controllers/misc';
import bodyParser from 'body-parser';
const jsonParser = bodyParser.json();
import cookieParser from '../middlewares/cookie';
import {authOrNotCookie} from '../middlewares/auth';

import auth, {authUser} from '../middlewares/auth';

const router = express.Router();
router.post('/feedback', cookieParser, authOrNotCookie, jsonParser, miscController.feedbackFunc);

router.post('/report', auth, authUser, jsonParser, miscController.report);


export default router;
