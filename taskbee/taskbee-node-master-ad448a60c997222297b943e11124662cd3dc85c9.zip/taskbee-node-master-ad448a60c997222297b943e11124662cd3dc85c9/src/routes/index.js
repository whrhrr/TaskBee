import express from 'express';
import user from './user';
import task from './task';
import tag from './tag';
import misc from './misc';
import order from './order';
import post from './post';
import event from './event';

const router = express.Router();

router.use('/user', user);
router.use('/task', task);
router.use('/tag', tag);
router.use('/misc', misc);
router.use('/order', order);
router.use('/post', post);
router.use('/event', event);

export default router;
