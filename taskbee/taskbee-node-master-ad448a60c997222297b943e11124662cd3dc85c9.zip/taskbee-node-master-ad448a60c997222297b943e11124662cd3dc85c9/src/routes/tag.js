import express from 'express';
import auth, {authUser} from '../middlewares/auth';
import * as tagController from '../controllers/tag';
import bodyParser from 'body-parser';
const jsonParser = bodyParser.json();

const router = express.Router();
router.post('/newTag', auth, authUser, jsonParser, tagController.newTag);
router.get('/getTags', tagController.getTags);
router.get('/getTagsMore', tagController.getTagsMore);

export default router;
