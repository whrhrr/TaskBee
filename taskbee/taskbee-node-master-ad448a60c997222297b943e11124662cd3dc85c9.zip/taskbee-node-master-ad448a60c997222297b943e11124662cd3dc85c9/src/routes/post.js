import express from 'express';
import auth, {authUser, authOrNot} from '../middlewares/auth';
import * as postController from '../controllers/post';
import bodyParser from 'body-parser';
import cookieParser from '../middlewares/cookie';

const jsonParser = bodyParser.json();
const urlParaser = bodyParser.urlencoded({
  extended: true
});
const router = express.Router();
router.post('/create', auth, authUser, jsonParser, postController.create);

router.post('/collect', auth, authUser, jsonParser, postController.collect);
router.post('/storage', auth, authUser, jsonParser, postController.storage);

router.post('/abandon', auth, authUser, jsonParser, postController.abandon);
router.post('/cast', auth, authUser, jsonParser, postController.cast);

router.post('/comment', auth, authUser, jsonParser, postController.newComment);

// router.post('/report', auth, authUser, jsonParser, postController.report);


router.get('/nearby', cookieParser, authOrNot, postController.getNearby);
router.get('/loadPost', postController.loadPost);
router.get('/loadPollen', postController.loadPollen);

router.get('/hotest', postController.hotestPost);




router.post('/notify/:postId', urlParaser, postController.notify);

export default router;
