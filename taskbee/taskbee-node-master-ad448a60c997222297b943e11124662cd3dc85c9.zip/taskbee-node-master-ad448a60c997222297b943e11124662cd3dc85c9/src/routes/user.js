import express from 'express';
import auth, {authCode, authUser, authOrNot, authOrNotCookie} from '../middlewares/auth';
import * as userController from '../controllers/user';
import bodyParser from 'body-parser';
import cookieParser from '../middlewares/cookie';
const jsonParser = bodyParser.json();
const urlParaser = bodyParser.urlencoded({
  extended: true
});
const router = express.Router();

router.post('/login', jsonParser, userController.login);
router.post('/getCode', jsonParser, userController.getCode);
router.post('/verifyCode', jsonParser, userController.verifyCode);
router.post('/register', auth, authCode, jsonParser, userController.register);
router.post('/newPassword', auth, authCode, jsonParser, userController.newPassword);
router.post('/changeSig', auth, authUser, jsonParser, userController.changeSig);
router.post('/changeName', auth, authUser, jsonParser, userController.changeName);
router.post('/changeGender', auth, authUser, jsonParser, userController.changeGender);
// router.post('/changeSchool', auth, authUser, jsonParser, userController.changeSchool);
router.post('/sign', auth, authUser, userController.sign);


router.post('/load', cookieParser, userController.load);
router.post('/logout', cookieParser, authOrNotCookie, userController.logout);

/*
  新蜂房
 */
router.post('/uploadAvatar', auth, authUser, userController.uploadAvatar);
router.post('/notify/:userId', urlParaser, userController.notify);

router.post('/like', auth, authUser, jsonParser, userController.like);
router.post('/unfriend', auth, authUser, jsonParser, userController.unfriend);

// 更新jpush
router.post('/setPushId', auth, authUser, jsonParser, userController.setPushId);

router.get('/test', userController.test);
router.get('/users', userController.getUsers);
// 判断该用户是否被喜欢过
router.get('/oneUser', userController.getOneUser);
router.get('/userDetail', cookieParser, authOrNotCookie, userController.getUserDetail);
router.get('/score', cookieParser, auth, authUser, userController.getScore);
router.get('/tasks', cookieParser, auth, authUser, userController.getTasks);
router.get('/tasksFav', cookieParser, auth, authUser, userController.getTasksFav);
router.get('/tasksHistory', cookieParser, auth, authUser, userController.getTasksHistory);
router.get('/friends', cookieParser, auth, authUser, userController.getFriends);

router.get('/myPollens', cookieParser, auth, authUser, userController.getMyPollens);


export default router;
