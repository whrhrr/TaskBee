import express from 'express';
import auth from '../middlewares/auth';
import * as messageController from '../controllers/message';
import bodyParser from 'body-parser';
const jsonParser = bodyParser.json();

cosnt router = express.Router();


router.post('/send', auth, jsonParser, messageController.send);


export default router;
