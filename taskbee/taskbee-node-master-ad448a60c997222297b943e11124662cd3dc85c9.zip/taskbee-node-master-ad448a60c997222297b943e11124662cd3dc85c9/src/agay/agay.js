import debugFunc from 'debug';
import express from 'express';
const debug = debugFunc('controllers:alinotify');
import Errors from 'throw.js';
import wrap from '../utils/wrap';
const router = express.Router();
import {verify, isFromAgay, sign} from '../utils/agaySign';
import bodyParser from 'body-parser';
const encodedParser = bodyParser.urlencoded({ extended: true });
import request from 'urllib';
import {Order, User} from '../models/index';
import * as check from '../utils/check';
import sendSms, {sendNoti} from '../utils/sms';

// todo
function confirmSent(tradeNo) {
  const feedId = sign({
    service: 'send_goods_confirm_by_platform',
    partner: '2088112817052311',
    _input_charset: 'utf-8',
    trade_no: tradeNo,
    logisitcs_name: '蜂房',
    transport_type: 'DIRECT',
  });
  const url = 'https://mapi.alipay.com/gateway.do';
  debug('confirm sent url', url);
  return request.request(url, {
    method: 'GET',
    data: feedId,
  });
}


/*
  [TODO]: 测试
 */
/*
  接手支付宝notify
 */
router.post('/notify', function(req, res, next) {
  req.headers['content-type'] = 'application/x-www-form-urlencoded';
  next();
}, encodedParser, wrap(async function getNotify(req, res, next) {
  debug(req.body);
  // ali notify body
  if (!req.body.sign || !req.body.sign_type || !req.body.notify_id) {
    console.log('[notify] malformed notify');
    return res.end('fail');
  }
  if (!verify(req.body)) {
    console.log('[notify] Wrong sign');
    return res.end('fail');
  }
  const veryNoti = await isFromAgay(req.body.notify_id);
  if (veryNoti.data.toString() !== 'true') {
    console.log('[notify] Invalide notify_id');
    return res.end('fail');
  }
  const {notify_type, trade_no, out_trade_no, trade_status, price} = req.body;
  if (notify_type === 'trade_status_sync') {
    // 交易notify
    if (!check.objectId(out_trade_no)) {
      console.log('[notify] malformed ID');
      return res.end('fail');
    }
    const order = await Order.findById(out_trade_no).exec();
    debug(order);
    if (!order) {
      console.log('[WIERED ORDER] Cant find order' + out_trade_no + '/' + trade_no);
      return res.end('fail');
    }
    switch (trade_status) {
    case 'WAIT_BUYER_PAY':
      if (order.state !== 1) {
        // 订单创建成功
        order.email = req.body.buyer_email;
        order.tradeNo = trade_no;
        order.state = 1;
        const newPrice = parseInt(price, 10);
        if (newPrice < order.price) {
          console.log('[WIERED ORDER] Price is lowered');
          order.price = newPrice; // 如果有人想改价格，没门
        }
        await order.save();
        return res.end('success');
      }
      else console.log('[WIERED ORDER] state 1');
      break;
    case 'WAIT_SELLER_SEND_GOODS':
      if (order.state !== 2 && order.tradeNo === trade_no) {
        // 先确认发货！
        let result = await confirmSent(trade_no);
        debug(result);
        result = result.data.toString();
        if (result.indexOf('<is_success>T') > 0) {
          order.state = 2;
          await order.save();
          return res.end('success');
        }
        console.log('[CONFRIM SEND FAILED]', result);
      } else console.log('[WIERED ORDER] state 2');
      break;
    case 'WAIT_BUYER_CONFIRM_GOODS':
      if (order.state !== 3 && order.tradeNo === trade_no) {
        // 等待买家确认收货了！ 这时候给钱包充值
        await User.update({_id: order.user}, {$inc: {money: order.price}});
        order.state = 3;
        await order.save();
        // 再发个推送吧
        const getUser = await User.findOne({_id: order.user}, {pushId: true});
        sendNoti(getUser.pushId, '已成功充值¥' + order.price);
        return res.end('success');
      } else console.log('[WIERED ORDER] state 3');
      break;
    case 'TRADE_FINISHED':
      if (order.state !== 4 && order.tradeNo === trade_no) {
        order.state = 4;
        await order.save();
        return res.end('success');
      } else console.log('[WIERED ORDER] state 4');
      break;
    case 'TRADE_CLOSED':
      if (order.state !== 5 && order.tradeNo === trade_no) {
        order.state = 5;
        await order.save();
        return res.end('success');
      } else console.log('[WIRED ORDER] state 5');
      break;
    default:
      console.log('[WIERED ORDER] UNKNOWN STATUS', req.body);
      break;
    }
  } else {
    // 其他notify_type
    console.log('[WIERED ORDER] UNKONW NOTIFY TYPE', req.body);
  }
  return res.end('fail');
}));

export default router;


/*
此接口只支持https请求；
请按照“签名及拿到签名结果”中的签名方法对输入参数进行签名，该接口请求才能够被支付宝系统接收；
在交易类型是支付宝担保交易时，如果交易状态是“买家已付款，等待卖家发货（交易状态参数trade_status值为WAIT_SELLER_SEND_GOODS）”的情况下确认发货接口才执行成功；如果交易状态不是“买家已付款，等待卖家发货”或“卖家已发货，等待买家确认”的情况下确认发货都将失败；
如果本交易为COD交易，则交易状态为“等待卖家发货”或者“等待买家签收付款”的情况下确认发货才执行成功；如果交易状态不是“等待卖家发货”或“等待买家签收付款”的情况下确认发货都将失败；
在担保交易或COD交易的接口中，如果设置了请求参数notify_url，那么执行了确认发货接口后，担保交易接口或COD交易接口的notify_url对应页面文件会收到支付宝的发货通知。具体通知内容根据对应接口的通知信息而定。
*/
