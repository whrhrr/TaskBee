import {Task, User, Message, SysMessage} from '../models/index';
import wrap from '../utils/wrap';
import {isOnline, sendSysMessage} from '../socket';
import sendSms, {sendNoti, sendNotiWithFallback, hasNotifications} from '../utils/sms';

export const expireTask = wrap(async function expireTask() {
  // 暂时只修改无人接单的任务！
  const tasks = await Task.find({ $or: [{state: 0}, {state: 6}], dueTime: {$lte: new Date()}}, { publisher: true, reward: true}).lean().exec();
  tasks.forEach( task => {
    User.update({_id: task.publisher}, {$pull: {taskPublish: task._id}, $inc: {score: 2, money: task.reward}}).exec();
    Task.update({_id: task._id}, {$set: {state: 4}}).exec();
    const to = task.publisher.toString();
    const sysMessage = new SysMessage({
      to,
      href: task._id.toString(),
      message: '有一个任务已经超时',
      type: 'task',
    });
    if (isOnline(to)) {
      sysMessage.hasRead = true;
      sendSysMessage(to, sysMessage);
    } else {
      User.findById(to, {pushId: true}).lean().exec().then(toUser => {
        sendNoti(toUser.pushId, sysMessage.message);
      });
    }
    sysMessage.save();
  });
});

export const countRemain = wrap(async function countRemain() {
  // 找到所有40小时前未提醒过的用户
  const users = await User.find({}, {pushId: true, lastNotiTime: true, lastNotiCreatedTime: true, phone: true, username: true}).lean().exec();
  console.log('Total users', users.length);
  users.forEach(async function (user) {
    try {
      const to = user._id;
      const counts = await Promise.all([
        Message.find({
          to,
          hasRead: false
        }).count(),
        SysMessage.find({
          to,
          hasRead: false,
        }).count(),
      ]);

      const count = counts[0] + counts[1];
      if (count > 0) {
        let lastNotiCreatedTime; // 创建最后一条提醒的时间
        if (counts[0] > 0) {
          const lastMessage = await Message.findOne({to, hasRead: false}).sort({createdAt: -1}).lean().exec();
          lastNotiCreatedTime = lastMessage.createdAt.getTime();
        }
        if (counts[1] > 0) {
          const lastSysMessage = await SysMessage.findOne({to, hasRead: false}).sort({createdAt: -1}).lean().exec();
          const time = lastSysMessage.createdAt.getTime();
          if (!lastNotiCreatedTime || time > lastNotiCreatedTime) lastNotiCreatedTime = time;
        }
        if (user.lastNotiTime === lastNotiCreatedTime) return;
        console.log('[SMS]发送未读消息短信');
        // 上一次发送提醒 是。。
        User.update({_id: to}, {$set: {lastNotiTime: lastNotiCreatedTime}}).exec();
        sendNotiWithFallback( user.pushId, '您有' + count + '条未查看的消息，可以回蜂房看看哦～', hasNotifications(user.phone, user.username, count));
      }
    } catch (ex) {
      console.log(ex);
    }
  });

});
