import {Task, User, Message, SysMessage, Post} from '../models/index';
import wrap from '../utils/wrap';
import sendSms, {
  girlSms as girlSmsStr
} from '../utils/sms';


function randomPos(closer = 1) {
  return (Math.random() - 0.5) / 100 / closer;
}


/*

  成熟中蜂房 专用更新

 */

 export const involvesTask = wrap(async function addLocation() {
  console.log('gogogo');
  let tasks;
  try {
    tasks = await Task.find({}, {publisher: true, involves: true}).lean().exec();
  } catch (ex) {
    console.log(ex);
  }
  console.log(tasks);
  tasks.forEach(async function (task) {
    try {
      if (!task.involves || task.involves.length === 0) {
        console.log('update');
        await Task.update({_id: task._id}, {$push: {
          involves: task.publisher.toString()
        }});
      }
    } catch (ex) {
      console.log(ex);
    }
  });

});


 export const involvesPost = wrap(async function addLocation() {
  console.log('gogogo');
  let tasks;
  try {
    tasks = await Post.find({}, {from: true, involves: true}).lean().exec();
  } catch (ex) {
    console.log(ex);
  }
  console.log(tasks);
  tasks.forEach(async function (task) {
    try {
      if (!task.involves || task.involves.length === 0) {
        console.log('update');
        await Post.update({_id: task._id}, {$push: {
          involves: task.from.toString()
        }});
      }
    } catch (ex) {
      console.log(ex);
    }
  });

});



/*
  新蜂房 专用更新
 */
function objectIdWithTimestamp(timestamp) {
  // Convert string date to Date object (otherwise assume timestamp is a date)
  if (typeof(timestamp) == 'string') {
      timestamp = new Date(timestamp);
  }

  // Convert date object to hex seconds since Unix epoch
  var hexSeconds = Math.floor(timestamp/1000).toString(16);

  // Create an ObjectId with that hex timestamp
  var constructedObjectId = ObjectId(hexSeconds + "0000000000000000");

  return constructedObjectId
}

export const girlSms = wrap(async function girlSms() {
    // sendSms(girlSmsStr('13918790617', '小不'));
    console.log('GIRLSMS');
    const users = await User.find({}, {username: true, phone: true}).lean().exec();
    console.log('find', users.length);
    users.forEach((user) => {
      if (process.env.NODE_ENV === 'production') {
        console.log('send sms');
        sendSms(girlSmsStr(user.phone, user.username));
      }
    });
});

export const addLocation = wrap(async function addLocation() {
  console.log('gogogo');
  // 更新嘉定
  let tasks;
  try {
    tasks = await Task.find({school: 0}, {loc: true}).lean().exec();
  } catch (ex) {
    console.log(ex);
  }
  console.log(tasks);
  tasks.forEach(async function (task) {
    try {
      if (!task.loc) {
        console.log('update');
        await Task.update({_id: task._id}, {$set: {
          loc: {
            type: 'Point',
            coordinates: [121.2103 + randomPos(), 31.28826 + randomPos()]
          }
        }});
      }
    } catch (ex) {
      console.log(ex);
    }
  });

  // 更新本部
  const tasks2 = await Task.find({school: 1}, {loc: true}).lean().exec();
  tasks2.forEach(async function (task) {
    try {
      if (!task.loc) {
        console.log('update');
        await Task.update({_id: task._id}, {$set: {
          loc: {
            type: 'Point',
            coordinates: [121.496893 + randomPos(), 31.284947 + randomPos()]
          }
        }});
      }
    } catch (ex) {
      console.log(ex);
    }
  });
});

// 只能更新一次
export const updateUser = wrap(async function updateUser() {
  const tasks = await User.find({}, {pollens: true, schoolId: true}).lean().exec();
  tasks.forEach(async function (task) {
    try {
      if (!task.pollens) {
        console.log('update');
        const updateObj = {
          friends: [],
          friendsCount: 0,
          liked: [],
          likedCount: 0,
          pollens: [],
          avatar: null,
          accountType: 0,
        };
        if (task.schoolId === 0) {
          updateObj.loc = {
            type: 'Point',
            coordinates: [121.2103 + randomPos(20), 31.28826 + randomPos(20)],
          };
        } else {
          updateObj.loc = {
            type: 'Point',
            coordinates: [121.496893 + randomPos(20), 31.284947 + randomPos(20)],
          };
        }
        await User.update({_id: task._id}, {$set: updateObj});
      }
    } catch (ex) {
      console.log(ex);
    }
  });
});
