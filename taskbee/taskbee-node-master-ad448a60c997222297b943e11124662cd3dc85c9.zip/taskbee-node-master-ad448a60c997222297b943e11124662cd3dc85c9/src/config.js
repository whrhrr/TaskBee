export const SECRET = 'jiongxiaobujujuju-secret';
export const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost/heart';
export const PORT = process.env.PORT || 7070;
export const TOKEN_EXPIRE = 60 * 60 * 24 * 14; // x秒jwt到期
export const QACCESS_KEY = 'Dju5t_O9uD6yB_-bjv1-J3oduQjRDP2a7nGHICLO';
export const QSECRET_KEY = 'd5_HMDEi6rFtGkzio3NeaNYm7aIxecyd9b6Wh8XX';

// 记得修改奥
export const HOST_URL = process.env.NODE_ENV === 'production' ? 'https://taskbee.cn' : 'http://beta.taskbee.cn';
