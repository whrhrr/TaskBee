export default {
  appId: 'wxfffba96f903dfd21',
  appSecret: '6af6974a38541577c438317245ac1e98',
  appToken: 'jiongjubu!@#$'
}