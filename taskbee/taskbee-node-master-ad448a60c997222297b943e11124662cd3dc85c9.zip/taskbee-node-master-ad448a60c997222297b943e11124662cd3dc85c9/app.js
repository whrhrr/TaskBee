//import {receiver, oauth} from './gaychat/index';
import express from 'express';
import httpProxy from 'http-proxy';
import routes from './src/routes/index';
import serveStatic from 'serve-static';
import mongoose from 'mongoose';
import io from './src/socket';
import http from 'http';
import * as jobs from './src/jobs/expires';
import * as config from './src/config.js';
import agay from './src/agay/agay';
import cron from 'cron';

import {involvesTask, involvesPost, girlSms} from './src/jobs/updateData';
import qiniu from 'qiniu';
qiniu.conf.ACCESS_KEY = config.QACCESS_KEY;
qiniu.conf.SECRET_KEY = config.QSECRET_KEY;

// 每分钟更新一下任务的状态，移除超时的任务
setInterval(jobs.expireTask, 1000 * 60 * 1);

const CronJob = cron.CronJob;
const job = new CronJob({
  cronTime: '50 3 * * *',  // minute
  onTick: jobs.countRemain,
  start: false,
  timeZone: 'Asia/Shanghai'
});
job.start();


mongoose.Promise = global.Promise;
mongoose.connect(config.MONGO_URL, {
  auth: {
    authdb: 'heart',
    authMechanism: 'SCRAM-SHA-1',
  }
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));


const debug = require('debug')('app:errors');
const app = express();
// server
const server = http.createServer(app);
io.attach(server);
app.disable('x-powered-by');
// [TODO] CONFIG IP
app.set('trust proxy', 'loopback, 10.144.49.213, ::ffff:10.144.49.213');
app.use(serveStatic('./public'));

/*
  经过proxy，所有请求都应该在/之后
 */
/*
app.use('/gaychat', receiver);
app.use('/gayoauth', oauth);
app.use('/', apis);
*/
// routes
app.use('/', routes);
// 支付宝通知
app.use('/agay', agay);

// 404
app.use((req, res) => {
  res.status(404).json({message: '这里什么都没有啦！'});
});

// error handling
app.use((err, req, res, next) => {
  if (err) {
    debug(err);
    if (err.statusCode) {
      res.status(err.statusCode).json({errorCode: err.errorCode, message: err.message});
    } else {
      console.log('ERROR:', err);
      res.status('500').json({message: '服务器内部错误'});
    }
  } else next();
});


/*
  通过代理，请求应该都在/api之后
 */

if (process.env.NODE_ENV === 'development') {
  server.listen(7070, () => {
    console.log('API Listenning on port 7070');
  });
  const proxyApp = express();
  const proxy = httpProxy.createProxyServer({
    target: 'http://localhost:7070',
    ws: true
  });
  proxyApp.use('/api', (req, res) => {
    proxy.web(req, res);
  });
  const proxyServer = http.createServer(proxyApp);
  proxyServer.on('upgrade', function (req, socket, head) {
    proxy.ws(req, socket, head);
  });
  proxyServer.listen(3000, ()=>{
    console.log('Listenning on port 3000 and 7070');
  });
} else {
  // 生产环境
  server.listen(config.PORT, () => {
    console.log('API Listenning on port ' + config.PORT);
  });
}
