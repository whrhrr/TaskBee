# HeartNode
NodeJS Backend for HeartRunner

##schoolid
0 - 同济嘉定
1 - 同济本部

# Requirement
Mongodb, NodeJS>=0.10.32

# Start
```
npm install
npm install nodemon -g
```
# Run
dev:
```
npm run dev
```
start:
```
npm run start
```
# 代码规范
## 概要
async/await > promise > callback

## Controllers
对于async函数，使用wrap包裹

# Using

####babel
es7 and es6 syntax
####express
routing
####mongoose
handling Mongodb connection
####passport
handling authentication
####node-wechat
handling gaychat
####mocha
test(TODO)
####airbnb eslint
better syntax(require ide integration)


# 问题
mocha测试时遇到请求被缓存的情况，导致测试不通过，但是这时候重新开控制台就能解决问题

# Considering
graphql server!!

##errors
400 Bad Request

throwjs.badRequest(message, errorCode);
401 Unauthorized

throwjs.unauthorized(message, errorCode);
402 Payment Required

throwjs.paymentRequired(message, errorCode);
403 Forbidden

throwjs.forbidden(message, errorCode);
404 Not Found

throwjs.notFound(message, errorCode);
405 Method Not Allowed

throwjs.methodNotAllowed(message, errorCode);
406 Not Acceptable

throwjs.notAcceptable(message, errorCode);
407 Proxy Authentication Required

throwjs.proxyAuthenticationRequired(message, errorCode);
408 Request Timeout

throwjs.requestTimeout(message, errorCode);
409 Conflict

throwjs.conflict(message, errorCode);
410 Gone

throwjs.gone(message, errorCode);
422 Unprocessable Entity

throwjs.unprocessableEntity(message, errorCode);
424 Failed Dependency

throwjs.failedDependency(message, errorCode);
500 Internal Server Error

throwjs.internalServerError(message, errorCode);
501 Not Implemented

throwjs.notImplemented(message, errorCode);
502 Bad Gateway

throwjs.badGateway(message, errorCode);
503 Service Unavailable

throwjs.serviceUnavailable(message, errorCode);
504 Gateway Timeout

throwjs.gatewayTimeout(message, errorCode);
505 HTTP Version Not Supported

throwjs.httpVersionNotSupported(message, errorCode);
511 Network Authentication Required

throwjs.networkAuthenticationRequired(message, errorCode);
