// import {receiver, oauth} from './gaychat/index';
import express from 'express';
import mongoose from 'mongoose';
import http from 'http';
import httpProxy from 'http-proxy';
import routes from './src/routes/index';
import worker from './src/worker';
import * as config from './src/config.js';

import cron from 'cron';
const CronJob = cron.CronJob;
const job = new CronJob({
  cronTime: '05 4 * * *',  // 在数据库备份完毕后爬一下，妈的爬的老慢了
  onTick: worker,
  start: false,
  timeZone: 'Asia/Shanghai'
});
job.start();
// worker();

mongoose.Promise = global.Promise;
mongoose.connect(process.env.MONGO_URL, {
  auth: {
    authdb: 'heart',
    authMechanism: 'SCRAM-SHA-1',
  }
});

// 开启爬虫！

const debug = require('debug')('app:errors');
const app = express();
// server
const server = http.createServer(app);
app.disable('x-powered-by');

app.use('/', routes);
// 404
app.use((req, res) => {
  // debug(req);
  res.status(404).json({message: '这里什么都没有啦！'});
});

// error handling
app.use((err, req, res, next) => {
  if (err) {
    debug(err);
    if (err.statusCode) {
      res.status(err.statusCode).json({errorCode: err.errorCode, message: err.message});
    } else {
      console.log('ERROR:', err);
      res.status('500').json({message: '服务器内部错误'});
    }
  } else next();
});


/*
  通过代理，请求应该都在/api之后
 */

if (process.env.NODE_ENV === 'development') {
  server.listen(3000, () => {
    console.log('API Listenning on port 7071');
  });

  const proxyApp = express();
  // 指向taskbee-node
  const proxy = httpProxy.createProxyServer({
    target: 'http://localhost:7070',
  });
  // 指向自身的api
  const proxySelf = httpProxy.createProxyServer({
    target: 'http://localhost:7071',
  });
  proxyApp.use('/api/yun', (req, res) => {
    proxySelf.web(req, res);
  });
  proxyApp.use('/api', (req, res) => {
    proxy.web(req, res);
  });


  const proxyServer = http.createServer(proxyApp);

  proxyServer.listen(config.PORT, ()=>{
    console.log('Listenning on port ' + config.PORT);
  });
} else {
  // 生产环境
  server.listen(config.PORT, () => {
    console.log('API Listenning on port ' + config.PORT);
  });
}
