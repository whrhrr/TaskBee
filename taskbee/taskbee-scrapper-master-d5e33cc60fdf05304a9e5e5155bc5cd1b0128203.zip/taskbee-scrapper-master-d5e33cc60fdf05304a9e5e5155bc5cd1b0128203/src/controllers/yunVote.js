// 用户提交评分
import jwt from 'jsonwebtoken';
import {YunVote, YunUser, YunComment} from '../models/index';
import wrap from '../utils/wrap';
import determineVote from '../utils/processData';
import Errors from 'throw.js';
import debugFunc from 'debug';
const debug = debugFunc('controllers:task');
import {projectionBrief} from '../models/yunUser';
import forEach from '../utils/funcs';
import mongoose from 'mongoose';
export const getRandom = wrap(async function getRandom(req, res, next) {
  const span = parseInt(req.query.span, 10) || 1;
  if (span < 0) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  const users = await YunUser.find({random: {$near : [Math.random(), 0]}}, projectionBrief).limit(span).lean().exec();
  if (req.user) {
    // 处理可评论的用户
    await determineVote(users, req.user.id);
  }
  res.json({data: users});
});

export const getHighest = wrap(async function getHighest(req, res, next) {
  let start = req.query.start;
  const span = parseInt(req.query.span, 10) || 1;
  if (span < 0) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  const type = parseInt(req.query.type, 10);

  const query = {};
  const sortQuery = {
  };
  if (type === 1) {
    debug('hot');
    sortQuery.hot = -1;
  } else {
    sortQuery.average = -1;
    query.voteCount = {$gt: 0};
  }

  let final = YunUser.find(query, projectionBrief).sort(sortQuery).limit(span)
  if (start) {
    start = parseInt(start, 10);
    final = final.skip(start);
  }
  const users = await final.lean().exec();
  if (req.user) {
    // 处理可评论的用户
    await determineVote(users, req.user.id);
  }
  res.json({data: users});
});

export const getSearch = wrap(async function getSearch(req, res, next) {
  const {start, type} = req.query;
  const span = parseInt(req.query.span, 10) || 1;
  if (span < 0) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  if (!type || type.length < 1) {
    return next(new Errors.notAcceptable('请搜索点东西', 1));
  }
  const query = {
    username: new RegExp(type), // `.*${type}.*`
  };
  if (start) {
    start = parseInt(start, 10);
    query._id= {$gt: start};
  }
  debug(query);
  const users = await YunUser.find(query, projectionBrief).sort({id: 1}).lean().exec();
  if (req.user) {
    await determineVote(users, req.user.id);
  }
  res.json({data: users});
});


export const getHotest = wrap(async function getHotest(req, res, next) {
  let start = req.query.start;
  const span = parseInt(req.query.span, 10) || 1;
  if (isNaN(span) || span < 0) {
    return next(new Errors.notAcceptable('span错误', 1));
  }
  const query = {};
  if (start) {
    start = parseInt(start, 10);
    query._id = { $lt: start};
  }
  const users = await YunUser.find(query, projectionBrief).sort({hot: -1}).limit(span).lean().exec();
  if (req.user) {
    // 处理可评论的用户
    await determineVote(users, req.user.id);
  }
  res.json({data: users});
});

export const getOne = wrap(async function getOne(req, res, next) {
  const _id = req.query.user;
  let limit;
  if (req.user && req.user.id) {
    limit = {random: false};
  } else limit = projectionBrief;
  const user = await YunUser.findOne({_id}, limit).lean().exec();
  if (req.user) {
    const objectId = mongoose.Types.ObjectId(req.user.id);
    await determineVote([user], req.user.id);
    const comments = await YunComment.find({userId: user._id}, {commenters: false, date: false, userId: false}).sort({score: -1}).lean().exec();
    await forEach( comments, async function(comment) {
      const exist = await YunComment.find({_id: comment._id, commenters: objectId}).limit(1).count();
      if (exist) {
        comment.voted = true;
      } else comment.voted = false;
    });
    user.comments = comments;
  }
  res.json({data: user});
});

// 发表评价
export const vote = wrap(async function vote(req, res, next) {
  const {_id} = req.body;
  const yunUser = await YunUser.findOne({_id}, {yunId: true, voteScore: true, voteCount: true}).limit(1).lean().exec();
  if (!yunUser) {
    return next(new Errors.notAcceptable('用户不存在', 1));
  }
  const score = parseFloat(req.body.score, 10);
  if (isNaN(score) || score < 0 || score > 10) {
    return next(new Errors.notAcceptable('分数在0~10分范围内', 1));
  }
  const userId = req.user.id;
  const previousVote = await YunVote.findOne({yunId: yunUser.yunId, voter: req.user.id}, {score: true}).lean().exec()
  if (previousVote) {
    debug('以前打过分数');
    const scoreDiff = - previousVote.score + score;
    const average = (yunUser.voteScore + scoreDiff) / (yunUser.voteCount);
    await Promise.all([
      YunVote.update({_id: previousVote._id}, {$set: {score, date: Date.now()}}),
      YunUser.update({_id: yunUser._id}, {$inc: {voteScore: scoreDiff}, $set: {average} }).exec(),
    ]);
  } else {
    const voteStore = new YunVote({
      score,
      voter: userId,
      yunId: yunUser.yunId,
    });
    const average = (yunUser.voteScore + score) / (yunUser.voteCount + 1);
    await Promise.all([
      voteStore.save(),
      YunUser.update({_id: yunUser._id}, {$inc: {voteScore: score, voteCount: 1, hot: 1}, $set: {average} }).exec(),
    ]);
  }

  res.json({data: true});
});

// 新评论
export const comment = wrap(async function comment(req, res, next) {
  debug('NEW COMMENT');
  const {userId, message} = req.body;
  const commenter = req.user.id;
  const yunUser = await YunUser.findOne({_id: userId}, {commentCount: true}).lean().exec();
  if (!yunUser) {
    return next(new Errors.notAcceptable('用户不存在', 1));
  }
  if (message.length < 2) {
    return next(new Errors.notAcceptable('印象太短', 1));
  }
  const comment = new YunComment({userId: yunUser._id, commenter, message});
  try {
    await comment.save();
  } catch(ex) {
    if (ex.code === 11000) {
      return next(new Errors.notAcceptable('该印象已经存在', 1));
    }
    else throw ex;
  }
  YunUser.update({_id: yunUser._id}, {$inc: { hot: 1, commentCount: 1}}).exec(),
  res.json({data: comment});
});

export const getComment = wrap(async function getComment(req, res, next) {
  const {userId} = req.query;
  const comments = await YunComment.find({userId: user._id}, {commenters: false, date: false, userId: false}).sort({score: -1}).lean().exec();
  res.json({data: comments});
});

export const voteComment = wrap(async function voteComment(req, res, next) {
  const {commentId} = req.body;
  const voter = mongoose.Types.ObjectId(req.user.id);
  const comment = await YunComment.findOne({_id: commentId}, {_id: true}).lean().exec();
  debug(comment);
  if (!comment) return next(new Errors.notAcceptable('找不到评论', 1));
  const myComment = await YunComment.find({_id: commentId, commenters: voter}, {_id: true}).limit(1).count();
  if (myComment === 0) {
    // 还没有点赞
    debug('还没有点赞');
    await YunComment.update({_id: comment._id}, {$inc: {score: 1}, $push: {commenters: voter}});
    const result = await YunComment.findOne({_id: comment._id}).lean().exec();
    debug(result);
  } else {
    // 已经点赞
    debug('已经点赞');
    await YunComment.update({_id: comment._id}, {$inc: {score: -1}, $pull: {commenters: voter}});
  }
  res.json({data: true});
});
