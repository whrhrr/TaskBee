import mongoose from 'mongoose';

const {Schema} = mongoose;

const voteSchema = new Schema({
  score: Number,
  // 受到投票的yun
  yunId: {
    type: String,
    index: true
  },
  // 投票人
  voter: {
    type: Schema.Types.ObjectId,
    index: true,
  },
  // 投票时间
  date: {
    type: Date,
    default: Date.now,
    index: true,
  },
});

const voteModel = mongoose.model('YunVote', voteSchema);

export default voteModel;
