import mongoose from 'mongoose';

const {Schema} = mongoose;

const commentSchema = new Schema({

  score: {
    type: Number,
    index: true,
    default: 0,
  },

  // 受到投票的yun
  userId: {
    type: Schema.Types.ObjectId,
    index: true
  },

  // 投票人
  commenters: {
    type: [{
      type: Schema.Types.ObjectId,
    }],
    index: true,
  },

  // 投票时间
  date: {
    type: Date,
    default: Date.now,
  },

  message: {
    type: String,
    index: true,
    unique: true,
  }

});

const commentModel = mongoose.model('YunComment', commentSchema);

export default commentModel;
