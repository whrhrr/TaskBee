import mongoose from 'mongoose';

const {Schema} = mongoose;


function randomLoc() {
  return [Math.random(), 0];
}

const userSchema = new Schema({

  // 用户名 最长10字符
  username: {
    type: String,
    index: true,
  },

  yunId: {
    type: String,
    index: true,
  },

  img: String,

  apartment: {
    type: String,
    default: ''
  },

  followerCount: {
    type: Number,
    default: 0,
  },

  voteScore: {
    type: Number,
    default: 0,
  },

  // 投票数
  voteCount: {
    type: Number,
    default: 0,
    index: true,
  },

  average: {
    type: Number,
    default: 5,
    index: true,
  },

  commentCount: {
    type: Number,
    default: 0
  },

  schoolId: {
    type: Number,
    default: 0
  },
  photos: [
    {type: String}
  ],
  random: {
    type: [Number],
    index: '2d',
    default: randomLoc,
  },
  // 定时计算所有人的热度
  hot: {
    type: Number,
    index: true,
    default: 0,
  }
});

userSchema.index({ _id: 1, hot: -1 }, { unique: true });
userSchema.index({ _id: 1, average: -1 }, { unique: true });


const userModel = mongoose.model('YunUser', userSchema);

export default userModel;

export const projectionBrief = {
  average: true,
  img: true,
  voteCount: true,
  voteScore: true,
  commentCount: true,
  yunId: true,
  username: true,
};
