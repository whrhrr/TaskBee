import jwt from 'jsonwebtoken';
import Errors from 'throw.js';
import {SECRET} from '../config';

export function authCode(req, res, next) {
  if (!req.user.code) {
    return next(new Errors.unauthorized('验证码无效'));
  }
  next();
}

export function authUser(req, res, next) {
  if (!req.user.id) {
    return next(new Errors.unauthorized('请重新登录', 'NEED_RELOGIN'));
  }
  next();
}

export default function auth(req, res, next){
  let token;
  // 判断是否是奇怪的请求
  if (req.method === 'OPTIONS' && req.headers.hasOwnProperty('access-control-request-headers')) {
    var hasAuthInAccessControl = !!~req.headers['access-control-request-headers']
      .split(',').map(function (header) {
        return header.trim();
      }).indexOf('authorization');

    if (hasAuthInAccessControl) {
      return next();
    }
  }
  if (req.method === 'GET') {
    // 从cookie获得token
    token = req.cookies.Bearer;
  }
  else {
    if (req.headers && req.headers.authorization) {
      var parts = req.headers.authorization.split(' ');
      if (parts.length === 2) {
        var scheme = parts[0];
        var credentials = parts[1];
        if (/^Bearer$/i.test(scheme)) {
          token = credentials;
        } else {
          return next(new Errors.unauthorized('请重新登录', 'NEED_RELOGIN'));
        }
      } else {
        return next(new Errors.unauthorized('请重新登录', 'NEED_RELOGIN'));
      }
    }
  }

  if (!token) {
    return next(new Errors.unauthorized('请重新登录', 'NEED_RELOGIN'));
  }

  jwt.verify(token, SECRET, function(err, decoded) {
    if (err) return next(new Errors.unauthorized('请重新登录', 'NEED_RELOGIN'));
    req.user = decoded;
    next();
  });
}

export function authOrNot(req, res, next) {
  let token;
  // 判断是否是奇怪的请求
  if (req.method === 'OPTIONS' && req.headers.hasOwnProperty('access-control-request-headers')) {
    const hasAuthInAccessControl = !!~req.headers['access-control-request-headers']
      .split(',').map(function (header) {
        return header.trim();
      }).indexOf('authorization');

    if (hasAuthInAccessControl) {
      return next();
    }
  }
  if (req.method === 'GET') {
    token = req.cookies.Bearer;
  }
  else {
    if (req.headers && req.headers.authorization) {
      const parts = req.headers.authorization.split(' ');
      if (parts.length === 2) {
        const scheme = parts[0];
        const credentials = parts[1];
        if (/^Bearer$/i.test(scheme)) {
          token = credentials;
        } else {
          return next();
        }
      } else {
        return next();
      }
    }
  }
  if (!token) {
    return next();
  }
  jwt.verify(token, SECRET, function(err, decoded) {
    if (err) return next();
    req.user = decoded;
    next();
  });
}

export function authOrNotCookie(req, res, next) {
  let token;
  // 判断是否是奇怪的请求
  if (req.method === 'OPTIONS' && req.headers.hasOwnProperty('access-control-request-headers')) {
    const hasAuthInAccessControl = !!~req.headers['access-control-request-headers']
      .split(',').map(function (header) {
        return header.trim();
      }).indexOf('authorization');

    if (hasAuthInAccessControl) {
      return next();
    }
  }
  token = req.cookies.Bearer;
  if (!token) {
    return next();
  }
  jwt.verify(token, SECRET, function(err, decoded) {
    if (err) return next();
    req.user = decoded;
    next();
  });
}
