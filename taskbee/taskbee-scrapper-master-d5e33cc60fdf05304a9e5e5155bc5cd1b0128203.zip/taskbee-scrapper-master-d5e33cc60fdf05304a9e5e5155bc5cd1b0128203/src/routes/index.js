import express from 'express';
import vote from './yunVote';

const router = express.Router();

router.use('/vote', vote);


export default router;
