import express from 'express';
import auth, {authUser, authOrNot} from '../middlewares/auth';
import cookieParser from '../middlewares/cookie';

import * as voteControllers from '../controllers/yunVote';
import bodyParser from 'body-parser';
const jsonParser = bodyParser.json();

const router = express.Router();
router.get('/random', cookieParser, authOrNot, jsonParser, voteControllers.getRandom);
router.get('/highest', cookieParser, authOrNot, jsonParser, voteControllers.getHighest);
// router.get('/hotest', cookieParser, authOrNot, jsonParser, voteControllers.getHotest);
router.get('/one', cookieParser, authOrNot, jsonParser, voteControllers.getOne);
router.get('/search', cookieParser, authOrNot, jsonParser, voteControllers.getSearch);

router.post('/vote', cookieParser, auth, authUser, jsonParser, voteControllers.vote);
router.post('/voteComment', cookieParser, auth, authUser, jsonParser, voteControllers.voteComment);
router.post('/comment', cookieParser, auth, authUser, jsonParser, voteControllers.comment);

export default router;
