export default async function (list, fn) {
  // list = [].slice.call(list);
  for (let i = 0; i < list.length; i++) {
    await fn(list[i]);
  }
}
