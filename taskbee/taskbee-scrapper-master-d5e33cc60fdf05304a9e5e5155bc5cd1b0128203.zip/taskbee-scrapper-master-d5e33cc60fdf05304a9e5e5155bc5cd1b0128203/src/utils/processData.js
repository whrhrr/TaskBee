import {YunVote} from '../models/index';
import forEach from '../utils/funcs';

// 为了减少内存消耗，这里使用了mutate的方法，请注意
export default async function determineVote(tasks, userId) {
  await forEach(tasks, async function (task) {
    const myVote = await YunVote.findOne({voter: userId, yunId: task.yunId}, {score: true, date: true}).lean().exec();
    task.myVote = myVote;
  });
}
