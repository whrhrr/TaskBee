export const SECRET = 'jiongxiaobujujuju-secret';
export const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost/heart';
export const PORT = process.env.PORT || 7071;
export const TOKEN_EXPIRE = 60 * 60 * 24 * 14; // x秒jwt到期
