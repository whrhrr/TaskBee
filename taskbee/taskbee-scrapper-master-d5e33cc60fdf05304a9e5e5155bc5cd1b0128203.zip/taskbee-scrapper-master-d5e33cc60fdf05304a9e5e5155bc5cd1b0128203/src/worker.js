import request from 'urllib';
import cheerio from 'cheerio';
import ensureComplete from './ensureComplete';

import YunUser from './models/yunUser';


const baseUrl = 'http://yun.tongji.edu.cn';

let totalUser = 0;

const wrap = fn => (...args) => fn(...args).catch(
  function(reason) {
    console.log('[An Error Occured]', reason);
  }
);

const cherrioEach = async function (list, fn) {
  list = [].slice.call(list);
  for (let i = 0; i < list.length; i++) {
    await fn(list[i]);
  }
}

const headers = {
  'Cookie': 'JSESSIONID=rtreegpsvxtli2xxz1wdnhge; pgv_pvi=5057683456; Hm_lvt_d5a76608e07e4903e91fe94d34b3cc0d=1439565122; featureTips_fwdToGroup20131101=1; amlbcookie=02; iPlanetDirectoryPro=AQIC5wM2LY4SfczzqMb6yaJGvaO%2BO45ykL6uyE%2BhF%2FI1aGk%3D%40AAJTSQACMDI%3D%23; at=a1bdbdff-0808-41cc-a3d5-7d736371fa95; cu=2aa99335-a55e-11e5-a1cc-00505681721d; rm=MmFhOTkzMzUtYTU1ZS0xMWU1LWExY2MtMDA1MDU2ODE3MjFkOjdlZDYzMDc0ZTYyZGE3ZjNhNzJiMjMxNDhiNjRmNTQz; sync_networkid=104; sync_userid=2aa99335-a55e-11e5-a1cc-00505681721d; cd=yun.tongji.edu.cn; cn=104',
  'Host': 'yun.tongji.edu.cn',
  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.' + Math.floor(Math.random() * 100),
  // 'X-Real-IP': '202.120.189.3',
};

export default wrap(async function test() {
  // 页面记录
  //
  let currentPage = 0;

  while (currentPage < 820) {
    currentPage++;
    console.log('［抓取页面］' + currentPage);
    const thisReq = request.request('http://yun.tongji.edu.cn/addressbook/home?pageIndex=' + currentPage, {
      method: 'GET',
      headers,
    });
    const result = await ensureComplete(thisReq);
    if (!result) continue; // 加载失败了。。
    const $ = cheerio.load(result.data.toString());
    // 读取用户列表
    const userList = $('.ab-info-avatar.namecard').filter((ind, el) => {
      // text, img, text
      return el.children[1].attribs['src'] !== '/space/c/photo/load?id=&spec=50'
    });
    console.log('userList', userList.length);

    await cherrioEach(userList, readUserData);
    if (userList.length === 0) {
      return console.log('［抓取完成］！！');
    }
  }

});


async function readUserData(userDom) {
  const userId = userDom.attribs['data-userid'];

  let user;
  const findUser = await YunUser.findOne({yunId: userId}).exec();
  if (findUser) user = findUser;
  else user = new YunUser();

  const url = baseUrl + userDom.attribs.href;
  const thisReq = request.request(url, {
    method: 'GET',
    headers,
  });
  const result = await ensureComplete(thisReq);
  if (!result) return; // 妈的又失败了


  const $ = cheerio.load(result.data.toString());

  const userSection = $('.mb-profile-info');
  const ul = userSection.children('ul').children();
  const followers = parseInt(ul.eq(0).children().eq(0).children('a').text(), 10);
  // 关注者大于等于20
  if (followers < 20) return;
  // console.log(followers);
  const apartment = ul.eq(2).children('span').text();
  // console.log(apartment);

  let img = $('.avatar-large').eq(0).attr('src');
  if (!img) return;
  img = img.split('&')[0];

  const username = userSection.children('h2').eq(0).children().eq(0).text();
  // save
  if (user.img !== img) {
    user.photos.push(img);
  }
  user.img = img;
  user.username = username,
  user.followerCount = followers,
  user.apartment = apartment,
  user.yunId = userId,

  await user.save();
}
