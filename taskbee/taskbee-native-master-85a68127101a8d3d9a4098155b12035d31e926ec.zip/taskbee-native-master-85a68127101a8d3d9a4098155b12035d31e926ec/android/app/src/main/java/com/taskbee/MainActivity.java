package com.taskbee;

import com.facebook.react.ReactActivity;
import android.os.Bundle;
import cn.reactnative.modules.talkingdata.TalkingDataPackage;
import cn.reactnative.modules.talkingdata.TalkingDataModule;
import cn.reactnative.modules.jpush.JPushPackage;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.mapbox.reactnativemapboxgl.ReactNativeMapboxGLPackage;
import com.github.xinthink.rnmk.ReactMaterialKitPackage;
import cl.json.RNSharePackage;
import com.imagepicker.ImagePickerPackage; // import
import com.microsoft.codepush.react.CodePush;
import com.xiaobu.amap.AMapLocationReactPackage;
import com.babisoft.ReactNativeLocalization.ReactNativeLocalizationPackage;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends ReactActivity {
    private ImagePickerPackage mImagePicker;

    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "taskbee";
    }

    /**
     * Returns whether dev mode should be enabled.
     * This enables e.g. the dev menu.
     */
    @Override
    protected boolean getUseDeveloperSupport() {
        return BuildConfig.DEBUG;
    }

    // 3. Override the getJSBundleFile method in order to let
    // the CodePush runtime determine where to get the JS
    // bundle location from on each app start
    @Override
    protected String getJSBundleFile() {
        return CodePush.getBundleUrl();
    }
   /**
   * A list of packages used by the app. If the app uses additional views
   * or modules besides the default ones, add more packages here.
   */
    @Override
    protected List<ReactPackage> getPackages() {
      return Arrays.<ReactPackage>asList(
        new MainReactPackage(),
        new TalkingDataPackage(),
        new JPushPackage(),
        new ReactNativeMapboxGLPackage(),
        new ReactMaterialKitPackage(),
        new RNSharePackage(),
        new ImagePickerPackage(),
        new AMapLocationReactPackage(),
        new ReactNativeLocalizationPackage(),
        new CodePush("JNfb3fIWq5UtJUywoGJakQ6ALmEv41FUwTzol", this)
      );
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        TalkingDataModule.register(getApplicationContext(), null, null, true);
        super.onCreate(savedInstanceState);
    }
}
