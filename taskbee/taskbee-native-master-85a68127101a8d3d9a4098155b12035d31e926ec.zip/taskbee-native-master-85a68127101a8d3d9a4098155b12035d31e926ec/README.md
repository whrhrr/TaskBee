# 代码风格
遵循Airbnb规范

## export import规则
rn  不喜欢对同一个组建export多次，所以 index文件存所有组建的引用是不可取的

## 创建图标
```
./generate-icon.js ~/Downloads/taskbee-icons/styles.css --componentName=Icon --fontFamily=taskbee-icons >myIcon.js
```

## 用到的需要额外配置的带原生代码的第三方库：
jpush

talkingdata

mapbox-gl

code-push

## 生产环境
```
┌────────────┬───────────────────────────────────────┐
│ Name       │ Deployment Key                        │
├────────────┼───────────────────────────────────────┤
│ Production │ JNfb3fIWq5UtJUywoGJakQ6ALmEv41FUwTzol │
├────────────┼───────────────────────────────────────┤
│ Staging    │ ujmT1Z6KkcrcNfLvWE3Qp8lIIyWl41FUwTzol │
└────────────┴───────────────────────────────────────┘


# code push
##1.生成资源 2.推送

code-push release-react Taskbee android --deploymentName Production

code-push release-react TaskbeeIOS ios --deploymentName Production --targetBinaryVersion 1.9.0

## staging
code-push release-react Taskbee android --deploymentName Staging


##Android 发布步骤

###codepush

1.debug模式没问题，设置新版本号 ( config.js  build.gradle taskbee-react/src/assets/android.txt)
2.（若没有staging版测试机，设置MainActivity.java key为staging然后编译安装）
3.build js 以及 asset
4.code push to staging
5.在staging版上测试改动
6.code push staging >> production
7.生成production版本（记得设置key)
8.编译
9.测试
10.发布
```
###原生
修改taskbee-react android.txt版本号！和说明！
