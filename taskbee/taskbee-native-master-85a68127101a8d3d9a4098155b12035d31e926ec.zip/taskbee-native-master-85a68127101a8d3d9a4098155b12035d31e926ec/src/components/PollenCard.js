import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Animated,
  PanResponder,
  Dimensions,
} from 'react-native';

import clamp from 'clamp';

import {
 Avatar, Tag, Timeline, Gender, Icon, SimpleImages, Text,
 HyperText,
} from '../components'; // Tag,

import {stateMap} from '../utils/dataMap';
import moment from 'moment';
moment.locale('zh-cn');

import {calcCrow} from '../utils/dataProcessor';

import config from '../config';

import {goTo} from '../utils/navigation';
import {MKButton, mdl} from 'react-native-material-kit';

const {width} = Dimensions.get('window');

import styles from './PollenCardStyles';
import locales from '../locales';

const SWIPE_THRESHOLD = width / 7 * 2;

export default class PollenCard extends Component {
  static propTypes = {
    _id: PropTypes.string,
    type: PropTypes.number,
  };

  constructor(props) {
    super(props);

    this.state = {
      pan: new Animated.ValueXY(),
      enter: new Animated.Value(0.5),
    }
  }

  componentWillMount() {
    this._panResponder = PanResponder.create({
      onMoveShouldSetResponderCapture: () => true,
      onMoveShouldSetPanResponderCapture: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: (e, gestureState) => {
        this.state.pan.setOffset({x: this.state.pan.x._value, y: this.state.pan.y._value});
        this.state.pan.setValue({x: 0, y: 0});
        if (config.isIOS && this.props.touchCard) {
          this.props.touchCard();
        }
      },

      onPanResponderMove: Animated.event([
        null, {dx: this.state.pan.x, dy: this.state.pan.y},
      ]),

      onPanResponderRelease: (e, {vx, vy}) => {
         if (config.isIOS && this.props.releaseCard) {
          this.props.releaseCard();
        }
        this.state.pan.flattenOffset();
        var velocity;

        if (vy >= 0) {
          velocity = clamp(vy, 4, 6);
        } else if (vy < 0) {
          velocity = clamp(vy * -1, 4, 6) * -1;
        }

        if (this.state.pan.y._value < -SWIPE_THRESHOLD) {
          Animated.decay(this.state.pan, {
            velocity: {y: velocity, x: vx},
            deceleration: 0.98
          }).start(this.props.cast)
        } else if (this.state.pan.y._value > SWIPE_THRESHOLD) {
          Animated.decay(this.state.pan, {
            velocity: {y: velocity, x: vx},
            deceleration: 0.98
          }).start(this.props.abandon)
        } else {
          if (Math.abs(this.state.pan.y._value) < 3 &&  Math.abs(this.state.pan.x._value) < 3) {
            this.props.goTo('PostDetail', {postId: this.props.postId._id})();
          }
          Animated.spring(this.state.pan, {
            toValue: {x: 0, y: 0},
            friction: 4
          }).start()
        }
      }
    });
  }

  componentDidMount() {
    this._animateEntrance();
  }


  _animateEntrance() {
    Animated.spring(
      this.state.enter,
      { toValue: 1, friction: 8 }
    ).start();
  }

  render() {
    const {goTo, type, postId: post} = this.props;
    const {_id: realId, comments, content: description, createdAt, from, imgs, spreadCount, readerCount, commentCount} = post;
    const {_id: pubId, avatar, username, gender} = from;

    // animation

    let { pan, enter, } = this.state;

    let [translateX, translateY] = [pan.x, pan.y];

    let rotate = pan.x.interpolate({inputRange: [-200, 0, 200], outputRange: ["-30deg", "0deg", "30deg"]});
    let opacity = pan.y.interpolate({inputRange: [-200, 0, 200], outputRange: [0.5, 1, 0.5]});
    // let opacityInfos = pan.y.interpolate({inputRange: [-200, 0, 200], outputRange: [0.1, 1, 0.1]});
    let scale = enter;

    let animatedCardStyles = {transform: [{translateX}, {translateY}, {rotate}, {scale}], opacity};
    let nopeOpacity = pan.y.interpolate({inputRange: [0, SWIPE_THRESHOLD], outputRange: [0, 1]});
    let nopeScale = pan.y.interpolate({inputRange: [0, SWIPE_THRESHOLD], outputRange: [0.5, 1], extrapolate: 'clamp'});
    let nopeTrans = pan.y.interpolate({inputRange: [0, SWIPE_THRESHOLD], outputRange: [-48, 52]});

    let yupOpacity = pan.y.interpolate({inputRange: [-SWIPE_THRESHOLD, 0], outputRange: [1, 0]});
    let yupScale = pan.y.interpolate({inputRange: [-SWIPE_THRESHOLD, 0], outputRange: [1, 0.5], extrapolate: 'clamp'});
    let yupTrans = pan.y.interpolate({inputRange: [-SWIPE_THRESHOLD, 0], outputRange: [68, -32]});

    let animatedYupStyles = {transform: [{scale: yupScale}, {rotate}], bottom: yupTrans, opacity: yupOpacity};
    let animatedNopeStyles = {transform: [{scale: nopeScale}, {rotate}],  top: nopeTrans, opacity: nopeOpacity};
    return (
      <View style={styles.container}>

        <Animated.View
          style={[styles.animatedCard, animatedCardStyles]}
          {...this._panResponder.panHandlers}
        >
          <TouchableOpacity
            onPress={goTo('PostDetail', {postId: realId})}
            style={[styles.taskItem]}
            shadowRadius={1}
            shadowOffset={{width: 0, height: 0.5}}
            shadowOpacity={0.7}
          >
            <View style={styles.miscView}>


              <Text style={styles.miscCard}>{moment(createdAt).fromNow()}</Text>
              <View style={styles.actionIcons}>
                <View style={styles.fav}>
                  <Icon name="bubble-comment-streamline-talk" size={14} color={config.colorNormal}/>
                  <Text style={styles.favCount}>{commentCount || '0'}</Text>
                </View>
                <View style={styles.fav}>
                  <Icon name="paper-plane" size={14} color={config.colorNormal}/>
                  <Text style={styles.favCount}>{spreadCount || '0'}</Text>
                </View>
                <View style={styles.fav}>
                  <Icon name="eye" size={14} color={config.colorNormal}/>
                  <Text style={styles.favCount}>{readerCount || '0'}</Text>
                </View>
              </View>
            </View>

            <View style={styles.description}>
              <HyperText style={styles.descriptionText}>{description}</HyperText>
              {
                imgs && imgs.length ? <SimpleImages style={{justifyContent: 'center'}} imgs={imgs} goTo={goTo}/>
                 : null
              }
            </View>
            <View style={styles.infos}>
              <View style={styles.user}>
                <TouchableOpacity style={styles.userAvatar} onPress={goTo('UserDetail', {userId: pubId})}>
                  <Avatar size={32} src={avatar}/>
                </TouchableOpacity>
                <View style={styles.username}>
                  <Text style={styles.nameText}>{username}</Text><Gender style={styles.gender} gender={gender}/>
                </View>

              <Text style={styles.distance}>
                {this.props.myPos !== undefined ? Math.floor(calcCrow(this.props.postId.loc.coordinates, this.props.myPos)) + 'm' : null}
              </Text>
              </View>


            </View>

          </TouchableOpacity>

        </Animated.View>

        <Animated.View style={[styles.nope, animatedNopeStyles]}>
          <Text style={styles.nopeText}>{locales.dismiss}</Text>
        </Animated.View>

        <Animated.View style={[styles.yup, animatedYupStyles]}>
          <Text style={styles.yupText}>{locales.spread}</Text>
        </Animated.View>




      </View>
    );
  }
}

