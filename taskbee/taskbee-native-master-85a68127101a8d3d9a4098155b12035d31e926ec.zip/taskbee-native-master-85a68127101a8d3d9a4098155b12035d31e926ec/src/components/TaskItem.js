import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Platform,
} from 'react-native';

import {
 Avatar, Tag, Timeline, Gender, Icon, SimpleImages, Text,
} from '../components'; // Tag,

import {stateMap} from '../utils/dataMap';
import moment from 'moment';
moment.locale('zh-cn');

import {calcCrow} from '../utils/dataProcessor';

import config from '../config';

import {goTo} from '../utils/navigation';
import {MKButton, mdl} from 'react-native-material-kit';
import shallowCompare from 'react-addons-shallow-compare';


const styles = StyleSheet.create({
  taskItem: {
    backgroundColor: '#fff',
    padding: config.normalPadding,
    borderRadius: config.borderRadius,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    marginBottom: 9,
  },
  taskItemMain: {
    flexDirection: 'row',
  },
  user: {
  // 头像，距离
    marginRight: config.normalPadding,

  },
  distance: {
    fontSize: 9,
    marginTop: 3,
    alignSelf: 'center',
  },
  content: {
    flex: 1,

  },
  nameText: {
    color: config.colorStand,
    marginRight: 3,
  },
  username: {
    flexDirection: 'row',
  },
  gender: {
    alignSelf:'center',
  },
  action: {
    flex: 1,
    alignItems: 'flex-end',
  },
  canVote: {
    fontSize: 9,
  },
  descriptionText: {
    color: config.colorMain,
    marginTop: 3,
  },
  state: {
    fontSize: config.fontSmall,
  },
  stand: {
    color: config.brandRed,

  },
  ongoing: {
    color: config.brandBlue,
  },
  mine: {
    color: config.brandPrimary
  },
  miscView: {
    marginLeft: 50,
    paddingTop: 12,
  },
  miscTexts: {
    flexDirection: 'row',
  },
  misc: {
    fontSize: config.fontSmall,
    color: config.colorSubtle,
    marginRight: 9,
  },
  inlineIcon: {
    marginRight: 3,
  },
  fav: {
    marginLeft: 12,
    paddingHorizontal: 3,
    paddingVertical: 8,
  },
  favCount: {
    position: 'absolute',
    backgroundColor: '#fff',
    right: 0,
    top: 0,
    fontSize: 12,
  },
  actionIcons: {
    flexDirection:'row',
  },
  images: {
    flexDirection: 'row',
  },
  image: {
    width: 60,
    height: 60,
    marginRight: 3,
  },
});

import locales from '../locales';

export default class TaskItem extends Component {
  static propTypes = {
    _id: PropTypes.string,
    onFavClick: PropTypes.func,
    faved: PropTypes.bool,
    timeline: PropTypes.bool,
    nofav: PropTypes.bool,
    state: PropTypes.number,
    reward: PropTypes.number,
    dueTime: PropTypes.string,
    startTime: PropTypes.string,
    tags: PropTypes.array,
    description: PropTypes.string,
    publisher: PropTypes.object,
    meId: PropTypes.string,
    canVote: PropTypes.array,
    tasker: PropTypes.any,
    loc: PropTypes.object,
    myPos: PropTypes.array,
    imgs: PropTypes.array,
    favs: PropTypes.number,
    type: PropTypes.number,
    navigator: PropTypes.object.isRequired,
  };

  constructor(props) {
    super(props);
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState);
  }

  goTo = goTo.bind(this);



  render() {
    const {startTime, dueTime, commentCount, type, favs, imgs, meId, canVote, _id, onFavClick, faved, timeline, nofav, state, reward, description, tasker, publisher = {} }  = this.props; // tags,
    const {_id: pubId, avatar, username, gender} = publisher;
    let stateStyle = [styles.state];
    if (state === 0) {
      stateStyle.push(styles.stand);
    } else if (state < 3) {
      stateStyle.push(styles.ongoing);
    }
    if (meId === pubId || tasker && ((tasker._id && tasker._id === meId) || tasker === meId)) stateStyle.push(styles.mine);
    const voteIndicator = meId && canVote && canVote.indexOf(meId) > -1 ? <Text style={styles.canVote}>{locales.canVote}</Text> : null;
    return (
      <TouchableOpacity
        onPress={this.goTo('TaskDetail', {taskId: this.props._id})}
        style={[styles.taskItem, type === 1 ? styles.schoolEvent : null]}
        rippleColor={config.rippleColor}
        shadowRadius={1}
        shadowOffset={{width: 0, height: 0.5}}
        shadowOpacity={0.7}
      >
        <View style={styles.taskItemMain}>
          <TouchableOpacity style={styles.user} onPress={this.goTo('UserDetail', {userId: this.props.publisher ? this.props.publisher._id : ''})}>
            <Avatar size={36} src={avatar}/>
          </TouchableOpacity>
          <View style={styles.content}>
            <View style={styles.username}>
              <View>
                <View style={styles.username}>
                  <Text style={styles.nameText}>{username}</Text><Gender style={styles.gender} gender={gender}/>
                </View>
                {type === 1 ? <Tag name={locales.events}/> : <Text style={stateStyle}>{stateMap[state]}</Text>}
              </View>
              <View style={styles.action}>
                <View style={styles.actionIcons}>
                  <TouchableOpacity style={styles.fav} onPress={this.goTo('TaskDetail', {taskId: this.props._id, isComment: true})}>
                    <Icon name="bubble-comment-streamline-talk" size={14} color={config.colorNormal}/>
                    <Text style={styles.favCount}>{commentCount || '0'}</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.fav} onPress={onFavClick}>
                    <Icon color={faved ? config.brandRed : config.colorNormal} name={faved ? 'heart-1': 'heart-o'} size={14}/>
                    {favs !== undefined ? <Text style={styles.favCount}>{favs}</Text> : null}
                  </TouchableOpacity>

                  </View>
                {voteIndicator}
              </View>
           </View>
            <View style={styles.description}>
              <Text style={styles.descriptionText}>{description}</Text>
              {
                imgs && imgs.length ? <SimpleImages imgs={imgs} goTo={this.goTo}/>
                 : null
              }
            </View>
          </View>
        </View>
        <View style={styles.miscView}>
          <View style={styles.miscTexts}>
            <Text style={styles.misc}>
              <Icon style={styles.inlineIcon} name="navigate"/>{this.props.loc !== undefined ? Math.floor(calcCrow(this.props.loc.coordinates, this.props.myPos)) + 'm' : null}
            </Text>
            <Text style={styles.misc}><Icon style={styles.inlineIcon} name="clock"/> {moment(startTime).format('MM/D HH:mm')}</Text>
            {type !== 1 && <Text style={styles.misc}><Icon style={styles.inlineIcon} name="vallet"/> ¥{reward}</Text>}
          </View>
          {
            timeline ?
            <Timeline state={state}/>
            : null
          }
        </View>
      </TouchableOpacity>
    );
  }
}

