import React, {
  Component,
  PropTypes,
  StyleSheet,
  TextInput,
  View,
  TouchableOpacity,
} from 'react-native';

import {Icon, Text, FadeInText} from './index';

import config from '../config';

const styles = StyleSheet.create({
  textInput: {
    marginVertical: 3,
    flexDirection: 'row',
    alignItems: 'center',
    height: 60,
    backgroundColor: '#fff',
    borderRadius: config.borderRadius,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  input: {
    borderBottomWidth: 0,
    flex: 1,
  },
  active: {

  },
  error: {

  },
  label: {
    width: 60,
    marginRight: config.normalPadding,
    textAlign: 'right',
    color: config.colorMain,
  },
  labelActive: {
    fontWeight: 'bold',
    color: '#000',
  },
  errorMsg: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  actionButton: {
    paddingRight: 12,
  },
  actionIcon: {

  },
});

export default class TextInputCustom extends Component {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.string,
    children: PropTypes.any,
    elementStyle: PropTypes.object,
    isPassowrd: PropTypes.bool,
    right: PropTypes.number,
  };

  constructor(props) {
    super(props);
    if (this.props.isPassword) {
      this.state = {
        showPassword: false
      };
      this.toggleShow = () => {
        this.setState({showPassword: !this.state.showPassword});
      }
    }
  }

  focus() {
    this.refs.nativeInput.focus();
  }

  onFocus = () => {
    const { extraOnFocus, onFocus} = this.props;
    extraOnFocus && extraOnFocus();
    onFocus && onFocus();
  };

  render() {
    const { onFocus, isPassword, elementStyle, right, serverError, label, placeholder, value, error, touched, active, children, ...others} = this.props;
    const showPassword = isPassword ? !this.state.showPassword : false;
    const fadeRight = right || (isPassword ? 40 : config.normalPadding);
    return (
      <View style={[styles.textInput, elementStyle, active ? {borderColor: config.colorBorderActive} : null]}>
        <Text style={[styles.label, active ? styles.labelActive : null]}>{label}</Text>
        <TextInput ref="nativeInput"
          enablesReturnKeyAutomatically
          style={styles.input} autoCorrect={false} underlineColorAndroid="transparent" value={value} placeholder={placeholder} secureTextEntry={showPassword}
          {...others}
          onFocus={this.onFocus}
        />
        { serverError
          ? <FadeInText text={serverError} right={fadeRight}/>
          : error && touched && (others.dirty || !active) && <FadeInText text={error} right={fadeRight}/>
        }
        { isPassword
          ? <TouchableOpacity onPress={this.toggleShow} style={styles.actionButton}>
              <Icon name={this.state.showPassword ? 'eye-slash' : 'eye'} size={18} color={config.colorNormal}/>
            </TouchableOpacity>
          : null
        }
        {this.props.children}
      </View>
    );
  }
}
