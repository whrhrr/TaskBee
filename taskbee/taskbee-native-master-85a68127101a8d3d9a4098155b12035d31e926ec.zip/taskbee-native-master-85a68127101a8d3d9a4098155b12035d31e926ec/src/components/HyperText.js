import React, {
  Linking,
  Alert,
  Component,
} from 'react-native';

import {
  Text
} from '../components';

import config from '../config';

function openUrl(url) {
  return () => {
    Linking.canOpenURL(url).then((supported) => {
      if (!supported) {
        Alert.alert('无法打开链接: ' + url);
      } else {
        Linking.openURL(url);
      }
    });
  };
}

function Link(props){
  return <Text onPress={openUrl(props.url)} style={[props.style, {color: config.brandBlue}]}>{props.children}</Text>;
}


export default class HyperText extends Component{
  render() {
    const props = this.props;
    // Check if nested content is a plain string
    if (typeof props.children === 'string') {

      // Split the content on space characters
      const words = props.children.split(/\s/);

      // Loop through the words
      const contents = words.map(function mapWords(word, i) {
        // Space if the word isn't the very last in the set, thus not requiring a space after it
        const separator = i < (words.length - 1) ? ' ' : '';

        // The word is a URL, return the URL wrapped in a custom <Link> component
        if (word.match(/^https?\:\//)) {
          return <Link key={i} style={props.style} url={word}>{word}{separator}</Link>;
        // The word is not a URL, return the word as-is
        }
        return word + separator;
      });
      return (
        <Text style={props.style}>
          {contents}
        </Text>
      );
    }
    console.log('Attempted to use <HyperText> with nested components. ' +
                 'This component only supports plain text children.');
    return <Text>{props.children}</Text>;
  }

}


