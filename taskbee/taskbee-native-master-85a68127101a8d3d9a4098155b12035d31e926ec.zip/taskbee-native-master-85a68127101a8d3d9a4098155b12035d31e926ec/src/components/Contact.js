import React, {
  PropTypes,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
// import {Link} from 'react-router';
import moment from 'moment';
import {
  Avatar,
  Gender,
  Text,
} from '../components';

import config from '../config'

const styles = StyleSheet.create({
  contact: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    padding: config.normalPadding,
  },
  message: {
    marginLeft: 9,
    flex: 1,
  },
  date: {
    position: 'absolute',
    right: config.normalPadding,
    top: config.normalPadding,
    fontSize: config.fontSmall,
  },
  name: {
    color: config.colorMain,
    fontSize: config.fontBig,
  },
  at: {
    color: config.brandBlue,
  },
  misc: {
  },
  unread: {
    backgroundColor: config.brandRed,
    height: 16,
    borderRadius: 8,
    paddingHorizontal: 4,
    alignSelf: 'flex-end',
    marginTop: 6,
  },
  unreadText: {
    color: config.colorVerySubtle,
    fontSize: config.fontXSmall,
  },
});


const Contact = (props) => {
  const {unread, _id, message, username, avatar, gender} = props;
  const goToChat = props.goTo('Chat', {
    userId: _id,
  }, {
    title: {
      type: 'user',
      username,
      gender,
      userId: _id,
    },
  });
  return (
    <TouchableOpacity style={styles.contact} onPress={goToChat}>
      <Avatar src={avatar} size={40}/>
      <View style={styles.message}>
        <Text style={styles.name}>{username} <Gender gender={gender}/></Text>
        <Text>{message.message}</Text>
      </View>
      <View style={styles.misc}>
        <Text>{moment(message.createdAt).format('MM/D HH:mm')}</Text>
         {
          unread !== undefined && unread !== 0 && <View style={styles.unread}><Text style={styles.unreadText}>{unread}</Text></View>
        }
      </View>

    </TouchableOpacity>
  );
};

Contact.propTypes = {
  _id: PropTypes.string,
  avatar: PropTypes.string,
  message: PropTypes.object,
  username: PropTypes.string,
  unread: PropTypes.number,
  gender: PropTypes.number,
  goTo: PropTypes.func.isRequired,
};

export default Contact;
