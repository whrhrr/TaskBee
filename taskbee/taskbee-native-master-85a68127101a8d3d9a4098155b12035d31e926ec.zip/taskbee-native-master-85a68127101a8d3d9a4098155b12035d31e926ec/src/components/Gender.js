import React, {
  PropTypes
} from 'react-native';

import Icon from './Icon';

const Gender = (props) => {
  const {gender, ...others} = props;
  return (
    <Icon color={gender ? '#D9ACC5' : '#B6C1DB'} name={gender ? 'symbol-woman' : 'symbol-man'} {...others}/>
  );
};
Gender.propTypes = {
  gender: PropTypes.number,
};

export default Gender;
