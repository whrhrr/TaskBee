// 支持全局样式
import React, {
  Text,
  View,
  StyleSheet,
  Platform,
} from 'react-native';

import config from '../config';
const styles = StyleSheet.create({
  text: {
    color: config.colorNormal,
    marginTop: (Platform.OS === 'ios') ? 2 : 0,
    marginBottom: (Platform.OS === 'ios') ? 1 : 0,
    fontSize: config.fontNormal,
    backgroundColor: 'transparent',
  }
});

export default function MyText(props) {
  const {style, children, ...others} = props;
  return <Text style={[styles.text, style]} {...others}>{children}</Text>
}
