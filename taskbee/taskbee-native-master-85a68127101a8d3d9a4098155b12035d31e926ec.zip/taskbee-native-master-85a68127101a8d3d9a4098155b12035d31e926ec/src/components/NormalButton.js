import React, {
  PropTypes,
  Text,
  StyleSheet,
} from 'react-native';

import {MKButton, mdl} from 'react-native-material-kit';
import config from '../config';

const styles = StyleSheet.create({
  button: {
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    shadowRadius: 1,
    shadowOffset: {width: 0, height: 0.5},
    shadowOpacity: 0.7,
    shadowColor: 'black',
    height: 42,
    borderRadius: 21,
    paddingHorizontal: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textNormal: {
    fontWeight: 'bold'
  }
});

function NormalButton(props) {
  let backgroundColor;
  let color;
  const {disabled, working, onPress, style, type, children, text, ...others} = props;
  if (disabled || working) {
    backgroundColor = config.colorVerySubtle;
    color = config.colorNormal;
  } else if (type === 1) {
    backgroundColor = '#fff';
    color = config.colorMain;
  } else {
    color = '#fff';
    backgroundColor = config.brandSecondary;
  }
  return (
    <MKButton
      backgroundColor={backgroundColor}
      shadowRadius={1}
      shadowOffset={{width: 0, height: 0.5}}
      shadowOpacity={0.5}
      shadowColor={config.borderColor}
      onPress={onPress}
      enabled={!disabled && !working}
      style={[styles.button, style]}
      rippleColor={config.rippleColor}
      maskBorderRadius={21}
      rippleLocation="center"
      elevation={1}
    >
      {
        working
        ? <mdl.Spinner />
        : children ? children
        : <Text pointerEvents="none"
          style={[styles.textNormal, {color}]}
        >
          {text}
        </Text>
      }

    </MKButton>
  );
}
NormalButton.propTypes = {
  backgroundColor: PropTypes.string,
  onPress: PropTypes.func,
  text: PropTypes.string,
  disabled: PropTypes.bool,
  working: PropTypes.bool,
  type: PropTypes.number,
  style: PropTypes.any,
};
export default NormalButton;
