import React, {
  StyleSheet,
  Component,
  View,
  Text,
  TouchableOpacity,
  Animated,
} from 'react-native';

import config from '../config';
const styles = StyleSheet.create({
  fadeInText: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    alignSelf: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  text: {
    color: config.brandRed,
  }
});

export default class FadeInText extends Component {

  state = {
    right: new Animated.Value(0),
    opacity: new Animated.Value(0),
  };

  componentDidMount() {
    this.state.right.setValue(-12);     // Start large
    this.state.opacity.setValue(0);     // Start large
    Animated.parallel([
      Animated.spring(this.state.right, {
        toValue: this.props.right || 14,
      }).start(),
      Animated.timing(this.state.opacity, {
        toValue: 1,
      }).start(),
    ]).start();
  }

  render() {
    return (
      <Animated.View pointerEvents="none" style={[styles.fadeInText, this.props.style, {right: this.state.right, opacity: this.state.op}]}>
        <Text pointerEvents="none" style={styles.text}>{this.props.text}</Text>
      </Animated.View>
    );
  }
}
