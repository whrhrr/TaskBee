import React, {
  PropTypes,
  StyleSheet,
  Component,
  View,
  TouchableOpacity,
  TouchableHighlight,
  Image,

} from 'react-native';
import Immutable from 'immutable';

import { Avatar, Text } from './index';

import config from '../config';
import {getRoute} from '../routes';
import locales from '../locales';

const styles = StyleSheet.create({
  myAccount: {
    marginBottom: config.normalPadding,
    backgroundColor: '#fff',
    flexDirection: 'row',
    padding: config.normalPadding,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  right: {
    marginLeft: config.normalPadding,
    flex: 1,
    justifyContent: 'center',
  },
  textMain: {
    fontWeight: 'bold',
  }
});

export default class MyAccount extends Component {
  static propTypes = {
    push: PropTypes.func.isRequired,
    user: Immutable.Map.isMap,
  };

  onPress = (loggedIn) => {
    if (loggedIn) {
      return () => {
        this.props.push(getRoute('MyAccount'));
      };
    }
    return () => {
      this.props.push(getRoute('Join'));
    };
  };

  render() {
    const {user} =  this.props;
    if (user) {
      return (
        <TouchableOpacity style={styles.myAccount} activeOpacity={0.8} onPress={this.onPress(true)}>
          <Avatar src={user.get('avatar')} />
          <View style={styles.right}>
            <Text style={styles.textMain}>{user.get('username')}</Text>
            <Text>{user.get('signature')}</Text>
          </View>
        </TouchableOpacity>
      );
    } else {
      return (
        <TouchableOpacity style={styles.myAccount} activeOpacity={0.8} onPress={this.onPress(false)}>
          <Avatar/>
          <View style={styles.right}>
            <Text style={styles.textMain}>{locales.notLoggedYet}</Text>
            <Text>{locales.goLoginAndRegNow}</Text>
          </View>
        </TouchableOpacity>
      );
    }

  }
}
