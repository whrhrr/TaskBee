import React, {
  Component,
  PropTypes,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';


import config from '../config';

const styles = StyleSheet.create({
});

export default class ThumbImage extends Component {

  constructor(props) {
    super(props);
    state = {
      width: null
    }
  }

  onThumbLayout = ({nativeEvent: { layout: {width}}}) => {
    this.setState({width});
  };

  render() {
    const {onPress} = this.props;
    <TouchableOpacity
      onLayout={this.onThumbLayout}
      onPress={onPress}
    >
      {
        this.state.width && <Image
          style={}
        />
      }
    </TouchableOpacity>
  }
}
