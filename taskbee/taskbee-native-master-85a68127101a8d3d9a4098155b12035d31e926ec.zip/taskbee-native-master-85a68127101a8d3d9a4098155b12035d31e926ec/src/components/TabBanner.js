import React, {
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

import config from '../config';

import {Text} from './index';

const styles = StyleSheet.create({
  mainTab: {
    height: config.bannerHeight,
    paddingTop: config.isIOS ? 12 : 0,
    flexDirection: 'row',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(0,0,0,.1)',
    backgroundColor: config.brandPrimary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: '#fff',
    fontSize: 12,
  },
  button: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderColor: 'rgba(0,0,0,.2)',
    borderWidth: config.borderWidth,
    borderRightWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeButton: {
    borderBottomColor: config.colorSubtle,
    backgroundColor: 'rgba(0,0,0,.7)',
  },
  firstButton: {
    borderTopLeftRadius: 6,
    borderBottomLeftRadius: 6,
  },
  lastButton: {
    borderTopRightRadius: 6,
    borderBottomRightRadius: 6,
    borderRightWidth: config.borderWidth,
  },
  addButton: {
    position: 'absolute',
    right: 0,
    paddingHorizontal: 12,
    top: config.isIOS ? 24 : 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
  },
});


function renderButton(active, {text, onPress}, index, length) {
  return (<TouchableOpacity key={index} onPress={onPress} style={[styles.button, active === index ? styles.activeButton : null, index === 0 ? styles.firstButton : null, (index === length - 1) ? styles.lastButton : null]}>
    <Text style={styles.text}>{text}</Text>
  </TouchableOpacity>);
}

function renderRightButton(rightButton) {
  if (rightButton) {
    return (<TouchableOpacity style={styles.addButton} onPress={rightButton.onPress}>
      {rightButton.children}
    </TouchableOpacity>);
  }
  return null;
}

export default function TabBanner({items, active, rightButton}) {
  return (
    <View style={styles.mainTab}>
      {
        items.map((item, index) => renderButton(active, item, index, items.length))
      }
      {renderRightButton(rightButton)}
    </View>
  );
}
