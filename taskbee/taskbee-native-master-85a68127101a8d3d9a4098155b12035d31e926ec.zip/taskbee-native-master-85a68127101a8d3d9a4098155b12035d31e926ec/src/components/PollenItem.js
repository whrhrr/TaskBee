import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
} from 'react-native';

import {
 Avatar, Tag, Timeline, Gender, Icon, SimpleImages, Text,
} from '../components'; // Tag,

import {stateMap} from '../utils/dataMap';
import moment from 'moment';
moment.locale('zh-cn');

import {calcCrow} from '../utils/dataProcessor';

import config from '../config';
import locales from '../locales';
import {MKButton, mdl} from 'react-native-material-kit';
import shallowCompare from 'react-addons-shallow-compare';


const styles = StyleSheet.create({
  taskItem: {
    backgroundColor: '#fff',
    padding: config.normalPadding,
    borderRadius: config.borderRadius,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    marginBottom: 9,
  },
  taskItemMain: {
    flexDirection: 'row',
  },
  user: {
  // 头像，距离
    marginRight: config.normalPadding,
  },
  content: {
    flex: 1,

  },
  nameText: {
    color: config.colorStand,
    marginRight: 3,
  },
  username: {
    flexDirection: 'row',
    marginBottom: 3,
  },
  gender: {
    alignSelf:'center',
  },
  action: {
    flex: 1,
    alignItems: 'flex-end',
  },
  canVote: {
    fontSize: 9,
  },
  description: {
    marginTop: 6,
  },
  descriptionText: {
    color: config.colorMain,
    fontWeight: '300',
  },
  state: {
    fontSize: config.fontSmall,
    marginTop: 3,
  },
  stand: {
    color: config.brandRed,
    borderWidth: 1,
    borderColor: config.brandRed,
    padding: 2,
    borderRadius: config.borderRadius,
  },
  ongoing: {
    color: config.brandBlue,
  },
  mine: {
    color: config.brandPrimary
  },
  miscView: {
    paddingTop: 12,
  },
  miscTexts: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
  },
  misc: {
    fontSize: config.fontSmall,
    marginLeft: 9,
  },
  inlineIcon: {
    marginRight: 3,
  },
  fav: {
    marginLeft: 12,
    paddingHorizontal: 3,
    paddingVertical: 4,
  },
  favCount: {
    position: 'absolute',
    backgroundColor: '#fff',
    right: 0,
    top: 0,
    fontSize: 8,
  },
  actionIcons: {
    flexDirection:'row',
  },
  subtleTag: {
    backgroundColor: config.colorVerySubtle,
  },
  subtleTagText: {
    color: config.colorLessSubtle,
  },
  score: {
    fontSize:config.fontSmall,
  }
});

export default class PollenItem extends Component {
  static propTypes = {
    _id: PropTypes.string,
    type: PropTypes.number,
    goTo: PropTypes.func.isRequired,
    postId: PropTypes.object,
  };

  constructor(props) {
    super(props);
  }

  shouldComponentUpdate(nextProps, nextState) {
    return shallowCompare(this, nextProps, nextState);
  }
  render() {
    const {type, postId: post, goTo} = this.props;
    const {_id: realId, comments, content: description, createdAt, from, imgs, spreadCount, readerCount, commentCount} = post;
    const {_id: pubId, avatar, username, gender} = from;

    return (
      <TouchableOpacity
        onPress={goTo('PostDetail', {postId: realId})}
        style={[styles.taskItem, type === 1 ? styles.schoolEvent : null]}
        rippleColor={config.rippleColor}
        shadowRadius={1}
        shadowOffset={{width: 0, height: 0.5}}
        shadowOpacity={0.7}
      >
        <View style={styles.taskItemMain}>
          <TouchableOpacity style={styles.user} onPress={goTo('UserDetail', {userId: pubId})}>
            <Avatar size={36} src={avatar}/>
          </TouchableOpacity>
          <View style={styles.content}>
            <View style={styles.username}>
              <View>
                <View style={styles.username}>
                  <Text style={styles.nameText}>{username}</Text><Gender style={styles.gender} gender={gender}/>
                </View>
              <Text style={styles.score}>
                {Math.floor(calcCrow(this.props.postId.loc.coordinates, this.props.myPos)) + 'm'}
              </Text>

              </View>
              <View style={styles.action}>
                <View style={styles.actionIcons}>
                  <TouchableOpacity style={styles.fav} onPress={goTo('PostDetail', {postId: realId, isComment: true})}>
                    <Icon name="bubble-comment-streamline-talk" color={config.colorNormal}/>
                    <Text style={styles.favCount}>{commentCount || '0'}</Text>
                  </TouchableOpacity>
                  <View style={styles.fav}>
                    <Icon name="paper-plane" color={config.colorNormal}/>
                    <Text style={styles.favCount}>{spreadCount || '0'}</Text>
                  </View>
                  <View style={styles.fav}>
                    <Icon name="eye" color={config.colorNormal}/>
                    <Text style={styles.favCount}>{readerCount || '0'}</Text>
                  </View>
                </View>
              </View>
           </View>
            <View style={styles.description}>
              <Text style={styles.descriptionText}>{description}</Text>
              {
                imgs && imgs.length ? <SimpleImages imgs={imgs} goTo={goTo}/>
                 : null
              }
            </View>
          </View>
        </View>
        <View style={styles.miscView}>
          <View style={styles.miscTexts}>
            {
              type === 1 ? <Tag style={styles.subtleTag} textStyle={styles.subtleTagText} name={locales.spreadTag}/> : <Tag  style={styles.subtleTag} textStyle={styles.subtleTagText} name={locales.originTag}/>
            }
            <Text style={styles.misc}><Icon style={styles.inlineIcon} name="clock"/> {moment(createdAt).fromNow()}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  }
}

