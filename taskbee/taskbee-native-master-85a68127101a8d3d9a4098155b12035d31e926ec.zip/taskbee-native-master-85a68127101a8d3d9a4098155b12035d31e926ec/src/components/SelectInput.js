import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Picker,
} from 'react-native';

import {
  Icon,
} from 'react-native-material-design';

import FadeInText from './FadeInText';

import config from '../config';

const styles = StyleSheet.create({
  textInput: {
    marginVertical: 3,
    flexDirection: 'row',
    alignItems: 'center',
    height: 60,
    backgroundColor: '#fff',
    borderRadius: config.borderRadius,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    overflow: 'hidden',
  },
  input: {
    borderBottomWidth: 0,
    flex: 1,
  },
  active: {

  },
  error: {

  },
  label: {
    width: 60,
    marginRight: config.normalPadding,
    textAlign: 'right',
    color: config.colorMain,
  },
  labelActive: {
    fontWeight: 'bold',
    color: '#000',
  },
  errorMsg: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  actionButton: {
    paddingRight: 12,
  },
  actionIcon: {

  },
});

export default class SelectInput extends Component {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.string,
    children: PropTypes.any,
    elementStyle: PropTypes.object,
    right: PropTypes.number,
    onGenderChange: PropTypes.func,
    selectedValue: PropTypes.any,
    picks: PropTypes.array,
  };

  constructor(props) {
    super(props);
  }

  render() {
    const { onValueChange, selectedValue, picks, elementStyle, right, serverError, label, value, error, touched, active, children, ...others} = this.props;
    const fadeRight = right || config.normalPadding;
    return (
      <View style={[styles.textInput, elementStyle, active ? {borderColor: config.colorBorderActive} : null]}>
        <Text style={[styles.label, active ? styles.labelActive : null]}>{label}</Text>
        <Picker style={styles.input}
          selectedValue={selectedValue}
          onValueChange={onValueChange}
          mode="dropdown"
        >
          {picks.map( data => <Picker.Item key={data.value} label={data.label} value={data.value} />)}
        </Picker>

        { serverError
          ? <FadeInText text={serverError} right={fadeRight}/>
          : error && touched && (others.dirty || !active) && <FadeInText text={error} right={fadeRight}/>
        }
        {this.props.children}
      </View>
    );
  }
}
