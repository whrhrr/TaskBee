import React, {
  Component,
  PropTypes,
  StyleSheet,
  Image,
  PixelRatio,
} from 'react-native';

import { Avatar } from 'react-native-material-design';
import config from '../config';

const defaultSize = PixelRatio.getPixelSizeForLayoutSize(60);

function CustomAvatar(props) {
  const size = PixelRatio.getPixelSizeForLayoutSize(props.size) || defaultSize;
  return (
    <Avatar style={props.style}
      size={props.size}
      onPress={props.onPress}
      image={
        props.src ? <Image source={{
          uri: config.imagePath + props.src + `?imageView2/1/w/${size}/h/${size}/format/jpg`
        }}
        /> :
        <Image source={require('../assets/avatar.png')}/>
      }
    />
  );
}

CustomAvatar.propTypes = {
  backgroundColor: PropTypes.string,
  src: PropTypes.string,
  style: PropTypes.any,
  size: PropTypes.number,
  onPress: PropTypes.func,
};
export default CustomAvatar;
