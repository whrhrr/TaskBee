import {
  StyleSheet,
  Dimensions,
} from 'react-native';
const {width} = Dimensions.get('window');

import config from '../config';

export default StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: config.brandGreen,
  },
  yup: {
    // borderColor: config.brandSecondary,
    // borderWidth: 2,
    position: 'absolute',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 5,
    left: 0,
    right: 0,
  },
  yupText: {
    textAlign: 'center',
    fontSize: 16,
    color: config.brandSecondary,
    fontWeight: 'bold',
  },
  nope: {
    // borderColor: config.brandRed,
    // borderWidth: 2,
    position: 'absolute',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 5,
    left: 0,
    right: 0,
  },
  nopeText: {
    textAlign: 'center',
    fontSize: 16,
    color: config.brandRed,
    fontWeight: 'bold',
  },
  taskItem: {
    backgroundColor: '#fff',
    padding: config.normalPadding,
    borderRadius: config.borderRadius,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    alignSelf: 'stretch',
    flex: 1,
  },
  description: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  descriptionText: {
    fontSize: config.fontLarge,
    color: config.colorMain,
  },
  miscView: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    alignItems: 'center'
  },
  distanceButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  distance: {
    color: config.colorSubtle,

  },
  misc: {
    flex: 1,
    alignSelf: 'flex-end',
    color: config.colorSubtle,
    textAlign: 'right',
  },
  miscCard: {
    flex: 1,
    color: config.colorSubtle,
  },
  animatedCard: {
    margin: config.normalPadding,
    flex: 1,
    alignSelf: 'stretch',
  },
  // 底下信息
  infos: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    alignItems: 'center',
  },
  user: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  infosDetail: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    alignItems: 'center',
    marginHorizontal: config.normalPadding,
    marginBottom: config.normalPadding,
  },

  username: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 9,
  },
  nameText: {
    fontSize: config.fontBig,
    paddingRight: 3,
  },
  actionIcons: {
    alignSelf: 'flex-end',
    flexDirection: 'row',
  },
  fav: {
    marginLeft: 9,
    paddingHorizontal: 3,
    paddingVertical: 7,
  },
  favCount: {
    position: 'absolute',
    right: 0,
    top: 0,
    fontSize: 12,
    backgroundColor: '#fff',
  },

  // detail
  containerDetail: {
    marginTop: config.bannerHeight,
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  nameTextDetail: {
    color: config.colorMain,
  },
  favCountDetail: {
    position: 'absolute',
    right: 0,
    top: 0,
    fontSize: 12,
    color: config.colorSubtle,
    backgroundColor: config.brandBackground,
  },
  scrollContainer: {
    flex: 1,
    paddingVertical: config.normalPadding,
  },
  comments: {
    marginVertical: config.normalPadding,
  },
  sectionTitle: {
    marginLeft: config.normalPadding,
    color: config.colorStand,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  empty: {
    marginLeft: config.normalPadding,
  },
  needLogin: {
    alignSelf: 'center',
  },
  spreadSection: {
    paddingHorizontal: config.normalPadding,
    flexDirection: 'row',
  },
  spreadBy: {
    position: 'relative',
    width: 30,
    height: 30,
    marginRight: 3,
    marginBottom: 3,
  },
  decorationIcon: {
    position: 'absolute',
    right: 0,
    top: 0,
    color: config.brandSecondary,
  },
  reportButton: {
    alignSelf: 'flex-end'
  },
  report: {
    textAlign: 'right',
    fontSize: config.fontSmall,
    color: config.colorSubtle,
  }
});
