import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
  Text,
} from 'react-native';

import {
  MKRadioButton,
} from 'react-native-material-kit';

import {
  RadioButtonGroup
} from 'react-native-material-design';


import FadeInText from './FadeInText';

import config from '../config';
import locales from '../locales';
const styles = StyleSheet.create({
  col: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  group: {
    flexDirection: 'row'
  },
  button: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  }
});

export default class SimpleRadios extends Component {
  static propTypes = {
    value: PropTypes.any,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.any,
  };
  constructor(props) {
    super(props);
    this.radioGroup = new MKRadioButton.Group();
  }

  onChange = (value) => {
    return ({checked}) => {
      if (!checked) return;
      this.props.onUpdate(value);
   }
  };

  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去

  }
  render() {
    const { serverError, value, error, touched, active, ...others} = this.props;
    return <View>
      <View style={styles.group}>
        <View style={styles.button}>
           <MKRadioButton
            fillColor={config.brandGreen}
            checked={value == '0'}
            group={this.radioGroup}
            onCheckedChange={this.onChange('0')}
          />
          <Text>{locales.male}</Text>
        </View>
        <View style={styles.button}>
          <MKRadioButton
            fillColor={config.brandGreen}
            checked={value == '1'}
            group={this.radioGroup}
            onCheckedChange={this.onChange('1')}
          />
          <Text>{locales.female}</Text>
        </View>
      </View>
      {!serverError && error && touched && (others.dirty || !active) && <FadeInText text={error} right={config.normalPadding}/>}
    </View>;
  }
}
