import React, {
  StyleSheet,
  Dimensions,
  PropTypes,
  Component,
  View,
  TouchableOpacity,
  Animated,
  Platform,
  AsyncStorage,
} from 'react-native';
const {width} = Dimensions.get('window');

import config from '../config';

import {connect} from 'react-redux';

import {goTo, requireLogin} from '../utils/navigation';


import {Icon, Text} from './index';
import locales from '../locales';

const styles = StyleSheet.create({
  mainTab: {
    height: 52,
    // paddingTop: Platform.OS === 'ios' ? 12 : 0,
    flexDirection: 'row',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(0,0,0,.1)',
  },
  button: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
  },
  theText: {
    color: config.colorLessSubtle,
    fontSize: 12,
    marginTop: 2,
  },
  text: {
    fontSize: config.fontSmall,
    color: '#fff',
  },
  activeText: {
    fontSize: config.fontSmall,
    color: '#fff',
  },
  addButton: {
    position: 'absolute',
    right: 0,
    // top: (Platform.OS === 'ios') ? 24 : 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
  },
  addText: {
    fontSize: 30,
  },
  tabUnderlineStyle: {
    position: 'absolute',
    width: width / 4,
    height: config.borderWidth,
    backgroundColor: config.brandPrimary,
    top: 0,
  },
  badge: {
    position: 'absolute',
    backgroundColor: config.brandRed,
    left: width / 8 + 4,
    top:6,
    height: 8,
    width: 8,
    borderRadius: 4,
  },
  unreadText: {
    color: config.colorVerySubtle,
    fontSize: 11,
  },

});

class MainTab extends Component {
  static propTypes = {
    goToPage: PropTypes.func,
    activeTab: PropTypes.number,
    tabs: PropTypes.array
  };

  onGoto = (index) => {
    return () => {
      this.props.goToPage(index);
    };
  };

  requireLogin = requireLogin.bind(this);
  goTo = goTo.bind(this);

  renderTabOption(name, page, iconName, count) {
    const isTabActive = this.props.activeTab === page;
    return (
      <TouchableOpacity key={name} onPress={this.onGoto(page)} style={styles.button}>
        <Icon name={iconName} size={18} color={isTabActive ? config.brandPrimary : 'rgba(0,0,0,.6)'} style={styles.icon} />
        {count ? <View style={styles.badge}></View> : null}
        <Text style={[styles.theText, {color: isTabActive ? config.brandPrimary : 'rgba(0,0,0,.6)'}]}>{name}</Text>
      </TouchableOpacity>
    );
  };

  renderActionButton() {
    switch (this.props.activeTab) {
      case 0:
      case 1:
        return (<TouchableOpacity style={styles.addButton} onPress={this.goTo('Mapbox')}>
          <Icon name="map" size={24} color={"rgba(0,0,0,.6)"}/>
        </TouchableOpacity>)
      case 2:
        return (<TouchableOpacity style={styles.addButton} onPress={this.requireLogin(this.goTo('Friend'))}>
          <Text style={styles.text}>{locales.friends}</Text>
        </TouchableOpacity>);
      default:
        break;
    }
  }

  render() {
    //const left = this.props.scrollValue.interpolate({
    //  inputRange: [0, 1], outputRange: [0, tabWidth]
    //});
    // 女生节
    return (
      <View style={styles.mainTab}>
        {/*<Animated.View style={[styles.tabUnderlineStyle, {left}]} */}
        {this.renderTabOption(locales.tabTask, 0, 'food-ice-cream-streamline')}
        {this.renderTabOption(locales.tabPollen, 1, 'taskbee')}
        {this.renderTabOption(locales.tabMessage, 2, 'bubble-comment-streamline-talk', this.props.messageCount + this.props.sysCount)}
        {this.renderTabOption(locales.tabMe, 3, 'man-people-streamline-user')}
        {/*this.renderActionButton()*/}
      </View>
    );
  }
}

export default connect(state => ({
  messageCount: state.messages.totalUnread,
  sysCount: state.sysMessages.unread,
  token: state.me.get('token'),
}))(MainTab)
