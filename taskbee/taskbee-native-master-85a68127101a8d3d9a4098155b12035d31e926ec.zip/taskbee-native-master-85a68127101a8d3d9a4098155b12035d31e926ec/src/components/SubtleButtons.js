import React, {
  Component,
  PropTypes,
  View,
  TouchableOpacity,
  Text,
  StyleSheet,

} from 'react-native';
import config from '../config';
const styles = StyleSheet.create({
  subtleButtons: {
    alignSelf: 'stretch',
    margin: config.normalPadding,
    flexDirection: 'row',
  },
  right: {
    position: 'absolute',
    right: 0,
  },
  text: {
    color: config.brandBlue,
  }
});

export default class SubtleButtons extends Component {
  static propTypes = {
    leftText: PropTypes.any,
    leftTo: PropTypes.func,
    rightText: PropTypes.any,
    rightTo: PropTypes.func,
  };

  render() {
    const {leftText, leftTo, rightText, rightTo} = this.props;
    return (
      <View style={styles.subtleButtons}>
        {leftText && <TouchableOpacity style={styles.left} onPress={leftTo}>
          <Text style={styles.text}>{leftText}</Text>
        </TouchableOpacity>}
        {rightText && <TouchableOpacity style={styles.right} onPress={rightTo}>
          <Text style={styles.text}>{rightText}</Text>
        </TouchableOpacity>}
      </View>
    );
  }
}
