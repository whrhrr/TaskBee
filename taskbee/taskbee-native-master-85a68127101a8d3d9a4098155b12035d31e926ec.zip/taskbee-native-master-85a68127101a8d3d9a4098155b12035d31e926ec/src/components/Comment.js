import React, {
  PropTypes,
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import {
  Avatar,
  Gender,
  Text,
} from '../components';
import moment from 'moment';
import config from '../config';
const styles = StyleSheet.create({
  comment: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    padding: config.normalPadding,
  },
  message: {
    marginLeft: 9,
    flex: 1,
  },
  date: {
    position: 'absolute',
    right: config.normalPadding,
    top: config.normalPadding,
    fontSize: config.fontSmall,
  },
  name: {
    color: config.colorMain,
    fontSize: config.fontBig,
    marginBottom: config.isIOS ? 2 : 1,
  },
  at: {
    color: config.brandBlue,
  }
});

const Comment = (props) => {
  const {goTo, from, body, onCommentSelect, to} = props;
  const date = moment(props.date).format('MM/D HH:mm');
  const onAvatarClick = goTo('UserDetail', {userId: from._id});
  return (
    <TouchableOpacity style={styles.comment} onPress={onCommentSelect(from)}>
      <TouchableOpacity onPress={onAvatarClick}><Avatar src={from.avatar} size={42}/></TouchableOpacity>
      <View style={styles.message}>
        <Text style={styles.name}>{from.username}<Gender gender={from.gender}/></Text>
        <Text>{to && <Text style={styles.at}>@{to.username}</Text>}{body}</Text>
      </View>
      <Text style={styles.date}>
        {date}
      </Text>
    </TouchableOpacity>
  );
};

Comment.propTypes = {
  date: PropTypes.string.isRequired,
  onCommentSelect: PropTypes.func,
  from: PropTypes.any.isRequired,
  to: PropTypes.any,
  body: PropTypes.string.isRequired,
  goTo: PropTypes.func.isRequired,
};

export default Comment;
