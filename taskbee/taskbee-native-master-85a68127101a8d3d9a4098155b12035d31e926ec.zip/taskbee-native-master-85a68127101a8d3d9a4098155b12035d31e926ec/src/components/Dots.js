import React, {
  PropTypes,
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

import config from '../config';

const styles = StyleSheet.create({
  dots: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: config.normalPadding * 2,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  dot: {
    marginHorizontal: 3,
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: config.colorVerySubtle,
    borderWidth: config.borderWidth,
  },
  active: {
    backgroundColor: config.brandPrimary,
  },
});

function renderDot(index, active, goToPage) {
  let activeStyle;
  if (index === active) activeStyle = styles.active;
  return (<TouchableOpacity key={index} style={[styles.dot, activeStyle]} onPress={() => goToPage(index)}>
  </TouchableOpacity>);
}

function renderDots(total, active, goToPage) {
  let index = 0;
  const renderArray = [];
  while (index < total) {
    renderArray.push(renderDot(index, active, goToPage));
    index++;
  }
  return renderArray;
}

const Dots = (props) => {
  const {goToPage, tabs, activeTab, ref} = props;
  return (
    <View style={styles.dots}>
      {renderDots(tabs.length, activeTab, goToPage)}
    </View>
  );
};

Dots.propTypes = {
  style: PropTypes.any,
  activeTab: PropTypes.number,
  tabs: PropTypes.array,
  goToPage: PropTypes.func,
};

export default Dots;
