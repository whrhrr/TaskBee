import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
  Text,
  Alert,
  Linking,
} from 'react-native';


import {NormalButton} from './index';

import config from '../config';
import locales from '../locales';

const styles = StyleSheet.create({
  button: {
    marginTop: 9,
    marginHorizontal: config.normalPadding,
  }
});

export default class SimpleRadios extends Component {
  static propTypes = {
    value: PropTypes.any,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.any,
  };

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
    }
  }

  checkUpdate = () => {
    this.setState({loading: true});
    fetch(config.androidUpdate).then(
      (res) => res.json()
    ).then( value => {
       this.setState({loading: false});
      if (value.version && (value.version[0] > config.appver[0] || value.version[1] > config.appver[1])) {
      // 需要更新apk
        Alert.alert(locales.gotANewVersion + value.version.join('.'), value.description + locales.updateOrNot, [
          {text: locales.dontUpdate},
          {text: locales.downloadUpdate, onPress: () => {Linking.openURL('https://taskbee.cn/latest.apk')} },
        ]);
      } else {
        Alert.alert(locales.needNoUpdate, locales.alreadyLates, [
          {text: locales.ok},
        ]);
      }
    }).catch( () => {
      this.setState({loading: false});
      Alert.alert(locales.failedToQuery, locales.pleaseTryAgainLater, [
        {text: locales.ok},
      ]);
    });
  };

  render() {
    return <NormalButton style={styles.button} text={locales.checkForUpdate} onPress={this.checkUpdate} working={this.state.loading}>

    </NormalButton>;
  }
}
