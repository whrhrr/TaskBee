import React, {
  PropTypes,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import {
  Avatar,
  Gender,
  Rating,
} from '../components';
import moment from 'moment';
import config from '../config';
const styles = StyleSheet.create({
  comment: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    padding: config.normalPadding,
  },
  message: {
    marginLeft: 9,
    flex: 1,
  },
  right: {
    position: 'absolute',
    right: config.normalPadding,
    top: config.normalPadding,
  },
  createdAt: {
    fontSize: config.fontSmall,
  },
  name: {
    color: config.colorMain,
    fontSize: config.fontBig,
  },
  text: {
    color: config.colorMain,
    marginTop: 3,
  },
  descript: {
    fontSize: config.fontSmall,
  }
});

const Comment = (props) => {
  const {goTo, from, message, type} = props;
  const createdAt = moment(props.createdAt).format('MM/D HH:mm');
  const onAvatarClick = goTo('UserDetail', {userId: from._id});
  return (
    <View style={styles.comment}>
      <TouchableOpacity onPress={onAvatarClick}><Avatar src={from.avatar} onPress={onAvatarClick}/></TouchableOpacity>
      <View style={styles.message}>
        <Text style={styles.name}>{from.username}<Gender gender={from.gender}/></Text>
        <Text style={styles.descript}>评价{type ? '接手人' : '发布人'}</Text>
        <Text style={styles.text}>{message || '没写评价啦'}</Text>
      </View>
      <View style={styles.right}>
        <Rating value={props.score} size={9}/>
        <Text style={styles.createdAt}>
          {createdAt}
        </Text>
      </View>
    </View>
  );
};

Comment.propTypes = {
  createdAt: PropTypes.string.isRequired,
  from: PropTypes.any.isRequired,
  message: PropTypes.string.isRequired,
  goTo: PropTypes.func.isRequired,
  type: PropTypes.bool,
  score: PropTypes.number,
};

export default Comment;
