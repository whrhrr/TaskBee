import {mdl} from 'react-native-material-kit';

const Indeterminate = mdl.Progress.indeterminateProgress()
  .withStyle({
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  })
  .build();

export default Indeterminate;
