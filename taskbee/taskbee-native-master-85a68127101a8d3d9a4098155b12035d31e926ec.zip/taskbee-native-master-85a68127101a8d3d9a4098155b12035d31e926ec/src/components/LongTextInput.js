import React, {
  Component,
  PropTypes,
  StyleSheet,
  TextInput,
  View,
  TouchableOpacity,
} from 'react-native';

import {FadeInText, Text,} from './index';

import config from '../config';

const styles = StyleSheet.create({
  textInput: {
    marginVertical: 3,
    flexDirection: 'column',
    backgroundColor: '#fff',
    borderRadius: config.borderRadius,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  input: {
    flex: 1,
    borderBottomWidth: 0,
    textAlignVertical: 'top',
    height: 180,
    fontSize: config.fontNormal,
    padding: config.normalPadding,
  },
  active: {

  },
  error: {

  },
  label: {
    marginTop: config.normalPadding,
    marginLeft: config.normalPadding,
    color: config.colorMain,
  },
  labelActive: {
    fontWeight: 'bold',
    color: '#000',
  },
  errorMsg: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  actionButton: {
    paddingRight: 12,
  },
  count: {
    position: 'absolute',
    right: config.normalPadding,
    bottom: config.normalPadding,
  }
});

export default class TextInputCustom extends Component {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.string,
    children: PropTypes.any,
    elementStyle: PropTypes.object,
    right: PropTypes.number,
    onKeyDown: PropTypes.func,
  };

  constructor(props) {
    super(props);
  }

  focus() {
    this.refs.nativeInput.focus();
  }

  onFocus = () => {
    const { extraOnFocus, onFocus} = this.props;
    extraOnFocus && extraOnFocus();
    onFocus && onFocus();
  };

  overrideOnChange = (event) => {
    const text = event.nativeEvent.text;
    if (text.length && text[text.length - 1] === '\n') {
      if (this.props.onEndEditing) this.props.onEndEditing();
    } else {
      this.props.onChange(event);
    }
  };

  render() {
    const { onFocus, maxLength, maxCount, row, onKeyDown, inputStyle, elementStyle, right, serverError, label, placeholder, value, error, touched, active, children, ...others} = this.props;
    const fadeRight = right || config.normalPadding;
    return (
      <View style={[styles.textInput, elementStyle, active ? {borderColor: config.colorBorderActive} : null]}>
        { label && <Text style={[styles.label, active ? styles.labelActive : null]}>{label}</Text>}
        <TextInput ref="nativeInput"
          {...others}
          style={[styles.input, inputStyle]}
          autoCorrect={false}
          underlineColorAndroid="transparent"
          value={value}
          placeholder={placeholder}
          multiline
          maxLength={maxCount || maxLength}
          onKeyPress={onKeyDown}
          onFocus={this.onFocus}
          onChange={this.overrideOnChange}
          // enablesReturnKeyAutomatically
        />
        {maxCount && <Text style={styles.count}>{maxCount - (value ? value.length : 0)}</Text>}
        { serverError
          ? <FadeInText style={{top: label ? 50 : config.normalPadding}} text={serverError} right={fadeRight}/>
          : error && touched && (others.dirty || !active) && <FadeInText style={{top: label ? 50 : config.normalPadding}} text={error} right={fadeRight}/>
        }
        {this.props.children}
      </View>
    );
  }
}
