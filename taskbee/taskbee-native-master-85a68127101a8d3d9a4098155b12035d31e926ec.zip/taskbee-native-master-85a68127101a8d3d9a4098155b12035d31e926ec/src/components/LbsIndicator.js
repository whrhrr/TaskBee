import React, {
  StyleSheet,
  Text,
  TouchableOpacity,
  PropTypes,
  View,
  Alert,
} from 'react-native';

import config from '../config';
import locales from '../locales';

const styles = StyleSheet.create({
  lbsIndicator: {
    alignSelf: 'center',
    backgroundColor: config.colorVerySubtle,
    height: 20,
    borderRadius: 10,
    paddingHorizontal: 9,
    marginVertical: 9,
  },
  lbsText: {
    fontSize: config.fontSmall,
  },
});

function showInformation() {
  Alert.alert(locales.lbsNotiTitle, locales.lbsNotiContent, [
    {text: locales.lbsOk},
  ]);
}

export default function LbsIndicator(props) {
  const {lbsLoaded, lbsLoading} = props;
  if (!lbsLoaded) {
    if (lbsLoading) {
      return (<TouchableOpacity style={styles.lbsIndicator} onPress={showInformation}>
        <Text style={styles.lbsText}>{locales.lbsLoadingText}</Text>
      </TouchableOpacity>);
    }

    return (<TouchableOpacity style={styles.lbsIndicator} onPress={showInformation}>
      <Text style={styles.lbsText}>{locales.lbsLoadFail}</Text>
    </TouchableOpacity>);
  }
  return <View />;
}

LbsIndicator.propTypes = {
  lbsLoaded: PropTypes.bool,
  lbsLoading: PropTypes.bool,
};
