import React, {
  Component,
  PropTypes,
  View,
  Text,
  StyleSheet,
  AsyncStorage,
  Animated,
  Dimensions,
} from 'react-native';
import {
  Icon,
} from '../components';


import config from '../config';
const {height, width} = Dimensions.get('window');

const styles = StyleSheet.create({

});

const colors = [
  config.brandPrimary,
  config.brandGreen,
  config.brandBlue,
  config.brandRed,
]

export default class Flower extends Component {
  static propTypes = {
    children: PropTypes.any,
    index: PropTypes.number,
  };

  constructor(props) {
    super(props);
    this.color = colors[Math.floor(Math.random() * colors.length)];
    this.rotationDuration = 1200 + 1200 * Math.random();
    this.speed = 20 + 25 * Math.random();
    this.state = {
      pos: new Animated.ValueXY(),
      opacity: new Animated.Value(0),
      rotation: new Animated.Value(1 - 2 * Math.random()),
    };
  }

  componentDidMount() {
    this.startAnimate();
    this.rotation();
  }

  startAnimate = () => {
    const top = Math.random() * height / 3;
    const goLegnth = height - top;
    this.state.opacity.setValue(0);
    this.state.pos.setValue({x: Math.random() * width, y: top});
    Animated.timing(
      this.state.opacity,
      {
        toValue: 1,
        duration: 1500,
      }
    ).start();
    Animated.timing(
      this.state.pos,
      {
        toValue: {x: Math.random() * width, y: top + goLegnth},
        duration: goLegnth * this.speed,
      },
    ).start(endState => {
      if (endState.finished) this.endAnimate();
    });
  };

  endAnimate = () => {
    Animated.timing(
      this.state.opacity,
      {
        toValue: 0,
        duration: 350,
      }
    ).start(endState => {
      if (endState.finished)  this.startAnimate();
    });
  };

  rotation = () => {
    Animated.timing(
      this.state.rotation, {
        toValue: 1,
        duration: this.rotationDuration,
      }
    ).start(endState => {
      if (endState.finished) this.rotationBack();
    })
  };

  rotationBack = () => {
    Animated.timing(
      this.state.rotation, {
        toValue: -1,
        duration: this.rotationDuration,
      }
    ).start(endState => {
      if (endState.finished) this.rotation();
    });
  };

  render() {
    const {pos, opacity, rotation: rawRota} = this.state;
    const rotate = rawRota.interpolate({inputRange: [-1, 0, 1], outputRange: ["-90deg", "0deg", "90deg"]});
    const transform = pos.getTranslateTransform();
    transform.push({rotate});
    return <Animated.View style={[{position: 'absolute'}, {opacity, transform}]}>
      <Icon name="flower" size={32} color={this.color}/>
    </Animated.View>;
  }

}
