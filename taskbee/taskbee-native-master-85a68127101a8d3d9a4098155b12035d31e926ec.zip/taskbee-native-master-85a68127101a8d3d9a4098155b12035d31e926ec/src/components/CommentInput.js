import React, {
  Component,
  PropTypes,
  StyleSheet,
  TextInput,
  View,
  TouchableOpacity,
} from 'react-native';

import {reduxForm} from 'redux-form';
import commentValidation from '../utils/commentValidation';
import {connect} from 'react-redux';
import {newComment} from '../modules/task';
import {mdl} from 'react-native-material-kit';

import {
  FadeInText,
  Icon,
} from '../components';

import locales from '../locales';

import config from '../config';
const styles = StyleSheet.create({
  textInput: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    height: 60,
    backgroundColor:'#fff',
    borderTopWidth: config.borderWidth,
    borderTopColor: config.colorBorder,
  },
  input: {
    flex: 1,
    borderBottomWidth: 0,
  },
  actionButton: {
    width: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

class CommentInput extends Component {
  static propTypes = {
    taskId: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.string,
    serverError: PropTypes.any,
    error: PropTypes.any,
    commentSubmitting: PropTypes.bool,
    handleSubmit: PropTypes.func.isRequired,
    onCommentClose: PropTypes.func,
    newComment: PropTypes.func.isRequired,
    fields: PropTypes.object.isRequired,
    to: PropTypes.object
  };

  onSendClick = (data) => {
    data.preventDefault();
    const {commentSubmitting, fields: {comment: {valid}}} = this.props;
    if (!commentSubmitting && valid) {
      this.props.handleSubmit(this.handleNewComment)(data);
    }
  };

  handleNewComment = (data) => {
    const {taskId, to, token} = this.props;
    this.props.newComment({
      taskId,
      to: to ? to.id : null,
      body: data.comment,
      token,
    });
    this.props.initializeForm({
      comment: '',
    });
  };

  render() {
    // 引用textinput
    const { needPadding, to, commentSubmitting, onCommentClose, serverError, fields: { comment: rawComment}, noClose, noAutoFocus } = this.props;
    const { error, valid, dirty, active, touched, ...comment} = rawComment;
    return (
      <View style={styles.textInput}>
        {noClose ? null : <TouchableOpacity style={styles.actionButton} onPress={onCommentClose}><Icon name="cross-mark" size={18} color={config.colorNormal}/></TouchableOpacity>}
        <TextInput {...comment}
          autoComplete="off" autoFocus={!noAutoFocus}
          placeholder={to ? ('@' + to.username ) : locales.commentPlaceholder}
          style={[styles.input, needPadding && {paddingLeft: config.normalPadding}]}
          underlineColorAndroid="transparent"
          onSubmitEditing={this.onSendClick}
          autoCorrect={false}
        />
        <TouchableOpacity style={styles.actionButton} onPress={this.onSendClick}>
         {commentSubmitting ? <mdl.Spinner/>
         : <Icon name="paper-plane" size={18} color={config.colorNormal}/>}
        </TouchableOpacity>
        {serverError && <FadeInText text={serverError.message} right={40}/>}
        {!serverError && error && touched && (dirty || !active) && <FadeInText text={error} right={40} />}
      </View>
    );
  }
}


export default connect(
  (state, props) => ({
    serverError: state.task.get(props.taskId).get('commentError'),
    commentSubmitting: state.task.get(props.taskId).get('commentSubmitting'),
    token: state.me.get('token'),
  }), {newComment}) (
  reduxForm({
    form: 'task',
    fields: ['comment'],
    validate: commentValidation
  })(
    CommentInput
  )
)

import {newComment as newCommentPost} from '../modules/post';
export const PostCommentInput = connect(
  (state, props) => {
    const post = state.post.get(props.taskId);
    return {
      noClose: true,
      noAutoFocus: !props.needFocus,
      needPadding: true,
      serverError: post ? post.get('commentError') : null,
      commentSubmitting: post ? post.get('commentSubmitting') : false,
      token: state.me.get('token'),
    }
  }, {newComment: newCommentPost}) (
  reduxForm({
    form: 'task',
    fields: ['comment'],
    validate: commentValidation
  })(
    CommentInput
  )
)
