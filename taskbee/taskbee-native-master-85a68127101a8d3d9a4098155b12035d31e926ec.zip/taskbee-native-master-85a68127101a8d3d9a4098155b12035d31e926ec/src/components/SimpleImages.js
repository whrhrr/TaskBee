import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity,
  PixelRatio,
} from 'react-native';

import config from '../config';

// const size = PixelRatio.getPixelSizeForLayoutSize(60);

const styles = StyleSheet.create({
  images: {
    alignSelf: 'stretch',
    flexDirection: 'row',
    marginTop: 3,
  },
  button: {
    marginRight: config.normalPadding / 2,
  },
  /*
  image: {
    width: 60,
    height: 60,
  },
  */
});

export default class SimpleImages extends Component {
  state = {

  };

  onLayout = ({nativeEvent: { layout: {width}}}) => {
    // 计算size
    const size = (width - config.normalPadding / 2) / 3;
    this.size = size;
    this.pixelSize = PixelRatio.getPixelSizeForLayoutSize(size);
    this.style = {
      width: size,
      height: size,
      backgroundColor: config.colorVerySubtle,
    }
    this.setState({width});
  };

  renderImages(imgs, style, width, pixelSize, goTo, size) {
    if (imgs.length === 1) {
      const img = imgs[0];
      return (<TouchableOpacity onPress={goTo('ImageView', {
            images: imgs,
            initial: 0,
          })}
          ><Image
            style={{backgroundColor: config.colorVerySubtle, height: size * 1.5, width: size * 1.5 / img.height * img.width}}
            source={{uri: config.imagePath + img.key + `?imageView2/2/h/${PixelRatio.getPixelSizeForLayoutSize(size * 1.5)}`}}
          />
          </TouchableOpacity>)
    } else {
      if (width) {
        return imgs.map((img, index) => <TouchableOpacity key={index} style={styles.button} onPress={goTo('ImageView', {
            images: imgs,
            initial: index,
          })}
          ><Image
            style={style}
            source={{uri: config.imagePath + img.key + `?imageView2/1/w/${pixelSize}/h/${pixelSize}`}}
          />
          </TouchableOpacity>
        )
      }
    }
    return <View/>;
  }

  render() {
    const {imgs, style, goTo} = this.props;

    return (<View
      style={[styles.images, style]}
      onLayout={this.onLayout}
     >
      {this.renderImages(imgs, this.style, this.state.width, this.pixelSize, goTo, this.size)}
    </View>);
  }

}
