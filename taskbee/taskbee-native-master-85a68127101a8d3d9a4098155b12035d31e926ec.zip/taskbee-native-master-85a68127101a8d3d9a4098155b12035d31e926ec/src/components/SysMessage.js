import React, {
  View,
  Text,
  PropTypes,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';import moment from 'moment';

import config from '../config';

const styles = StyleSheet.create({
  sysMessage: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    padding: config.normalPadding,
    alignItems: 'center',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  message: {
    color: config.colorMain,
    flex: 1,
  },
  date: {
    alignSelf: 'flex-end',
  },
  indicator: {
    marginRight: 3,
    marginLeft: -6,
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: config.brandRed,
  }
});
const Message = (props) => {

  const {message, href, goTo, read, type, visit} = props;
  const date = moment(props.createdAt).format('MM/D HH:mm');
  function onClick() {
    if (type === 'vote') {
      goTo('UserDetail', {userId: href})();
    } else if (type === 'postComment') {
      goTo('PostDetail', {postId: href, isComment: true})();
    } else if (type === 'friend') {
      goTo('Chat', {userId: href})();
    } else if (type === 'comment') {
      goTo('TaskDetail', {taskId: href, isComment: true})();
    } else goTo('TaskDetail', {taskId: href})();
    visit(href);
  }
  return (
    <TouchableOpacity style={styles.sysMessage} onPress={onClick}>
      {!read && <View style={styles.indicator}></View>}
      <Text style={styles.message}>{message}</Text>
      <Text style={styles.date}>{date}</Text>
    </TouchableOpacity>
  );
};

Message.propTypes = {
  type: PropTypes.string,
  href: PropTypes.string,
  read: PropTypes.bool,
  createdAt: PropTypes.string,
  message: PropTypes.string.isRequired,
  goTo: PropTypes.func.isRequired,
  visit: PropTypes.func.isRequired,
};


export default Message;
