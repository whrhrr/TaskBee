'use strict'

import React, {
  Animated,
  Component,
  Dimensions,
  PanResponder,
  View,
  Text,
  StyleSheet
} from 'react-native'

import ScrollableTabView from 'react-native-scrollable-tab-view';

import Dots from './Dots'

const hasValue = v => v != null;

const styles = StyleSheet.create({
  swipe: {
    backgroundColor: '#000',
  },
  sceneContainerStyle: {
    flex: 1,
    flexDirection: 'row',
  }
});

export default class Swiper extends Component {
  static propTypes = {
    children: React.PropTypes.node.isRequired,
    index: React.PropTypes.number,
    initialIndex: React.PropTypes.number,
    pager: React.PropTypes.bool,
    onPageChange: React.PropTypes.func,
    activeDotColor: React.PropTypes.string,
  };

  static defaultProps = {
    initialIndex: 0,

  };

  constructor(props) {
    super(props);
  }

  componentWillReceiveProps(nextProps) {
    if (this.isControlled && nextProps.index !== this.state.index) {
      this.goToPage(nextProps.index);
      clearTimeout(this.revertSwipeTimer);
    }
  }

  renderTabBar = () => {
    return (
      <Dots/>
    );
  }


  render() {
    return (
      <ScrollableTabView
       style={styles.swipe}
       tabBarPosition="overlayBottom"
       renderTabBar={this.renderTabBar}
       initialPage={this.props.initialPage || 0}
      >
        { this.props.children }
      </ScrollableTabView>
    )
  }
}
