import React, {
  View,
  StyleSheet,
} from 'react-native';

import config from '../config';

import {Text} from './index';

const styles = StyleSheet.create({
  tag: {
    paddingHorizontal: 9,
    paddingTop: 2,
    paddingBottom: 3,
    backgroundColor: config.brandBlue,
    borderRadius: config.borderRadius,
    alignSelf: 'flex-start',
  },
  tagText: {
    color: '#fff',
    fontSize: config.fontSmall,
  },
});

export default function Tag({style, textStyle, name, onPress}) {
  return (
    <View style={[styles.tag, style]} onPress={onPress}>
      <Text style={[styles.tagText, textStyle]}>{name}</Text>
    </View>
  );
}
