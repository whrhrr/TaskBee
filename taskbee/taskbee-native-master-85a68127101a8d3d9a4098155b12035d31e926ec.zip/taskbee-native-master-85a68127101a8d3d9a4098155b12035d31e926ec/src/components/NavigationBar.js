import React, {
  Component,
  View,
  Text,
  StyleSheet,
  TouchableHighlight,
  Platform,
  BackAndroid,
  Navigator,
  Dimensions,
  AsyncStorage,
  InteractionManager,
} from 'react-native';


const styles = StyleSheet.create({
  navStyle: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(0,0,0,.1)',
  }
});

import config from '../config';

const COMPONENT_NAMES = ['Title', 'LeftButton', 'RightButton'];
export default class NavigationBar extends Navigator.NavigationBar {
  render() {
    const routes = this.props.navState.routeStack;
    let route;
    if (routes.length > 1) route = routes[routes.length - 1];
    else return null;
    if (route.transparent && !route.needBack) return null;
    const navBarStyle = {
      height: config.bannerHeight,
      backgroundColor: route && route.backgroundColor ? route.backgroundColor : config.brandPrimary,
      borderBottomColor: route && route.transparent ? 'transparent' : 'rgba(0,0,0,.1)',
    };

    const navState = this.props.navState;
    const components = navState.routeStack.map((route, index) =>
      COMPONENT_NAMES.map(componentName =>
        this._getComponent(componentName, route, index)
      )
    );

    return (
      <View
        key={this._key}
        style={[styles.navStyle, navBarStyle, this.props.style]}>
        {components}
      </View>
    );
  }
}

