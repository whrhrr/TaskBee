import React, {
  View,
  Text,
  StyleSheet,
} from 'react-native';

import Icon from './Icon';
import config from '../config';

const styles = StyleSheet.create({
  rating: {
    paddingVertical: 3,
    margin: 3,
    borderRadius: config.borderRadius,
    flexDirection: 'row',
  },
  tagText: {
    color: '#fff',
    fontSize: config.fontSmall,
    textAlign: 'right',
  },
  icon: {
    margin: 2,
  },
});


function renderStart(index, value, onUpdate, size) {
  const color = index <= value ? config.brandSecondary : config.colorVerySubtle;
  return <Icon style={styles.icon} key={index} size={size || 18} name="heart-1" color={color} onPress={() => {onUpdate && onUpdate(index)} }/>;
}
export default function Tag({style, value, onUpdate, size}) {
  const roundedValue = Math.round(value);
  return (
    <View style={[styles.rating, style]}>
     {
       [1, 2, 3, 4, 5].map(index => renderStart(index, roundedValue, onUpdate, size))
     }
    </View>
  );
}
