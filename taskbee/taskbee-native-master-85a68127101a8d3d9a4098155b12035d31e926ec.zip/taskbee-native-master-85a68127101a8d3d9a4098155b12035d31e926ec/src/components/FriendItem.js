import React, {
  PropTypes,
  StyleSheet,
  TouchableOpacity,
  View,
  Text
} from 'react-native';
// import {Link} from 'react-router';
import moment from 'moment';
import {
  Avatar,
  Gender,
} from '../components';

import config from '../config'

const styles = StyleSheet.create({
  contact: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    padding: config.normalPadding,
  },
  message: {
    marginLeft: 9,
    flex: 1,
    alignSelf: 'center',
  },
  date: {
    position: 'absolute',
    right: config.normalPadding,
    top: config.normalPadding,
    fontSize: config.fontSmall,
  },
  name: {
    color: config.colorMain,
    fontSize: config.fontBig,
  },
  at: {
    color: config.brandBlue,
  },
  misc: {
  },
  unread: {
    backgroundColor: config.brandRed,
    height: 16,
    borderRadius: 8,
    paddingHorizontal: 4,
    alignSelf: 'flex-end',
    marginTop: 6,
  },
  unreadText: {
    color: config.colorVerySubtle,
    fontSize: config.fontXSmall,
  },
});


const Contact = (props) => {
  const {_id, username, avatar, gender, goTo} = props;
  const goToChat = goTo('Chat', {
    userId: _id,
  }, {
    title: {
      type: 'user',
      username,
      gender,
      userId: _id,
    },
  });
  return (
    <TouchableOpacity style={styles.contact} onPress={goToChat}>
      <Avatar src={avatar} size={40}/>
      <View style={styles.message}>
        <Text style={styles.name}>{username} <Gender gender={gender}/></Text>
      </View>
    </TouchableOpacity>
  );
};

Contact.propTypes = {
  _id: PropTypes.string,
  avatar: PropTypes.string,
  message: PropTypes.object,
  username: PropTypes.string,
  unread: PropTypes.number,
  gender: PropTypes.number,
  goTo: PropTypes.func.isRequired,
};

export default Contact;
