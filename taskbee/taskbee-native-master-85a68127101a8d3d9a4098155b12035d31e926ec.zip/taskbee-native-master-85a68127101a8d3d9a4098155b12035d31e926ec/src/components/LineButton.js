import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
} from 'react-native';


import {MKButton} from 'react-native-material-kit';
import {
  Icon,
  Text,
} from '../components';
import config from '../config';

const styles = StyleSheet.create({
  button: {
    //borderTopWidth: config.borderWidth,
    //borderBottomWidth: config.borderWidth,
    //borderColor: config.colorBorder,
    backgroundColor: '#fff',

    height: 48,
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row',
    paddingHorizontal: config.normalPadding,
  },
  textNormal: {
    marginLeft: 9,
    color: config.colorMain,
  },
  textMain: {
    flex: 1,
    textAlign: 'right',
  },
  right: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  }
});

function LineButton(props) {
  return (
    <MKButton
      backgroundColor="#fff"
      onPress={props.onPress}
      style={[styles.button, props.style]}
      rippleColor={config.rippleColor}
    >
      {props.icon && <Icon size={16} name={props.icon} color={config.brandPrimary}/>}
      <Text pointerEvents="none"
        style={styles.textNormal}
      >
        {props.label}
      </Text>
      <View style={styles.right}>
        <Text pointerEvents="none"
          style={styles.textMain}
        >
          {props.text}
        </Text>
        {props.children}
        {!props.noJump && <Icon size={16} name="right-open-big" color={config.colorNormal}/>}
      </View>
    </MKButton>
  );
}

LineButton.propTypes = {
  backgroundColor: PropTypes.string,
  onPress: PropTypes.func,
  label: PropTypes.string,
  text: PropTypes.any,
  working: PropTypes.bool,
  type: PropTypes.number,
  style: PropTypes.any,
  icon: PropTypes.string,
  children: PropTypes.any,
  noJump: PropTypes.bool,
};
export default LineButton;
