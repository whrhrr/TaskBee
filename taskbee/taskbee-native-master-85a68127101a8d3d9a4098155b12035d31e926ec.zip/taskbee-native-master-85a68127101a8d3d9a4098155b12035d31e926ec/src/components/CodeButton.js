import React, {
  Component,
  PropTypes,
  StyleSheet,
} from 'react-native';

import { connect } from 'react-redux';
import NormalButton from './NormalButton';

import locales from '../locales';

const styles = StyleSheet.create({
  button: {
    height: 60,
    paddingHorizontal: 3,
    borderRadius: 0,
  }
});

class CodeButton extends Component {
  static propTypes = {
    availableTime: PropTypes.number,
    loading: PropTypes.bool,
    onClick: PropTypes.func
  };

  state = { countDown: 0 };

  componentWillReceiveProps(nextProps) {
    if (nextProps.availableTime !== this.props.availableTime) {
      // 新建倒计时, 假定同一页面只会存在一个该空间
      const time = Math.round((nextProps.availableTime - Date.now()) / 1000);
      this.setState({countDown: time});
      this.countDownHandle = setInterval( () => {
        const nextCountDown = this.state.countDown - 1;
        this.setState({countDown: nextCountDown});
        if (nextCountDown <= 0) {
          clearInterval(this.countDownHandle);
        }
      }, 1000);
    }
  }

  componentWillUnmount() {
    if (this.countDownHandle) {
      clearInterval(this.countDownHandle);
    }
  }

  render() {
    const { loading } = this.props;
    const { countDown } = this.state;
    let content;
    if (loading) {
      content = locales.gettingCode;
    } else if (countDown > 0) {
      content = `${countDown}${locales.codeCooldown}`;
    } else {
      content = locales.getCode;
    }

    return (
      <NormalButton style={styles.button} working={loading} disabled={loading || countDown > 0} onPress={this.props.onPress} text={content}/>
    );
  }
}
export default connect(state => ({
  availableTime: state.verify.availableTime,
  loading: state.verify.loading,
}))(CodeButton)
