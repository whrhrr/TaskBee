import React, {
  PropTypes,
  StyleSheet,
  View,

} from 'react-native';
import { Text } from './index';

// import {stateMap} from 'utils/dataMap';
import config from '../config';
import locales from '../locales';

const styles = StyleSheet.create({
  timeline: {
    flexDirection: 'row',
    marginVertical: config.normalPadding,
  },
  line: {
    alignItems: 'center',
    flex: 1,
  },
  dot: {
    height: 6,
    width: 6,
    borderRadius: 3,
    backgroundColor: config.colorVerySubtle,
  },
  text: {
    fontSize: config.fontSmall,
    color: config.colorSubtle,
  },
  lightText: {
    color: config.colorMain,
  },
  lightDot: {
    backgroundColor: config.brandGreen,
  }
});

function renderDot(text, index, state) {
  let lightDot;
  let lightText;
  if (index <= state) lightDot = styles.lightDot;
  if (index === state || (state > 3 && index >= 3)) lightText = styles.lightText;
  return <View style={styles.line}><View style={[styles.dot, lightDot]}/><Text style={[styles.text, lightText]}>{text}</Text></View>;
}

const Timeline = (props) => {

  const {state} = props;
  let lastSection;
  if (state < 4) {
    lastSection = locales.state3;
  } else if (state === 4) {
    lastSection = locales.state4;
  } else {
    lastSection = locales.state5;
  }
  return (
    <View style={styles.timeline}>
      {renderDot(locales.state0, 0, state)}
      {renderDot(locales.state1, 1, state)}
      {renderDot(locales.taskerComplete, 2, state)}
      {renderDot(lastSection, 3, state)}
    </View>
  );
};

Timeline.propTypes = {
  state: PropTypes.number.isRequired,
};

export default Timeline;
