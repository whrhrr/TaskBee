import React, {
  PropTypes,
  StyleSheet,
  View,
  TouchableOpacity,
} from 'react-native';

import {orderStateMap} from '../utils/dataMap';

import {
  Text
} from '../components';
import moment from 'moment';

import config from '../config';
const styles = StyleSheet.create({
  orderItem: {
    padding: config.normalPadding,
    backgroundColor: '#fff',
    flexDirection: 'row',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  section: {

  },
  sectionRight: {
    alignSelf: 'stretch',
    flex: 1,
  },
  date: {
    textAlign: 'right',
    alignSelf: 'stretch'
  },
  email: {
    textAlign: 'right',
  },
  price: {
    fontWeight: 'bold',
    color: config.brandGreen,
  },
  state: {
    color: config.colorMain,
  }
});

const OrderItem = (props) => {
  const {_id, price, state, createdDate, email, goTo} = props;
  const date = moment(createdDate).format('MM/D HH:mm');

  return (
    <TouchableOpacity style={styles.orderItem} onPress={goTo('OrderDetail', {orderId: _id})}>
      <View style={styles.section}>
        <Text style={styles.price}>¥{price}</Text>
        <Text style={styles.state}>{orderStateMap[state]}</Text>
      </View>
      <View style={styles.sectionRight}>
        <Text style={styles.date}>{date}</Text>
        <Text style={styles.email}>支付宝账户：{email || '无'}</Text>
      </View>
    </TouchableOpacity>
  );
};

OrderItem.propTypes = {
  price: PropTypes.number,
  state: PropTypes.number,
  _id: PropTypes.string,
  createdDate: PropTypes.string,
  email: PropTypes.string,
  goTo: PropTypes.func.isRequired,
};


export default OrderItem;
