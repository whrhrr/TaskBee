import React, {
  Text,
  View,
  Animated,
  Image,
  StyleSheet
} from 'react-native';
import config from '../config';

import {Map} from 'immutable';
import {
  Avatar,
} from '../components';

const styles = StyleSheet.create({
  message: {
    flexDirection: 'column',
    marginVertical: config.normalPadding / 2,
    position: 'relative',
  },
  bubble: {
    borderRadius: config.borderRadius,
    paddingLeft: 14,
    paddingRight: 14,
    paddingBottom: 10,
    paddingTop: 8,
  },
  text: {
    color: '#000',
  },
  textLeft: {
  },
  textRight: {
    // color: '#fff',
  },
  bubbleLeft: {
    marginLeft: 9 + 36,
    marginRight: 42,
    backgroundColor: '#e6e6eb',
    alignSelf: 'flex-start',
  },
  bubbleRight: {
    marginRight: 9 + 36,
    marginLeft: 42,
    backgroundColor: config.brandGreen,
    alignSelf: 'flex-end',
  },
  bubbleError: {
    backgroundColor: config.brandRed,
  },
  messageRight: {
    alignSelf: 'flex-end',
  },
  avatar: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
  },
  avatarRight: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
  }
});

function renderText(text = '', position) {
  return (
    <Text style={[styles.text, (position ? styles.textRight : styles.textLeft)]}>
      {text}
    </Text>
  );
}

function renderAvatar(user, position) {
  return <View style={position ? styles.avatarRight : styles.avatar}><Avatar src={user ? user.get('avatar') : null} size={36}/></View>;
}

export default function Message(props) {
  const flexStyle = {};
  if (props.text.length > 40) {
    flexStyle.flex = 1;
  }
  const {position, status, text, user} = props;
  return (
    <View style={[styles.message, (position ? styles.messageRight : null)]}>
      {renderAvatar(user, position)}
      <View style={[styles.bubble,
        (position ? styles.bubbleRight : styles.bubbleLeft),
        (status === 'ErrorButton' ? styles.bubbleError : null),
        flexStyle]}
      >
        {renderText(text, position)}
      </View>
    </View>
  );
}

Message.propTypes = {
  position: React.PropTypes.bool, // true == right / false == left
  status: React.PropTypes.string,
  text: React.PropTypes.string,
  user: Map.isMap,
};
