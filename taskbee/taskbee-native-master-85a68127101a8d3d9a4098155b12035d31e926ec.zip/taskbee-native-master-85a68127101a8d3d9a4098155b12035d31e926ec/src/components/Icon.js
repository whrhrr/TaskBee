/**
 * Icon icon set component.
 * Usage: <Icon name="icon-name" size={20} color="#4F8EF7" />
 *
 * @providesModule Icon
 */


import {createIconSet} from 'react-native-vector-icons';
const glyphMap = {
  "info": 97,
  "mail": 98,
  "chevron-left": 99,
  "home-house-streamline": 100,
  "man-people-streamline-user": 102,
  "food-ice-cream-streamline": 101,
  "bubble-comment-streamline-talk": 103,
  "plus-circle": 104,
  "bulb": 105,
  "study": 106,
  "vallet": 107,
  "heart": 108,
  "right-open-big": 109,
  "symbol-woman": 110,
  "symbol-mixed": 111,
  "symbol-man": 112,
  "eye": 113,
  "eye-slash": 114,
  "clock": 115,
  "heart-o": 116,
  "heart-1": 117,
  "check-clipboard-1": 118,
  "paper-plane": 119,
  "cross-mark": 120,
  "cn-alibabai-alipay": 121,
  "share-square-o": 122,
  "garden": 65,
  "pagelines": 66,
  "map": 67,
  "pencil-square-o": 68,
  "arrow-left": 69,
  "list": 70,
  "camera": 71,
  "image": 72,
  "man": 73,
  "navigate": 74,
  "flower": 76,
  "taskbee": 75,
  "flame": 78,
  "more": 77,
  "flag": 79,
};

const Icon = createIconSet(glyphMap, 'taskbee-icons', 'taskbee-icons.ttf');
module.exports = Icon;
