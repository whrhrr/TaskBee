// 引用containers
// 直接从index里引用会导致reference变成undefined不知道为何
import Join from './containers/Join';
import Tabs from './containers/Tabs';
import Login from './containers/Login';
import Register from './containers/Register';
import VerifyForm from './containers/VerifyForm';
import ChangePassword from './containers/ChangePassword';
import MyAccount from './containers/MyAccount';
import Score from './containers/Score';
import Wallet from './containers/Wallet';
import {ChangeSignature, ChangeName, ChangeGender} from './containers/ChangeInfos';
import {FavTasks, HistoryTasks} from './containers/OtherTasks';
import TaskDetail from './containers/TaskDetail';
import UserDetail from './containers/UserDetail';
import Chat from './containers/Chat';
import Friend from './containers/Friend';
import Feedback from './containers/Feedback';
import About from './containers/About';
import {MyPollens} from './containers/PollenList';
import Task from './containers/Task';
import ImageView from './containers/ImageView';
// 这个再考虑一下
import Mapbox from './containers/Mapbox';
import PostDetail from './containers/PostDetail';
import CreatePollen from './containers/CreatePollen';
import CreateTask from './containers/CreateTask';
import MainMap from './containers/MainMap';
import Vote from './containers/Vote';
import OrderDetail from './containers/OrderDetail';
import OrderList from './containers/OrderList';
import Withdraw from './containers/Withdraw';
import WithdrawList from './containers/WithdrawList';
import Report from './containers/Report';

import {HotestPost} from './containers/OtherPosts';

import locales from './locales';

import config from './config';

const routes = {
  Report: {
    info: {
      name: 'Report',
      title: locales.report,
    },
    component: Report,
  },
  HotestPost: {
    info: {
      name: 'HotestPost',
      title: locales.weeklyHotest,
    },
    component: HotestPost,
  },
  WithdrawList: {
    info: {
      name: 'WithdrawList',
      title: '提现记录',
    },
    component: WithdrawList,
  },
  Withdraw: {
    info: {
      name: 'Withdraw',
      title: '提现',
    },
    component: Withdraw,
  },
  OrderList: {
    info: {
      name: 'OrderList',
      title: '订单列表',
    },
    component: OrderList,
  },
  OrderDetail: {
    info: {
      name: 'OrderDetail',
      title: '充值详情',
    },
    component: OrderDetail,
  },
  Vote: {
    info: {
      name: 'Vote',
      title: '评价对方',
      sceneConfig: 'FloatFromBottom',
    },
    component: Vote,
  },
  CreateTask: {
    info: {
      name: 'CreateTask',
      title: locales.publishTaskTitle, // 女生节
      sceneConfig: 'FloatFromBottom',
    },
    component: CreateTask,
  },
  MainMap: {
    info: {
      name: 'MainMap',
      transparent: true,
      backgroundColor: 'transparent',
      needBack: true,
      sceneConfig: 'FloatFromBottom',
    },
    component: MainMap,
  },
  CreatePollen: {
    info: {
      name: 'CreatePollen',
      transparent: true,
      sceneConfig: 'FloatFromBottom',
    },
    component: CreatePollen,
  },
  PostDetail: {
    info: {
      name: 'PostDetail',
      title: locales.pollenDetail,
      sceneConfig: 'FloatFromBottom',
    },
    component: PostDetail,
  },
  Mapbox: {
    info: {
      name: 'Mapbox',
      transparent: true,
      backgroundColor: 'transparent',
      needBack: true,
      sceneConfig: 'FloatFromBottom',
    },
    component: Mapbox,
  },
  ImageView: {
    info: {
      name: 'ImageView',
      transparent: true,
      backgroundColor: 'transparent',
      needBack: true,
      sceneConfig: 'FloatFromBottom',
    },
    component: ImageView,
  },
  Task: {
    info: {
      name: 'Task',
      title: locales.myTasks,
      sceneConfig: 'FloatFromBottom',
    },
    component: Task,
  },
  MyPollens: {
    info: {
      name: 'MyPollens',
      title: locales.myPollens,
      sceneConfig: 'FloatFromBottom',
    },
    component: MyPollens,
  },
  About: {
    info: {
      name: 'About',
      title: locales.aboutTaskbee,
    },
    component: About,
  },
  Feedback: {
    info: {
      name: 'Feedback',
      title: locales.feedback,
    },
    component: Feedback,
  },
  Friend: {
    info: {
      name: 'Friend',
      title: locales.myFriend,
    },
    component: Friend,
  },
  Chat: {
    info: {
      name: 'Chat',
      title: '私信',
    },
    component: Chat,
  },
  UserDetail: {
    info: {
      name: 'UserDetail',
      title: locales.userDetail,
    },
    component: UserDetail,
  },
  TaskDetail: {
    info: {
      name: 'TaskDetail',
      title: locales.detail,
    },
    component: TaskDetail,
  },
  HistoryTasks: {
    info: {
      name: 'HistoryTasks',
      title: locales.historyTasks,
    },
    component: HistoryTasks,
  },
  FavTasks: {
    info: {
      name: 'FavTasks',
      title: locales.likedTasks,
    },
    component: FavTasks,
  },
  ChangeSignature: {
    info: {
      name: 'ChangeSignature',
      title: locales.change + locales.signature,
    },
    component: ChangeSignature,
  },
  ChangeGender: {
    info: {
      name: 'ChangeGender',
      title: locales.change + locales.gender,
    },
    component: ChangeGender,
  },
  ChangeName: {
    info: {
      name: 'ChangeName',
      title: locales.change + locales.realName,
    },
    component: ChangeName,
  },
  Score: {
    info: {
      name: 'Score',
      title: locales.my + locales.honey,
    },
    component: Score,
  },
  Wallet: {
    info: {
      name: 'Wallet',
      title: locales.my + locales.wallet,
    },
    component: Wallet,
  },
  MyAccount: {
    info: {
      name: 'MyAccount',
      title: locales.aboutMe,
    },
    component: MyAccount,
  },
  Login: {
    info: {
      name: 'Login',
      title: locales.login,
    },
    component: Login,
  },
  Register: {
    info: {
      name: 'Register',
      title: locales.register,
      passProps: {
        successRoute: 'RealRegister'
      },
    },
    component: VerifyForm,
  },
  RealRegister: {
    info: {
      name: 'RealRegister',
      title: locales.completeRegister,
    },
    component: Register,
  },
  Forget: {
    info: {
      name: 'Forget',
      title: locales.forgetPassword,
      passProps: {
        forget: true,
        successRoute: 'RealForget'
      },
    },
    component: VerifyForm,
  },
  Forget2: {
    info: {
      name: 'Forget2',
      title: locales.changePassword,
      passProps: {
        forget: true,
        successRoute: 'RealForget'
      },
    },
    component: VerifyForm,
  },
  RealForget: {
    info: {
      name: 'RealForget',
      title: locales.changePassword,
    },
    component: ChangePassword,
  },
  Join: {
    info: {
      name: 'Join',
      title: locales.welcomeBack,
      transparent: true,
      sceneConfig: 'FloatFromBottom',
    },
    component: Join,
  },
  Tabs: {
    info: {
      name: 'Tabs',
    },
    component: Tabs,
  }
};

export default routes;

export function getRoute(name, data, override) {
  if (data) {
    const info = routes[name].info;
    return {
      ...info,
      ...override,
      passProps: {
        ...info.passProps,
        ...data,
      }
    };
  }
  return routes[name].info;
}
