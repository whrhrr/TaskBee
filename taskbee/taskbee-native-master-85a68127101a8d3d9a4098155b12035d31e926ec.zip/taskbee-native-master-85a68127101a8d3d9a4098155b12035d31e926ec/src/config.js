import React, {
  Platform,
  StyleSheet,
  PixelRatio,
} from 'react-native';

import locales from './locales';

let sizeIncrease = 0;
const ratio = PixelRatio.get();
if (ratio > 1) sizeIncrease = 1;

export default {
  isCN: locales.getLanguage() === 'zh',
  imageSettings: {
    noData: true,
    quality: 0.9,
    maxWidth: 2048,
    maxHeight: 2048,
  },
  isIOS: Platform.OS === 'ios',
  appver: [1, 9, 2],
  userGuideVer: __DEV__ ? 'test5' : '1.7.0',
  brandPrimary: '#FFAB4D', // '#FEAC36', //
  brandBackground: '#FAF9F5',
  brandRed: '#E6381F',
  brandBlue: '#4A90E2',
  brandGreen: '#9FE0DB',
  brandPink: '#F9678F',

  brandSecondary: '#FEAC36',

  colorMain: '#4a4a4a',
  colorStand: '#2a2a2a',
  colorTab: '#fff',
  colorNormal: '#737373',
  colorTextBg: '#fff',
  colorSubtle: '#9B9B9B',
  colorLessSubtle: '#7A7A7A',
  colorVerySubtle: '#E7E7E7',

  buttonSecondary: '#F0F0F0',


  mapHeight: 300,

  // 字体
  fontXSmall: 11 + sizeIncrease,
  fontSmall: 12 + sizeIncrease,
  fontNormal: 14 + sizeIncrease,
  fontBig: 16 + sizeIncrease,
  fontLarge: 18 + sizeIncrease,
  fontXLarge: 20 + sizeIncrease,

  // 布局
  normalPadding: 14,
  tabHeight: 48,
  bannerHeight: Platform.OS === 'ios' ? 64 : 56,
  textInputHeight: 48,

  // 细节
  borderRadius: 3,
  colorBorder: 'rgba(0,0,0,.1)',
  colorBorderActive: 'rgba(0,0,0,.2)',
  borderWidth: StyleSheet.hairlineWidth,
  rippleColor: 'rgba(0,0,0,.1)',

  styleExtraError: {
    color: '#E6381F',
    alignSelf: 'stretch',
    textAlign: 'center',
    marginVertical: 9,
  },

  // 配置
  serverPath: __DEV__ ? 'http://192.168.100.11:7070' : 'https://taskbee.cn/api', // 'http://192.168.100.11:7070'http://10.0.0.2:7070''
  androidUpdate: __DEV__ ? 'http://192.168.100.11:8080/android.txt' : 'https://taskbee.cn/android.txt',
  imagePath: 'http://7xn0s3.com1.z0.glb.clouddn.com/',

  // 字符串
  networkError: '哎哟，网炸了，等等再战……',



};
