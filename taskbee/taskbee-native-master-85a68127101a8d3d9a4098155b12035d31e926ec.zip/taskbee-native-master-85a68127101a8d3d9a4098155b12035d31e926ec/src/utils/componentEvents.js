import {getRoute} from '../routes';

import {requireLogin} from './navigation';

// 点击了添加收藏 需要fav,unfav,pushState
export function onFavClick(id, task) {
  return requireLogin.bind(this)((event) => {
    event.preventDefault();
    event.stopPropagation();
    const {token} = this.props;
    if (task) {
      // 已经toJS
      if (task.faved) {
        this.props.unfav({id, token});
      } else {
        this.props.fav({id, token});
      }
    } else {
      const theTask = this.props.tasks.get(id);
      if (theTask.get('faved')) {
        this.props.unfav({id, token});
      } else {
        this.props.fav({id, token});
      }
    }
  }).bind(this);
}

export function throttle(fn, delay = 2000) {
  let allowSample = true;
  return function throttled(...args) {
    if (allowSample) {
      allowSample = false;
      setTimeout(function allowNext() { allowSample = true; }, delay);
      fn(...args);
    }
  };
}

export function debounce(fn, delay = 700) {
  // 不应该throttle 应该debounce
  let timeout;
  return function debounced(...args) {
    const later = function later() {
      timeout = null;
      fn(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, delay);
    // if (!timeout) fn(ev);
  };
}
