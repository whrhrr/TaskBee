import memoize from 'lru-memoize';
import {createValidator, required, minLength, maxLength, phone, oneOf} from './validation';

const userValidation = createValidator({
  password: [required, minLength(8), maxLength(60)],
  username: [required, minLength(2), maxLength(16)],
  gender: [oneOf(['0', '1', 0, 1])],
});
export default memoize(10)(userValidation);
