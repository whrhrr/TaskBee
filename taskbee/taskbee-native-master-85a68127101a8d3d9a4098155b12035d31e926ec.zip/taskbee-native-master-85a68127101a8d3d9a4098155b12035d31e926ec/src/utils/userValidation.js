import memoize from 'lru-memoize';
import {createValidator, required, minLength, maxLength, phone, oneOf} from './validation';

const userValidation = createValidator({
  phone: [required, phone],
  password: [required, minLength(8), maxLength(60)],
  verify: [required, minLength(5), maxLength(10)],
  username: [minLength(2), maxLength(20)],
  gender: [oneOf(['0', '1', 0, 1])],
  occupation: maxLength(20) // single rules don't have to be in an array
});
export default memoize(10)(userValidation);
