export function serverError(errorObject) {
  return (field) => {
    if (errorObject && errorObject.errorCode === field) return errorObject.message;
  };
}


export class textJumper {
  currentIndex = 0;
  textRefs = [];

  refFunc = (ref) => {
    this.textRefs.push(ref);
  };

  genTextJumper = () => {
    const index = ++this.currentIndex; // 递增
    console.log('fired');
    return {
      ref: this.refFunc,
      onSubmitEditing: () => {
        console.log(this.currentIndex, this.textRefs);
        this.textRefs[index].focus();
      }
    }
  };
}
