// import memoize from 'lru-memoize';
import {createValidator, required, minLength, maxLength} from './validation';

const commentValidation = createValidator({
  comment: [required, minLength(1), maxLength(280)],
});
export default commentValidation;
