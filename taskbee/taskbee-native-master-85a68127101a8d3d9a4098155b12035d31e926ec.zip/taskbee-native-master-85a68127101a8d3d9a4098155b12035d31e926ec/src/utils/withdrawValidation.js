import memoize from 'lru-memoize';
import {createValidator, required, minLength} from './validation';

const withdrawValidation = createValidator({
  money: required,
  email: [required, minLength(5)],
  realname: [required, minLength(1)],
});
export default memoize(10)(withdrawValidation);
