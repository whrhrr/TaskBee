import {getRoute} from '../routes';

export function goTo(route, data, override) {
  return () => {
    this.props.navigator.push(
      getRoute(route, data, override)
    );
  };
}

export function requireLogin(fn) {
  return (...args) => {
    if (!this.props.token) { // TODO 需要思考
      goTo.bind(this)('Join')();
    }
    else fn(...args)
  }
}

export function requireLoginFactory(key) {
  return (fn) => {
    if (!this.props[key]) { // TODO 需要思考
      return goTo.bind(this)('Join');
    }
    return fn;
  };
}
