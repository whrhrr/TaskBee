/*

  创建一个保存存储部分数据的reducer

 */
export default function createReducer(key, ) {

  return (reducer) => {
    function persistReducer(state, action) {
      if (action.type === key) {
        return state.set('hydrated', true);
      } else {
        return reducer(state);
      }
    }

    return persistReducer;
  };
}
