'use strict';
import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
  TouchableOpacity,
  ListView,
  RefreshControl,
  AppState,
} from 'react-native';
import { connect } from 'react-redux';
import {load, collect, abandon, cast, storage} from '../modules/pollen';
import {touchCard, releaseCard} from '../modules/misc';

import connectData from '../libs/connectData';

import {goTo, requireLogin} from '../utils/navigation';
import {MKButton} from 'react-native-material-kit';

import config from '../config';
import moment from 'moment';
import {
  MainTab,
  NormalButton,
  PollenCard,
  LoadingIndicator,
  MainMap,
  Icon,
  Text,
  LbsIndicator,
} from '../components';
import {PollenGuide} from './index';
const styles = StyleSheet.create({
  text: {
    width: 100,
    height: 30,
    padding: 10,
    backgroundColor: 'lightgray',
    margin: 3
  },
  home: {
    flex: 1,
    position: 'relative',
  },
  center: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  noOther: {
    flex: 1,
  },
  subtle: {
    marginBottom: 9,
    color: config.colorMain,
    fontSize: config.fontBig,
  },
  errorMessage: config.styleExtraError,
  mainView: {
    flex: 1,
    justifyContent: 'center',
  },
  goCollect: {
    alignItems: 'center',
  },
  mainText: {
    color: config.colorMain,
    fontSize: config.fontLarge,
    marginBottom: config.normalPadding / 3,
  },
  subtleText: {
    marginBottom: config.normalPadding,
    marginHorizontal: config.normalPadding,
    textAlign: 'center',
  },
  buttons: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  button: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: 48,
    flexDirection: 'row',
  },
  spliter: {
    width: config.borderWidth,
    backgroundColor: config.colorBorder,
    height: 24,
  },

  error: {
    paddingBottom: config.nomralPadding,
  },
  collectTime: {
    fontSize: config.fontSmall,
    color: config.colorSubtle,
    marginTop: config.fontSmall / 2,
  },
  errorPadding: {
    paddingBottom: 48,
  },
  collectButton: {
    width: 110,
    height: 110,
    borderRadius: 55,
    paddingHorizontal: 0,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    shadowRadius: 1,
    shadowOffset: { width: 0, height: 0.5 },
    shadowOpacity: 0.1,
    shadowColor: 'black',
    elevation: 2,
  },
  fab: {
    backgroundColor: config.brandPrimary,
    position: 'absolute',
    right: 24,
    bottom: 18,
  }
});

import locales from '../locales';

const ColoredFab = MKButton.coloredFab()
  .withStyle(styles.fab)
  .build();

const simpleText = config.isCN ? [
  // '4.1 - 4.7 愚人节专场！同学挫照发起来！',
  // '蜂房花粉，一个比朋友圈更真实、更真实、更有趣、更有趣、更有趣的动态消息漂流瓶',
  '用吐槽宣战平淡生活，用态度鄙视平凡世界。表达真实自我，尽在蜂房花粉',
  '只属于身边同学的朋友圈，分享你的心情吧～',
  // '更有趣的朋友圈，一条花粉只有10人能看，通过他人的传播，克隆新花粉',
  '畅所欲言，一个同学间的朋友圈',
  '没花粉了吧，早就告诉你！读万千动态不如轧二里马路！友情提示花粉收集范围3000米嗡～',
  '报告！该坐标花粉已空，请求支援！请求支援！',
  '不怕作大死，就怕没人看',
]
:
[
  'No more pollens around, come back later.',
  'A pollen will be available to only 10 users at the begining, spreading will spread it to more people!'
];
function genText() {
  const len = simpleText.length;
  return simpleText[Math.floor(Math.random() * len)];
}
class Home extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
    user: PropTypes.object,
    loading: PropTypes.bool,
    error: PropTypes.any,
    load: PropTypes.func.isRequired,
    collect: PropTypes.func.isRequired,
    loadingCollect: PropTypes.bool,
    collected: PropTypes.array,
    abandon: PropTypes.func.isRequired,
    cast: PropTypes.func.isRequired,
    listLength: PropTypes.number.isRequired,
    loadingNearby: PropTypes.bool,
    // arriveTask: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (item1, item2) => {
      return item1 !== item2;
    }});
    this.emptyText = genText();
  }

/*
  componentWillReceiveProps(nextProps) {
    // 加载新任务
    if (!this.props.lbsLoaded && nextProps.lbsLoaded) {
      const {long, lati} = nextProps;
      this.props.load(long, lati);
    }
  }
*/
  componentWillUnmount() {
    clearInterval(this.autoUpdateHandler);
    AppState.removeEventListener('change', this.handleAppStateChange);
  }

  handleAppStateChange = () => {
    this.emptyText = genText();
    this.forceUpdate();
  };

  componentDidMount() {
    this.autoUpdateHandler = setInterval(this.autoUpdate, 60 * 1000 * 3);
    AppState.addEventListener('change', this.handleAppStateChange);

  }

  goTo = goTo.bind(this);
  requireLogin = requireLogin.bind(this);

  autoUpdate = () => {
    const {long, lati} = this.props;
    // this.props.load(long, lati);
    // 收集花粉
    if (this.props.token && this.props.collected.length < 30) {
      this.onCollectClick();
    }
  };

  onCollectClick = this.requireLogin(() => {
    if (!this.props.loadingCollect && this.props.collected.length < 30) {
      const {long, lati, token} = this.props;
      this.props.collect({
        long,
        lati,
        token
      });
    }
  });

  abandon = (id) => {
    return () => {
      this.props.abandon({long: this.props.long, lati: this.props.lati, id, token: this.props.token});
    };
  };

  cast = (id) => {
    return () => {
      this.props.cast({id,
       token: this.props.token,
       long: this.props.long, lati: this.props.lati,
     });
    };
  };

  renderHeader = () => {
    const {lbsLoaded, lbsLoading} = this.props;
    return <LbsIndicator lbsLoaded={lbsLoaded} lbsLoading={lbsLoading} />
  };

  renderFooter = () => {
    const {errorCollect} = this.props;
    if (errorCollect) {
      return (<View style={[styles.center, styles.error, styles.errorPadding]}>
        <Text style={styles.errorMessage}>{errorCollect.message || locales.strangeError}</Text>
      </View>);
    }
  };

  render() {
    const {lastCollectTime, loading, error, long, lati, loadingCollect} = this.props;
    const item = this.props.collected[0];
    return (
      <View style={styles.home}>
        {this.renderHeader()}
        <View style={styles.mainView}>
          {
            item ? <PollenCard key={item._id} {...item} goTo={this.goTo} myPos={[long, lati]} abandon={this.abandon(item._id)} cast={this.cast(item._id)} touchCard={this.props.touchCard} releaseCard={this.props.releaseCard}/>
            : <View style={styles.goCollect}>
                <Text style={styles.mainText}>{locales.noMorePollens}</Text>
                <Text style={styles.subtleText}>{this.emptyText}</Text>
                <NormalButton fab maskBorderRadiusInPercent={50} maskEnabled maskBorderRadius={65} style={styles.collectButton} onPress={this.onCollectClick} working={loadingCollect} text={locales.collectPollen}/>
                {lastCollectTime && <Text style={styles.collectTime}>{locales.lastCollectAt}{moment(lastCollectTime).fromNow()}</Text>}
              </View>
          }
        </View>
        {this.renderFooter()}

        <ColoredFab onPress={this.requireLogin(this.goTo('CreatePollen'))}>
          <Icon name="pencil-square-o" size={20} color="#fff"/>
        </ColoredFab>
        <PollenGuide/>
      </View>
    );
  }
}


function fetchDataDeferred(getState, dispatch) {
  // 加载任务活动列表
  const state = getState();
  const me = state.me;
  const token = me.get('token');
  // dispatch(load(me.get('longitude'), me.get('latitude')));
  if (token) {
    // 存储的
    if (!state.pollen.collected.length) {
      dispatch(storage({
        token: me.get('token'),
      }));
    }
    // 收集
    if (state.lbs.get('loadedLbs') && state.pollen.collected.length < 30) {
      dispatch(collect({
        long: state.lbs.get('longitude'),
        lati: state.lbs.get('latitude'),
        token,
      }));
    }
  }
}

export default connectData(fetchDataDeferred)(
  connect(
    state => {
      return ({
        // 我的信息
        token: state.me.get('token'),
        meId: state.me.get('meId'),
        long: state.lbs.get('longitude'),
        lati: state.lbs.get('latitude'),
        lbsLoaded: state.lbs.get('loadedLbs'),
        lbsLoading: state.lbs.get('loadingLbs'),
        lbsError: state.lbs.get('errorLbs'),
        // 列表
        // 载入周围简要信息
        loading: state.lists.loading,
        error: state.lists.error,
        listLength: state.pollen.list.length,
        // 收集周围
        loadingCollect: state.pollen.loadingCollect,
        errorCollect: state.pollen.errorCollect,
        collected: state.pollen.collected,
        lastCollectTime: state.pollen.lastCollectTime,
      });
    },
    { load, collect, abandon, cast, storage, touchCard, releaseCard }
  )(Home)
);
