'use strict';

import React, {
  PropTypes,
  Component,
  ScrollView,
  StyleSheet,
  View,
  Text,
  Alert,
  TouchableOpacity,
} from 'react-native';
import {logout, upload} from '../modules/me';
import { connect } from 'react-redux';
import {Map} from 'immutable';
import {goTo, requireLogin} from '../utils/navigation'; // simple helper

import {
  MyLittleAccount,
  LineButton,
  Avatar,
  LoadingIndicator,
} from '../components';

import config from '../config';
import {gender} from '../utils/dataMap';
import {ImagePickerManager} from 'NativeModules';
import locales from '../locales';

const styles = StyleSheet.create({
  me: {
    marginTop: config.bannerHeight,
  },
  contentContainer: {
    paddingVertical: config.normalPadding,
  },
  main: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: config.normalPadding,
  },
  textMain: {
    fontSize: config.fontLarge,
    color: config.colorMain,
    marginTop: 12,
  },
  spliter: {
    height: config.borderWidth,
    alignSelf: 'stretch',
    marginHorizontal: config.normalPadding,
    backgroundColor: config.colorVerySubtle,
  },
  section: {
    borderTopWidth: config.borderWidth,
    borderBottomWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  noti: {
    color: config.colorLessSubtle,
    marginBottom: 9,
  },
  extraError: config.styleExtraError,
});

class Me extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
    user: Map.isMap,
    logout: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);
  }

  onReadyExit = () => {
    Alert.alert(locales.logout, locales.sureLogout, [
      {text: locales.no},
      {text: locales.logout, onPress: this.props.logout},
    ]);
  };

  goTo = goTo.bind(this);
  requireLogin = requireLogin.bind(this);

  onChooseAvatar = () => {
    if (this.props.uploading) return;
    const options = {
      title: locales.pickAnAvatar, // specify null or empty string to remove the title
      cancelButtonTitle: locales.cancelPick,
      takePhotoButtonTitle: locales.takeAPhoto, // specify null or empty string to remove this button
      chooseFromLibraryButtonTitle: locales.fromLibrary, // specify null or empty string to remove this button
      cameraType: 'front', // 'front' or 'back'
      mediaType: 'photo', // 'photo' or 'video'
      maxWidth: 2800,
      maxHeight: 2800,
      aspectX: 1, // aspectX:aspectY, the cropping image's ratio of width to height
      aspectY: 1, // aspectX:aspectY, the cropping image's ratio of width to height
      quality: 0.98, // photos only
      angle: 0, // photos only
      allowsEditing: true, // Built in functionality to resize/reposition the image
      noData: true, // photos only - disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents/pictures directory (rather than a temporary directory)
      }
    };
    ImagePickerManager.showImagePicker(options, (response) => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePickerManager Error: ', response.error);
      }
      else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      }
      else {
        this.props.upload({
          attach: response.uri,
          token: this.props.token,
        });
      }
    });
  };

  render() {
    const {navigator, user, uploading, uploadError} = this.props;
    return (
      <ScrollView style={styles.me} contentContainerStyle={styles.contentContainer}>
        {/* <MyLittleAccount push={navigator.push} user={user}/> */}
        <TouchableOpacity style={styles.main} onPress={this.onChooseAvatar}>
          {!user.get('avatar') && <Text style={styles.noti}>{locales.firstAvatar}</Text>}
          <Avatar size={80} src={user.get('avatar')}/>
          {uploading && <LoadingIndicator/>}
          {uploadError && <Text style={styles.extraError}>{uploadError.message || locales.strangeError}</Text>}
          <Text style={styles.textMain}>{user.get('username')}</Text>
        </TouchableOpacity>
        <View style={styles.section}>
          <LineButton label={locales.myScore} onPress={this.goTo('UserDetail', {userId: user.get('_id')})}/>
          <View style={styles.spliter}/>
          <LineButton label={locales.signature} text={user.get('signature') || locales.noSignature} onPress={this.goTo('ChangeSignature')}/>
          <View style={styles.spliter}/>
          <LineButton label={locales.realName} text={user.get('realname') || locales.anonymouse} onPress={this.goTo('ChangeName')}/>
          <View style={styles.spliter}/>
          <LineButton label={locales.gender} text={gender[user.get('gender')]} onPress={this.goTo('ChangeGender')}/>
          <View style={styles.spliter}/>
          <LineButton label={locales.changePassword} onPress={this.goTo('Forget2')}/>
          <View style={styles.spliter}/>
          <LineButton label={locales.logout} onPress={this.onReadyExit}/>
        </View>
      </ScrollView>
    );
  }
}

export default connect(state => ({
  user: state.me.get('data') || Map(), // immutable map
  uploading: state.me.get('uploading'),
  uploadError: state.me.get('uploadError'),
  token: state.me.get('token'),
}), {logout, upload})(Me);
