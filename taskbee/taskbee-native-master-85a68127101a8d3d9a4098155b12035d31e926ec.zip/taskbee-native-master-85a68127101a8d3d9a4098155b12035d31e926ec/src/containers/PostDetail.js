import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Animated,
  PanResponder,
  Dimensions,
  ScrollView,
  RefreshControl,
  Platform,
  Clipboard,
} from 'react-native';

import clamp from 'clamp';
import toast from '../libs/toast';
import {
  NormalButton, Avatar, Tag, Timeline,
  Gender, Icon, SimpleImages, Comment,
  Text, HyperText,
} from '../components'; // Tag,

import {PostCommentInput as CommentInput} from '../components/CommentInput';

import {stateMap} from '../utils/dataMap';
import moment from 'moment';
moment.locale('zh-cn');

import {calcCrow} from '../utils/dataProcessor';

import config from '../config';

import {goTo, requireLogin} from '../utils/navigation';
import {MKButton, mdl} from 'react-native-material-kit';

import connectData from '../libs/connectData';
import { connect } from 'react-redux';

import {loadPost, startComment, stopComment} from '../modules/post';

const {height, width} = Dimensions.get('window');

import styles from '../components/PollenCardStyles';

import locales from '../locales';

const SWIPE_THRESHOLD = width / 7 * 2;

export default class PollenDetail extends Component {
  static propTypes = {
    _id: PropTypes.string,
    type: PropTypes.number,
  };

  constructor(props) {
    super(props);

    this.state = {
      to: null,
      keyboardHeight: 0,
    }
    this.keyboardSettings = config.isIOS ? {
      onKeyboardWillShow: this.onKeyboardWillShow,
      onKeyboardWillHide: this.onKeyboardWillHide,
    } : {
      onKeyboardDidShow: this.onKeyboardWillShow,
      onKeyboardDidHide: this.onKeyboardWillHide,
    }

  }


  componentDidMount() {
    if (this.props.isComment) {
      requestAnimationFrame(this.scrollToBottom);
    }
  }

  componentWillReceiveProps(nextProps) {
    // 评论成功后拉到页面底部
    if (!this.props.task) return;
    if (!this.props.task.get('commentSuccess') && nextProps.task.get('commentSuccess')) {
      this.setState({to: null});
      setTimeout(() => {
        this.scrollToBottom();
      }, 200);

    }
  }
  goTo = goTo.bind(this);
  requireLogin = requireLogin.bind(this);

  scrollToBottom = () => {
    if (config.isIOS) {
      if (this.footerY) {
        const scrollDistance = this.footerY - height + this.state.keyboardHeight  + 60 + config.bannerHeight;
        if (scrollDistance > 0) this.refs.scroll.scrollTo({y: scrollDistance});
      }
    } else {
      this.refs.scroll.scrollTo({y: 9999999});
    }
  };

  onKeyboardWillShow = (e) => {
    if(config.isIOS) this.setState({keyboardHeight: e.endCoordinates ? e.endCoordinates.height : e.end.height});
    requestAnimationFrame(this.scrollToBottom);

  };

  onKeyboardWillHide = () => {
    if(config.isIOS) this.setState({keyboardHeight: 0});
    requestAnimationFrame(this.scrollToBottom);
  };

  onCommentSelect = (from) => {
    return () => {
      if (this.props.token) {
        this.setState({
          to: {
            id: from._id,
            username: from.username
          }
        });
        this.props.startComment({postId: this.props.postId});
      }
    };
  };

  onDescription = () => {
    Clipboard.setString(this.props.post.get('content'));
    toast(locales.textCopied);
  };

  reload = () => {
    if (!this.props.loading ) {
      this.props.loadPost(this.props.postId);
    }
  };

  render() {
    const {post: immuPost, loading, error, user} = this.props;
    const toJSedUser = user ? user.toJS() : null;
    const post = immuPost ? immuPost.toJS() : {};
    const {_id: id, spreadBy, loc, comments, content: description, createdAt, from = {}, imgs, spreadCount, readerCount, commentCount, commentOpen} = post;
    const {_id: pubId, avatar, username, gender} = from;
    return (
      <View style={[styles.containerDetail, config.isIOS && this.state.keyboardHeight ? {paddingBottom: this.state.keyboardHeight} : null]}>
      <ScrollView
        ref="scroll"
        style={styles.scrollView}
        scrollContainerStyle={styles.scrollContainer}
        refreshControl={config.isIOS ? null :
           <RefreshControl
            colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
            refreshing={loading} onRefresh={this.reload}/>
        }
        {...this.keyboardSettings}
      >
        <View onLayout={(e) => {
            this.footerY = e.nativeEvent.layout.height;
          }}>

          <View
            style={[styles.taskItem, {margin: config.normalPadding}]}
          >
            <View style={styles.description}>
              <TouchableOpacity style={styles.reportButton} onPress={this.requireLogin(this.goTo('Report', {itemId: id, type: 0}))}>
                <Text style={styles.report}>{locales.report}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={this.onDescription}><HyperText style={styles.descriptionText}>{description}</HyperText></TouchableOpacity>
              {
                imgs && imgs.length ? <SimpleImages style={{justifyContent: 'center'}} imgs={imgs} goTo={this.goTo}/>
                 : null
              }
            </View>
            <View style={styles.miscView}>
              <TouchableOpacity style={styles.distanceButton} onPress={loc && this.goTo('MainMap', {coordinates: loc.coordinates})}>
                <Icon name="navigate" color={config.colorNormal}/>
                {this.props.long !== undefined && loc ? <Text style={styles.distance}>{Math.floor(calcCrow(loc.coordinates, [this.props.long, this.props.lati])) + 'm'}</Text> : null}
              </TouchableOpacity>

              <Text style={styles.misc}>{moment(createdAt).fromNow()}</Text>
            </View>
          </View>

        <View style={styles.infosDetail}>
          <View style={styles.user}>
            <TouchableOpacity style={styles.userAvatar} onPress={this.goTo('UserDetail', {userId: pubId})}>
              <Avatar size={36} src={avatar}/>
            </TouchableOpacity>
            <View style={styles.username}>
              <Text style={styles.nameTextDetail}>{username}</Text><Gender style={styles.gender} gender={gender}/>
            </View>
          </View>

          <View style={styles.actionIcons}>
            <View style={styles.fav}>
              <Icon name="bubble-comment-streamline-talk" size={14} color={config.colorSubtle}/>
              <Text style={styles.favCountDetail}>{commentCount || '0'}</Text>
            </View>
            <View style={styles.fav}>
              <Icon name="paper-plane" size={14} color={config.colorSubtle}/>
              <Text style={styles.favCountDetail}>{spreadCount || '0'}</Text>
            </View>
            <View style={styles.fav}>
              <Icon name="eye" size={14} color={config.colorSubtle}/>
              <Text style={styles.favCountDetail}>{readerCount || '0'}</Text>
            </View>
          </View>
        </View>

        <Text style={styles.sectionTitle}>{locales.spreader}</Text>
        { spreadBy && spreadBy.length ? <ScrollView style={styles.spreadSection} contentContainerStyle={{paddingRight: config.normalPadding * 2}} horizontal={true} showsHorizontalScrollIndicator={false}>
          {
            spreadBy.reverse().map( user => (
            <TouchableOpacity key={user._id} style={styles.spreadBy} onPress={this.goTo('UserDetail', {userId: user._id})}>
              <Avatar src={user.avatar} size={28}/>
              <Icon style={styles.decorationIcon} name="paper-plane" size={9}/>
            </TouchableOpacity>
            ))
          }
          {spreadBy.length >= 30 ? <Text>...</Text> : null}
        </ScrollView>

        :
        <Text style={styles.empty}>{locales.toBeViewed}</Text>
        }

        <View style={styles.comments}>
          <Text style={styles.sectionTitle}>{locales.comments}</Text>
          {
            comments && comments.length ?
            comments.map( (comment, index) => {
              if (!comment.from) {
                return <Comment key={index} {...comment} from={toJSedUser} onCommentSelect={this.onCommentSelect} goTo={this.goTo}/>;
              }
              return <Comment key={index} {...comment} onCommentSelect={this.onCommentSelect} goTo={this.goTo}/>;
            })
            :
            <Text style={styles.empty}>{locales.leaveAComment}</Text>
          }
        </View>
        </View>
      </ScrollView>

      <View style={styles.controls}>
        {
          this.props.token ?
          <CommentInput taskId={id} to={this.state.to} needFocus={this.props.isComment}/>
          : <NormalButton style={styles.needLogin} type={1} text={locales.canCommentAfterLogin} onPress={this.goTo('Login')}/>
        }
      </View>

      </View>
    );
  }
}


function fetchData (getState, dispatch, passProps) {
  dispatch(loadPost(passProps.postId));
};

export default connectData(fetchData)(
  connect(
    (state, props) => {
      return {
        loading: state.post.get('loadingPollen'),
        error: state.post.get('errorPollen'),
        post: state.post.get(props.postId),
        user: state.me.get('data'),
        meId: state.me.get('meId'),
        token: state.me.get('token'),
        long: state.lbs.get('longitude'),
        lati: state.lbs.get('latitude'),
      };
  }, { loadPost, startComment, stopComment})(
    PollenDetail
  )
)
