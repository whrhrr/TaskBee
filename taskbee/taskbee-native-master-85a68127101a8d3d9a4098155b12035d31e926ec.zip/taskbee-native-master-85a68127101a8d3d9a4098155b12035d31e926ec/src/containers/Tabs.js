'use strict';

import React, {
  PropTypes,
  Component,
  StyleSheet,
  View,
  Text,
} from 'react-native';
import {
  MainTab
} from '../components';
import ScrollableTabView from 'react-native-scrollable-tab-view';

import {
  Deferred,
} from './index';

import RealHome from './RealHome';
import RealPollen from './RealPollen';
import Message from './Message';
import Me from './Me';
import { connect } from 'react-redux';
import connectData from '../libs/connectData';
import {trackEvent} from 'react-native-talkingdata';

const styles = StyleSheet.create({
  tabView: {


  }
});

class Tabs extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
  };

  state = {
    show: [false, false, false, false]
  };

  renderTabBar = () => {
    return <MainTab navigator={this.props.navigator}/>;
  };

  onChangeTab = ({i, ref}) => {
    if(!__DEV__) trackEvent('tabs', 'changeTab', {item: i.toString()})
  };

  render() {
    const {navigator, touching} = this.props;
    return (
      <ScrollableTabView
        renderTabBar={this.renderTabBar}
        style={styles.tabView}
        initialPage={0}
        onChangeTab={this.onChangeTab}
        locked={touching}
        tabBarPosition="bottom"
      >
        <RealHome tabLabel="Home" navigator={navigator}/>
        <RealPollen tabLabel="HomePollen" navigator={navigator}/>
        <Message tabLabel="Message" navigator={navigator}/>
        <Me tabLabel="Me" navigator={navigator}/>
      </ScrollableTabView>
    );
  }
}

function fetchData (getState, dispatch, passProps) {
  RealHome.fetchData(getState, dispatch, passProps);
  RealPollen.fetchData(getState, dispatch, passProps);
  Me.fetchData(getState, dispatch, passProps);
};

export default connectData(fetchData)(
  connect(
    state => ({
      touching: state.misc.touching
    })
  )(Tabs)
)
