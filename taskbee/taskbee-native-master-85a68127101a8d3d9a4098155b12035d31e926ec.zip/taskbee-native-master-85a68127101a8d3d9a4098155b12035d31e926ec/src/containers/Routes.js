'use strict';

import React, {
  Component,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  BackAndroid,
  Navigator,
  Dimensions,
  AsyncStorage,
  InteractionManager,
  StatusBar,
  Clipboard,
  NetInfo,
  Alert,
  Linking,

} from 'react-native';

import { connect } from 'react-redux';
import Share from 'react-native-share';
import {trackPageBegin, trackPageEnd} from 'react-native-talkingdata';

import {UserGuide} from './index';
import routes, {getRoute} from '../routes';

import codePush from "react-native-code-push";

import {
  NavigationBar,
  Icon,
  Avatar,
  Gender,
} from '../components';

import toast from '../libs/toast';
import locales from '../locales';

// import { Icon } from 'react-native-material-design';

import config from '../config';

import { dehydrate as dehydrateMe, load } from '../modules/me';
import { dehydrate as dehydrateLbs } from '../modules/lbs';
import {debounce, throttle} from '../utils/componentEvents';

const {height, width} = Dimensions.get('window');


const styles = StyleSheet.create({
  body: {
    flex: 1,
    position: 'relative',
    backgroundColor: config.brandBackground,

  },
  fakeBanner: {
    height: config.bannerHeight,
    backgroundColor: config.brandPrimary,
  },
  sceneStyle: {
    height,
    flex: 1,
    backgroundColor: config.isIOS ? 'transparent' : config.brandBackground,
  },
  titleStyle: {
    flex: 1,
    alignSelf: 'stretch',
    justifyContent: 'center',
    alignItems: Platform.OS === 'ios' ? 'center' : 'flex-start',
  },
  titleText: {
    color: '#fff',
    fontSize: 16,
  },
  back: {
    paddingLeft: 12,
    flex: 1,
    justifyContent: 'center',
  },
  touchIcon: {
    fontWeight: '800',
    color: '#fff',
  },
  bannerText: {
    color: '#fff',
  },
  bannerButton: {
    height: Platform.OS === 'ios' ? 48 : 56,
    width: 68,
    alignItems: 'center',
    justifyContent: 'center',
  }
});


function shareClick(taskId) {
  return () => {
    Clipboard.setString('https://taskbee.cn/tasks/' + taskId);
    toast(locales.linkCopied);
    Share.open({
      share_text: locales.shareTask,
      share_URL: 'https://taskbee.cn/tasks/' + taskId,
      title: locales.shareTaskTitle,
    }, function(e) {
      console.log(e);
    });
  };
}

function sharePostClick(postId) {
  return () => {
    Clipboard.setString('https://taskbee.cn/pollens/' + postId);
    toast(locales.linkCopied);
    Share.open({
      share_text: locales.sharePollen,
      share_URL: 'https://taskbee.cn/pollens/' + postId,
      title: locales.sharePollenTitle,
    }, function(e) {
      console.log(e);
    });
  };
}

// 在自带navigationbar上修改
const routeMapper = {
  LeftButton(route, navigator, index, navState) {
    if (!route.title && !route.needBack) return;
    return <TouchableOpacity style={styles.back} onPress={navigator.pop}>
        <Icon name="arrow-left" color="#fff" size={22}/>
     </TouchableOpacity>
  },
  RightButton(route, navigator, index, navState) {
    if (route.name === 'TaskDetail') {
      return (
        <TouchableOpacity style={styles.bannerButton} onPress={shareClick(route.passProps.taskId)}>
          <Icon name="share-square-o" size={22} color='#fff'/>
        </TouchableOpacity>
      );
    } else if (route.name === 'PostDetail') {
      return (
        <TouchableOpacity style={styles.bannerButton} onPress={sharePostClick(route.passProps.postId)}>
          <Icon name="share-square-o" size={22} color='#fff'/>
        </TouchableOpacity>
      );
    } else if (route.name === 'Wallet') {
      return (
        <TouchableOpacity style={styles.bannerButton} onPress={() => navigator.push(getRoute('OrderList'))}>
          <Text style={styles.bannerText}>订单列表</Text>
        </TouchableOpacity>
      );
    } else if (route.name === 'Withdraw') {
      return (
        <TouchableOpacity style={styles.bannerButton} onPress={() => navigator.push(getRoute('WithdrawList'))}>
          <Text style={styles.bannerText}>提现记录</Text>
        </TouchableOpacity>
      );
    }
  },
  Title(route, navigator, index, navState) {
    if (route.title) {
      if (typeof route.title === 'string')
        return <View style={styles.titleStyle}><Text style={styles.titleText}>{route.title}</Text></View>;
      else {
        const {title} = route;
        switch(title.type) {
          case 'user':
            return <TouchableOpacity style={styles.titleStyle} onPress={() => navigator.push(getRoute('UserDetail', {userId: title.userId}))}><Text style={styles.titleText}>{title.username} <Gender gender={title.gender}/></Text></TouchableOpacity>;
          default:
            break;
        }
      }
    }
  },
};

const INITIAL_ROUTE = {name: 'Tabs'};
class Routes extends Component {

  constructor(props) {
    super(props);
    this.store = props.rawStore;
    this.state = {
      initialRouteStack: null,
    }
    // 装载路由
    let routeStack;
    if (__DEV__) {
      AsyncStorage.getItem('routeStack').then(value => {
        console.log('[ROUTE STACK]', value);
        if (!value) {
          this.setState({
            initialRouteStack: [INITIAL_ROUTE],
          })
        } else {
          this.setState({
            initialRouteStack: JSON.parse(value),
          })
        }
      });
    } else {
      routeStack = [INITIAL_ROUTE];
    }
    this.state = {
      initialRouteStack: routeStack
    }

    this.debounceDehydrateLbs = throttle(this.props.dehydrateLbs);

  }

  componentDidMount() {
    // 返回键
    if (Platform.OS === 'android') {
      BackAndroid.addEventListener('hardwareBackPress', () => {
        const routes = this.refs.nav.getCurrentRoutes();
        if (routes.length > 1) {
          this.refs.nav.pop();
          return true;
        }
        return false;
      });
    }
    // 如果已经加水了，载入哈
    if (this.props.hydrated) {
      if (this.props.token) this.props.load();
    }

    // 无论如何都确认完成
    codePush.notifyApplicationReady();

    InteractionManager.runAfterInteractions(() => {
      // 更新应用代码
      if (Platform.OS === 'android') {
        NetInfo.isConnectionExpensive().then((isConnectionExpensive) => {
          // 读取网络上的最新版
          if(!isConnectionExpensive) {
            fetch(config.androidUpdate).then(
              (res) => res.json()
            ).then( value => {
              if (value.version && (value.version[0] > config.appver[0] || value.version[1] > config.appver[1])) {
                // 需要更新apk
                AsyncStorage.getItem('lastIgnore').then(data => {
                  if (data) {
                    const lastVer = JSON.parse(data);
                    if (value.version[0] === lastVer[0] && value.version[1] === lastVer[1] && value.version[2] === lastVer[2]) {
                      return;
                    }
                  }
                  Alert.alert(locales.gotANewVersion + value.version.join('.'), value.description +  locales.updateOrNot, [
                    {text: locales.neverUpdate, onPress: () => {AsyncStorage.setItem('lastIgnore', JSON.stringify(value.version))} },
                    {text: locales.dontUpdate},
                    {text: locales.downloadUpdate, onPress: () => {Linking.openURL('https://taskbee.cn/latest.apk')} },
                  ]);
                });

              }
            });
            codePush.sync({installMode: codePush.InstallMode.ON_NEXT_RESUME, minimumBackgroundDuration: 10 * 60 });
          }
        });
      } else {
        NetInfo.fetch().done(
          (connectionInfo) => {
            if (connectionInfo === 'wifi') {
              codePush.sync({installMode: codePush.InstallMode.ON_NEXT_RESUME, minimumBackgroundDuration: 10 * 60 });
            }
          }
        );
      }

    });
  }

  componentWillReceiveProps(nextProps) {
    // 如果加水在组建装载之后，登录状态判断
    if (!this.props.hydrated && nextProps.hydrated) {
      if (nextProps.token) this.props.load();
    }

    if (this.props.hydrated) {
      this.checkLoginState(nextProps);

      // 脱水部分store
      if (this.props.me !== nextProps.me) {
        // store变啦，脱水！
        // InteractionManager.runAfterInteractions(this.props.dehydrateMe);
        this.props.dehydrateMe();
      }
      if (this.props.longitude !== nextProps.longitude) {
        this.debounceDehydrateLbs();
      }
    }


  }

  shouldComponentUpdate(nextProps, nextState) {
    // 加载完成后
    if (this.refs.nav) return false;
    return true;
  }

  didFocus = (event) => {
    // const route = event.target.routeStack[0];
    const route = event.target.currentRoute;
    InteractionManager.runAfterInteractions(() => {
      this._lastRoute = route.name;
      if(!__DEV__) trackPageBegin(route.name);
      const realRoute = routes[route.name]
      const Elem = realRoute.component;
      if (Elem && Elem.fetchData) {
        const store = this.store;
        Elem.fetchData(store.getState, store.dispatch, route.passProps);
      }
    });
  };

  willFocus = (event) => {
    // 在跳转前的页面
    if (this._lastRoute) if(!__DEV__) trackPageEnd(this._lastRoute);
  };

  checkLoginState(nextProps) {
    if (!this.props.token && nextProps.token) {
      // logged in
      this.refs.nav.resetTo(INITIAL_ROUTE);
    } else if (this.props.token && !nextProps.token) {
      // logout
      this.refs.nav.resetTo(INITIAL_ROUTE);
    }
  }

  configureScene = (route) => {
    if (route.sceneConfig) {
      return Navigator.SceneConfigs[route.sceneConfig];
    }
    return Navigator.SceneConfigs.FloatFromRight;
  };

  renderScene = (route, navigator) => {
    if (__DEV__ && this.refs.nav) {
      // 记录当前页面, 只在开发环境下
      const stack = navigator.state.routeStack;
      AsyncStorage.setItem('routeStack', JSON.stringify(stack));
    }

    if (!this._subscribedToFocusEvents) {
      navigator.navigationContext.addListener('didfocus', this.didFocus);
      navigator.navigationContext.addListener('willfocus', this.willFocus);
      this._subscribedToFocusEvents = true;
    }

    // this.listenEvents(navigator);
    let Elem;
    let backable = true;
    // console.log('Route Change', route, navigator);
    let realRoute = routes[route.name]
    if (realRoute) {
      Elem = realRoute.component;
      if (!Elem) {
        console.warn('找不到组建', realRoute);
        Elem = <Text>WTF!!</Text>;
      }
    } else {
      Elem = <Text>Nothing Here</Text>;
    }
    return <View style={styles.sceneStyle}>
      { Elem ? <Elem navigator={navigator} {...route.passProps}/> : <Text>404</Text> }
    </View>;

  };

  renderLoading = () => {
    return <View style={styles.loading}><View style={styles.fakeBanner}/></View>; // <Login/>
  };

  renderRouter = () => {
    if (this.props.hydrated && this.props.hydratedLbs) {
      if (this.state.initialRouteStack) {
        return (<Navigator
          ref="nav"
          // onDidFocus={this.didFocus}
          initialRouteStack={this.state.initialRouteStack}
          renderScene={this.renderScene}
          configureScene={this.configureScene}
          navigationBar={<NavigationBar style={styles.navStyle} routeMapper={routeMapper}/>}
        />);
      }
      return this.renderLoading();
    }
    return this.renderLoading();
  };

  render() {
    return (<View style={styles.body}>
      {this.renderRouter()}
      <StatusBar
       backgroundColor="#000"
       barStyle="light-content"
     />
      <UserGuide/>
    </View>);
  }
}

export default connect(
  state => ({
    token: state.me.get('token'),
    hydrated: state.me.get('hydrated'),
    hydratedLbs: state.lbs.get('hydrated'),
    me: state.me,
    longitude: state.lbs.get('longitude'),
    // lastLocation: state.misclastLocation,
  }), {
    dehydrateMe,
    dehydrateLbs,
    load,
  }
)(Routes);

// console.log(Navigator.SceneConfigs);
// AsyncStorage.clear();
