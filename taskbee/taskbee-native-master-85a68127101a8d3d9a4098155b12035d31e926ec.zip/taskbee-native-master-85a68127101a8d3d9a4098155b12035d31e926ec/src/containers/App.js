// App入口
import React, {
  Component,
  StyleSheet,
  NetInfo,
  AppState,
  View,
  AsyncStorage,
  Platform,
  Alert,
  Linking,
  InteractionManager,
} from 'react-native';
import { createStore, applyMiddleware, combineReducers, compose } from 'redux';
import { Provider } from 'react-redux';

import middleware from '../libs/reduxMiddleware';
import reducer from '../modules/reducers';
import {Routes} from './index';

import {rehydrate as rehydrateMe} from '../modules/me';

import {loadLbs, loadLbsSuccess, loadLbsFail} from '../modules/lbs';

import {rehydrate as rehydrateMessages} from '../modules/messages';
import {rehydrate as rehydrateSysMessages} from '../modules/sysMessages';
import {rehydrate as rehydrateUser} from '../modules/user';
import {rehydrate as rehydrateLbs} from '../modules/lbs';

import config from '../config';

import {getMessage, getNew, getStatus} from '../modules/messages';
import {getNewSys, getSysMessage} from '../modules/sysMessages';
import {netChange, socketConnected, socketDisconnected} from '../modules/misc';
import createLogger from 'redux-logger';
import {Iterable} from 'immutable';
import JPush , {JpushEventReceiveMessage, JpushEventOpenMessage} from 'react-native-jpush'

import ALocation from 'react-native-amap-location';

const lbsOptions = {
  accuracy: 'BatterySaving',
  killProcess: true,
  mockEnable: true,
  needAddress: false,
  interval: 1000 * 60 * 1,
};

window.navigator.userAgent = "react-native";
const io = require('socket.io-client/socket.io');

let finalCreateStore;
if (__DEV__) {
  console.log('Remote Redux Dev Tools Enabled');
  const stateTransformer = (state) => {
    const logState = {}
    state = {...state};
    Object.keys(state).forEach( key => {
      let innerState = state[key];
      if (Iterable.isIterable(innerState)) logState[key] = innerState.toJS();
      else logState[key] = innerState;
    })
    return logState;
  };
  const logger = createLogger({
    stateTransformer,
  });
  finalCreateStore = compose(
    applyMiddleware(middleware, logger),
  )(createStore);
} else {
  finalCreateStore = applyMiddleware(middleware)(createStore);
}

const store = finalCreateStore(reducer);

/*
  加水
 */

rehydrateLbs(store.dispatch);
rehydrateUser(store.dispatch, store.getState);
rehydrateMessages(store.dispatch, store.getState);
rehydrateSysMessages(store.dispatch, store.getState);
rehydrateMe(store.dispatch, store.getState);

/*
  Websocket
 */

function initSocket(getState, dispatch) {
  const socket = io(__DEV__ ? 'http://192.168.100.11:7070' : 'https://taskbee.cn', {path: '/ws', jsonp: false, transports: ['websocket']}); // , transports: ['websocket']
  function login() {
    socket.emit('bearer', getState().me.get('token'));
  }
  socket.on('connect', login);
  socket.on('reconnect', login);

  socket.on('bearer', (result) => {
    console.log('bearer', result);
    dispatch(socketConnected());
    // 载入聊天数据
    socket.emit('getNew', null, function getNewCallback(data) {
      dispatch(getNew(data));
    });
    // 载入系统消息
    socket.emit('getNewSystem', null, function getNewSystemCallback(data) {
      dispatch(getNewSys(data));
    });
  });
  socket.on('disconnect', () => {
    dispatch(socketDisconnected());
  });
  socket.on('message', (data) => {
    // 得到消息的时候，应该给其他地方推送数量增加
    dispatch(getMessage(data));
  });
  socket.on('sysMessage', (data) => {
    dispatch(getSysMessage(data));
  });
  socket.on('status', (data) => {
    dispatch(getStatus(data));
  });
  return socket;
}

// 让我们来把store和io衔接上吧
let lastMeId;
let isActive = true;
function handleChange() {
  const state = store.getState(); // 获取state tree
  if (isActive && state.misc.connected) {
    // 网络已连接上
    if (state.me.get('meId')) {
      // 登录状态
      if (!global.socket) {
        // 初始化socket
        global.socket = initSocket(store.getState, store.dispatch);
      } else if (global.socket.disconnected) {
        // 断线重连
        socket.connect();
      }
    } else if (lastMeId && global.socket.connected) {
      // 已经登出
      global.socket.disconnect();
    }
    lastMeId = state.me.get('meId');
  }
}

store.subscribe(handleChange); // 会返回一个unscribe，但是因为我们整个生命都需要，所以不必了
function handleConnectivityChange(isConnected) {
  store.dispatch(netChange(isConnected));
}

/*
  网络状况
 */

// 获取一次网络状态 以尝试socket connect!
NetInfo.isConnected.fetch().done((isConnected) => {
  // 判断是否连线，若连线则dispatch，顺便触发了socket监听的事件
  store.dispatch(netChange(isConnected));
});

NetInfo.isConnected.addEventListener(
  'change',
  handleConnectivityChange
);

const successLbs = (pos) => store.dispatch(loadLbsSuccess(pos));
const failLbs = (error) => store.dispatch(loadLbsFail(error));

export default class App extends Component {
  handleAppStateChange = (currentAppState) => {
    const state = store.getState();
    if (currentAppState === 'active') {
      // 回到前台
      isActive = true;
      if (global.socket && state.me.get('meId') && !global.socket.connected) {
        global.socket.connect();
      }
      // 地理位置
      if (config.isIOS) {
        if (!this.watchId) this.startWatchLoc();
      } else {
        ALocation.startLocation(lbsOptions);
      }

      if (Platform.OS === 'android') {
        JPush.clearAllNotifications();
      } else {
        JPush.cancelAllLocalNotifications();
      }
    } else {
      // 进入后台
      isActive = false;
      if (global.socket && state.me.get('meId') && global.socket.connected) {
        global.socket.disconnect();
      }
      // 地理位置
      if (config.isIOS) {
        if (this.watchId) {
          navigator.geolocation.clearWatch(this.watchId);
          this.watchId = null;
        }
      } else {
        ALocation.stopLocation();
      }

    }
  };

  startWatchLoc = () => {
    if (this.watchId) {
      navigator.geolocation.clearWatch(this.watchId);
    }
    this.watchId = navigator.geolocation.watchPosition(successLbs, failLbs, {
      enableHgihAccuracy: true,
      maximumAge: 60000,
      timeout: 60000,
    });
  };

  startWatchLocAndroid = () => {
    ALocation.addEventListener(
      (data) => {
        console.log('aloaction', data);
        if (data.errorCode) {
          // 地理位置错误
          failLbs(data.errorInfo);
        } else {
          successLbs({coords: data});
        }
      }
    );
    ALocation.startLocation(lbsOptions);
  };

  waitForGuide = () => {
    this._handler = setInterval(() => {
      AsyncStorage.getItem('guide').then( value => {
        if (value === config.userGuideVer) {
          clearInterval(this._handler);
          JPush.requestPermissions();
          if (config.isIOS) {
              navigator.geolocation.getCurrentPosition(successLbs, failLbs,
              {
                maximumAge: 60000 * 2,
                timeout: 60000,
              }
            );
            this.startWatchLoc();
          } else {
            this.startWatchLocAndroid();
          }
        }
      });
    }, 400);
  };

  componentDidMount() {

    store.dispatch(loadLbs());

    // 用一个很垃圾的hack来搞定提示信息
    this.waitForGuide();


    // 程序状态变化
    AppState.addEventListener('change', this.handleAppStateChange);

  }

  componentWillUnmount() {
    /*
    this.pushlisteners.forEach(listener=> {
        JPush.removeEventListener(listener);
    });
    */
  }

  onReceiveMessage = (message) => {
    console.log(message);
  };

  onOpenMessage = (message) => {
    console.log(message);
  };

  render() {
    return (

      <Provider store={store}>
        <Routes rawStore={store}/>
      </Provider>

    );
  }
}
