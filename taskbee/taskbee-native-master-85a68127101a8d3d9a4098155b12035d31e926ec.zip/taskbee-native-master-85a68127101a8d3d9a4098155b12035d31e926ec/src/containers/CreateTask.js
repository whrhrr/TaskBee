import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  TouchableOpacity,
  InteractionManager,
  Image,
  Dimensions,
  ScrollView,
  TextInput,
  DatePickerAndroid,
  TimePickerAndroid,
  DatePickerIOS,
  Platform,
} from 'react-native';

import toast from '../libs/toast';
import Modal from 'react-native-modalbox';
import { connect } from 'react-redux';
import {reduxForm} from 'redux-form';
import createValidation from '../utils/createValidation';

import {create, newPublish} from '../modules/publish';
import {ImagePickerManager} from 'NativeModules';
import moment from 'moment';

import {
  ImagePicker,
  LongTextInput,
  NormalButton,
  Spinner,
  FadeInText,
  Icon,
  LocationSelect,
  Text,
} from '../components';

import locales from '../locales';
import config from '../config';

const {height, width} = Dimensions.get('window');
const imageSize = (width - config.normalPadding * 3) / 3;

const styles = StyleSheet.create({
  create: {
    flex: 1,
    marginTop: config.bannerHeight,
  },
  outerView: {
    flex: 1,
  },
  // cta
  errorMsg: config.styleExtraError,
  cta: {

    backgroundColor: '#fafafa',
    borderTopWidth: config.borderWidth,
    borderColor: config.colorBorder,

  },
  innerCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingRight: config.normalPadding,

  },
  count: {
    marginRight: 12,
    color: config.colorSubtle,
  },
  button: {
    alignSelf: 'flex-end',
    marginVertical: 9,
  },
  actions: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  action: {
    paddingVertical: config.normalPadding,
    paddingHorizontal: config.normalPadding - 3,
  },
  actionActive: {
    backgroundColor: config.brandGreen,
  },
  images: {
    flexDirection: 'row',
    padding: config.normalPadding,
  },
  image: {
    width: imageSize,
    height: imageSize,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    backgroundColor: config.colorVerySubtle,
    marginRight: config.normalPadding / 3,
  },
  fullText: {
    marginLeft: config.normalPadding,
    color: config.colorSubtle,
  },
  mapOpen: {
    height: 200,
  },
  mapClose: {
    height: 0,
    opacity: 0,
  },
  spliter: {
    backgroundColor: config.colorSubtle,
    width: config.borderWidth,
    height: 24,
    marginHorizontal: config.normalPadding / 2,
  },
  modal: {
    justifyContent: 'center',
    alignItems: 'center',
    height: 300,
    width: width - config.normalPadding * 2,
    borderRadius: config.borderRadius,
    padding: config.normalPadding,
  },
  timeModal: {
    height: 450,
  },
  modalInfo: {
    marginBottom: config.normalPadding,
  },
  rewardInput: {
    height: 48,
  },
  modalTitle: {
    color: config.colorMain,
    marginBottom: 3,
  },
  miscs: {
    flexDirection: 'row',
    marginTop: 12,
  },
  misc: {
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    flex: 1,
    padding: config.normalPadding,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  miscTitle: {
    color: config.colorMain,
  },
  // 女生节
  girl: {
    margin: config.normalPadding,
  },
});

const simpleText = config.isCN ? [
  '世界那么大，想去看看吗？',
  '汉子们已经等不及啦～',
  '找人泡图书馆？找人打球？求学姐学长教学？',
  '是FF，不是FFF，不来发任务吗少年',
  '天气辣么好，不找个人打球吗？',
  '校园这么大，找个志同道合的小伙伴聊聊那些小众的兴趣爱好吧～',
  '快递来不及领？发个任务吧！',
]
:
[
  'What do you need?',
  'Want to hang out with people around you?',
];

function genText() {
  const len = simpleText.length;
  return simpleText[Math.floor(Math.random() * len)];
}

class CreateTask extends Component {
  static propTypes = {
    creating: PropTypes.bool,
    registerError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    initializeForm: PropTypes.func.isRequired,
    create: PropTypes.func.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    newPublish: PropTypes.func.isRequired,
    token: PropTypes.string,
    createError: PropTypes.any,
    success: PropTypes.any,
    user: PropTypes.object.isRequired,
    long: PropTypes.number,
    lati: PropTypes.number,
  };

  constructor(props) {
    super(props);
    this.state = {
      mapOpen: false,
      loaded: false,
      // 杂项选择
      moneyOpen: false,
      startTimeOpen: false,
      dueTimeOpen: false,
      keyboardHeight: 0,
    }
    this.long = props.long;
    this.lati = props.lati;
    this.text = genText();
  }

  componentWillMount() {

  }
  componentDidMount() {

    InteractionManager.runAfterInteractions(() => {
      this.setState({loaded: true});
    });
  }

  componentWillReceiveProps(nextProps) {
    // 评论成功后拉到页面底部
    if (!this.props.success && nextProps.success) {
      this.props.navigator.pop();
      if (nextProps.success.length) {
        toast(locales.lostImages);
      } else {
        toast(locales.publishSucess);
      }
      InteractionManager.runAfterInteractions(() => {
        this.props.newPublish();
      });
    }
    if (!this.props.createError && nextProps.createError) {
      toast(locales.publishFail + ':' + (nextProps.createError.message || locales.strangeError));
    }
  }

  onCameraPress = () => {
    ImagePickerManager.launchCamera(config.imageSettings, (response)  => {
      console.log('Response = ', response);
      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePickerManager Error: ', response.error);
      } else {
        this.onSetImage(response);
      }
    });
  };

  onImagePress = () => {
    ImagePickerManager.launchImageLibrary(config.imageSettings, (response)  => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePickerManager Error: ', response.error);
      } else {
        this.onSetImage(response);
      }
    });
  };

  onSetImage = (data) => {
    const {images} = this.props.fields;
    // !!!mutate 不知道是否可行
    images.value.push(data);
    images.onBlur(images.value);
  };

  onNavigatePress = () => {
    this.setState({
      mapOpen: !this.state.mapOpen
    });
  };

  onCloseMap = () => {
    this.setState({
      mapOpen: false
    });
  };

  onRegionChange = (data) => {
    if (Platform.OS === 'android') {
      data = data.src;
    }
    const {latitude, longitude} = data;
    // 避免渲染
    this.lati = latitude;
    this.long = longitude;
  };

  onRewardOpen = () => {
    this.setState({moneyOpen: true});
    // 等待元素被mount
  };


  confirmReward = () => {
    const val = parseInt(this.props.fields.reward.value, 10);
    if ( val < 0 || isNaN(val)) {
      this.props.fields.reward.onChange('0');
    } else if ( val > this.props.user.money) {
      this.props.fields.reward.onChange(this.props.user.money);
    }
    this.setState({moneyOpen: false});
  };

  onStartTimeClick = async function() {
    if (Platform.OS === 'ios') {
      return this.setState({startTimeOpen: true});
    }
    const date = this.props.fields.startTime.value;
    const realDate = new Date(date);
    try {
      const {action, year, month, day} = await DatePickerAndroid.open({
        date,
        minDate: date,
        maxDate: date + 60 * 1000 * 60 * 24 * 60,
      });
      if (action === DatePickerAndroid.dismissedAction) return;
      // 选择时间

      const {action: action2, minute, hour} = await TimePickerAndroid.open({
        hour: realDate.getHours(),
        minute: realDate.getMinutes(),
        is24Hour: true,
      });
      if (action2 === TimePickerAndroid.dismissedAction) return;
      const newDate = (new Date(year, month, day, hour, minute)).getTime();
      this.props.fields.startTime.onUpdate(newDate);
      if (newDate > this.props.fields.dueTime.value) {
        this.props.fields.dueTime.onUpdate(newDate + 60 * 1000 * 60 * 24 * 30);
      }
    } catch ({code, message}) {
      console.log('time error', message);
    }
  }.bind(this);

  onDueTimeClick = async function() {
    if (Platform.OS === 'ios') {
      return this.setState({dueTimeOpen: true});
    }
    const date = this.props.fields.dueTime.value;
    const realDate = new Date(date);
    try {
      const {action, year, month, day} = await DatePickerAndroid.open({
        date,
        minDate: this.props.fields.startTime.value,
        maxDate: date + 60 * 1000 * 60 * 24 * 60,
      });
      if (action === DatePickerAndroid.dismissedAction) return;
      // 选择时间

      const {action: action2, minute, hour} = await TimePickerAndroid.open({
        hour: realDate.getHours(),
        minute: realDate.getMinutes(),
        is24Hour: true,
      });
      if (action2 === TimePickerAndroid.dismissedAction) return;
      const newDate = (new Date(year, month, day, hour, minute)).getTime();
      this.props.fields.dueTime.onUpdate(newDate);
    } catch ({code, message}) {
      console.log('time error', message);
    }
  }.bind(this);

  prepareToCreate = (data) => {
    // 处理正确的提交数据
    if (config.isIOS) {
      data.startTime = data.startTime.getTime();
      data.dueTime = data.dueTime.getTime();
    }
    data.token = this.props.token;
    data.pos = [this.long, this.lati];
    data.images = data.images.map( item => item.uri); //.filter(item => item !== null);
    this.props.create(data);
  };

  onSubmitClick = (data) => {
    const {creating} = this.props;
    if (!creating) {
      this.props.handleSubmit(this.prepareToCreate)(data);
    }
  };

  // ios only
  confirmStartTime = () => {
    this.setState({startTimeOpen: false});
  };

  // ios only
  confirmDueTime = () => {
    this.setState({dueTimeOpen: false});
  };

  // ios only
  onStarTimeUpdate = (date) => {
    if (date.getTime() > this.props.fields.dueTime.value.getTime()) {
      this.props.fields.dueTime.onUpdate(new Date(date.getTime() + 60 * 1000 * 60 * 24 * 30));
    }
    this.props.fields.startTime.onUpdate(date);
  };
  onKeyboardWillShow = (e) => {
    if(config.isIOS) this.setState({keyboardHeight: e.endCoordinates ? e.endCoordinates.height : e.end.height});
  };

  onKeyboardWillHide = () => {
    if(config.isIOS) this.setState({keyboardHeight: 0});
  };
  render() {
    const {user, long, lati, navigator, creating, success, createError, fields: {images, startTime, dueTime, reward, description, secret}} = this.props;
    const {mapOpen} = this.state;


    return (
      <View style={[styles.create, config.isIOS && this.state.keyboardHeight ? {paddingBottom: this.state.keyboardHeight} : null]}>
        <ScrollView
         style={styles.outerView}
         onKeyboardWillShow={this.onKeyboardWillShow}
         onKeyboardWillHide={this.onKeyboardWillHide}
        >
          {createError && <Text style={styles.errorMsg}>{createError.message || locales.strangeError}</Text>}
          <LongTextInput
            label={locales.taskDescription}
            placeholder={locales.descriptionDescription + this.text}
            rows="7" maxCount={280}
            extraOnFocus={this.onCloseMap}
            {...description}/>

          <View style={styles.miscs}>
            <TouchableOpacity style={styles.misc} onPress={this.onStartTimeClick}>
              <Text style={styles.miscTitle}>{locales.startTime}</Text>
              <Text style={styles.miscText}>{moment(startTime.value).format('MM/D HH:mm')}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.misc} onPress={this.onDueTimeClick}>
              <Text style={styles.miscTitle}>{locales.endDate}</Text>
              <Text style={styles.miscText}>{moment(dueTime.value).format('MM/D HH:mm')}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.misc} onPress={this.onRewardOpen}>
              <Text style={styles.miscTitle}>{locales.reward}</Text>
              <Text style={styles.miscText}>¥{reward.value}</Text>
            </TouchableOpacity>

          </View>
          <View style={styles.images}>
              {
                images.value && images.value.map((data, index) => {
                  return <Image key={index} style={styles.image} resizeMode={Image.resizeMode.contain} source={{uri: data.uri, isStatic: true}}/>
                })
              }
          </View>
          <LongTextInput
            label={locales.secretInformation}
            placeholder={locales.secretDescription}
            rows="5"
            maxCount={280}
            {...secret}/>


        </ScrollView>
        <View style={styles.cta}>
          {this.state.loaded && <LocationSelect onRegionChange={this.onRegionChange} style={mapOpen ? styles.mapOpen : styles.mapClose} long={long} lati={lati}/>}
         <View style={styles.innerCta}>
            <View style={styles.actions}>
              {
                images.value && images.value.length > 2 ?
                <Text style={styles.fullText}>{locales.max3pics}</Text>
                :
                [<TouchableOpacity key="camera" style={styles.action} onPress={this.onCameraPress}>
                  <Icon name="camera" size={24} color={config.colorLessSubtle}/>
                </TouchableOpacity>,
                <TouchableOpacity key="image" style={styles.action} onPress={this.onImagePress}>
                  <Icon name="image" size={24} color={config.colorLessSubtle}/>
                </TouchableOpacity>]
              }

              <TouchableOpacity style={[styles.action, mapOpen ? styles.actionActive : null]} onPress={this.onNavigatePress}>
                <Text>{ mapOpen ? locales.closeMap : locales.confirmLocation }</Text>
              </TouchableOpacity>
            </View>

            {/*<Text style={styles.count}>{280 - (description.value ? description.value.length : 0)}</Text>*/}
            <NormalButton style={styles.button} onPress={this.onSubmitClick} text={locales.publishButton} working={creating}/>
          </View>
        </View>

        <Modal style={styles.modal} isOpen={this.state.moneyOpen} animationDuration={250} animated onClosed={this.confirmReward}>
              <Text style={styles.modalTitle}>{locales.canGiveSomeReward}</Text>
              <Text>{locales.currentBalance}¥{user.get('money')}</Text>
                <TextInput
                  style={styles.rewardInput}
                  keyboardType="numeric"
                  autoFocus
                  ref="rewardInput" placeholder={locales.pleaseEnterAnInteger}
                  underlineColorAndroid={config.brandGreen}
                  {...reward}
                  onEndEditing={this.confirmReward}
                />
            <NormalButton onPress={this.confirmReward} text={locales.confirmReward}/>
        </Modal>

        {
          config.isIOS ?
          <Modal style={[styles.modal, styles.timeModal]} isOpen={this.state.startTimeOpen} animationDuration={250} swipeToClose={false} animated onClosed={this.confirmStartTime}>
            <View style={styles.modalInfo}>
              <Text style={styles.modalTitle}>{locales.startTimeDescription}
              </Text>
              <DatePickerIOS
                mode="datetime"
                minimumDate={new Date()}
                maximumDate={new Date(Date.now() + 60 * 1000 * 60 * 24 * 60)}
                onDateChange={this.onStarTimeUpdate}
                date={startTime.value}
              />
            </View>
            <NormalButton onPress={this.confirmStartTime} text={locales.confirmTime}/>
        </Modal>
          : null
        }

        {
          config.isIOS ?
          <Modal style={[styles.modal, styles.timeModal]} isOpen={this.state.dueTimeOpen} animationDuration={250} swipeToClose={false} animated onClosed={this.confirmDueTime}>
            <View style={styles.modalInfo}>
              <Text style={styles.modalTitle}>{locales.endTimeDescription}
              </Text>
              <DatePickerIOS
                mode="datetime"
                minimumDate={startTime.value}
                maximumDate={new Date((startTime.value ? startTime.value.getTime() : Date.now()) + 60 * 1000 * 60 * 24 * 60)}
                onDateChange={dueTime.onUpdate}
                date={dueTime.value}
              />
            </View>
            <NormalButton onPress={this.confirmDueTime} text={locales.confirmTime}/>
        </Modal>
          : null
        }
      </View>

    );
  }
}

export default reduxForm({
  form: 'create',
  fields: ['startTime', 'dueTime', 'reward', 'description', 'secret', 'images'],
  validate: createValidation,
  initialValues: {
    startTime: config.isIOS ? new Date() : Date.now(),
    dueTime: config.isIOS ? new Date(Date.now() + 60 * 1000 * 60 * 24 * 30) : Date.now() + 60 * 1000 * 60 * 24 * 30,
    reward: '0',
    description: '',
    secret: '',
    images: [],
  }
})(
  connect(
    state => ({
      user: state.me.get('data'),
      token: state.me.get('token'),
      long: state.lbs.get('longitude'),
      lati: state.lbs.get('latitude'),
      createError: state.publish.error,
      success: state.publish.success,
      creating: state.publish.creating,
    }), { create, newPublish})
(CreateTask)
)


