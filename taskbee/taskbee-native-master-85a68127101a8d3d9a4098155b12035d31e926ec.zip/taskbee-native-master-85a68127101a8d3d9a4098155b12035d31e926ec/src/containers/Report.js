import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
} from 'react-native';
import {
  TextInput,
  LongTextInput,
  NormalButton,
  Icon,
  Text,
} from '../components';

import {reduxForm} from 'redux-form';
import {connect} from 'react-redux';

import {reportAgain as feedbackAgain, report as feedback} from '../modules/misc';

import {serverError} from '../utils/dataHelpers';

import config from '../config';
const styles = StyleSheet.create({
  feedback: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
  },
  mainText: {
    alignItems: 'center',
    margin: config.normalPadding,
  },
  submit: {
    alignSelf: 'center',
    marginTop: config.normalPadding,
  },
  icon: {
    color: config.colorMain,
    marginVertical: config.normalPadding,
  },
  input: {
    flex: 1,
    justifyContent: 'center',
  },
  success: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
    marginHorizontal: config.normalPadding,
  },
  successMain: {
    color: config.colorMain,
    fontSize: config.fontLarge,
  }
});

class Feedback extends Component {
  static propTypes = {
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    feedback: PropTypes.func.isRequired,
    feedbackAgain: PropTypes.func.isRequired,
    feedbacking: PropTypes.bool,
    feedbackSuccess: PropTypes.bool,
    feedbackError: PropTypes.any
  };

  onSubmitClick = (data) => {
    const {token, feedbacking, itemId, type, fields: {message}} = this.props;
    if (!feedbacking) {
      this.props.feedback({
        itemId,
        type,
        token,
        message: message.value
      });
    }
  };

  render() {
    const {feedbackSuccess, feedbacking, feedbackError, fields: {message}} = this.props; /* eslint no-shadow: 0*/

    const errorFunc = serverError(feedbackError);

    return (
      <View style={styles.feedback}>
        <View style={styles.mainText}>
          <Text>一个能让大家都喜欢的蜂房离不开各位共同的监督！我们会认真对待每一个违规情况。</Text>
        </View>
        <View>
          {
            feedbackSuccess ? <View style={styles.success}>
              <Text style={styles.successMain}>非常感谢您的举报</Text>
              <Text>我们会尽快调查，如果违反规定将进行相应处理</Text>
              <NormalButton onPress={this.props.feedbackAgain} text="继续举报"/>
            </View> :
            <View style={styles.input}>
              {feedbackError && (!feedbackError.errorCode || typeof feedbackError.errorCode === 'number') && <Text style={styles.extraError}>{feedbackError.message || '迷的错误'}</Text>}
              <LongTextInput
                placeholder="请简要描述一下违规内容"
                rows="10"
                maxCount={560}
                {...message}
                onSubmitEditing={this.onSubmitClick}
              />
             <NormalButton style={styles.submit} text="提交举报" working={feedbacking} onPress={this.onSubmitClick}/>
            </View>

          }
        </View>
      </View>
    );
  }
}

export default reduxForm({
  form: 'misc',
  fields: ['message'],
})(
  connect(
    state => ({
      token: state.me.get('token'),
      feedbackError: state.misc.reportError,
      feedbackSuccess: state.misc.reportSuccess,
      feedbacking: state.misc.reporting,
    }),
    {feedbackAgain, feedback})(
    Feedback
  )
)

