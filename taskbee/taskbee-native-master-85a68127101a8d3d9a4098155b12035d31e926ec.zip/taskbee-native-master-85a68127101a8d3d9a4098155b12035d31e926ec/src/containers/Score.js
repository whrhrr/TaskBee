import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  ScrollView,
  Image,
} from 'react-native';

import {Text} from '../components';

import {connect} from 'react-redux';
import config from '../config';

const styles = StyleSheet.create({
  score: {
    marginTop: config.bannerHeight,
  },
  realPadding: {
    paddingVertical: config.normalPadding,
  },
  intro: {

    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  introText: {
    fontSize: config.fontXLarge,
    color: config.colorMain,
    marginTop: 6,
  },
  introImage: {

  },
  rules: {
    margin: config.normalPadding,
    borderRadius: config.borderRadius,
    backgroundColor: '#fff',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  mainText: {
    padding: config.normalPadding,
    borderBottomWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
});

class Score extends Component {
  static propTypes = {
    user: PropTypes.object,
  };

  renderText(texts) {
    return texts.map((text, index) => <View key={index} style={styles.mainText}><Text>{text}</Text></View>);
  }

  render() {
    const scoreImg = require('../assets/Score.png');
    return (
      <ScrollView
       style={styles.score}
       contentContainerStyle={styles.realPadding}

      >
        <View style={styles.intro}>
          <Image style={styles.introImage} source={scoreImg}/>
          <Text style={styles.introText}>{this.props.user && this.props.user.get('score')}</Text>
        </View>

        <View style={styles.rules}>
          {this.renderText(
            config.isCN ?
            [
              '蜂蜜是您在使用蜂房过程中获得的积分',
              '蜂蜜为负时不得发布/接手任务',
              '每日签到(每天发布的第一条花粉) ＋1',
              '接手任务 ＋1',
              '发布任务 －2',
              '任务顺利完成 发布者 ＋1/ 接手者 ＋1',
              '接手任务者，若接手后不能完成任务 －6',
              '发布任务者，若在有人接手后撤销任务 －6',
              '完成任务后评价对方，可为对方增加（0～2）蜂蜜',
            ]
            :
            [
              'Honey is the score you earn during using Taskbee',
              'You\'ll not be able to take/publish a task if you Honey drops below 0',
              'Taking a task +1',
              'Publish a task -2',
              'Task finish +1',
              'Give up a task -6',
              'After a task is completed, you can vote the other to award them more Honey(0~2)',
            ]
          )}
        </View>
      </ScrollView>
    );
  }
}

export default connect(
  state => ({
    user: state.me.get('data')
  })
)(Score)
