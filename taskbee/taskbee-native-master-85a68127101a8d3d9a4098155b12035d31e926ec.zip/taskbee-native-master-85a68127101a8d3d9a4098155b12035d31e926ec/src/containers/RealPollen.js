import React, {
  Component,
  View,
  PropTypes,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import {connect} from 'react-redux';

import {setPollenTab} from '../modules/misc';

import {
  NormalButton,
  Text,
  TabBanner,
  Icon,
} from '../components';

import {
  HomePollen,
} from '../containers';

import {MyPollens} from './PollenList';
import {HotestPost} from './OtherPosts';

import locales from '../locales';
const styles = StyleSheet.create({
  fullHeight: {
    flex: 1,
  }
});
class RealPollen extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
  };

  render() {
    const {navigator, active, token} = this.props;
    return (<View  style={styles.fullHeight} >
      <TabBanner
        items={[
          {
            text: locales.nearbyPollens,
            onPress: () => this.props.setPollenTab(0),
          },
           {
            text: locales.myPollens,
            onPress:  () => this.props.setPollenTab(1),
          },
          {
            text: locales.weeklyHotest,
            onPress: () => this.props.setPollenTab(2),
          }
        ]}
        active={active}
      />
      {
        active === 0 ? <HomePollen style={styles.fullHeight} navigator={navigator}/>
        : active === 1 ? <MyPollens navigator={navigator}/>
        : <HotestPost navigator={navigator}/>
      }
    </View>);
  }
  static fetchData(getState, dispatch, passProps) {
    HomePollen.fetchData(getState, dispatch, passProps);
    MyPollens.fetchData(getState, dispatch, passProps);
    HotestPost.fetchData(getState, dispatch, passProps);
  }
}

export default connect(state => ({
  active: state.misc.pollenTab,
  token: state.me.get('token'),
}), {setPollenTab}
)(RealPollen);
