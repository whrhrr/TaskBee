import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  RefreshControl,
  ListView,
} from 'react-native';
import { connect } from 'react-redux';

import {
  TaskItem,
  NormalButton,
  Text,
} from '../components';

import {getTasksFav, getTasksHistory} from '../modules/me';
import {fav, unfav} from '../modules/task';
import {onFavClick} from '../utils/componentEvents.js';
import {mdl} from 'react-native-material-kit';
import config from '../config';
import locales from '../locales';
function getDisplayName(Comp) {
  return Comp.displayName || Comp.name || 'Component';
}
// 生成对应的修改个人信息页面
function factory({loadingKey, errorKey, taskKey, load, name, noMoreKey}) {
  // 将异步获取数据移动到这里，以获取apiKey
  return DecoratedComponent => {
    class RealOtherTasks extends Component {
      static displayName = `${name}(${getDisplayName(DecoratedComponent)})`;
      static fetchData(getState, dispatch) {
        return dispatch(load());
      }
      static DecoratedComponent = DecoratedComponent;
      render() {
        return <DecoratedComponent name={name} {...this.props}/>;
      }
    }
    return connect(
      state => {
        return ({
          loading: state.me.get(loadingKey),
          error: state.me.get(errorKey),
          tasks: state.task,
          taskIds: state.me.get(taskKey) || [],
          token: state.me.get('token'),
          noMore: state.me.get(noMoreKey),
          meId: state.me.get('meId'),
          long: state.lbs.get('longitude'),
          lati: state.lbs.get('latitude'),
        });
      },
      { load, fav, unfav })(RealOtherTasks);
  }
}

const styles = StyleSheet.create({
  noList: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
    marginVertical: config.normalPadding,
  },
  otherTasks: {
    marginTop: config.bannerHeight,
  },
  center: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    padding: config.normalPadding,
  },
  subtle: {
    padding: config.normalPadding,
  },
  errorMessage: config.styleExtraError,
});
const Indeterminate = mdl.Progress.indeterminateProgress()
  .build();
class OtherTasks extends Component {
  static propTypes = {
    taskIds: PropTypes.array.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
    name: PropTypes.string.isRequired,
    load: PropTypes.func.isRequired,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    tasks: PropTypes.object.isRequired,
    noMore: PropTypes.bool,
    meId: PropTypes.string,
    navigator: PropTypes.object.isRequired,
  };

  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (item1, item2) => {
      console.warn(item1);
      return item1 !== item2
    }});
    this.state = {
      dataSource: ds.cloneWithRows(props.taskIds.map(id => props.tasks.get(id))),
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.taskIds.length !== nextProps.taskIds.length || nextProps.tasks.size !== this.props.tasks.size) {
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(nextProps.taskIds.map(id => nextProps.tasks.get(id))),
      });
    }
  }

  onLoadMore = () => {
    if (!this.props.noMore && !(!this.props.taskIds.length && this.props.error) && !this.props.loading) {
      const {taskIds} = this.props;
      this.props.load(taskIds[Math.max(taskIds.length - 1, 0)]);
    }
  };

  onBindedFavClick = onFavClick.bind(this);

  onScrollLoad = () => {
    if (!this.props.error && !this.props.loading) {
      this.props.load();
    }
  };

  onRetryClick = () => {
    if (!this.props.loading) {
      this.props.load();
    }
  };

  renderRow = (item) => {
    console.warn('renderRow');
    if (item) {
      item = item.toJS();
      return <TaskItem {...item} onFavClick={this.onBindedFavClick(item._id)} meId={this.props.meId} navigator={this.props.navigator} myPos={[this.props.long, this.props.lati]}/>;
    } else return <View/>;
  };

  renderFooter = () => {
    const { meId, noMore, tasks, loading, taskIds, error, name} = this.props;
    let content;
    if (loading) {
      content = <View style={styles.center}><Indeterminate /></View>;
    } else if (error) {
      content = (<View style={styles.center}>
      <Text style={styles.errorMessage}>{error.message || locales.strangeError}</Text>
      <NormalButton text={locales.retry} onPress={this.onRetryClick}/>
    </View>);
    } else if (noMore && taskIds.length) {
      content = (<Text style={[styles.center, styles.action]}>
          {locales.noMore}
        </Text>);
    } else if (!taskIds.length) {
      content = (<View style={styles.center}>
        <Text style={styles.subtle}>{locales.noYet}{name}</Text>
        {/* <NormalButton style={styles.button} to="/">去浏览任务</NormalButton>*/}
      </View>);
    } else if(tasks.size) {
      content = <View style={[styles.center, styles.action]} onPress={this.onLoadMore}><Text>{locales.loadMore}</Text></View>;
    } else content = <View><Indeterminate /></View>
    return content;
  };

  render() {
    const {navigator, meId, noMore, tasks, loading, taskIds, error, name} = this.props;

    return (
      <ListView style={styles.otherTasks}
        dataSource={this.state.dataSource}
        renderRow={this.renderRow}
        renderFooter={this.renderFooter}
        onEndReached={this.onLoadMore}
        onEndReachedThreshold={50}
        contentContainerStyle={styles.realTask}
        refreshControl={config.isIOS ? null :
          <RefreshControl
            colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
            refreshing={loading} onRefresh={this.onScrollLoad}/>
        }
      />
    );
  }
}

export const FavTasks = factory({
  loadingKey: 'gettingFavTasks',
  errorKey: 'getFavTasksError',
  taskKey: 'taskFav',
  load: getTasksFav,
  name: locales.likedTasks,
  noMoreKey: 'noMoreFav'
})(OtherTasks);

export const HistoryTasks = factory({
  loadingKey: 'gettingHistoryTasks',
  errorKey: 'getHistoryTasksError',
  taskKey: 'taskHistory',
  load: getTasksHistory,
  name: locales.historyTasks,
  noMoreKey: 'noMoreHistory',
})(OtherTasks);
