import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
  AsyncStorage,
  Animated,
  TouchableOpacity,
} from 'react-native';
import {
  NormalButton,
  Modal,
  Swiper,
  PollenCard,
  Text,
  Icon,
} from '../components';

const THISID = __DEV__ ? 'test2' : '1.7.0';
import LocalizedStrings from 'react-native-localization';

import config from '../config';

const styles = StyleSheet.create({
  userGuide: {
    position: 'absolute',
    top: config.normalPadding,
    bottom: config.normalPadding,
    left: config.normalPadding,
    right: config.normalPadding,
    borderRadius: config.normalPadding,
    backgroundColor: config.brandPrimary,
    alignItems: 'stretch',
    justifyContent: 'center',
    padding: config.normalPadding,
    elevation: 5,
  },
  title: {
    // color: config.colorStand,
    fontSize: config.fontBig,
    marginBottom: config.normalPadding,
    color: '#fff',
    fontWeight: 'bold',
  },
  text: {
    color: '#fff',
    textAlign: 'center',
    marginBottom: 3,
  },
  spliter: {
    marginVertical: config.normalPadding,
    height: 1,
    alignSelf: 'stretch',
    backgroundColor: config.colorBorder,
  },
  button: {
    marginTop: config.normalPadding,
  },
  skip: {
    position: 'absolute',
    right: config.normalPadding,
    top: config.normalPadding,
  },
  section: {
    alignItems: 'center',
    alignSelf: 'stretch',
  },
  pollenCard: {
    flex: 1,
    alignSelf: 'stretch',
  },
  icon: {
    marginBottom: config.normalPadding,
  }
});

const strings = new LocalizedStrings({
  en: {
    task: 'This is FF Task, sharing your skill!',
    descript1: 'Get help with your study',
    descript2: 'Or find people to hang out',
    descript3: 'Share your skill, share your time',
    start: 'Let\'s go!',
  },
  zh: {
    task: '这里是蜂房任务',
    descript1: '学习指导、技能求教、约自习、约运动！',
    descript2: '分享技能、分享时间、大学生活不再无趣',
    descript3: '人人都是老司机!',
    start: '我们开始吧～',
  }

});

export default class PollenGuide extends Component {
  static propTypes = {
    children: PropTypes.any,
    index: PropTypes.number,
  };

  state = {
    show: false,
  };

  componentDidMount() {
    AsyncStorage.getItem('guideTask').then(data => {
      if (data !== THISID) {
        this.setState({
          show: true,
          page: new Animated.Value(0),
          realPage: 1
        }, () => {
          Animated.timing(
            this.state.page,
            {
              toValue: 1,
              duration: 500
            }
          ).start();
        });
      }
    });
  };

  onRequestClose = () => {
    this.setState({show: false});
    AsyncStorage.setItem('guideTask', THISID);
  };

  onFirstPress = () => {
    this.setState({
      realPage: 2,
    });
    Animated.timing(
      this.state.page,
      {
        toValue: 2,
        duration: 500
      }
    ).start();
  };

  onSecondPress = () => {
    this.setState({
      realPage: 3,
    });
    Animated.timing(
      this.state.page,
      {
        toValue: 3,
        duration: 500
      }
    ).start();
  };

  renderFirst = () => {
    const {page, realPage} = this.state;
    if (realPage === 1) {
      return <View style={[styles.section]}>
        <Icon style={styles.icon} name="heart" size={60} color="rgba(0,0,0,.4)"/>
        <Text style={styles.title}>{strings.task}</Text>
        <Text style={styles.text}>{strings.descript1}</Text>
        <Text style={styles.text}>{strings.descript2}</Text>
        <Text style={styles.text}>{strings.descript3}</Text>

        <NormalButton style={styles.button} type={1} text={strings.start} onPress={this.onRequestClose}/>
      </View>;
    }
  };

  render() {
    const {show} = this.state;
    if (!show) return <View/>;
    // 计算guide啦！

    return (
      <View style={styles.userGuide}>
        {this.renderFirst()}
      </View>
    );
  }

}
