import React, {
  Component,
  View,
  PropTypes,
  StyleSheet,
} from 'react-native';
import { mdl } from 'react-native-material-kit';
const {Spinner} = mdl;

const styles = StyleSheet.create({
  deffered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  size: {
    width: 40,
    height: 40,
  },
});

export default class Deferred extends Component {
  static propTypes = {
    showElem: PropTypes.bool,
    choldren: PropTypes.element,
  };
  constructor(props) {
    super(props);

  }

  render() {
    if (this.props.showElem) {
      return this.props.children;
    }
    return (
      <View style={styles.deffered}>
        <Spinner style={styles.size}/>
      </View>
    );
  }
}
