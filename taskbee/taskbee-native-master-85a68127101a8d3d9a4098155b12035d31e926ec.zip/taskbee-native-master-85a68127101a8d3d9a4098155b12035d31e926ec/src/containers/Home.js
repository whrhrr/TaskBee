'use strict';
import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
  TouchableOpacity,
  ListView,
  RefreshControl,
  Dimensions,
} from 'react-native';
import { connect } from 'react-redux';
import { load } from '../modules/lists';
import connectData from '../libs/connectData';
import {fav, unfav} from '../modules/task';
import {goTo, requireLogin} from '../utils/navigation';
import {onFavClick} from '../utils/componentEvents';
import {setLocation} from 'react-native-talkingdata';

import config from '../config';
const {height} = Dimensions.get('window');

import {MKButton} from 'react-native-material-kit';
import locales from '../locales';


import {
  TaskGuide,
} from '../containers';

import {
  MainTab,
  NormalButton,
  TaskItem,
  LoadingIndicator,
  MainMap,
  Icon,
  Text,
  LbsIndicator,
} from '../components';

const styles = StyleSheet.create({
  text: {
    width: 100,
    height: 30,
    padding: 10,
    backgroundColor: 'lightgray',
    margin: 3
  },
  home: {
    flex: 1,
    alignSelf: 'stretch',
  },
  center: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  noOther: {
    flex: 1,
    paddingTop: height / 2 - 120,
  },
  subtle: {
    marginBottom: config.normalPadding / 3,
    color: config.colorMain,
    fontSize: config.fontLarge,
    textAlign: 'center',
  },
  errorMessage: config.styleExtraError,
  listView: {
    flex: 1,
  },
  buttons: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    backgroundColor: '#fafafa',
    borderTopWidth: config.borderWidth,
    borderTopColor: config.colorBorder,
    alignItems: 'center',
  },
  button: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: 48,
    flexDirection: 'row',
  },
  spliter: {
    width: config.borderWidth,
    backgroundColor: config.colorBorder,
    height: 24,
  },
  subtleText: {
    marginBottom: config.normalPadding,
    marginHorizontal: config.normalPadding,
    textAlign: 'center',
  },
  subtleTextExtra: {
    paddingBottom: config.normalPadding / 2,
    textAlign: 'center',
    fontSize: config.fontSmall,
  },
  fab: {
    backgroundColor: config.brandSecondary,
    position: 'absolute',
    right: 24,
    bottom: 18,
  }
});


const ColoredFab = MKButton.coloredFab()
  .withStyle(styles.fab)
  .build();

const simpleText = config.isCN ? [
  '蜂房是ff，不是fff！少年不来一发任务吗嗡～',
  '任务被领完了嗡～',
  '憋说话，嗡我！',
]
: [
  'There is no more task!'
];

function genText() {
  const len = simpleText.length;
  return simpleText[Math.floor(Math.random() * len)];
}

class Home extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
    user: PropTypes.object,
    briefTasks: PropTypes.object.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    onFavClick: PropTypes.func.isRequired,
    load: PropTypes.func.isRequired,
    // arriveTask: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (item1, item2) => {
      return item1 !== item2;
    }});
    this.state = {
      dataSource: ds.cloneWithRows(props.tasks),
    };
    this.emptyText = genText();
  }

  componentWillReceiveProps(nextProps) {
    // 加载新任务
    if (!this.props.lbsLoaded && nextProps.lbsLoaded) {
      const {long, lati} = nextProps;
      this.props.load({ loc: [long, lati]});
      // 位置track
      if(!__DEV__) setLocation(lati, long);
    }
    if (this.props.tasks.length !== nextProps.tasks.length || nextProps.briefTasks.size !== this.props.briefTasks.size) {
      this.setState({dataSource: this.state.dataSource.cloneWithRows(nextProps.tasks)});
    }
  }

  goTo = goTo.bind(this);
  requireLogin = requireLogin.bind(this);
  onFavClick = (id, task) => this.requireLogin((event) => {
    event.preventDefault();
    event.stopPropagation();
    const {token} = this.props;
    if (task) {
      // 已经toJS
      if (task.faved) {
        this.props.unfav({id, token});
      } else {
        this.props.fav({id, token});
      }
    } else {
      const theTask = this.props.briefTasks.get(id);
      if (theTask.get('faved')) {
        this.props.unfav({id, token});
      } else {
        this.props.fav({id, token});
      }
    }
  });

  loadTasks = () => {
    const {long, lati} = this.props;
    this.props.load({ loc: [long, lati]});
  };

  renderRow = (id) => {
    const immutalbeItem = this.props.briefTasks.get(id);
    if (immutalbeItem) {
      const item = immutalbeItem.toJS();
      if (item._id) return <TaskItem {...item}
       navigator={this.props.navigator}
       meId={this.props.meId}
       onFavClick={this.onFavClick(id)}
       myPos={[this.props.long, this.props.lati]}
      />;
    } else return <View><Text>...</Text></View>;
  };

  renderHeader = () => {
    const {lbsLoaded, lbsLoading} = this.props;
    return <LbsIndicator lbsLoaded={lbsLoaded} lbsLoading={lbsLoading} />
  };

  // 女生节
  renderFooter = () => {
    const { tasks, loading, error, lbsLoaded} = this.props;
    if (error) {
      return (<View style={styles.center}>
        <Text style={styles.errorMessage}>{error.message || locales.strangeError}</Text>
        <NormalButton text={locales.retry} onPress={this.loadTasks}/>
      </View>);
    } else if (!tasks.length) {
      return (<View style={[styles.noOther, styles.center]}>
        <Text style={styles.subtle}>{locales.noMoreTasks}~</Text>
        <Text style={styles.subtleText}>{this.emptyText}</Text>
        <NormalButton text={locales.publishTask} onPress={this.requireLogin(this.goTo('CreateTask'))}/>
      </View>);
    } else if(!lbsLoaded) {
      return (<View>
        <Text style={styles.subtleTextExtra}>{locales.locationNotLoaded}</Text>
        <Text style={styles.subtleTextExtra}>{locales.tasksMayNotBeReal}</Text>
      </View>
      )
    } else {
      return (<View>
        <Text style={styles.subtleTextExtra}>{locales.thatsAllTasks}</Text>
        </View>
      )
    }
  };

  render() {
    const {loading, error} = this.props;
    return (
      <View style={styles.home}>
        <ListView
          style={styles.listView}
          dataSource={this.state.dataSource}
          renderRow={this.renderRow}
          renderFooter={this.renderFooter}
          renderHeader={this.renderHeader}
          contentContainerStyle={styles.contentContainerStyle}
          refreshControl={config.isIOS ? null :config.isIOS ? null :
            <RefreshControl
              colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
              refreshing={loading} onRefresh={this.loadTasks}/>
          }
        />

        <ColoredFab onPress={this.requireLogin(this.goTo('CreateTask'))}>
          <Icon name="pencil-square-o" size={20} color="#fff"></Icon>
        </ColoredFab>
        <TaskGuide/>
      </View>
    );
  }
}


function fetchDataDeferred(getState, dispatch) {
  // 加载任务活动列表
  const state = getState();
  const lbs = state.lbs;
  dispatch(load({
    loc: [
      lbs.get('longitude'),
      lbs.get('latitude'),
    ]
  }));
}

export default connectData(fetchDataDeferred)(
  connect(
    state => {
      return ({
        // 我的信息
        token: state.me.get('token'),
        meId: state.me.get('meId'),
        long: state.lbs.get('longitude'),
        lati: state.lbs.get('latitude'),
        lbsLoaded: state.lbs.get('loadedLbs'),
        lbsLoading: state.lbs.get('loadingLbs'),
        lbsError: state.lbs.get('errorLbs'),
        // 列表
        tasks: state.lists.data,
        loading: state.lists.loading,
        error: state.lists.error,
        briefTasks: state.task,
      });
    },
    { load, onFavClick, fav, unfav }
  )(Home)
);
