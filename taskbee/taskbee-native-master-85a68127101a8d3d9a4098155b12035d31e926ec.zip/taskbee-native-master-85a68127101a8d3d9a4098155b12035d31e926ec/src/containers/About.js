import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  ScrollView,
  Text,
  Image
} from 'react-native';

import {connect} from 'react-redux';
import config from '../config';

import {Icon, UpdateButton} from '../components';

const styles = StyleSheet.create({
  score: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
  },
  intro: {

    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  introText: {
    fontSize: config.fontXLarge,
    color: config.colorMain,
    marginTop: 6,
  },
  introImage: {

  },
  rules: {
    marginVertical: config.normalPadding,
    borderRadius: config.borderRadius,
    backgroundColor: '#fff',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  mainText: {
    padding: config.normalPadding,
    borderBottomWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  version: {
    textAlign: 'center',
  },
  credit: {
    fontSize: config.fontSmall,
    textAlign: 'center',
    color: config.colorSubtle,
  },
  container: {
    paddingBottom: 2 * config.normalPadding,
  },
});

class About extends Component {
  static propTypes = {
    user: PropTypes.object,
  };

  renderText(texts) {
    return texts.map((text, index) => <View key={index} style={styles.mainText}><Text>{text}</Text></View>);
  }

  render() {
    return (
      <ScrollView style={styles.score} contentContainerStyle={styles.container}>
        <View style={styles.intro}>
          <Icon style={styles.introImage} name="taskbee" size={96} color={config.brandPrimary}/>
        </View>
        <Text style={styles.version}>v{config.appver.join('.')}</Text>
        <View style={styles.rules}>
          {this.renderText([
            '蜂房由同济大学学生创立，目前面向同济大学开放',
            '我们是一个年轻而各有所长的团队，核心成员有5名',
            '小不、May、胡老丝、赵姑娘、尚老板',
            '我们只做有意思、有质量的互联网产品',
            '欢迎大家加入QQ蜂房交流群：478227215，一起灌灌水',
          ])}
        </View>
        <Text style={styles.credit}>地图由给力的OpenStreetMap以及Mapbox提供!</Text>
        {config.isIOS ? null : <UpdateButton/>}
      </ScrollView>
    );
  }
}

export default connect(
  state => ({
    user: state.me.get('data')
  })
)(About)
