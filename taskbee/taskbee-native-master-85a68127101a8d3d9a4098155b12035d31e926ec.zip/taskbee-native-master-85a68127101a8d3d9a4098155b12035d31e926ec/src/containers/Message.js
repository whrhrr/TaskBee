import React, {
  Component,
  View,
  PropTypes,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { mdl } from 'react-native-material-kit';
import {connect} from 'react-redux';
import {checkMessage, leaveMessage, visit} from '../modules/sysMessages';
import {arriveMessage} from '../modules/misc';
import {goTo, requireLogin} from '../utils/navigation';

import {msgSelector} from '../modules/messages';

const {Spinner} = mdl;

import config from '../config';

import {
  NormalButton,
  Text,
} from '../components';

const styles = StyleSheet.create({
  message: {
    flex: 1,
  },
  noContact: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  wrapper: {
    flex: 1,
  },
  title: {
    color: config.colorMain,
    fontSize: config.fontLarge,
    marginBottom: 3,
  },
  tabs: {
    flexDirection: 'row',
  },
  button: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: 48,
    backgroundColor: '#fff',
    borderBottomWidth: config.borderWidth,
    borderBottomColor: config.colorBorder,
    flexDirection: 'row',
  },
  buttonActive: {
    borderBottomWidth: 2,
    borderBottomColor: config.brandGreen,
  },
  loginButton: {
    marginTop: config.normalPadding,
  },
  badge: {

    backgroundColor: config.brandRed,
    marginLeft: 6,
    borderRadius: 8,
    paddingHorizontal: 4,
  },
  unreadText: {
    color: config.colorVerySubtle,
    fontSize: 11,
  },
  addButton: {
    width: 60,
    height: 48,
    backgroundColor: '#fff',
    borderBottomWidth: config.borderWidth,
    borderBottomColor: config.colorBorder,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
  },
  addText: {
    fontSize: 30,
  },
});

import {
  Contact,
  SysMessage,
} from '../components';
import locales from '../locales';

class Message extends Component {
  static propTypes = {
    messages: PropTypes.object.isRequired,
    sysMessages: PropTypes.array.isRequired,
    checkMessage: PropTypes.func.isRequired,
    leaveMessage: PropTypes.func.isRequired,
    arriveMessage: PropTypes.func.isRequired,
    isInSys: PropTypes.bool,
    unreadSys: PropTypes.number.isRequired,
    unreadMsg: PropTypes.number.isRequired,
    navigator: PropTypes.object.isRequired,
    token: PropTypes.string,
  };

  componentDidMount() {
    // this.props.arriveMessage();
  }

  goTo = goTo.bind(this);
  requireLogin = requireLogin.bind(this);

  render() {
    const {token, unreadSys, unreadMsg, messages, isInSys, sysMessages} = this.props;
    if (!token) {
      return <View style={styles.message}>
        <View style={styles.noContact}>
          <Text style={styles.title}>{locales.notLoggedYet}</Text>
          <Text>{locales.messageNeedLogin}</Text>
         <NormalButton style={styles.loginButton} onPress={this.goTo('Join')} text={locales.goLoginAndReg} />

        </View>
      </View>
    }
    let contacts;
    if (isInSys) {
      if (sysMessages.length) {
        contacts = sysMessages.map( (sys, ind) => <SysMessage key={ind} {...sys} goTo={this.goTo} visit={this.props.visit}/>);
      } else {
        contacts = (<View style={styles.noContact}>
            <Text style={styles.title}>{locales.noSysm}</Text>
            <Text></Text>
          </View>);
      }
    } else {
      let keys = Object.keys(messages);
      keys = keys.filter( key => key.length === 24);
      if (keys.length) {
        // 按未读数排列
        contacts = keys.map( key => <Contact key={key} {...messages[key]} goTo={this.goTo}/>)
      } else {
        contacts = (<View style={styles.noContact}>
            <Text style={styles.title}>{locales.noPm}</Text>
            <Text>{locales.chatWithFriends}</Text>
            <Text>{locales.messageSave}</Text>
          </View>);
      }
    }

    return (
      <View style={styles.message}>
        <View style={styles.tabs}>
          <TouchableOpacity style={[styles.button, !isInSys && styles.buttonActive]} onPress={this.props.leaveMessage}>
            <Text>{locales.pm}</Text>
            {unreadMsg ? <View style={styles.badge}><Text style={styles.unreadText}>{unreadMsg}</Text></View> : null}
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, isInSys && styles.buttonActive]} onPress={this.props.checkMessage}>
            <Text>{locales.sysm}</Text>
            {unreadSys ? <View style={styles.badge}><Text style={styles.unreadText}>{unreadSys}</Text></View> : null}
          </TouchableOpacity>
          <TouchableOpacity style={styles.addButton} onPress={this.requireLogin(this.goTo('Friend'))}>
            <Text style={styles.text}>{locales.friends}</Text>
          </TouchableOpacity>
        </View>
        <ScrollView style={styles.wrapper} contentContainerStyle={contacts.length ? null : styles.wrapper}>
          {contacts}
        </ScrollView>

      </View>
    );
  }
}

export default connect(msgSelector, {arriveMessage, checkMessage, leaveMessage, visit})(Message)
