import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
  AsyncStorage,
  Animated,
  Dimensions,
  Image,
  Platform,
} from 'react-native';
import {
  NormalButton,
  Modal,
  Swiper,
  Text,
} from '../components';

const {height, width} = Dimensions.get('window');

import config from '../config';
import LocalizedStrings from 'react-native-localization';
import ScrollableTabView from 'react-native-scrollable-tab-view';

const THISID = __DEV__ ? 'TEST2' : config.userGuideVer;

const styles = StyleSheet.create({
  userGuide: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: config.brandGreen,
  },
  swiper: {
    flex: 1,
  },
  card: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    backgroundColor: 'transparent',
  },
  title: {
    fontSize: config.fontXLarge,
    fontWeight: 'bold',
    marginBottom: config.normalPadding,
    color: config.brandPrimary,
    opacity: .8,
  },
  normal: {
    color: '#666',
    fontSize: config.fontBig,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  fullBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height,
    width,
  },
  bottom: {
    backgroundColor: '#fff',
    paddingBottom: config.normalPadding * 4,
  },
  lastImage: {
    height: height / 3,
    width:  462 / (577 / height * 3),
  },
  withPadding: {
    marginBottom: 9,
    marginTop: config.normalPadding * 4,
  },
  permission: {
    marginTop: 22,
    fontSize: config.fontSmall,
    color: config.colorSubtle,
  }
});

const strings = new LocalizedStrings({
  en: {
    sec1Title: 'FF + Events = Fun',
    sec2Title: 'FF + Pollens = Free',
    sec3Title: 'FF + Task = Friend',
    sec4Title: 'FF + U is Brilliant! ',
    sec11: 'Get to know all school events via FF!',
    sec12: 'Enjoy local events like a boss',
    // 花粉
    sec21: 'Share your moments',
    sec22: 'Get connected with local students',
    sec23: 'Chat with interesting people around you',
    sec24: 'Anyone can be popular!',
    // 任务
    sec31: 'Post a task',
    sec32: 'And get help from local students',

    sec41: '',


    join: 'Join FF!',
    needs: 'FF requires notification and locations to work',
  },
  zh: {
    sec1Title: '蜂房+活动 = Fun',
    sec2Title: '蜂房+花粉 = Free',
    sec3Title: '蜂房+任务 = Friend',
    sec4Title: '蜂房+你更精彩',
    sec11: '校园活动一览无余',
    sec12: '查看地图即可知道身边的活动信息',
    sec21: '身边同学的朋友圈',
    sec22: '基于地理位置的独特玩法',
    sec23: '八卦吐槽，上课群聊',
    sec24: '成为校园大V之利器',
    sec31: '发布你的技能需求或陪伴需求到蜂房任务',
    sec32: '技能求教，约自习、约运动、约陪伴',
    sec41: 'Fire Your Life!',
    join: '进入蜂房之旅',
    needs: '蜂房需要推送和地理位置来工作哦～',
  },
});

export default class UserGuide extends Component {
  static propTypes = {
    children: PropTypes.any,
    index: PropTypes.number,
  };

  state = {
    show: false,
    y: new Animated.Value(0),
  };

  componentDidMount() {
    AsyncStorage.getItem('guide').then(data => {
      if (data !== THISID) {
        this.setState({show: true}); /* eslint react/no-did-mount-set-state: 0 */
      }
    });
  };

  onRequestClose = () => {
     Animated.spring(       // Uses easing functions
        this.state.y, // The value to drive
        {
          toValue: 1,
          velocity: .8,
          tension: -10,
          friction: 3,
        },
      ).start(() => {
      AsyncStorage.setItem('guide', THISID);
      this.setState({show: false});
    });

  };

  render() {
    const {show, y} = this.state;
    if (!show) return <View/>;
    const translateY = y.interpolate({inputRange: [0, 1], outputRange: [0, -height]});
    const opacity = y.interpolate({inputRange: [0, 1], outputRange: [1, 0]});

    const animatedCardStyles = {transform: [{translateY}], opacity};

    return (
      <Animated.View style={[styles.userGuide, animatedCardStyles]}>
        <Swiper

        >
          <View style={styles.card}>
            <Image resizeMode={Image.cover} source={require('../assets/guide2.png')} style={styles.fullBackground}/>
            <Text style={[styles.title, {color: config.brandBlue}]}>{strings.sec3Title}</Text>
            <Text style={styles.normal}>{strings.sec31}</Text>
            <Text style={styles.normal}>{strings.sec32}</Text>
          </View>

          <View style={styles.card}>
            <Image resizeMode={Image.cover} source={require('../assets/guide1.png')} style={styles.fullBackground}/>
            <Text style={[styles.title, {color: config.brandRed}]}>{strings.sec2Title}</Text>
            <Text style={styles.normal}>{strings.sec21}</Text>
            <Text style={styles.normal}>{strings.sec22}</Text>
            <Text style={styles.normal}>{strings.sec23}</Text>
            <Text style={styles.normal}>{strings.sec24}</Text>
          </View>
          {
            /*
              <View style={styles.card}>
                <Image resizeMode={Image.cover} source={require('../assets/guide0.png')} style={styles.fullBackground}/>
                <Text style={styles.title}>{strings.sec1Title}</Text>
                <Text style={styles.normal}>{strings.sec11}</Text>
                <Text style={styles.normal}>{strings.sec12}</Text>
              </View>
             */
          }

          <View style={[styles.card, styles.bottom]}>
            <Image resizeMode={Image.contain} source={require('../assets/guide3.png')} style={styles.lastImage}/>
            <Text style={[styles.title, styles.withPadding]}>{strings.sec4Title}</Text>
            <Text style={[styles.title]}>{strings.sec41}</Text>
            <NormalButton text={strings.join} onPress={this.onRequestClose}/>
            <Text style={styles.permission}>{strings.needs}</Text>
          </View>
        </Swiper>
      </Animated.View>
    );
  }

}
