'use strict';

import React, {
  PropTypes,
  Component,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  View,
  Text,
  Image,
  Platform,
} from 'react-native';
import {bindActionCreators} from 'redux';
import { connect } from 'react-redux';
import config from '../config';

import {NormalButton, Icon, } from '../components';
import Flower from '../components/Flower';
import {goTo} from '../utils/navigation';

import locales from '../locales';

// import {getRoute} from '../routes';

const styles = StyleSheet.create({
  join: {
    flex: 1,
  },
  container: {
    justifyContent: 'center',
    flex: 1,
  },
  title: {
    color: config.brandPrimary,
    fontSize: 36,
    textAlign: 'center',
    alignSelf: 'stretch',
  },
  sub: {
    fontSize: 20,
    textAlign: 'center',
    alignSelf: 'stretch',
    color: config.colorStand,
    marginTop: (Platform.OS === 'ios') ? 12 : 0,
  },
  logo: {
    alignSelf: 'center',
  },
  controls: {
    marginTop: config.normalPadding * 5,
    justifyContent: 'center',
  },
  button: {
    flex: 1,
    marginVertical: 6,
    alignSelf: 'center',
    paddingHorizontal: 72,

  },
  back: {
    marginTop: (Platform.OS === 'ios') ? 24 : 0,
    padding: config.normalPadding,
  },
  background: {
    position: 'absolute',
    left: 0,
    top: 0,
    right: 0,
    bottom: 0,
  },
  girl: {
    marginTop: 12,
    color: 'pink',
  },
  girlSub: {
    textAlign: 'center',
    color: config.colorSubtle,
    marginTop: 9,
    fontSize: config.fontSmall,
  }
});

export default class Join extends Component {
  static propTypes = {
  };

  constructor(props) {
    super(props);
  }

  goTo = goTo.bind(this);

  render() {
    const {navigator} = this.props;
    return (
      <View style={styles.join}>

        <View style={styles.background} renderToHardwareTextureAndroid>
          <Flower/>
          <Flower/>
          <Flower/>
          <Flower/>
          <Flower/>
          <Flower/>
        </View>

        <TouchableOpacity style={styles.back} onPress={navigator.pop}>
          <Icon name="arrow-left" size={22}   color={config.colorLessSubtle}/>
        </TouchableOpacity>
        <View style={styles.container}>
          <Icon style={styles.logo} name="taskbee" size={96} color={config.brandPrimary}/>
          <Text style={styles.title}>{locales.taskbee}</Text>
          {/* <Text style={styles.sub}>享受身边的精彩</Text> */}
          <Text style={styles.sub}>{locales.startTitle1}</Text>
          <Text style={styles.girlSub}>{locales.startTitle2}</Text>
          <View style={styles.controls}>
            <NormalButton type={1} style={styles.button} text={locales.login} onPress={this.goTo('Login')}/>
            <NormalButton style={styles.button} text={locales.register} onPress={this.goTo('Register')}/>
          </View>
        </View>
      </View>
    );
  }
}
