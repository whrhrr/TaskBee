import React, {
  Component,
  PropTypes,
  ScrollView,
  View,
  StyleSheet,
} from 'react-native';

import {
  LoadingIndicator,
  NormalButton,
  WithdrawItem,
  Text,
} from '../components';

import {connect} from 'react-redux';
import {loadWithdrawList} from '../modules/order';
import connectData from '../libs/connectData';
import config from '../config';

const styles = StyleSheet.create({
  orderList: {
    marginTop: config.bannerHeight,
  },
  noOther: {
    flex: 1,
    alignItems:'center',
    justifyContent: 'center',
  },
  center: {
  }
});

class WithdrawList extends Component {
  static propTypes = {
    loadWithdrawList: PropTypes.func.isRequired,
    orderList: PropTypes.array.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
  };

  render() {
    const {orderList, loading, error} = this.props;
    let content;
    let centerStyle = [styles.center];
    if (!orderList || !orderList.length) {
      centerStyle.push(styles.noOther);
    }
    if (loading) {
      content = <View style={centerStyle}><LoadingIndicator /></View>;
    } else if (error) {
      content = (<View style={centerStyle}>
        <Text>{error.message || '网络错误，请稍候重试'}</Text>
        <NormalButton onPress={this.props.loadOrderList} text="重试"></NormalButton>
      </View>);
    } else if (!orderList.length) {
      content = (<View style={centerStyle}>
        <Text style={styles.subtle}>还没有提现记录</Text>
      </View>);
    } else {
      content = (<View style={[centerStyle, styles.action]}>
        {orderList.map(orderItem => {
          return <WithdrawItem key={orderItem._id} {...orderItem}/>;
        })}
      </View>);
    }
    return (
      <ScrollView style={styles.orderList}>
        {content}
      </ScrollView>
    );
  }
}

function fetchDataDeferred(getState, dispatch) {
  return dispatch(loadWithdrawList());
}

export default connectData(fetchDataDeferred)(
  connect(state => {
    return {
      orderList: state.order.withdraws,
      loading: state.order.loadWithdrawList,
      error: state.order.loadWithdrawListError,
    };
  }, {loadWithdrawList})(
    WithdrawList
  )
)


