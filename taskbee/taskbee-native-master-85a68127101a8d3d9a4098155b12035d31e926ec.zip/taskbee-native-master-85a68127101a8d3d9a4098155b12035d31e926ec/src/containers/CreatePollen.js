import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  InteractionManager,
  Image,
  Dimensions,
  Platform,
  ScrollView,
} from 'react-native';
import {reduxForm} from 'redux-form';
import {connect} from 'react-redux';
// import connectData from 'helpers/connectData';
import {
  ImagePicker,
  LongTextInput,
  NormalButton,
  Spinner,
  FadeInText,
  Icon,

} from '../components'; // TagEditor


import toast from '../libs/toast';
import {createPost as create, newPublishPost as newPublish} from '../modules/publish'; // isTagLoaded, getTags
import config from '../config';
import locales from '../locales';
import {ImagePickerManager} from 'NativeModules';
const {height, width} = Dimensions.get('window');

const imageSize = (width - config.normalPadding * 3) / 3;
const styles = StyleSheet.create({
  create: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollview: {
    flex: 1,
  },
  back: {
    padding: config.normalPadding,
    marginTop: (Platform.OS === 'ios') ? 24 : 0,
  },
  errorMsg: config.styleExtraError,
  cta: {
    backgroundColor: '#fafafa',
    borderTopWidth: config.borderWidth,
    borderColor: config.colorBorder,
    paddingRight: config.normalPadding,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 60,
  },
  count: {
    marginRight: 12,
    color: config.colorSubtle,
  },
  button: {
    alignSelf: 'flex-end',
    marginVertical: 9,
  },
  actions: {
    flex: 1,
    flexDirection: 'row',
  },
  action: {
    padding: config.normalPadding,
  },
  images: {
    flexDirection: 'row',
    padding: config.normalPadding,
  },
  image: {
    width: imageSize,
    height: imageSize,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
    backgroundColor: config.colorVerySubtle,
    marginRight: config.normalPadding / 3,
  },
  fullText: {
    marginLeft: config.normalPadding,
    color: config.colorSubtle,
  }
});

const simpleText = config.isCN ? [
  '远亲不如近邻，和身边人分享些什么吧',
  '花粉：身边人的朋友圈～',
  '小伙伴们，有什么想吐槽的？',
  '用吐槽宣战平淡生活，用态度鄙视平凡世界。表达真实自我，尽在蜂房花粉。',
  '在想些什么？',
  '听课无聊了？你一定不是一个人嗡～',
  '发生了什么？',
  '21号是爱你日，让花粉带走你的思念～【from想红的21号',
  '功夫都在课下！寻找课上聊友！【from资深学渣协会',
  '有趣即正义，有什么好玩儿的要和大家分享吗嗡～',
  '当你孤单你会想起谁🎵 就让花粉带走你的思念～',
  '想啥说啥，就是这么自信',
  '今天有什么好想法分享给大家?',
  '当你觉得没意思的时候，应该坐下来，静静地思考人生、哲学和神学，体会世界的苦难。然后就会觉得更没意思了嗡～人生苦短，及时吐槽',
]
: [
  'What\'s happening...',
  'What are you thinking...',
];

function genText() {
  const len = simpleText.length;
  return simpleText[Math.floor(Math.random() * len)];
}

class CreatePollen extends Component {
  static propTypes = {
    creating: PropTypes.bool,
    registerError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    initializeForm: PropTypes.func.isRequired,
    create: PropTypes.func.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    newPublish: PropTypes.func.isRequired,
    token: PropTypes.string,
    createError: PropTypes.any,
    success: PropTypes.any,
    user: PropTypes.object.isRequired,
    long: PropTypes.number,
    lati: PropTypes.number,
    signed: PropTypes.bool,
  };

  constructor(props) {
    super(props);
    this.text = genText();
    if (config.isIOS) {
      this.state = {
        keyboardHeight: 0,
      }
    }
  }

  componentDidMount() {
    this.props.initializeForm({
      images: [],
    });
  }

  componentWillReceiveProps(nextProps) {
    // 评论成功后拉到页面底部
    if (!this.props.success && nextProps.success) {
      this.props.navigator.pop();
      if (nextProps.success.length) {
        toast(locales.lostImages);
      } else if (nextProps.signed) {
        toast(locales.pollenSign);
      } else {
        toast(locales.publishSucess);
      }
      InteractionManager.runAfterInteractions(() => {
        this.props.newPublish();
      });
    }
  }

  onSubmitClick = (data) => {
    const {creating} = this.props;
    if (!creating) {
      this.props.handleSubmit(this.prepareToCreate)(data);
    }
  };

  onGoToTaskClick = () => {
    // 进入/task
    // this.props.replaceState(null, '/');
    this.props.newPublish();
    // 初始化
    // this.onContinueClick();
  };

  onSetImage = (data) => {
    const {images} = this.props.fields;
    // !!!mutate 不知道是否可行
    images.value.push(data);
    images.onBlur(images.value);
  };


  prepareToCreate = (data) => {
    data.pos = [this.props.long, this.props.lati];
    data.token = this.props.token;
    data.images = data.images.map( item => item.uri);
    this.props.create(data);
  };

  onCameraPress = () => {
    ImagePickerManager.launchCamera(config.imageSettings, (response)  => {
      console.log('Response = ', response);
      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePickerManager Error: ', response.error);
      } else {
        this.onSetImage(response);
      }
    });
  };

  onImagePress = () => {
    ImagePickerManager.launchImageLibrary(config.imageSettings, (response)  => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePickerManager Error: ', response.error);
      } else {
        this.onSetImage(response);
      }
    });
  };

  onKeyboardWillShow = (e) => {
    if(config.isIOS) this.setState({keyboardHeight: e.endCoordinates ? e.endCoordinates.height : e.end.height});

  };

  onKeyboardWillHide = () => {
    if(config.isIOS) this.setState({keyboardHeight: 0});
  };

  render() {
    const {navigator, creating, success, createError, fields: {description, images}} = this.props;

    return (
      <View style={[styles.create, config.isIOS && this.state.keyboardHeight ? {paddingBottom: this.state.keyboardHeight} : null]}>
        <ScrollView
          style={styles.scrollview}
          contentContainerStyle={styles.scrollview}
          onKeyboardWillShow={this.onKeyboardWillShow}
          onKeyboardWillHide={this.onKeyboardWillHide}
          scrollEnabled={false}
        >
          <TouchableOpacity style={styles.back} onPress={navigator.pop}>
            <Icon name="arrow-left" size={22} color={config.colorNormal}/>
          </TouchableOpacity>
          <LongTextInput
            autoFocus
            maxLength={280}
            inputStyle={{fontSize: config.fontLarge}}
            elementStyle={{marginVertical: 0, borderWidth: 0, flex: 1,}}
            placeholder={this.text} {...description}
            serverError={createError && createError.message}/>

          <View style={styles.images}>
            {
              images.value && images.value.map((data, index) => {
                return <Image key={index} style={styles.image} resizeMode={Image.resizeMode.contain} source={{uri: data.uri, isStatic: true}}/>
              })
            }
          </View>


        </ScrollView>
         <View style={styles.cta}>
          {
            images.value && images.value.length > 2 ?
            <View style={styles.actions}>
              <Text style={styles.fullText}>{locales.max3pics}</Text>
            </View>
            :
            <View style={styles.actions}>
              <TouchableOpacity style={styles.action} onPress={this.onCameraPress}>
                <Icon name="camera" size={24} color={config.colorLessSubtle}/>
              </TouchableOpacity>
              <TouchableOpacity style={styles.action} onPress={this.onImagePress}>
                <Icon name="image" size={24} color={config.colorLessSubtle}/>
              </TouchableOpacity>
            </View>
          }
          <Text style={styles.count}>{280 - (description.value ? description.value.length : 0)}</Text>
          <NormalButton style={styles.button} onPress={this.onSubmitClick} text={locales.publishButton} working={creating}/>
        </View>
      </View>
    );
  }
}

export default reduxForm({
  form: 'create',
  fields: ['description', 'images'],
})(
  connect(
    state => ({
      user: state.me.get('data'),
      token: state.me.get('token'),
      long: state.lbs.get('longitude'),
      lati: state.lbs.get('latitude'),
      createError: state.publish.errorPost,
      success: state.publish.successPost,
      creating: state.publish.creatingPost,
      signed: state.publish.signed,
    }), {create, newPublish})(
      CreatePollen
    )
)

