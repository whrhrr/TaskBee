import React, {
  PropTypes,
  Component,
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  PanResponder,
  NativeModules,
  Platform,
} from 'react-native';

import Mapbox from 'react-native-mapbox-gl';
// import reactMixin from 'react-mixin';
import {load} from '../modules/pollen';

import {goTo, requireLogin} from '../utils/navigation';
import {
  Icon
} from '../components';

import config from '../config';
import {connect} from 'react-redux';
import {locsOnMapSelector} from '../modules/lists';
import connectData from '../libs/connectData';

const {MapboxGLManager} = NativeModules;

const TOKEN = 'pk.eyJ1IjoieGlhb2J1IiwiYSI6ImNpamNjcTVhajAwMXV2MW0wbDIwNmVoM2wifQ.K-QHYmExydp-t7z8YCqfKw';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  myPos: {
    position: 'absolute',
    right: 32,
    bottom: 48,
    backgroundColor: '#fff',
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: config.borderRadius,
  },
});

class MyMapbox extends Component {

  componentWillMount() {

  }

  componentDidMount() {
  }

  goTo = goTo.bind(this);

  componentWillReceiveProps(nextProps) {
    if (this.props.locations.length !== nextProps.locations.length && nextProps.locations.length > 0 ) this.updateAnotations(nextProps);
  }

  updateAnotations = (props) => {
    MapboxGLManager.addAnnotations(React.findNodeHandle(this.refs.mapRef), props.locations);
  };

  onPositionPress = () => {
    MapboxGLManager.setCenterCoordinateAnimated(React.findNodeHandle(this.refs.mapRef), this.props.latitude, this.props.longitude);
  };

  onOpenAnnotation = (annotation) => {
    if (config.isIOS) {

    } else if (annotation.src.subtitle) this.goTo('TaskDetail', {taskId: annotation.src.subtitle})();
  };

  render() {
    const {longitude, latitude} = this.props;
    return (<View style={styles.container}>
      <Mapbox
        accessToken={TOKEN}
        annotations={this.props.locations}
        centerCoordinate={{
          latitude,
          longitude
        }}
        ref="mapRef"
        // onRegionChange={this.onRegionChange}
        rotateEnabled
        scrollEnabled
        style={styles.container}
        showsUserLocation
        styleURL={'mapbox://styles/xiaobu/cijcd4giu00dgbkku5ymwdjy8'}
        userTrackingMode={MapboxGLManager.userTrackingMode.None}
        zoomEnabled
        attributionButtonIsHidden
        logoIsHidden
        zoomLevel={14}
        onOpenAnnotation={this.onOpenAnnotation}
      />
      <TouchableOpacity style={styles.myPos} onPress={this.onPositionPress}>
        <Icon name="man" size={20}/>
      </TouchableOpacity>
    </View>);
  }
}
// reactMixin(MyMapbox.prototype, Mapbox.Mixin);

function fetchDataDeferred(getState, dispatch) {
  // 加载任务活动列表
  const state = getState();
  dispatch(load(state.lbs.get('longitude'), state.lbs.get('latitude')));
}

export default connectData(fetchDataDeferred)(
  connect(locsOnMapSelector, {})(MyMapbox)
);
