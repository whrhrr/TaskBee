import React, {
  StyleSheet,
  Component,
  PropTypes,
  View,
  Text,
} from 'react-native';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from '../utils/userValidation';

import {changePassword} from '../modules/me';

import {
  NormalButton,
  TextInput,
  SubtleButtons,
} from '../components';
import config from '../config';
import {serverError} from '../utils/dataHelpers';
import {getRoute} from '../routes';

const styles = StyleSheet.create({
  login: {
    marginTop: config.bannerHeight,
    padding: config.normalPadding,
  },
  cta: {
    marginTop: 24,
  },
  extraError: config.styleExtraError,
});

class ChangePassword extends Component {
  static propTypes = {
    changingPassword: PropTypes.bool,
    changePasswordError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    changePassword: PropTypes.func.isRequired,
    verifyToken: PropTypes.string,
  };

  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去
    if (this.props.changingPassword && !nextProps.changingPassword && !nextProps.changePasswordError) {
      this.props.navigator.pop();
      // if (this.props.token) this.props.history.goBack();
      // else this.props.history.replaceState(null, '/login');
    }
  }

  onSubmit = (event) => {
    const {changingPassword, fields, valid, verifyToken} = this.props;
    if (!changingPassword && valid) {
      this.props.changePassword({
        password: fields.password.value,
        verifyToken
      });
    }
  };

  render() {
   const {
      verifyToken,
      changingPassword,
      fields: {password},
      invalid,
      changePasswordError,
    } = this.props;

    const errorFunc = serverError(changePasswordError);

    return (
      <View style={styles.login}>
        <TextInput
          onSubmitEditing={this.onSubmit}
          autoFocus
          isPassword label="新密码"
          placeholder="请输入新密码(8~32位)"
          serverError={errorFunc('password')} {...password} />
        <View style={styles.cta}>
          <NormalButton onPress={this.onSubmit} text="更换密码" working={changingPassword} disabled={invalid}/>
        </View>
        {changePasswordError && !changePasswordError.errorCode && <Text style={styles.extraError}>{changePasswordError.message || '迷的错误'}</Text>}

      </View>
    );
  }
}

export default  reduxForm({
  form: 'user',
  fields: ['password'],
  validate: userValidation
})(
  connect(
  state => ({
    codeError: state.verify.error,
    verifyToken: state.verify.verifyToken,
    changingPassword: state.me.get('changingPassword'),
    changePasswordError: state.me.get('changePasswordError'),
  }),
  {changePassword})(
    ChangePassword
  )
)

