import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
} from 'react-native';

import {connect} from 'react-redux';
import config from '../config';
import {
  Icon,
  NormalButton,
  Text,
} from '../components';

import {createOrder} from '../modules/order';
import {orderArray} from '../utils/dataMap';
import {getRoute} from '../routes';
import {goTo} from '../utils/navigation';

const {width} = Dimensions.get('window');

const styles = StyleSheet.create({
  score: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
  },
  intro: {

    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  introText: {
    fontSize: config.fontXLarge,
    color: config.colorMain,
    marginTop: 6,
  },
  introImage: {

  },
  icon: {
    color: config.colorMain,
    marginVertical: config.normalPadding,
  },
  rules: {
    margin: config.normalPadding,
    borderRadius: config.borderRadius,
    backgroundColor: '#fff',
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  mainText: {
    padding: config.normalPadding,
    borderBottomWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  error: config.styleExtraError,
  buy: {
    backgroundColor: '#fff',
    alignItems: 'center',
    paddingVertical: config.normalPadding,
    borderWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  buttons: {
    alignSelf: 'stretch',
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
  },
  mainTitle: {
    color: config.colorMain,
    fontSize: config.fontBig,
  },
  offer: {
    height: 48,
    marginLeft: config.normalPadding,
    marginTop: config.normalPadding,
    borderRadius: config.borderRadius,
    backgroundColor: config.colorVerySubtle,
    width: (width - config.normalPadding * 4) / 3,
    alignItems: 'center',
    justifyContent: 'center'
  },
  active: {
    backgroundColor: config.brandGreen,
  },
  submit: {
    marginTop: config.normalPadding,
  },
  createText: {
    color: '#fff',
  },
  withdrawButton: {
    marginTop: 3,
  },
});

class Score extends Component {
  static propTypes = {
    user: PropTypes.object,
  };

  constructor(props) {
    super(props);
    this.state = {
      select: 1,
    };
  }


  componentWillReceiveProps(nextProps) {
    // 成功之后进入到订单详情页面
    if (this.props.creating && !nextProps.creating && !nextProps.createError) {
      this.props.navigator.push(
        getRoute('OrderDetail', {orderId: nextProps.nextOrder})
      );
    }
  }

  goTo = goTo.bind(this);

  onOrderClick = (ind) => {
    return () => {
      this.setState({select: ind});
    };
  };

  onCreateOrderClick = () => {
    const {creating, token} = this.props;
    if (!creating) {
      this.props.createOrder({
        orderId: this.state.select,
        token,
      });
    }
  };

  renderText(texts) {
    return texts.map((text, index) => <View key={index} style={styles.mainText}><Text>{text}</Text></View>);
  }

  render() {
    const {select} = this.state;
    const {creating, createError, user} = this.props;

    return (
      <ScrollView style={styles.score}>
        <View style={styles.intro}>
          <Icon style={styles.icon} name="vallet" size={22}/>
          <Text style={styles.introText}>¥{this.props.user && this.props.user.get('money')}</Text>
          <TouchableOpacity onPress={this.goTo('Withdraw')}>
            <Text style={styles.withdrawButton}>提现</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.rules}>
          {this.renderText(
            config.isCN ?
            [
              '钱包是您使用蜂房过程中积攒的收入',
              '钱包中的钱也能给同学发放报酬',
            ]
            :
            [
              'Wallet stores the money you earned through Taskbee',
              'You can reward others with your balance',
            ]
          )}
        </View>

        <View style={styles.buy}>
          <Text style={styles.mainTitle}>给钱包充{orderArray[select].price}元</Text>
          <View style={styles.buttons}>
            {orderArray.map((order, ind) => <TouchableOpacity
             style={[styles.offer, (ind === select ? styles.active : null)]}
             key={order.price} onPress={this.onOrderClick(ind)}>
                <Text>{order.price}元</Text>
              </TouchableOpacity>
            )}
          </View>
          <NormalButton style={styles.submit} working={creating} onPress={this.onCreateOrderClick}>
            <Text style={styles.createText}><Icon name="cn-alibabai-alipay"/> 创建支付宝订单</Text>
          </NormalButton>
          {createError && <Text style={styles.error}>{createError.message || locales.strangeError}</Text>}
        </View>
      </ScrollView>
    );
  }
}

export default connect(
  state => ({
    user: state.me.get('data'),
    token: state.me.get('token'),
    creating: state.order.creating,
    createError: state.order.createError,
    nextOrder: state.order.nextOrder,
  }), {createOrder}
)(Score)
