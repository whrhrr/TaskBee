import React, {
  Component,
  View,
  PropTypes,
  StyleSheet,
  Image,
  Dimensions,
  PixelRatio,
} from 'react-native';
const {height, width} = Dimensions.get('window');
const windowRatio = height / width;
import { mdl } from 'react-native-material-kit';

import {
  Swiper
} from '../components';

import config from '../config';

const styles = StyleSheet.create({
  swipper: {
    flex: 1,
    backgroundColor: '#000',
  },
  image: {
    backgroundColor: '#fff',
  },
  imageContainer: {
    flex: 1,
    width,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default class ImageView extends Component {
  static propTypes = {
    images: PropTypes.array.isRequired,
  };

  constructor(props) {
    super(props);

  }

  render() {
    const {images, initial} = this.props;
    return (
      <Swiper style={styles.swipper} initialPage={initial}>
        {
          images.map((img, index) => {
            const ratio = img.height / img.width;
            if (ratio < windowRatio) {
              // 横图
              const betterWidth = width;
              const roundWidth = PixelRatio.getPixelSizeForLayoutSize(betterWidth);
              const betterHeight =ratio * betterWidth;
              return (<View key={index} style={styles.imageContainer}>
                <Image style={[styles.image, {width: betterWidth, height: betterHeight}]}
                  source={{uri: config.imagePath + img.key + `?imageView2/2/w/${roundWidth}`}}/>
              </View>);
            } else {
              // 树图
              const betterHeight = height;
              const roundHeight = PixelRatio.getPixelSizeForLayoutSize(betterHeight);
              const betterWidth = betterHeight / ratio;
              return (<View key={index} style={styles.imageContainer}>
                <Image style={[styles.image, {width: betterWidth, height: betterHeight}]} source={{uri: config.imagePath + img.key + `?imageView2/2/h/${roundHeight}`}}/>
              </View>);
            }

          })
        }
      </Swiper>
    );
  }
}
