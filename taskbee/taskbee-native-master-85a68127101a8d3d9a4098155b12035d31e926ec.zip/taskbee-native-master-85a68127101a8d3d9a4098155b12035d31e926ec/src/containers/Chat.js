import React, {
  Component,
  View,
  PropTypes,
  StyleSheet,
  ListView,
  TouchableOpacity,
  TextInput,
  Platform,
  InteractionManager,
  Dimensions,
} from 'react-native';
import { mdl } from 'react-native-material-kit';
import {
  Avatar,
  ImageViewer,
  Gender,
  LoadingIndicator,
  NormalButton,
  VoteItem,
  Rating,
  Icon,
  Message,
  FadeInText,
  Text,
} from '../components';

import connectData from '../libs/connectData';
import {connect} from 'react-redux';
import {send, read, leave} from '../modules/messages';
import {getOneUser} from '../modules/user';
import moment from 'moment';


const {Spinner} = mdl;
import config from '../config';

const styles = StyleSheet.create({
  chat: {
    marginTop: config.bannerHeight,
    padding: config.normalPadding,
    flex: 1,
  },
  size: {
    width: 40,
    height: 40,
  },
  scrollview: {
    paddingBottom: config.normalPadding,
  },
  container: {
    flex: 1,
  },
  textInput: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    backgroundColor:'#fff',
    height: 60,
    borderTopWidth: config.borderWidth,
    borderTopColor: config.colorBorder,
  },
  input: {
    flex: 1,
    paddingHorizontal: config.normalPadding,

  },
  actionButton: {
    width: 48,
    alignItems: 'center',
  },
  date: {
    alignSelf: 'center',
    marginVertical: 6,
    fontSize: config.fontSmall,
  },
  disconnectText: {
    alignSelf: 'center',
  },
  empty: {
    alignSelf: 'center',
    backgroundColor: config.colorVerySubtle,
    height: 24,
    borderRadius: 12,
    paddingHorizontal: 8,
  }
});

class Chat extends Component {
  static propTypes = {
    send: PropTypes.func.isRequired,
    leave: PropTypes.func.isRequired,
    messages: PropTypes.array,
  };

  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (item1, item2) => item1.length !== item2.length });
    this.state = {
      dataSource: ds.cloneWithRows(props.messages),
      value: '',
      keyboardHeight: 0,
    };
    this.keyboardSettings = config.isIOS ? {
      onKeyboardWillShow: this.onKeyboardWillShow,
      onKeyboardWillHide: this.onKeyboardWillHide,
    } : {
      onKeyboardDidShow: this.onKeyboardWillShow,
      onKeyboardDidHide: this.onKeyboardWillHide,
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.messages.length !== nextProps.messages.length) {
      setTimeout(() => {
        this.scrollToBottom();
      }, 200);

      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(nextProps.messages),
      });
    }

    if (this.props.chatSubmitting && !nextProps.chatSubmitting && !nextProps.error) {
      this.setState({value: ''});
    }
  }

  componentWillUnmount() {
    this.props.leave(this.props.userId);
  }

  scrollToBottom = () => {
    if (this.listHeight && this.footerY && this.footerY > this.listHeight) {
      const scrollDistance = this.footerY - this.listHeight + config.normalPadding;
      this.refs.listView.scrollTo({y: scrollDistance});
    }
  };

  onInputChange = (text) => {
    this.setState({value: text});
  };

  onSendClick = () => {
    if (!this.props.chatSubmitting && this.props.userId) {
      this.props.send({
        to: this.props.userId,
        from: this.props.meId,
        message: this.state.value,
      });
    }
  };

  onFooterLayout = (e) => {
    this.footerY = e.nativeEvent.layout.y;
  };


  onKeyboardWillShow = (e) => {
    if(config.isIOS) this.setState({keyboardHeight: e.endCoordinates ? e.endCoordinates.height : e.end.height});
  };

  onKeyboardWillHide = (e) => {
    if(config.isIOS) this.setState({keyboardHeight: 0});
  };

  renderDate = (message, id) => {
    if (id === '0' ) return <Text style={styles.date}>{moment(message.createdAt).calendar()}</Text>
    else {
      const createdAt = message.createdAt;
      const lastAt = this.props.messages[parseInt(id) - 1].createdAt;
      if (createdAt - lastAt > 1000 * 60 * 1) {
        // 超过1分钟
        return <Text style={styles.date}>{moment(message.createdAt).calendar()}</Text>
      }
    }
  };
  renderRow = (message, secId, id) => {
    const {meId, me, user} = this.props;
    const isMe = message.from === meId;
    return (
      <View>
         {this.renderDate(message, id)}
         <Message
           key={message.message + message.createdAt}
           text={message.message}
           position={isMe}
           user={isMe ? me : user}
         />
      </View>
      );
  };

  renderEmpty = () => {
    if (!this.props.messages.length) {
      return (<View style={styles.empty} onLayout={this.onFooterLayout}>
          <Text>和对方聊天吧～消息最多存储50条～</Text>
        </View>);
    }
    return <View onLayout={this.onFooterLayout}/>
  };

  renderFooter = () => {
    const {chatSubmitting, error, socketConnected} = this.props;
    if (!socketConnected) {
      return ( <View style={styles.textInput}>
          <Text style={styles.disconnectText}>聊天服务未连接</Text>
        </View>
      );
    }
    return ( <View style={styles.textInput}>
        <TextInput autoComplete="off" autoFocus
          value={this.state.value}
          placeholder="输入消息"
          style={styles.input}
          onChangeText={this.onInputChange}
          onSubmitEditing={this.onSendClick}
          blurOnSubmit={false}
          autoCorrect={false}
        />
        <TouchableOpacity style={styles.actionButton} onPress={this.onSendClick}>
         {chatSubmitting ? <mdl.Spinner/>
         : <Icon name="paper-plane" size={18} color={config.colorNormal}/>}
        </TouchableOpacity>
        {error && <FadeInText text={error.message} right={40} />}
      </View>);
  };

  render() {
    return (
      <View style={[styles.container, config.isIOS && this.state.keyboardHeight ? {paddingBottom: this.state.keyboardHeight} : null]}>
        <ListView style={styles.chat}
          onLayout={(e)=>{
            this.listHeight = e.nativeEvent.layout.height;
            requestAnimationFrame(() => this.scrollToBottom());
          }}
          // keyboardDismissMode={config.isIOS ? 'interactive' : 'on-drag'}
          ref="listView"
          dataSource={this.state.dataSource}
          renderRow={this.renderRow}
          initialListSize={this.props.messages.length}
          contentContainerStyle={styles.scrollview}
          renderFooter={this.renderEmpty}
          {...this.keyboardSettings}
        />
        {this.renderFooter()}
      </View>
    );
  }
}


function fetchDataDeferred(getState, dispatch, params) {
  const {userId} = params;
  const user = getState().user.get('userId');
  dispatch(read(userId));
  if (!user) return dispatch(getOneUser(userId));
}
export default connectData(fetchDataDeferred)(
  connect(
    (state, props) => {
      const {userId} = props;
      return {
        user: state.user.get(userId),
        messages: state.messages[userId] ? state.messages[userId].messages : [],
        me: state.me.get('data'),
        meId: state.me.get('meId'),
        token: state.me.get('token'),
        chatSubmitting: state.messages.submitting,
        error: state.messages.error,
        socketConnected: state.misc.socketConnected,
        userId
      };
    },
    {send, leave}
  )(
    Chat
  )
)
