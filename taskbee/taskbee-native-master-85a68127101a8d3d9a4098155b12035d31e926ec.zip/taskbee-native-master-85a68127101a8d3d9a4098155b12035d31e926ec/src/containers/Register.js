import React, {
  StyleSheet,
  Component,
  PropTypes,
  View,
  Text,
  TouchableOpacity,
  Linking,
} from 'react-native';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from '../utils/registerValidation';

import {register} from '../modules/me';

import {
  NormalButton,
  TextInput,
  SubtleButtons,
  SelectInput,
} from '../components';
import config from '../config';
import {serverError} from '../utils/dataHelpers';
import {getRoute} from '../routes';

import locales from '../locales';

const styles = StyleSheet.create({
  login: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
  },
  cta: {
    marginTop: 24,
    marginHorizontal: config.normalPadding,
  },
  extraError: config.styleExtraError,
  subtleInfo: {
    color: config.colorSubtle,
    marginBottom: 12,
    marginLeft: config.normalPadding,
  },
  agreement: {
    textAlign: 'center',
    color: config.brandBlue,
    marginVertical: 6,
  }
});

class Register extends Component {
  static propTypes = {
    registering: PropTypes.bool,
    register: PropTypes.func.isRequired,
    registerError: PropTypes.any,
    verifyToken: PropTypes.string.isRequired,
    fields: PropTypes.object.isRequired,
    invalid: PropTypes.bool.isRequired,
    valid: PropTypes.bool.isRequired,
  };

  state = {gender: '0'}; // , school: '0'

  onSubmit = (event) => {
    event.preventDefault();
    console.log(this.props.fields);
    const {registering, fields, valid, verifyToken} = this.props;
    if (!registering && valid) {
      this.props.register({
        username: fields.username.value,
        password: fields.password.value,
        gender: this.state.gender,
        // schoolId: this.state.school,
        verifyToken,
      });
    }
  };

  focusNextField = (toFocus) => {
    return () => {
      this.refs[toFocus].focus();
    }
  };

  onReplace = (route) => {
    return () => {
      this.props.navigator.replace(route);
    };
  };

  onGenderChange = (value) => {
    this.setState({gender: value});
  };

  openPolicy = () => {
    Linking.openURL('https://taskbee.cn/agreement.html');
  };

  render() {
    const {
      verifyToken,
      registering,
      fields: {username, password},
      valid,
      invalid,
      registerError,
      phone
    } = this.props;

    const errorFunc = serverError(registerError);

    return (
      <View style={styles.login}>
        <Text style={styles.subtleInfo}>{locales.registering}: {phone}</Text>
        <TextInput
          blurOnSubmit={false}
          onSubmitEditing={this.focusNextField('0')}
          focus={true}
          label={locales.nickname}
          placeholder={locales.nicknamePlaceholder}
          serverError={errorFunc('phone')} {...username} />
        <TextInput
          onSubmitEditing={this.onSubmit}
          ref="0"
          isPassword label={locales.password}
          placeholder={locales.passwordPlaceholder}
          serverError={errorFunc('password')} {...password} />
        <SelectInput
          selectedValue={this.state.gender}
          onValueChange={this.onGenderChange}
          mode="dropdown"
          label={locales.gender}
          picks={[{
            label: locales.male,
            value: 0,
          }, {
            label: locales.female,
            value: 1,
          }]}
          serverError={errorFunc('gender')}
        />
        <TouchableOpacity
          onPress={this.openPolicy}
        ><Text style={styles.agreement}>注册表明您已经阅读并接受用户协议</Text></TouchableOpacity>
        <View style={styles.cta}>
          <NormalButton onPress={this.onSubmit} text={locales.register} working={registering} disabled={invalid}/>
        </View>
        {registerError && !registerError.errorCode && <Text style={styles.extraError}>{registerError.message || locales.strangeError}</Text>}

      </View>
    );
  }
}

export default  reduxForm({
  form: 'user',
  fields: ['username', 'phone', 'password'],
  validate: userValidation
})(
  connect(
  state => ({
    phone: state.verify.phone,
    verifyToken: state.verify.verifyToken,
    registering: state.me.get('registering'),
    registerError: state.me.get('registerError'),
  }),
  {register})(
    Register
  )
)

