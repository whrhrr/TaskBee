import React, {
  StyleSheet,
  Component,
  PropTypes,
  View,
  Text,
} from 'react-native';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import {getCode, verifyCode} from '../modules/verify';
import userValidation from '../utils/userValidation';

import {login} from '../modules/me';

import {
  NormalButton,
  TextInput,
  SubtleButtons,
  CodeButton,
} from '../components';

import config from '../config';
import {getRoute} from '../routes';
import {serverError} from '../utils/dataHelpers';

import locales from '../locales';

const styles = StyleSheet.create({
  login: {
    marginTop: config.bannerHeight,
    padding: config.normalPadding,
  },
  cta: {
    marginTop: 24,
  },
  extraError: config.styleExtraError,
});

class VerifyForm extends Component {
  static propTypes = {
    codeError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    getCode: PropTypes.func.isRequired,
    verifyCode: PropTypes.func.isRequired,
    verifying: PropTypes.bool,
    verifyError: PropTypes.any,
    forget: PropTypes.bool,
    verifyToken: PropTypes.string,
    navigator: PropTypes.object,
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.verifyToken && !nextProps.verifying && !nextProps.verifyError) {
      console.log(this.props.successRoute);
      this.props.navigator.replace(getRoute(this.props.successRoute));
    }
  }

 onCodeClick = () => {
    this.props.getCode({phone: this.props.fields.phone.value, forget: this.props.forget});
    this.refs[0].focus();
  };

  onSubmit = () => {
    const {verifying, fields, valid} = this.props;
    if (!verifying && valid) {
      this.props.verifyCode({phone: fields.phone.value, code: fields.verify.value});
    }
  };

  focusNextField = (toFocus) => {
    return () => {
      this.refs[toFocus].focus();
    }
  };

  onReplace = (route) => {
    return () => {
      this.props.navigator.replace(route);
    };
  };

  render() {
    const {
        fields: {phone, verify},
        valid,
        verifying,
        codeError,
        verifyError
      } = this.props;

    const extra = {};
    if (!valid) {
      extra.disabled = true;
      extra.backgroundColor = config.colorVerySubtle;
    }

    const loginError = codeError || verifyError;
    const errorFunc = serverError(loginError);

    return (
      <View style={styles.login}>
        <TextInput
          keyboardType="phone-pad"
          blurOnSubmit={false}
          onSubmitEditing={this.focusNextField('0')}
          autoFocus
          label={locales.phone}
          placeholder={locales.phonePlaceholder}
          serverError={errorFunc('phone')} {...phone} />
        <TextInput
          getCode={this.onCodeClick}
          onSubmitEditing={this.onSubmit}
          ref="0"
          label={locales.code}
          placeholder="❤️"
          right={90}
          serverError={errorFunc('verify')} {...verify}
        >
          <CodeButton onPress={this.onCodeClick}/>
        </TextInput>
        <View style={styles.cta}>
          <NormalButton onPress={this.onSubmit} {...extra} text={locales.nextStep} working={verifying}/>
        </View>
        {loginError && !loginError.errorCode && <Text style={styles.extraError}>{locales.strangeError}</Text>}
      </View>
    );
  }
}

export default  reduxForm({
  form: 'user',
  fields: ['phone', 'verify'],
  validate: userValidation
})(
connect(
  state => ({
    codeError: state.verify.error,
    verifying: state.verify.verifing,
    verifyError: state.verify.verifyError,
    verifyToken: state.verify.verifyToken,
  }),
  {verifyCode, getCode})(
    VerifyForm
  )
)

