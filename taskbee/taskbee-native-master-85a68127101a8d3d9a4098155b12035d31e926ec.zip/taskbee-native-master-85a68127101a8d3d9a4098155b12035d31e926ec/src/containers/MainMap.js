import React, {
  StyleSheet,
  Component,
  View,
  Text,
  Dimensions,
  TouchableOpacity,
  NativeModules,
  Platform,
} from 'react-native';

import Mapbox from 'react-native-mapbox-gl';

import {connect} from 'react-redux';
import config from '../config';
import {calcCrow} from '../utils/dataProcessor';

import {
  Icon
} from '../components';

const {MapboxGLManager} = NativeModules;

const styles = StyleSheet.create({
  mainMap: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  myPos: {
    position: 'absolute',
    right: 32,
    bottom: 48,
    backgroundColor: '#fff',
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: config.borderRadius,
  },
  location: {
    position: 'absolute',
    top: 64,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  distance: {
    paddingVertical: 6,
    width: 120,
    backgroundColor: 'rgba(0,0,0,.1)',
    borderRadius: config.borderRadius,
  },
  distanceText: {
    textAlign: 'center',
    color: '#fff',
  }
});

class MainMap extends Component {

  onPositionPress = () => {
    MapboxGLManager.setCenterCoordinateAnimated(React.findNodeHandle(this.refs.mapRef), this.props.lati, this.props.long);
  };
  render() {
    const {coordinates, long, lati} = this.props;

    return (
      <View style={styles.mainMap}>
        <Mapbox
          style={styles.container}
          annotations={
            [
              {
                coordinates: [coordinates[1], coordinates[0]],
                type: 'point',
                id: '1',
              }
            ]
          }
          accessToken="pk.eyJ1IjoieGlhb2J1IiwiYSI6ImNpamNjcTVhajAwMXV2MW0wbDIwNmVoM2wifQ.K-QHYmExydp-t7z8YCqfKw"
          centerCoordinate={{longitude: coordinates[0], latitude: coordinates[1] }}
          ref="mapRef"
          rotateEnabled
          scrollEnabled
          showsUserLocation
          userTrackingMode={MapboxGLManager.userTrackingMode.None}
          styleURL="mapbox://styles/xiaobu/cijcd4giu00dgbkku5ymwdjy8"
          zoomEnabled
          zoomLevel={14}
          logoIsHidden
          attributionButtonIsHidden
        />
        <View style={styles.location}>
          <View style={styles.distance}>
            <Text style={styles.distanceText}>{Math.round(calcCrow(coordinates, [long, lati]))}米</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.myPos} onPress={this.onPositionPress}>
          <Icon name="man" size={20}/>
        </TouchableOpacity>
      </View>
    );
  }
}

export default connect(
  (state) => ({
    long: state.lbs.get('longitude'),
    lati: state.lbs.get('latitude'),
  })
)(MainMap);
