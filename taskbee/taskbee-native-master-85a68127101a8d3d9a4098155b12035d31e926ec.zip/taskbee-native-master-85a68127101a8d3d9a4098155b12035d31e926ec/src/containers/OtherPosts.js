import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  RefreshControl,
  ListView,
} from 'react-native';
import { connect } from 'react-redux';

import {
  PollenItem,
  NormalButton,
  Text,
} from '../components';

import {getHotest} from '../modules/post';

import {mdl} from 'react-native-material-kit';
import config from '../config';
import locales from '../locales';
import {goTo} from '../utils/navigation';

function getDisplayName(Comp) {
  return Comp.displayName || Comp.name || 'Component';
}

// 生成对应的修改个人信息页面
function factory({loadingKey, errorKey, postKey, load, name, noMoreKey}) {
  // 将异步获取数据移动到这里，以获取apiKey
  return DecoratedComponent => {
    class RealOtherTasks extends Component {
      static displayName = `${name}(${getDisplayName(DecoratedComponent)})`;
      static fetchData(getState, dispatch) {
        return dispatch(load());
      }
      static DecoratedComponent = DecoratedComponent;
      render() {
        return <DecoratedComponent name={name} {...this.props}/>;
      }
    }
    return connect(
      state => {
        return ({
          loading: state.post.get(loadingKey),
          error: state.post.get(errorKey),
          posts: state.post.get(postKey),
          noMore: state.post.get(noMoreKey),
          token: state.me.get('token'),
          meId: state.me.get('meId'),
          long: state.lbs.get('longitude'),
          lati: state.lbs.get('latitude'),
        });
      },
      { load })(RealOtherTasks);
  }
}

const styles = StyleSheet.create({
  noList: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
    marginVertical: config.normalPadding,
  },
  otherTasks: {
    // marginTop: config.bannerHeight,
  },
  center: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    padding: config.normalPadding,
  },
  action: {
    marginBottom : config.normalPadding,
  },
  errorMessage: config.styleExtraError,
});

const Indeterminate = mdl.Progress.indeterminateProgress()
  .build();

class OtherPost extends Component {
  static propTypes = {
    loading: PropTypes.bool,
    error: PropTypes.any,
    name: PropTypes.string.isRequired,
    load: PropTypes.func.isRequired,
    posts: PropTypes.array.isRequired,
    noMore: PropTypes.bool,
    meId: PropTypes.string,
    navigator: PropTypes.object.isRequired,
  };

  constructor(props) {
    super(props);
    console.log(props);
    const ds = new ListView.DataSource({rowHasChanged: (item1, item2) => item1 !== item2 });
    this.state = {
      dataSource: ds.cloneWithRows(props.posts),
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.posts.length !== nextProps.posts.length) {
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(nextProps.posts),
      });
    }
  }

  goTo = goTo.bind(this);
  onLoadMore = () => {
    if (!this.props.noMore && !(!this.props.posts.length && this.props.error) && !this.props.loading) {
      const {posts} = this.props;
      if (posts.length) this.props.load(posts.length);
      else this.props.load(0);
    }
  };

  onScrollLoad = () => {
    if (!this.props.error && !this.props.loading) {
      this.props.load(0);
    }
  };

  renderRow = (item) => {
    if (item) {
      return <PollenItem postId={item} type={0} myPos={[this.props.long, this.props.lati]} goTo={this.goTo}/>;
    } else return <View/>;
  };

  renderFooter = () => {
    const {navigator, meId, noMore, loading, posts, error, name} = this.props;
    let content;
    if (loading) {
      content = <View style={styles.center}><Indeterminate /></View>;
    } else if (error) {
      content = (<View style={styles.center}>
      <Text style={styles.errorMessage}>{error.message || locales.strangeError}</Text>
      <NormalButton text={locales.retry} onPress={this.onLoadMore}/>
    </View>);
    } else if (noMore && posts.length) {
      content = (<Text style={[styles.center, styles.action]}>
          {locales.noMore}
        </Text>);
    } else if (!posts.length) {
      content = (<View style={styles.center}>
        <Text style={styles.subtle}></Text>
      </View>);
    } else {
      content = <View style={[styles.center, styles.action]} onPress={this.onLoadMore}><Text>{locales.loadMore}</Text></View>;
    }
    return content;
  };

  render() {
    const {navigator, meId, noMore, loading, posts, error, name} = this.props;

    return (
      <ListView style={styles.otherTasks}
        dataSource={this.state.dataSource}
        renderRow={this.renderRow}
        renderFooter={this.renderFooter}
        onEndReached={this.onLoadMore}
        onEndReachedThreshold={50}
        initialListSize={1}
        contentContainerStyle={styles.realTask}
        refreshControl={config.isIOS ? null :
          <RefreshControl
            colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
            refreshing={loading} onRefresh={this.onScrollLoad}/>
        }
      />
    );
  }
}

export const HotestPost = factory({
  loadingKey: 'loadingHotest',
  errorKey: 'errorHotest',
  postKey: 'hotPost',
  load: getHotest,
  name: locales.weeklyHotest,
  noMoreKey: 'noMoreHot'
})(OtherPost);

