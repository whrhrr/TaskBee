import React, {
  Component,
  PropTypes,
  View,
  Text,
  StyleSheet,
  ScrollView,
} from 'react-native';
import {
  OrderItem,
  LoadingIndicator,
  NormalButton,
} from '../components';
import {connect} from 'react-redux';
import {loadOrderList} from '../modules/order';
import connectData from '../libs/connectData';
import config from '../config';
import {goTo} from '../utils/navigation';

const styles = StyleSheet.create({
  orderList: {
    marginTop: config.bannerHeight,
  },
  noOther: {
    flex: 1,
    alignItems:'center',
    justifyContent: 'center',
  },
  center: {
  }
});

class OrderList extends Component {
  static propTypes = {
    loadOrderList: PropTypes.func.isRequired,
    order: PropTypes.object.isRequired,
    orderList: PropTypes.array.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
  };

  goTo = goTo.bind(this);

  render() {
    const { orderList, order, loading, error} = this.props;
    let content;
    let centerStyle = [styles.center];
    if (!orderList || !orderList.length) {
      centerStyle.push(styles.noOther);
    }
    if (loading) {
      content = <View style={centerStyle}><LoadingIndicator /></View>;
    } else if (error) {
      content = (<View style={centerStyle}>
        <Text>{error.message || '网络错误，请稍候重试'}</Text>
        <NormalButton onPress={this.props.loadOrderList} text="重试"></NormalButton>
      </View>);
    } else if (!orderList.length) {
      content = (<View style={centerStyle}>
        <Text style={styles.subtle}>还没有充值订单</Text>
      </View>);
    } else {
      content = (<View style={[centerStyle, styles.action]}>
        {orderList.map(orderId => {
          const orderItem = order[orderId];
          return <OrderItem key={orderItem._id} {...orderItem} goTo={this.goTo}/>;
        })}
      </View>);
    }
    return (
      <ScrollView style={styles.orderList}>
        {content}
      </ScrollView>
    );
  }
}

function fetchDataDeferred(getState, dispatch) {
  return dispatch(loadOrderList());
}

export default connectData(fetchDataDeferred)(
  connect(state => {
    return {
      orderList: state.order.orders,
      order: state.order,
      loading: state.order.loadingList,
      error: state.order.loadingListError,
    };
  }, {loadOrderList})(
    OrderList
  )
)
