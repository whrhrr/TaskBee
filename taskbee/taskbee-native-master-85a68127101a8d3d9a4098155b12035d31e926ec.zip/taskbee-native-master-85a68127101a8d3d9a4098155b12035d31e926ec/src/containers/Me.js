'use strict';
import {trackEvent} from 'react-native-talkingdata';

import React, {
  PropTypes,
  Component,
  TouchableHighlight,
  ScrollView,
  StyleSheet,
  View,
  Text,
  Linking,
  Clipboard,
} from 'react-native';
import { connect } from 'react-redux';
import Immutable from 'immutable';
import Share from 'react-native-share';

import {
  MyLittleAccount,
  LineButton,
  Icon,
  NormalButton,
} from '../components';

import {sign, getScore} from '../modules/me';

import {goTo, requireLogin} from '../utils/navigation'; // simple helper

import connectData from '../libs/connectData';

import config from '../config';
import toast from '../libs/toast';
import locales from '../locales';

function isToday(date) {
  const tmp = new Date(date);
  return tmp.setHours(0, 0, 0, 0) === (new Date()).setHours(0, 0, 0, 0);
}

const styles = StyleSheet.create({

  spliter: {
    height: config.borderWidth,
    alignSelf: 'stretch',
    marginHorizontal: config.normalPadding,
    backgroundColor: config.colorVerySubtle,
  },
  section: {
    borderTopWidth: config.borderWidth,
    borderBottomWidth: config.borderWidth,
    borderColor: config.colorBorder,
    marginBottom: config.normalPadding,
  },
  contentContainer: {
    paddingVertical: config.normalPadding,
  },
  extraError: config.styleExtraError,
  signButton: {
    marginHorizontal: config.normalPadding,
    marginBottom: config.normalPadding,
  },
  signText: {
    color: '#fff',
  },
});

class Me extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
    user: Immutable.Map.isMap,
    signing: PropTypes.bool,
    signError: PropTypes.any,
    sign: PropTypes.func.isRequired,
    token: PropTypes.string,
  };

  constructor(props) {
    super(props);
  }

  goTo = goTo.bind(this);
  requireLogin = requireLogin.bind(this);


  onSignClick = () => {
    if (!this.props.signing) {
      this.props.sign(this.props.token);
    }
  };

  openHot() {
    Linking.openURL('http://hot.taskbee.cn/');
    if(!__DEV__) trackEvent('Me', 'openHot');
  }
  shareMe() {
    Clipboard.setString('https://taskbee.cn/');
    toast('链接已复制');
    Share.open({
      share_text: '人人微信都Out了，我在玩蜂房～',
      share_URL: 'https://taskbee.cn/',
      title: "分享蜂房给朋友",
    }, function(e) {
      console.log(e);
    });
    trackEvent('Me', 'shareMe');
  }

  renderSign = () => {
    const {user, signing, signError} = this.props;
    let signTime;
    let signCount;
    let signText;
    let alreadSigned;
    if (user) {
      signTime = user.get('signTime');
      signCount = user.get('signCount');
      alreadSigned = signTime && isToday(signTime);
      if (signing) {
      } else if (alreadSigned) {
        signText = <Text>{locales.signedToday} <Text style={styles.signCount}>{locales.continuouslySign}<Text style={styles.number}>{signCount}</Text>{locales.day}</Text></Text>;
      } else {
        signText = <Text style={styles.signText}><Icon name="heart"/>{locales.checkinText}</Text>;
      }
    }
    return (<View style={styles.sign}>
      <NormalButton working={signing} style={styles.signButton} disabled={signing || alreadSigned} onPress={this.requireLogin(this.goTo('CreatePollen'))}>
        {signText}
      </NormalButton>
      {signError && !signError.errorCode && <Text style={styles.extraError}>{signError.message || locales.strangeError}</Text>}
    </View>)
  };

  render() {
    const {navigator, user, token} = this.props;

    return (
      <ScrollView
        contentContainerStyle={styles.contentContainer}>
        <MyLittleAccount push={navigator.push} user={user}/>
        <View style={styles.section}>
          <LineButton icon="heart-o" label={locales.honey} text={user ? user.get('score') : '0'} onPress={this.requireLogin(this.goTo('Score'))} />
          <View style={styles.spliter}/>
          <LineButton icon="vallet" label={locales.wallet} text={'¥' + (user ? user.get('money') : '0')} onPress={this.requireLogin(this.goTo('Wallet'))}/>
        </View>
        {token ? this.renderSign() : null}
        <View style={styles.section}>
          <LineButton icon="share-square-o" label={locales.recommandToFriends} onPress={this.shareMe}/>
          <View style={styles.spliter}/>
          <LineButton icon="bulb" label={locales.feedback} onPress={this.goTo('Feedback')}/>
          <View style={styles.spliter}/>
          <LineButton icon="study" label={locales.about} onPress={this.goTo('About')}/>
          <View style={styles.spliter}/>
          <LineButton icon="paper-plane" label="前往同济热脸" onPress={this.openHot}/>
        </View>
      </ScrollView>
    );
  }
}
function fetchDataDeferred(getState, dispatch) {
  if (getState().me.get('token')) return dispatch(getScore());
}

export default connectData(fetchDataDeferred)(
  connect(state => ({
    user: state.me.get('data'), // immutable map
    token: state.me.get('token'),
    signing: state.me.get('signing'),
    signError: state.me.get('signError'),
  }), {sign}
  )(Me)
)
