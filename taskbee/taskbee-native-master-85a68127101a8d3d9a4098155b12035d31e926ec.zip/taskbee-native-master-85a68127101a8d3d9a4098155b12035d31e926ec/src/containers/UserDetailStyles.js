import config from '../config';
import {StyleSheet} from 'react-native';
export default StyleSheet.create({
  userDetail: {
    flex: 1,
    marginTop: config.bannerHeight,
  },
  info: {
    backgroundColor: '#fff',
    padding: config.normalPadding,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: config.borderWidth,
    borderBottomColor: config.colorBorder,
  },
  confirmed: {
    position: 'absolute',
    left: config.normalPadding,
    top: config.normalPadding,
  },
  reportButton: {
    position: 'absolute',
    right: config.normalPadding,
    top: config.normalPadding,
  },
  report: {
    color: config.colorSubtle,
    fontSize: config.fontSmall,
  },
  username: {
    marginTop: config.normalPadding,
    fontSize: config.fontLarge,
    color: config.colorStand,
  },
  signature: {
    color: config.colorMain,
  },
  misc: {
    alignSelf: 'stretch',
    marginHorizontal: 9,
    marginTop: config.normalPadding,
    paddingTop: 12,
    borderTopWidth: config.borderWidth,
    borderTopColor: config.colorBorder,
    flexDirection: 'row',
  },
  miscSection: {
    flex: 1,
    alignItems: 'center',
  },
  miscCount: {
    color: config.colorMain,
    fontWeight: 'bold',
  },
  miscTitle: {
    fontSize: config.fontSmall,
  },
  vote: {
    marginTop: config.normalPadding,
  },
  nothing: {
    marginLeft: config.normalPadding,
  },
  voteTitle: {
    marginLeft: config.normalPadding,
    marginBottom: config.normalPadding,
    color: config.colorStand,
    fontSize: config.fontBig,
  },
  interest: {
    alignItems: 'center',
    padding: config.normalPadding,
  },
  error: {
    padding: config.normalPadding,
    alignItems: 'center',
    justifyContent: 'center',
  },
  friended: {
    color: config.brandPrimary,
    fontWeight: 'bold',
    marginVertical: 9,
  },
  subtle: {
    marginTop: 6,
    color: config.colorVerySubtle,
    fontSize: config.fontSmall,
  }
});
