import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
} from 'react-native';
import {
  TextInput,
  LongTextInput,
  NormalButton,
  Icon,
  Text,
} from '../components';

import {reduxForm} from 'redux-form';
import {connect} from 'react-redux';
import feedbackValidation from '../utils/feedbackValidation';
import {feedbackAgain, feedback} from '../modules/misc';
import {serverError} from '../utils/dataHelpers';

import config from '../config';
import locales from '../locales';
const styles = StyleSheet.create({
  feedback: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
  },
  mainText: {
    alignItems: 'center',
  },
  submit: {
    alignSelf: 'center',
    marginTop: config.normalPadding,
  },
  icon: {
    color: config.colorMain,
    marginVertical: config.normalPadding,
  },
  input: {
    flex: 1,
    justifyContent: 'center',
  },
  success: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  successMain: {
    color: config.colorMain,
    fontSize: config.fontLarge,
  },
  subtle: {
    marginHorizontal: config.normalPadding,
  }
});

class Feedback extends Component {
  static propTypes = {
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    feedback: PropTypes.func.isRequired,
    feedbackAgain: PropTypes.func.isRequired,
    feedbacking: PropTypes.bool,
    feedbackSuccess: PropTypes.bool,
    feedbackError: PropTypes.any
  };

  onSubmitClick = (data) => {
    const {feedbacking} = this.props;
    if (!feedbacking) {
      this.props.handleSubmit(this.props.feedback)(data);
    }
  };

  render() {
    const {feedbackSuccess, feedbacking, feedbackError, fields: {email, feedback}} = this.props; /* eslint no-shadow: 0*/

    const errorFunc = serverError(feedbackError);

    return (
      <View style={styles.feedback}>
        <View style={styles.mainText}>
          <Icon style={styles.icon} size={22} name="bulb"/>
          <Text>{locales.feedbackText1}</Text>
          <Text>{locales.feedbackText2}</Text>
        </View>
        <View>

          {
            feedbackSuccess ? <View style={styles.success}>
              <Text style={styles.successMain}>{locales.thankFeedback}</Text>
              <Text style={styles.subtle}>{locales.willContactYou}</Text>
              <NormalButton onPress={this.props.feedbackAgain} text={locales.submitAnotherFeedback}/>
            </View> :
            <View style={styles.input}>
              {feedbackError && (!feedbackError.errorCode || typeof feedbackError.errorCode === 'number') && <Text style={styles.extraError}>{feedbackError.message || '迷的错误'}</Text>}
              <LongTextInput
                placeholder={locales.pleaseEnterFeedback}
                rows="10"
                maxCount={700}
                {...feedback}
                serverError={errorFunc('feedback')}
                onSubmitEditing={this.onSubmitClick}
              />
              <TextInput
                label={locales.email}
                placeholder={locales.ifPreferContact}
                {...email}
                serverError={errorFunc('email')}
              />

             <NormalButton style={styles.submit} text={locales.submit} working={feedbacking} onPress={this.onSubmitClick}/>
            </View>

          }
        </View>
      </View>
    );
  }
}

export default reduxForm({
  form: 'misc',
  fields: ['email', 'feedback'],
  validate: feedbackValidation
})(
  connect(
    state => ({
      feedbackError: state.misc.feedbackError,
      feedbackSuccess: state.misc.feedbackSuccess,
      feedbacking: state.misc.feedbacking,
    }),
    {feedbackAgain, feedback})(
    Feedback
  )
)

