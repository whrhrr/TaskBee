import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
} from 'react-native';
import {connect} from 'react-redux';
import {
 Banner,
 NormalButton,
 LongTextInput,
 Rating,
 Text,
} from '../components';

import {Map} from 'immutable';
import connectData from '../libs/connectData';
import {loadDetail, vote} from '../modules/task';
import {reduxForm} from 'redux-form';

import config from '../config';
const styles = StyleSheet.create({
  vote: {
    marginTop: config.bannerHeight,
    flex: 1,
    paddingVertical: config.normalPadding,
  },
  rating: {
    alignItems: 'center',

  },
  score: {
    color: config.colorMain,
  },
  button: {
    alignSelf: 'center',
    marginTop: config.normalPadding,
  },
  error: config.styleExtraError,
});


class Vote extends Component {
  static propTypes = {
    loading: PropTypes.bool,
    loadError: PropTypes.any,
    task: PropTypes.object,
    meId: PropTypes.string,
    fields: PropTypes.object.isRequired,
    vote: PropTypes.func.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    taskId: PropTypes.string.isRequired,
    token: PropTypes.string.isRequired,
    navigator: PropTypes.object.isRequired,
  };

  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去
    if (this.props.task.get('voting') && !nextProps.task.get('voting') && !nextProps.task.get('voteError')) {
      this.props.navigator.pop();
    }
  }

  onVoteSubmit = (data) => {
    if (!this.props.task.get('voting')) {
      this.props.handleSubmit(this.processVoteSubmit)(data);
    }
  };

  onKeyEnter = () => {
    if (event.keyCode === 13) {
      event.preventDefault();
      this.onVoteSubmit();
    }
  };

  processVoteSubmit = (data) => {
    const {token, meId, taskId} = this.props;
    this.props.vote({
      token,
      meId,
      taskId,
      ...data
    });
  };

  render() {
    const {meId, task, fields: {score, message}} = this.props;
    const canVote = task.get('canVote');
    const voting = task.get('voting');
    const voteError = task.get('voteError');
    const votable = canVote && canVote.indexOf(meId) > -1;
    const mutateScore = score.value - 3 || 0;
    console.log('canVote', canVote);
    return (
      <View style={styles.vote}>
        {
          votable ?
          <View style={styles.voteForm}>
            <View style={styles.rating}>
              <Text style={styles.score}>{'蜂蜜' + (mutateScore < 0 ? mutateScore : '+' + mutateScore)}</Text>
              <Rating isInput {...score}/>
            </View>
            <LongTextInput
              {...message}
              onKeyDown={this.onKeyEnter}
              maxCount={280}
              rows={6}
              placeholder="（可选）输入对对方的评价，让更多人更好的了解TA"
              onEndEditing={this.onVoteSubmit}
            />
            {
              voteError && <Text style={styles.error}>{voteError.message || '迷的错误'}</Text>
            }
            <NormalButton style={styles.button} working={voting} text="提交评价" onPress={this.onVoteSubmit}/>
          </View>
          :
          <Text style={styles.error}>您不能评价这个任务</Text>
        }
      </View>
    );
  }
}

function fetchDataDeferred(getState, dispatch, params) {
  const {taskId} = params;
  console.log(params);
  if (!getState().task.get(taskId)) return dispatch(loadDetail(taskId));
}

export default connectData(fetchDataDeferred)(
  connect(
    (state, props) => {
      const {taskId} = props;
      return {
        taskId,
        task: state.task.get(taskId) || Map(),
        meId: state.me.get('meId'),
        token: state.me.get('token'),
      };
    }, {vote}
  )(
    reduxForm({
      form: 'user',
      fields: ['score', 'message'],
      initialValues: {
        score: 3,
        message: '',
      }
    })(Vote)
  )
);
