import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  RefreshControl,
  ListView,
} from 'react-native';
import { connect } from 'react-redux';

import {
  PollenItem,
  NormalButton,
  Text,
} from '../components';

import {getPollens} from '../modules/me';

import {mdl} from 'react-native-material-kit';
import config from '../config';
import locales from '../locales';
import {goTo} from '../utils/navigation';

function getDisplayName(Comp) {
  return Comp.displayName || Comp.name || 'Component';
}

// 生成对应的修改个人信息页面
function factory({loadingKey, errorKey, pollenKey, load, name, noMoreKey}) {
  // 将异步获取数据移动到这里，以获取apiKey
  return DecoratedComponent => {
    class RealOtherTasks extends Component {
      static displayName = `${name}(${getDisplayName(DecoratedComponent)})`;
      static fetchData(getState, dispatch) {
        if (getState().me.get('token')) return dispatch(load(null, 15, true));
      }
      static DecoratedComponent = DecoratedComponent;
      render() {
        return <DecoratedComponent name={name} {...this.props}/>;
      }
    }
    return connect(
      state => {
        return ({
          loading: state.me.get(loadingKey),
          error: state.me.get(errorKey),
          pollens: state.me.get(pollenKey),
          token: state.me.get('token'),
          noMore: state.me.get(noMoreKey),
          meId: state.me.get('meId'),
          long: state.lbs.get('longitude'),
          lati: state.lbs.get('latitude'),
        });
      },
      { load })(RealOtherTasks);
  }
}

const styles = StyleSheet.create({
  noList: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
    marginVertical: config.normalPadding,
  },
  otherTasks: {
    // marginTop: config.bannerHeight,
  },
  center: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    padding: config.normalPadding,
  },
  action: {
    marginBottom : config.normalPadding,
  },
  errorMessage: config.styleExtraError,
});

const Indeterminate = mdl.Progress.indeterminateProgress()
  .build();

class OtherPollens extends Component {
  static propTypes = {
    loading: PropTypes.bool,
    error: PropTypes.any,
    name: PropTypes.string.isRequired,
    load: PropTypes.func.isRequired,
    pollens: PropTypes.array.isRequired,
    noMore: PropTypes.bool,
    meId: PropTypes.string,
    navigator: PropTypes.object.isRequired,
  };

  constructor(props) {
    super(props);
    console.log(props);
    const ds = new ListView.DataSource({rowHasChanged: (item1, item2) => item1 !== item2 });
    this.state = {
      dataSource: ds.cloneWithRows(props.pollens),
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.pollens.length !== nextProps.pollens.length) {
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(nextProps.pollens),
      });
    }
  }

  goTo = goTo.bind(this);

  onLoadMore = () => {
    if (!this.props.noMore && !(!this.props.pollens.length && this.props.error) && !this.props.loading) {
      const {pollens} = this.props;
      if (pollens.length) this.props.load(pollens[pollens.length - 1].createdAt);
      else this.props.load();
    }
  };

  onScrollLoad = () => {
    if (!this.props.error && !this.props.loading) {
      this.props.load();
    }
  };

  onRetryClick = () => {
    if (!this.props.loading) {
      this.props.load();
    }
  };

  renderRow = (item) => {
    if (item) {
      return <PollenItem {...item} myPos={[this.props.long, this.props.lati]} goTo={this.goTo}/>;
    } else return <View/>;
  };

  renderFooter = () => {
    const {navigator, meId, noMore, loading, pollens, error, name} = this.props;
    let content;
    if (loading) {
      content = <View style={styles.center}><Indeterminate /></View>;
    } else if (error) {
      content = (<View style={styles.center}>
      <Text style={styles.errorMessage}>{error.message || locales.strangeError}</Text>
      <NormalButton text={locales.retry} onPress={this.onRetryClick}/>
    </View>);
    } else if (noMore && pollens.length) {
      content = (<Text style={[styles.center, styles.action]}>
          {locales.noMore}
        </Text>);
    } else if (!pollens.length) {
      content = (<View style={styles.center}>
        <Text style={styles.subtle}>{locales.noYet}{name}</Text>
      </View>);
    } else {
      content = <View style={[styles.center, styles.action]} onPress={this.onLoadMore}><Text>载入更多</Text></View>;
    }
    return content;
  };

  render() {
    const {navigator, meId, noMore, loading, pollens, error, name} = this.props;

    return (
      <ListView style={styles.otherTasks}
        dataSource={this.state.dataSource}
        renderRow={this.renderRow}
        renderFooter={this.renderFooter}
        onEndReached={this.onLoadMore}
        onEndReachedThreshold={50}
        initialListSize={1}
        contentContainerStyle={styles.realTask}
        refreshControl={config.isIOS ? null :
          <RefreshControl
            colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
            refreshing={loading} onRefresh={this.onScrollLoad}/>
        }
      />
    );
  }
}

export const MyPollens = factory({
  loadingKey: 'gettingPollen',
  errorKey: 'getPollenError',
  pollenKey: 'myPollens',
  load: getPollens,
  name: locales.myPollens,
  noMoreKey: 'noMorePollens'
})(OtherPollens);

