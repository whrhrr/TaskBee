'use strict';
import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
} from 'react-native';

import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from '../utils/userValidation';

import {
  NormalButton,
  Text,
} from '../components';
import LongTextInput from '../components/LongTextInput';
import SimpleRadios from '../components/SimpleRadios';

import config from '../config';
import locales from '../locales';

import {changeInfo} from '../modules/me';

function getDisplayName(Comp) {
  return Comp.displayName || Comp.name || 'Component';
}
// 生成对应的修改个人信息页面
function factory({key, name, introduction, url, component, props}) {
  // 将异步获取数据移动到这里，以获取apiKey
  return DecoratedComponent => {
    class RealChangeInfo extends Component {
      static propTypes = {
        changeInfo: PropTypes.func.isRequired,
      };
      static displayName = `RealChangeInfo(${getDisplayName(DecoratedComponent)})`;
      static DecoratedComponent = DecoratedComponent;
      render() {
        return <DecoratedComponent name={name} actionKey={key} introduction={introduction} url={url} props={props} component={component} {...this.props}/>;
      }
    }
    return reduxForm({
      form: 'userInfo',
      fields: [key],
      validate: userValidation
    },
    state => ({
      initialValues: {
        [key]: state.me.get('data') ? state.me.get('data').get(key) : 'hh'
      }
    }))(
      connect(
      state => {
        const changingMap = state.me.get('changing');
        return ({
          changing: state.me.getIn(['changing', key]),
          error: state.me.getIn(['changeError', key]),
          token: state.me.get('token'),
        });
      },
      { changeInfo })(
        RealChangeInfo
      )
    )
  }
}


const styles = StyleSheet.create({
  changeInfo: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
    // marginHorizontal: config.normalPadding,
  },
  introduction: {
    marginBottom: 9,
    marginTop: 9,
    marginHorizontal: config.normalPadding,
  },
  cta: {
    marginHorizontal: config.normalPadding,
  }

});

class ChangeInfo extends Component {
  static propTypes = {
    changing: PropTypes.bool,
    fields: PropTypes.object.isRequired,
    invalid: PropTypes.bool.isRequired,
    valid: PropTypes.bool.isRequired,
    name: PropTypes.string.isRequired,
    actionKey: PropTypes.string.isRequired,
    error: PropTypes.any,
    introduction: PropTypes.string,
    changeInfo: PropTypes.func.isRequired,
    url: PropTypes.string.isRequired,
    navigator: PropTypes.object.isRequired,
    token: PropTypes.string.isRequired,
    component: PropTypes.func.isRequired,
    props: PropTypes.object,
  };

  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去
    if (this.props.changing && !nextProps.changing && !nextProps.error) {
      this.props.navigator.pop();
    }
  }

  onSubmit = () => {
    const {changing, actionKey, url, token} = this.props;
    if (!changing) {
      this.props.changeInfo({
        data: {[actionKey]: this.props.fields[actionKey].value},
        key: actionKey,
        url,
        token
      });
    }
  };

  onKeyEnter = (keyCode) => {
    if (keyCode === 13) {
      this.onSubmit();
    }
  };

  render() {
    const {
        changing,
        valid,
        name,
        introduction,
        actionKey,
        error,
        props
      } = this.props;
    const CustomComp = this.props.component;
    const singleField = this.props.fields[actionKey];

    return (
      <View style={styles.changeInfo}>
          {error && !error.errorCode && <View style={styles.extraError}><Text>{error.message || locales.strangeError}</Text></View>}
          <CustomComp autoFocus {...props} onKeyDown={this.onKeyEnter} serverError={error && error.errorCode === 'input' && error.message} {...singleField}/>
          <Text style={styles.introduction}>{introduction}</Text>
          <View style={styles.cta}>
            <NormalButton working={changing} disabled={!valid} onPress={this.onSubmit} text={locales.submit}/>
          </View>
      </View>
    );
  }
}

export const ChangeSignature = factory({
  key: 'signature',
  name: locales.signature,
  introduction: '简单的签名能够让同学更好得了解您',
  url: '/user/changeSig',
  component: LongTextInput,
  props: {
    maxCount: 32,
    placeholder: '输入您的个性签名',
    rows: '3'
  }
})(ChangeInfo)

export const ChangeName = factory({
  key: 'realname',
  name: locales.realName,
  introduction: '输入真实姓名，方便任务发布者和接收者交流',
  url: '/user/changeName',
  component: LongTextInput,
  props: {
    maxCount: 10,
    placeholder: '输入您的真实姓名',
    rows: '2'
  }
})(ChangeInfo)

export const ChangeGender = factory({
  key: 'gender',
  name: locales.gender,
  introduction: '',
  url: '/user/changeGender',
  component: SimpleRadios,
})(ChangeInfo)

