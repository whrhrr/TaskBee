import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
  AsyncStorage,
  Animated,
  TouchableOpacity,
} from 'react-native';
import {
  NormalButton,
  Modal,
  Swiper,
  PollenCard,
  Text,
} from '../components';

const THISID = __DEV__ ? 'test0' : '1.7.0';

import config from '../config';
import locales from '../locales';

const styles = StyleSheet.create({
  userGuide: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: config.brandGreen,
    alignItems: 'stretch',
    justifyContent: 'center',
    padding: config.normalPadding,
    elevation: 5,
  },
  title: {
    color: config.colorStand,
    fontSize: config.fontBig,
    marginBottom: config.normalPadding,
  },
  text: {
    color: config.colorMain,
    marginBottom: 3,
  },
  spliter: {
    marginVertical: config.normalPadding,
    height: 1,
    alignSelf: 'stretch',
    backgroundColor: config.colorBorder,
  },
  button: {
    marginTop: config.normalPadding,
  },
  skip: {
    position: 'absolute',
    right: config.normalPadding,
    top: config.normalPadding,
  },
  section: {
    alignItems: 'center',
    alignSelf: 'stretch',
  },
  pollenCard: {
    flex: 1,
    alignSelf: 'stretch',
  },
});

export default class PollenGuide extends Component {
  static propTypes = {
    children: PropTypes.any,
    index: PropTypes.number,
  };

  state = {
    show: false,
  };

  componentDidMount() {
    AsyncStorage.getItem('guidePollen').then(data => {
      if (data !== THISID) {
        this.setState({
          show: true,
          page: new Animated.Value(0),
          realPage: 1
        }, () => {
          Animated.timing(
            this.state.page,
            {
              toValue: 1,
              duration: 500
            }
          ).start();
        });
      }
    });
  };

  onRequestClose = () => {
    this.setState({show: false});
    AsyncStorage.setItem('guidePollen', THISID);
  };

  onFirstPress = () => {
    this.setState({
      realPage: 2,
    });
    Animated.timing(
      this.state.page,
      {
        toValue: 2,
        duration: 500
      }
    ).start();
  };

  onSecondPress = () => {
    this.setState({
      realPage: 3,
    });
    Animated.timing(
      this.state.page,
      {
        toValue: 3,
        duration: 500
      }
    ).start();
  };

  renderFirst = () => {
    const {page, realPage} = this.state;
    if (realPage === 1) {
      return <Animated.View style={[styles.section, {opacity: page, transform: [{scale: page}]}]}>
          <Text style={styles.title}>{locales.pollenTitle}</Text>
          <Text style={styles.text}>{locales.howPollenText1}</Text>
          <Text style={styles.text}>{locales.howPollenText2}</Text>

          <NormalButton style={styles.button} text={locales.howPollen} onPress={this.onFirstPress}/>

        </Animated.View>;
    }
  };

  renderSecond = () => {
    const {page, realPage} = this.state;
    if (realPage === 2) {
      const opacity = this.state.page.interpolate({inputRange: [1, 2], outputRange: [0, 1]});
      return <Animated.View style={[styles.section, {flex: 1, opacity}]}>
        <PollenCard
          style={styles.pollenCard}
          goTo={() => () => {}}
          postId={{
            content: locales.howPollenCard,
            createdAt: Date.now(),
            spreadCount: 85,
            readerCount: 99,
            commentCount: 42,
            from: {
              username: locales.nearbyLaowang,
              gender: 1,
            }
          }}
          abandon={this.onSecondPress}
          cast={this.onSecondPress}
        />
      </Animated.View>
    }
  };

  renderThird = () => {
    const {page, realPage} = this.state;
    if (realPage === 3) {
      const opacity = this.state.page.interpolate({inputRange: [2, 3], outputRange: [0, 1]});
      return <Animated.View style={[styles.section, {opacity, transform: [{scale: opacity}]}]}>
        <Text style={styles.title}>{locales.pollenSuccess}</Text>
        <Text style={styles.text}>{locales.howPollenFinish}</Text>
        <NormalButton style={styles.button} text={locales.gotoPollen} onPress={this.onRequestClose}/>
      </Animated.View>
    }
  };


  render() {
    const {show} = this.state;
    if (!show) return <View/>;
    // 计算guide啦！

    return (
      <View style={styles.userGuide}>

        {this.renderFirst()}
        {this.renderSecond()}
        {this.renderThird()}
        <TouchableOpacity style={styles.skip} onPress={this.onRequestClose}>
          <Text>{this.state.realPage}/3 {locales.skipGuide}</Text>
        </TouchableOpacity>

      </View>
    );
  }

}
