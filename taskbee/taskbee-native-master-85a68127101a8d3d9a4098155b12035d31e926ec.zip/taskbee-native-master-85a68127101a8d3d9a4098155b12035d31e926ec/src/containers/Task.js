import React, {
  PropTypes,
  Component,
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';

import {
  MainTab,
  NormalButton,
  TaskItem,
  LoadingIndicator,
} from '../components';

import ScrollableTabView from 'react-native-scrollable-tab-view';

import {
  Home,
  News,
  Me,
  Deferred,
} from './index';

import {Map} from 'immutable';
import { connect } from 'react-redux';
import {getTasks} from '../modules/me';
import config from '../config';
import {goTo} from '../utils/navigation';
import {mdl} from 'react-native-material-kit';
import {onFavClick} from '../utils/componentEvents';
import {fav, unfav} from '../modules/task';
import connectData from '../libs/connectData';

const styles = StyleSheet.create({

  needLogin: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
    margin: config.normalPadding,

  },
  needLoginText: {
    fontSize: config.fontLarge,
    color: config.colorMain,
    margin: config.normalPadding,
  },
  button: {
    alignSelf: 'stretch',
  },
  pannels: {
    flexDirection: 'row',
  },
  taskPannel: {
    flex: 1,
    borderRadius: 0,
  },
  task: {
    flex: 1,
  },
  container: {
    flex: 1,

  },
  realTask: {
  },
  taskSection: {
    marginVertical: config.normalPadding,
  },
  mainLabel: {
    color: config.colorStand,
    fontSize: config.fontBig,
    margin: 12,
  },
  nothingText: {
    marginLeft: 12,
  },
  extraError: config.styleExtraError,

});


import locales from '../locales';

class Tasks extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
    user: PropTypes.object,
    tasks: PropTypes.object.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    onFavClick: PropTypes.func.isRequired,
    getTasks: PropTypes.func.isRequired,
    // arriveTask: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);

    /* 载入我的任务
    if (props.user) props.getTasks();
    */
  }

  goTo = goTo.bind(this);
  onFavClick = onFavClick.bind(this);

  renderTaskSection = (label, key, nothingText) => {
    const taskIds = this.props.user.get(key);
    let content;
    if (this.props.tasks.size && taskIds && taskIds.length) {
      content = taskIds.map( id => {
        const immutalbeItem = this.props.tasks.get(id);
        if (immutalbeItem) {
          const item = immutalbeItem.toJS();
          if (item._id) return <TaskItem key={id} {...item} navigator={this.props.navigator} meId={this.props.meId} onFavClick={this.onFavClick(id)} myPos={[this.props.long, this.props.lati]}/>;
        } else return <View key={id}/>;
      });
    } else {
      content = <Text style={styles.nothingText}>{nothingText}</Text>;
    }
    return (<View style={styles.taskSection}>
      <Text style={styles.mainLabel}>{label}</Text>
      {content}
    </View>);
  };

  render() {
    if (!this.props.user) {
      return (
        <View style={styles.needLogin}>
          <Text style={styles.needLoginText}>{locales.onlyAfterLoginMyTask}</Text>
          <NormalButton style={styles.button} onPress={this.goTo('Join')} text={locales.goLoginAndReg} />
        </View>
      );
    }
    const {navigator, tasks, loading, user, error} = this.props;
    return (
      <View style={styles.container}>
        <View style={styles.pannels}>
          <NormalButton style={styles.taskPannel} type={1} text={locales.historyTasks} onPress={this.goTo('HistoryTasks')}/>
          <NormalButton style={styles.taskPannel} type={1} text={locales.likedTasks} onPress={this.goTo('FavTasks')}/>
        </View>
        <ScrollView
          style={styles.task}
          contentContainerStyle={styles.realTask}
          refreshControl={config.isIOS ? null :
            <RefreshControl
              colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
              refreshing={loading} onRefresh={this.props.getTasks}/>
          }
        >

          {error && <Text style={styles.extraError}>{error.message || config.networkError} </Text>}
          {this.renderTaskSection(locales.takenTasks, 'taskTaken', locales.noTakenTask)}
          {this.renderTaskSection(locales.publishedTasks, 'taskPublish', locales.noPublishedTask)}

        </ScrollView>

      </View>
    );
  }
}

function fetchDataCustom(getState, dispatch) {
  console.log('fetch tasks');
  if (getState().me.get('data')) {
    dispatch(getTasks());
  }
}

export default connectData(fetchDataCustom)(connect(state => ({
  user: state.me.get('data'),
  tasks: state.task,
  loading: state.me.get('gettingTasks'),
  error: state.me.get('getTasksError'),
  token: state.me.get('token'),
  meId: state.me.get('meId'),
  long: state.lbs.get('longitude'),
  lati: state.lbs.get('latitude'),
}), {getTasks, onFavClick, fav, unfav})(Tasks))
