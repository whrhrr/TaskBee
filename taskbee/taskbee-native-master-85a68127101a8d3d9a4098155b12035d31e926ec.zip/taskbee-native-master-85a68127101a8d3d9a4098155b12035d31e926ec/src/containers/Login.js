import React, {
  StyleSheet,
  Component,
  PropTypes,
  View,
  Text,
} from 'react-native';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from '../utils/userValidation';

import {login} from '../modules/me';

import {
  NormalButton,
  TextInput,
  SubtleButtons,
} from '../components';
import config from '../config';
import locales from '../locales';

import {goTo} from '../utils/navigation';

import {serverError} from '../utils/dataHelpers';

const styles = StyleSheet.create({
  login: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
  },
  cta: {
    marginTop: 24,
    paddingHorizontal: config.normalPadding,
  },
  extraError: config.styleExtraError,
});

class Login extends Component {
  static propTypes = {
    loggingIn: PropTypes.bool,
    login: PropTypes.func.isRequired,
    loginError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    invalid: PropTypes.bool.isRequired,
    valid: PropTypes.bool.isRequired,
  };

  onSubmit = () => {
    const {loggingIn, valid} = this.props;
    if (!loggingIn && valid) {
      this.props.login({phone: this.props.fields.phone.value, password: this.props.fields.password.value});
    }
  };

  focusNextField = (toFocus) => {
    return () => {
      this.refs[toFocus].focus();
    }
  };

  goTo = goTo.bind(this);

  render() {
    const {
        fields: {phone, password},
        loggingIn,
        valid,
        invalid,
        loginError,
      } = this.props;

    const errorFunc = serverError(loginError);

    return (
      <View style={styles.login}>
        <TextInput
          keyboardType="phone-pad"
          blurOnSubmit={false}
          onSubmitEditing={this.focusNextField('0')}
          autoFocus
          label={locales.phone}
          placeholder={locales.phonePlaceholder}
          serverError={errorFunc('phone')} {...phone} />
        <TextInput
          onSubmitEditing={this.onSubmit}
          ref="0"
          isPassword label={locales.password}
          placeholder={locales.passwordPlaceholder}
          serverError={errorFunc('password')} {...password} />
        <View style={styles.cta}>
          <NormalButton onPress={this.onSubmit} text={locales.login} working={loggingIn} disabled={invalid}/>
        </View>
        {loginError && !loginError.errorCode && <Text style={styles.extraError}>{loginError.message || '迷的错误'}</Text>}
        <SubtleButtons leftText={locales.forgetPassword} leftTo={this.goTo('Forget')} rightText={locales.register} rightTo={this.goTo('Register')}/>
      </View>
    );
  }
}

export default  reduxForm({
  form: 'user',
  fields: ['phone', 'password'],
  validate: userValidation
})(
  connect(
  state => ({
    loggingIn: state.me.get('logining'),
    loginError: state.me.get('loginError'),
  }),
  {login})(
    Login
  )
)

