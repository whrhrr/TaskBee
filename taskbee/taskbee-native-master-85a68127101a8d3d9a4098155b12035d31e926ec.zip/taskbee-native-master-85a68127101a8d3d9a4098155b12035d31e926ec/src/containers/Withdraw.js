import React, {
  Component,
  PropTypes,
  View,
  StyleSheet,
} from 'react-native';

import {
  Banner,
  NormalButton,
  Spinner,
  TextInput,
  Text,
} from '../components';

import {connect} from 'react-redux';

import {withdraw, confirmWithdraw} from '../modules/order';

import withdrawValidation from '../utils/withdrawValidation';

import {reduxForm} from 'redux-form';
import {serverError} from '../utils/dataHelpers';
import config from '../config';
const styles = StyleSheet.create({
  withdraw: {
    marginTop: config.bannerHeight,
    paddingVertical: config.normalPadding,
  },
  remaining: {
    color: config.colorMain,

    margin: config.normalPadding,
  },
  subtle: {
    alignSelf: 'stretch',
    textAlign: 'center',
    marginVertical: 9,
  },
  button: {
    alignSelf: 'center',
    marginTop: 3,
  },
  error: config.styleExtraError,
  success: {
    alignSelf: 'center',
    justifyContent: 'center',
    padding: config.normalPadding,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  mainTitle: {
    color: config.colorMain,
    fontSize: config.fontBig,
  }
});

class Withdraw extends Component {
  static propTypes = {
    user: PropTypes.object,
    token: PropTypes.string,
    withdrawing: PropTypes.bool,
    withdrawError: PropTypes.any,
    withdrawSuccess: PropTypes.bool,
    fields: PropTypes.object.isRequired,
    withdraw: PropTypes.func.isRequired,
    confirmWithdraw: PropTypes.func.isRequired,
    invalid: PropTypes.bool.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    initializeForm: PropTypes.func.isRequired,
  };

  componentDidMount() {
    const {user} = this.props;
    this.props.initializeForm({
      money: user.get('money').toString(),
      realname: user.get('realname'),
    });
  }

  onSubmit = (data) => {
    data.preventDefault();
    const {withdrawing} = this.props;
    if (!withdrawing) {
      this.props.handleSubmit(this.prepareToSubmit)(data);
    }
  };

  prepareToSubmit = (data) => {
    data.token = this.props.token;
    this.props.withdraw(data);
  };

  render() {
    const {fields: {money, email, realname}, invalid,
      user, withdrawing, withdrawError, withdrawSuccess} = this.props;
    const errorFunc = serverError(withdrawError);
    return (
      <View style={styles.withdraw}>
        {withdrawSuccess ? <View style={styles.success}>
            <Text style={styles.mainTitle}>提交提款成功！</Text>
            <Text>预计5个工作日内到账！</Text>
            <NormalButton style={styles.button} onPress={this.props.confirmWithdraw} text="OK">
            </NormalButton>
          </View>
          :
          <View>
            <Text style={styles.remaining}>钱包余额：¥{user.get('money')}</Text>
            <TextInput keyboardType="numeric" label="金额" placeholder="请输入提款金额" serverError={errorFunc('money')} {...money} />
            <TextInput label="支付宝" placeholder="请输入支付宝账户" serverError={errorFunc('email')} {...email} />
            <TextInput label="姓名" placeholder="请输入对应支付宝的姓名以确保提款安全" serverError={errorFunc('realname')} {...realname} />
            <Text style={styles.subtle}>10元及以上可以提款 预计5个工作日内到账</Text>
            <NormalButton style={styles.button} working={withdrawing} text="提款" disabled={invalid} onPress={this.onSubmit}>
            </NormalButton>
            {withdrawError && !withdrawError.errorCode && <Text style={styles.error}>{withdrawError.message || '网络错误，请稍候重试'}</Text>}
          </View>
        }
      </View>
    );
  }
}

export default reduxForm({
  form: 'user',
  fields: ['money', 'email', 'realname'],
  validate: withdrawValidation,
})(
  connect(
    state => ({
      user: state.me.get('data'),
      token: state.me.get('token'),
      withdrawing: state.order.withdrawing,
      withdrawSuccess: state.order.withdrawSuccess,
      withdrawError: state.order.withdrawError,
    }), {withdraw, confirmWithdraw}
  )(
    Withdraw
  )
)
