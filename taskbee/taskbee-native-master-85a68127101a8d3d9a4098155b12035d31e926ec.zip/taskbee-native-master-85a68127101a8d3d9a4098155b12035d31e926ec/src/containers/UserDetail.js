import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  RefreshControl,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import {connect} from 'react-redux';

import {
  Avatar,
  ImageViewer,
  Gender,
  LoadingIndicator,
  NormalButton,
  VoteItem,
  Rating,
  Icon,
  Tag,
  Text,
} from '../components';

import connectData from '../libs/connectData';
import {loadUserDetail, like, unfriend} from '../modules/user';
import {mdl} from 'react-native-material-kit';
const {width: windowWidth} = Dimensions.get('window');

import {goTo, requireLogin} from '../utils/navigation';
const {Spinner} = mdl;
import config from '../config';
import locales from '../locales';
import styles from './UserDetailStyles';

function fetchDataDeferred(getState, dispatch, passProps) {
  const {userId} = passProps;
  return dispatch(loadUserDetail(userId));
}

class UserDetail extends Component {
  static propTypes = {
    user: PropTypes.object,
    loadUserDetail: PropTypes.func.isRequired,
    userId: PropTypes.string,
    loading: PropTypes.bool,
    loadError: PropTypes.any,
    navigator: PropTypes.object.isRequired,
    like: PropTypes.func.isRequired,
    unfriend: PropTypes.func.isRequired,
    token: PropTypes.string,
    meId: PropTypes.string,
  };

  goTo = goTo.bind(this);
  requireLogin = requireLogin.bind(this);

  onImageClick = () => {
    if (this.props.user.get('avatar')) {
      this.goTo('ImageView', {images: [{key: this.props.user.get('avatar'), height: windowWidth, width: windowWidth }], initial: 0})();
    }
  };

  onModalClose = () => {
    this.setState({showImage: false});
  };

  onRetryClick = () => {
    if (!this.props.loading) this.props.loadUserDetail(this.props.userId);
  };

  onLikeClick = this.requireLogin(() => {
    if (!this.props.user.get('liking')) { // 未感兴趣
      this.props.like({toLike: this.props.userId, token: this.props.token});
    }
  });

  onUnfriendClick = this.requireLogin(() => {
    if (!this.props.user.get('unfriending')) { // 未感兴趣
      this.props.unfriend({toUnfriend: this.props.userId, token: this.props.token});
    }
  });;

  render() {
    const {meId, userId, history, user: immuUser, loading, loadError} = this.props;
    const user = immuUser ? immuUser.toJS() : {};
    let likeMessage;
    if (user.friended) {
      likeMessage = locales.friended;
    } else if (user.liked) {
      likeMessage = locales.interestedIn;
    } else {
      likeMessage = locales.notIntersted;
    }
    return (
      <ScrollView
        style={styles.userDetail}
        // ref="scroll"
        refreshControl={config.isIOS ? null :
           <RefreshControl
            colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
            refreshing={loading === undefined ? true : loading} onRefresh={this.onRetryClick}/>
        }
      >
        {
          loadError && <View style={styles.error}>
            <Text>{loadError.message || locales.strangeError}</Text>
            <NormalButton onPress={this.onRetryClick} text={locales.retry}/>
          </View>
        }
        {/*
          user.avatar ? <ImageViewer show={this.state.showImage} index={0} onRequestClose={this.onModalClose} images={[{key: user.avatar}]}/> : null
        */}
        <View style={styles.info}>
          <TouchableOpacity style={styles.image} onPress={this.onImageClick}>
            <Avatar src={user.avatar} size={60}/>
          </TouchableOpacity>
          { user.accountType === 1 ? <Tag style={styles.confirmed} name={locales.veryfiyEvent}/> : null}
          { user.accountType === 2 ? <Tag style={styles.confirmed} name={locales.officialAccount}/> : null}
          <TouchableOpacity style={styles.reportButton} onPress={this.requireLogin(this.goTo('Report', {itemId: userId, type: 2}))}>
            <Text style={styles.report}>{locales.report}</Text>
          </TouchableOpacity>
          {/* <View style={styles.school}>来自{schoolMap[user.schoolId]}</View> */}
          <Text style={styles.username}>{user.username}<Gender style={styles.gender} gender={user.gender} /></Text>
          {user.voteCount ? <Rating value={user.voteScore / user.voteCount}/> : null}
          <Text style={styles.signature}>{user.signature || locales.noSignature}</Text>
          <View style={styles.misc}>
            <View style={styles.miscSection}>
              <Text style={styles.miscCount}>{user.likedCount || 0}</Text>
              <Text style={styles.miscTitle}>{locales.interested}</Text>
            </View>
            <View style={styles.miscSection}>
              <Text style={styles.miscCount}>{user.countTotalTaken || 0}</Text>
              <Text style={styles.miscTitle}>{locales.takenTasks}</Text>
            </View>
            <View style={styles.miscSection}>
              <Text style={styles.miscCount}>{user.countTotalPublish || 0}</Text>
              <Text style={styles.miscTitle}>{locales.publishedTasks}</Text>
            </View>
            <View style={styles.miscSection}>
              <Text style={styles.miscCount}>{user.score || 0}</Text>
              <Text style={styles.miscTitle}>{locales.honey}</Text>
            </View>
          </View>
        </View>
        {
          // 操作
          meId === userId ? null :
          <View style={styles.interest}>
            <TouchableOpacity style={styles.fav} onPress={this.onLikeClick}>
              <Icon name={ user.liked ? 'heart-1' : 'heart-o'} color={config.brandRed} size={24}/>
            </TouchableOpacity>
             <Text style={user.friended ? styles.friended : null}>{likeMessage}</Text>
             {user.liking ? <Spinner/> : null}
             {user.likeError ? <Text>{user.likeError.message || locales.strangeError}</Text> : null}
             {
               user.friended ?  <NormalButton onPress={this.goTo('Chat', {userId: user._id})} text="私信对方"/>
               : null
             }
             <Text style={styles.subtle}>{locales.descLike}</Text>
          </View>
        }

        <View style={styles.vote}>
          <Text style={styles.voteTitle}>{locales.votes}</Text>
          <View style={styles.votes}>
          {
            user.votes && user.votes.length ? user.votes.map( vote => <VoteItem key={vote._id} {...vote} goTo={this.goTo}/>)
            : <Text style={styles.nothing}>{locales.noVoteYet}</Text>
          }
          </View>
        </View>
      </ScrollView>
    );
  }
}

export default connectData(fetchDataDeferred)(
  connect(
    (state, props) => {
      const {userId} = props;
      return {
        user: state.user.get(userId),
        // meUser: state.me.get('data'),
        loading: state.user.get('loadingUser'),
        loadError: state.user.get('loadUserError'),
        token: state.me.get('token'),
        meId: state.me.get('meId'),
        userId,
      };
    },
    {loadUserDetail, like, unfriend}
  )(
    UserDetail
  )
)


