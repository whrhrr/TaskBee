import React, {
  Component,
  PropTypes,
  StyleSheet,
  View,
  ListView,
  Dimensions,
} from 'react-native';

const {height} = Dimensions.get('window');

import {
  FriendItem,
  Text,
} from '../components';
import {connect} from 'react-redux';
import {loadFriends} from '../modules/me';
import connectData from '../libs/connectData';
import config from '../config';
import locales from '../locales';
import {goTo, requireLogin} from '../utils/navigation';

const styles = StyleSheet.create({
  friends: {
    marginTop: config.bannerHeight,
    flex: 1,
  },
  notFound: {
    flex: 1,
    justifyContent: 'center',
    marginTop: height / 2 - 120,
    marginHorizontal: config.normalPadding,
  },
  notMain: {
    color: config.colorMain,
    fontSize: config.fontBig,
    marginBottom: 9,
    textAlign: 'center',
  },
  red: {
    color: config.brandRed,
  },
  para: {
    marginBottom: 3,
  }
});

function fetchDataDeferred(getState, dispatch) {
  return dispatch(loadFriends());
}


class Friends extends Component {
  static propTypes = {
    friends: PropTypes.array.isRequired,
    loadFriends: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (item1, item2) => item1 !== item2 });
    this.state = {
      dataSource: ds.cloneWithRows(props.friends),
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.friends.length !== nextProps.friends.length) {
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(nextProps.friends),
      });
    }
  }

  goTo = goTo.bind(this);

  renderRow = (friend) => {
    return <FriendItem goTo={this.goTo} {...friend}/>;
  };

  renderFooter = () => {
    if (!this.props.friends.length) {
      return <View style={styles.notFound}>
        <Text style={styles.notMain}>{locales.noFriendsYet}</Text>
        <Text style={styles.para}>在蜂房里看到感兴趣的头像就快快点进去点亮<Text style={styles.red}>❤</Text>吧～</Text>
        <Text style={styles.para}>记得在蜂房里留下你的足迹嗡～</Text>
        <Text style={styles.para}>若是对方也看到了你的头像并点亮了<Text style={styles.red}>❤</Text> ，你们就成为FF好友啦～</Text>
      </View>
    }
  };

  render() {
    return (
      <ListView
        style={styles.friends}
        dataSource={this.state.dataSource}
        renderRow={this.renderRow}
        renderFooter={this.renderFooter}
      />
    );
  }
}

export default connectData(fetchDataDeferred)(
  connect(state => {
    return {
      friends: state.me.get('friends'),
      loading: state.me.get('loadingUser'),
      error: state.me.get('loadingUserError'),
    };
  }, {loadFriends})(
    Friends
  )
)
