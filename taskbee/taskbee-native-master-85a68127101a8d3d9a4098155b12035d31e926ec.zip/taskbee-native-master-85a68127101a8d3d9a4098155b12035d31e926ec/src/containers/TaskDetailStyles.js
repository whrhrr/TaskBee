
import React, {
  StyleSheet,

} from 'react-native';

import config from '../config';

export default StyleSheet.create({
  error: {
    margin: config.normalPadding,
    alignItems: 'center',
    justifyContent: 'center',
  },
  errorMessage: config.styleExtraError,
  scrollView: {
    flex: 1,
    borderTopWidth: config.borderWidth,
    borderColor: config.colorBorder,
  },
  taskDetail: {
    flex: 1,
    paddingTop: config.bannerHeight,
  },

  additional: {
    justifyContent: 'center',
    alignItems: 'center',
    margin: config.normalPadding,
  },
  additionalAvatar: {
    marginBottom: 9,
  },
  user: {
    color: config.colorMain,
  },
  big: {
    fontSize: config.fontBig,
  },
  plainWait: {
    marginTop: 9,
    marginBottom: 0,
  },
  mainView: {
    flex: 1,
    paddingHorizontal: config.normalPadding,
    borderBottomWidth: config.borderWidth,
    borderBottomColor: config.colorBorder,
  },
  taskStatus: {
    backgroundColor: '#fff',

  },

  info: {
    marginVertical: config.normalPadding,
    padding: config.normalPadding,
    backgroundColor: '#fff',
  },
  words: {
    color: config.colorMain,
  },
  misc: {
    margin: 12,
    padding: 12,
    marginBottom: 0,
    paddingBottom: 0,
    borderTopWidth: config.borderWidth,
    borderTopColor: config.colorBorder,
    flexDirection: 'row',
  },
  miscRow: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  miscRowBorder: {
    borderLeftWidth: config.borderWidth,
    borderRightColor: config.colorBorder,
    borderRightWidth: config.borderWidth,
    borderLeftColor: config.colorBorder,
    marginHorizontal: 12,
    paddingHorizontal: 12,
  },

  cancelTask: {
    alignItems: 'center',
    paddingBottom: config.normalPadding,
  },
  fav: {
    marginTop: config.normalPadding,
    flexDirection: 'row',
  },
  favBy: {
    position: 'relative',
    width: 30,
    height: 30,
    marginRight: 3,
    marginBottom: 3,
  },
  decorationIcon: {
    position: 'absolute',
    right: 0,
    top: 0,
    color: config.brandRed,
  },

  title: {
    color: config.colorMain,
  },

  publisher: {
    marginHorizontal: config.normalPadding,
    flexDirection: 'row',
  },
  userInfo: {
    marginLeft: config.normalPadding,
    flex: 1,
  },


  comments: {
    marginVertical: config.normalPadding,
  },
  empty: {
    marginLeft: config.normalPadding,
  },
  sectionTitle: {
    marginLeft: config.normalPadding,
    color: config.colorStand,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  controls: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderTopWidth: config.borderWidth,
    borderTopColor: config.colorBorder,
  },
  withError: {
    paddingTop: 24,
    height: 84,
  },
  goError: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    paddingTop: 5,
  },
  goErrorText: {
    color: config.brandRed,
  },
  controlFav: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 6,
  },
  favCount: {

  },
  controlButton: {
    flex: 1,
    marginHorizontal: 6,
  },
  controlButton2: {
    flex: 2,
    marginHorizontal: 6,
  },
  distanceButton: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  distance: {
    fontSize: config.fontSmall,
    marginTop: 3,
  },
  locAndReport: {
    flexDirection: 'row',
  },
  reportButton: {
    alignSelf: 'flex-end',
  },
  report: {
    fontSize: config.fontSmall,
    color: config.colorSubtle,
  },
});
