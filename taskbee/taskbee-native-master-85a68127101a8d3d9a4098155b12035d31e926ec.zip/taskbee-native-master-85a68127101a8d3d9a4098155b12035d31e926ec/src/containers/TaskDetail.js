'use strict';

import React, {
  PropTypes,
  Component,
  StyleSheet,
  View,
  ScrollView,
  RefreshControl,
  Alert,
  TouchableOpacity,
  Platform,
  Dimensions,
  Clipboard,
} from 'react-native';

import {
  Gender,
  Avatar,
  Timeline,
  NormalButton,
  LoadingIndicator,
  Comment,
  CommentInput,
  Icon,
  SimpleImages,
  Text,
} from '../components';

import {
} from './index';

import connectData from '../libs/connectData';

import { connect } from 'react-redux';

import {loadDetail, startComment, stopComment, take, confirmTasker, confirmPublisher, cancelPuber, cancelTasker} from '../modules/task';
import {fav, unfav} from '../modules/task';
import {onFavClick} from '../utils/componentEvents';
import config from '../config';

import moment from 'moment';
import {calcCrow} from '../utils/dataProcessor';
import {goTo, requireLogin} from '../utils/navigation';

import {MKButton, mdl} from 'react-native-material-kit';
import toast from '../libs/toast';

import locales from '../locales';

const {Spinner} = mdl;
const {height,weight} = Dimensions.get('window');

const publisherStateToButton = {
  0: locales.waitForTaking,
  1: locales.confirmCompletionEarlier,
  2: locales.confirmCompletion,
  3: locales.state3 + '\(￣▽￣)/',
  4: locales.state4,
  5: locales.state5,
};

const taskerStateToButton = {
  0: locales.meTake,
  1: locales.confirmCompletion,
  2: locales.state2,
  3: locales.finishAndThanks,
  4: locales.state4,
  5: locales.state5,
};

const normalStateToButton = {
  0: locales.meTake,
  1: locales.takenAndLate,
  2: locales.state2,
  3: locales.state3,
  4: locales.state4,
  5: locales.state5,
};

const stateToDescription = {
  0: locales.descTake,
  1: locales.descCompletion,
  2: locales.descConfirm,
};


import styles from './TaskDetailStyles';

class TaskDetail extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
    user: PropTypes.object,
    commentOpen: PropTypes.bool,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    startComment: PropTypes.func.isRequired,
    stopComment: PropTypes.func.isRequired,
    meId: PropTypes.string,
    task: PropTypes.object,
    dueTime: PropTypes.string,
    startTime: PropTypes.string,
    taskId: PropTypes.string,
    token: PropTypes.string,
    take: PropTypes.func.isRequired,
    confirmTasker: PropTypes.func.isRequired,
    confirmPublisher: PropTypes.func.isRequired,
    cancelTasker: PropTypes.func.isRequired,
    cancelPuber: PropTypes.func.isRequired,
    loadDetail: PropTypes.func.isRequired,
  };

  constructor(props){
    super(props);
    this.state = {
      to: null,
      keyboardHeight: 0,
    };
    this.keyboardSettings = config.isIOS ? {
      onKeyboardWillShow: this.onKeyboardWillShow,
      onKeyboardWillHide: this.onKeyboardWillHide,
    } : {
      onKeyboardDidShow: this.onKeyboardWillShow,
      onKeyboardDidHide: this.onKeyboardWillHide,
    }
  };


  componentDidMount() {
    if (this.props.isComment) {
      console.warn('is comment');
      setTimeout(this.scrollToBottom, 200);
    }
  }

  componentWillReceiveProps(nextProps) {
    // 评论成功后拉到页面底部
    if (!this.props.task) return;
    if (!this.props.task.get('commentSuccess') && nextProps.task.get('commentSuccess')) {
      setTimeout(() => {
        this.scrollToBottom();
      }, 200);

    }
  }



  reload = () => {
    if (!this.props.task.get('loadDetail')) {
      this.props.loadDetail(this.props.taskId);
    }
  };
  goTo = goTo.bind(this);
  onBindedFavClick = onFavClick.bind(this);
  requireLogin = requireLogin.bind(this);

  scrollToBottom = () => {
    if (config.isIOS) {
      if (this.footerY) {
        const scrollDistance = this.footerY - height + this.state.keyboardHeight  + 60 + config.bannerHeight;
        if (scrollDistance > 0) this.refs.scroll.scrollTo({y: scrollDistance});
      }
    } else {
      this.refs.scroll.scrollTo({y: 9999999});
    }
  };

  onCommentClick = this.requireLogin(() => {
    this.props.startComment({taskId: this.props.taskId});
  });


  onCommentSelect = (from) => {
    return () => {
      if (this.props.token) {
        this.setState({
          to: {
            id: from._id,
            username: from.username
          }
        });
        this.props.startComment({taskId: this.props.taskId});
      }
    };
  };

  onCommentClose = () => {
    this.props.stopComment({taskId: this.props.taskId});
    this.setState({
      to: null
    });
  };


  onCancelClick = () => {
    const task = this.props.task;
    const cancelling = task.get('cancelling');
    if (cancelling) return;
    const taskId = task.get('_id');
    const tasker = task.get('tasker');
    const publisher = task.get('publisher');
    const {token, meId} = this.props;
    let cancelText;
    let cancelDescription;
    let onPress;
    if (tasker && tasker === meId) {
      cancelText = locales.giveUpTask;
      cancelDescription = '中途放弃任务对于任务发布者是不小的麻烦，并且会降低蜂蜜，最好和任务发布者提前取得联系，进行通知，是否要放弃任务？';
      onPress = () => this.props.cancelTasker({taskId, token});
    } else if (publisher._id === meId) {
      cancelText = locales.cancelTask;
      cancelDescription = '如果任务已经有人接手，取消任务会减少蜂蜜，最好提前和任务进行人提前取得联系，是否要取消任务？';
      onPress = () => this.props.cancelPuber({taskId, token});
    }
    Alert.alert(cancelText, cancelDescription, [
      {text: locales.no},
      {text: cancelText, onPress: onPress},
    ]);
  };

  onComplexClick = this.requireLogin(() => {
    const {task, token, meId} = this.props;
    const taskId = task.get('_id');
    const state = task.get('state');
    const ongoing = task.get('ongoing');
    const tasker = task.get('tasker');
    if (!ongoing) {
      if (state === 0) {
        Alert.alert(locales.takeOrNot, '接手后，可以看到任务发布者的具体联系方式。接手任务后，请务必完成', [
          {text: locales.noTake},
          {text: locales.meTake, onPress: () => this.props.take({taskId, meId, token})},
        ]);
      } else if (state === 1) {
        if (meId === tasker) {
          Alert.alert(locales.confirmOrNot, '请确保已经完成了任务发布者的要求，确认后请让发布人确认，才能收到报酬', [
            {text: locales.noConfirm},
            {text: locales.confirmCompletion, onPress: () => this.props.confirmTasker({taskId, token})},
          ]);
        } else {
          Alert.alert(locales.confirmOrNot, '即将提前确认任务完成', [
            {text: locales.noConfirm},
            {text: locales.confirmCompletionEarlier, onPress: () => this.props.confirmPublisher({taskId, token})},
          ]);
        }
      } else if (state === 2) {
        Alert.alert(locales.confirmOrNot, '在确认完成后，对方将收到您的报酬～', [
          {text: locales.noConfirm},
          {text: locales.confirmCompletion, onPress: () => this.props.confirmPublisher({taskId, token})},
        ]);
      }
    }
  });

  onKeyboardWillShow = (e) => {
    if(config.isIOS) this.setState({keyboardHeight: e.endCoordinates ? e.endCoordinates.height : e.end.height});
    requestAnimationFrame(this.scrollToBottom);

  };

  onKeyboardWillHide = () => {
    if(config.isIOS) this.setState({keyboardHeight: 0});
    requestAnimationFrame(this.scrollToBottom);
  };

  onDescription = () => {
    Clipboard.setString(this.props.task.get('description'));
    toast(locales.textCopied);
  };

  copyPhone = () => {
    Clipboard.setString(this.props.user.get('phone'));
    toast(locales.phoneCopied);
  };

  renderAdditional = (user, secret) => {
    if (user) return (<View style={styles.additional}>
      <TouchableOpacity style={styles.additionalAvatar} onPress={this.goTo('UserDetail', {userId: user._id})}><Avatar src={user.avatar} size={60}/></TouchableOpacity>
      <Text style={[styles.user, styles.big]}>{user.username}<Gender style={styles.subtle} gender={user.gender}/></Text>
      <Text style={styles.user}>{user.description || locales.noSignature}</Text>
      <Text style={styles.user}>{locales.realname}：{user.realname || locales.anonymouse}</Text>
      <TouchableOpacity onPress={this.copyPhone}><Text style={styles.user}>{locales.phone}：{user.phone}</Text></TouchableOpacity>
      { secret !== undefined &&
        <View style={styles.secret}>
          <Text>{secret}</Text>
        </View>
      }
      <NormalButton onPress={this.goTo('Chat', {userId: user._id})} text={locales.sendPM}/>
    </View>);
  };

  renderInfo = (task) => {
    const {long, lati} = this.props;
    const {favBy, type, loc, imgs, canVote, secret,cancelling, cancelError, commentOpen, comments, tasker = {}, state, reward, favs, faved, _id: id, description, loadingDetail: loading, detailError } = task;
    const dueTime = moment(task.dueTime).format('MM/D HH:mm');
    const startTime = moment(task.startTime).format('MM/D HH:mm');
    return (<View style={styles.info}>
      <TouchableOpacity onPress={this.onDescription}><Text style={styles.words}>{description}</Text></TouchableOpacity>
      <View style={styles.locAndReport}>
        { loc ?
        <TouchableOpacity style={styles.distanceButton} onPress={this.goTo('MainMap', {coordinates: loc.coordinates})}>
          <Icon name="navigate" color={config.colorNormal}/>
          <Text style={styles.distance}>{calcCrow(loc.coordinates, [long, lati]).toFixed(1)}m</Text>
        </TouchableOpacity>
        : null}
        <TouchableOpacity style={styles.reportButton} onPress={this.requireLogin(this.goTo('Report', {itemId: this.props.task.get('_id'), type: 1}))}>
          <Text style={styles.report}>{locales.report}</Text>
        </TouchableOpacity>
      </View>
      {
        imgs && imgs.length ? <SimpleImages style={{justifyContent: 'center'}} imgs={imgs} goTo={this.goTo}/>
         : null
      }
      <View style={styles.misc}>
        <View style={styles.miscRow}>
          <Text style={styles.title}>{locales.startTime}</Text>
          <Text>{startTime}</Text>
        </View>
        <View style={[styles.miscRow, styles.miscRowBorder]}>
          <Text style={styles.title}>{locales.endDate}</Text>
          <Text>{dueTime}</Text>
        </View>
        <View style={styles.miscRow}>
          <Text style={styles.title}>{locales.reward}</Text>
          <Text><Text style={styles.yuan}>¥</Text>{reward}</Text>
        </View>
      </View>

      { favBy && favBy.length ? <ScrollView style={styles.fav} contentContainerStyle={{paddingRight: config.normalPadding * 2}} horizontal={true} showsHorizontalScrollIndicator={false}>
        {
          favBy.reverse().map( user => (
          <TouchableOpacity key={user._id} style={styles.favBy} onPress={this.goTo('UserDetail', {userId: user._id})}>
            <Avatar src={user.avatar} size={28}/>
            <Icon style={styles.decorationIcon} name="heart-1" size={9}/>
          </TouchableOpacity>
          ))
        }
        {favBy.length >= 30 ? <Text>...</Text> : null}
      </ScrollView>
      :
      null}
    </View>);
  };

  renderMiscInfos = (publisher) => {
    const {avatar, username, signature, score, gender} = publisher;
    return (<TouchableOpacity style={styles.publisher} onPress={this.goTo('UserDetail', {userId: publisher._id})}>
      <Avatar src={avatar} size={42}/>
      <View style={styles.userInfo}>
        <Text style={styles.big}>{username}<Gender gender={gender}/></Text>
        <Text style={styles.signature}>{signature || locales.noSignature}</Text>
      </View>
    </TouchableOpacity>);
  };

  renderComments = (comments, user) => {
    return (<View style={styles.comments}>
      <Text style={styles.sectionTitle}>{locales.comments}</Text>
      {
        comments && comments.length ?
        comments.map( (comment, index) => {
          if (!comment.from) {
            return <Comment key={index} {...comment} from={user} onCommentSelect={this.onCommentSelect} goTo={this.goTo}/>;
          }
          return <Comment key={index} {...comment} onCommentSelect={this.onCommentSelect} goTo={this.goTo}/>;
        })
        :
        <Text style={styles.empty}>{locales.leaveAComment}</Text>
      }
    </View>);
  };

  render() {
    const {long, lati, history, meId, user, task: _task} = this.props;
    const toJSedUser = user ? user.toJS() : null;
    const task = _task ? _task.toJS() : {};
    const {type, loc, imgs, canVote, secret, cancelling, cancelError, ongoing, goError, commentOpen, comments, publisher = {}, tasker = {}, state, reward, favs, faved, _id: id, description, loadingDetail: loading, detailError} = task;
    /*const {avatar, username, signature, score, gender} = publisher;*/

    let additional;
    let buttonText;
    let buttonDisabled;
    let voteEnabled;
    let canCancel;
    if (type === 1) {
      // 校园活动
      buttonDisabled = true;
      buttonText = locales.goPresence;
    } else if (meId === publisher._id) {
      // 我是任务发布人
      voteEnabled = canVote && canVote.indexOf(meId) > -1;
      if (state <= 2) {
         canCancel = true;
      }
      if ((state < 1 || state > 2) && !voteEnabled) {
        // 不能操作
        buttonDisabled = true;
      }
      buttonText = publisherStateToButton[state];
      if (state < 3 || tasker && tasker._id) {
        // 任务没有被取消，或者已经取消，但是有接单人
        additional = (<View style={styles.additional}>
        {
          tasker && tasker._id ? this.renderAdditional(tasker, secret)
          :
          <View style={styles.additional}>
            <Avatar style={styles.additionalAvatar}/>
            <Text style={[styles.user, styles.big, styles.plainWait]}>{locales.waitForTaking}</Text>
            { secret ?
              <View style={styles.secret}>
                <Text>{secret}</Text>
              </View>
              : null
            }
          </View>
        }
      </View>);
      }
    } else if (meId === tasker) {
      // 我是任务接手人
      voteEnabled = canVote && canVote.indexOf(meId) > -1;
      if (state !== 1 && !voteEnabled) {
        // 不是任务正在进行中
        buttonDisabled = true;
      }
      if (state === 1) {
        canCancel = true;
      }
      buttonText = taskerStateToButton[state];
      additional = this.renderAdditional(publisher, secret);
    } else {
      // 我是围观群众， 啥都不能干
      buttonText = normalStateToButton[state];

      if (state !== 0) {
        buttonDisabled = true;
      }
    }

    return (
      <View style={[styles.taskDetail, config.isIOS && this.state.keyboardHeight ? {paddingBottom: this.state.keyboardHeight} : null]}>
        <ScrollView
          ref="scroll"
          style={styles.scrollView}
          renderFooter={this.renderEmpty}
          refreshControl={config.isIOS ? null :
             <RefreshControl
              colors={[config.brandPrimary, config.brandGreen, config.brandBlue, config.brandRed]}
              refreshing={loading} onRefresh={this.reload}/>
          }
          {...this.keyboardSettings}
        >
          {
            detailError && <View style={styles.error}>
              <Text style={styles.errorMessage}>{detailError.message || locales.strangeError}</Text>
              <NormalButton onPress={this.onRetryClick} text={locales.retry}/>
            </View>
          }
          { // 渲染主要界面
            id && <View sytle={styles.mainView} onLayout={(e) => this.footerY = e.nativeEvent.layout.height}>
            <View style={styles.taskStatus}>
              {type === 1 ? null : <Timeline state={state}/>}
              {additional}
              {canCancel && <TouchableOpacity style={styles.cancelTask} onPress={this.onCancelClick}>
                  {cancelling ? <Spinner/> : <Text style={styles.cancelText}>{locales.cancelTask}</Text>}
              </TouchableOpacity>}
            </View>
              {this.renderInfo(task)}
              {this.renderMiscInfos(publisher)}
              {this.renderComments(comments, toJSedUser)}

            </View>
          }
        </ScrollView>
        {
          // 底部按钮
          commentOpen ? <View style={styles.controls}>
            <CommentInput
             onCommentClose={this.onCommentClose}
             taskId={id}
             to={this.state.to}
            />
          </View>
          :
            id && <View style={[styles.controls, goError && styles.withError]}>
            { goError && <View style={styles.goError}><Text style={styles.goErrorText}>{goError.message || locales.failed}</Text></View>}
            <TouchableOpacity style={styles.controlFav} onPress={this.onBindedFavClick(id, task)}>
              <Icon
                color={faved ? config.brandRed : config.colorLessSubtle}
                size={23}
                name={faved ? 'heart-1': 'heart-o'}/>
              {favs !== undefined ? <Text style={styles.favCount}>{favs}</Text> : null}
            </TouchableOpacity>
            <NormalButton style={styles.controlButton} onPress={this.onCommentClick} text={locales.comment}/>
            {voteEnabled ? <NormalButton style={styles.controlButton2} onPress={this.goTo('Vote', {taskId: id})} text={locales.vote}/>
            :
            <NormalButton style={styles.controlButton2} disabled={buttonDisabled} onPress={this.onComplexClick} text={buttonText} working={ongoing}/>
            }
          </View>
        }
      </View>
    );
  }
}

function fetchData (getState, dispatch, passProps) {
  dispatch(loadDetail(passProps.taskId));
};

export default connectData(fetchData)(
  connect(
    (state, props) => {
      return {
        task: state.task.get(props.taskId),
        user: state.me.get('data'),
        meId: state.me.get('meId'),
        token: state.me.get('token'),
        long: state.lbs.get('longitude'),
        lati: state.lbs.get('latitude'),
      };
  }, { loadDetail, fav, unfav, startComment, stopComment, take, confirmTasker, confirmPublisher, cancelPuber, cancelTasker})(
    TaskDetail
  )
)
