import React, {
  Component,
  View,
  PropTypes,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import {connect} from 'react-redux';

import {setHomeTab} from '../modules/misc';
import {goTo} from '../utils/navigation';

import {
  NormalButton,
  Text,
  TabBanner,
  Icon,
} from '../components';

import {
  Home,
  Task,
} from '../containers';
import locales from '../locales';
const styles = StyleSheet.create({
  fullHeight: {
    flex: 1,
  }
});
class RealHome extends Component {
  static propTypes = {
    navigator: PropTypes.object.isRequired,
  };

  goTo = goTo.bind(this);

  render() {
    const {navigator, active} = this.props;
    return (<View  style={styles.fullHeight} >
      <TabBanner
        items={[
          {
            text: locales.nearbyTasks,
            onPress: () => this.props.setHomeTab(0),
          },
           {
            text: locales.myTasks,
            onPress:  () => this.props.setHomeTab(1),
          }
        ]}
        active={active}
        rightButton={{
          onPress: this.goTo('Mapbox'),
          children: <Icon name="map" size={24} color={"rgba(0,0,0,.6)"}/>
        }}
      />
      {
        active === 0 ? <Home style={styles.fullHeight} navigator={navigator}/>
        : <Task navigator={navigator}/>
      }
    </View>);
  }
  static fetchData(getState, dispatch, passProps) {
    Home.fetchData(getState, dispatch, passProps);
    Task.fetchData(getState, dispatch, passProps);
  }
}

export default connect(state => ({
  active: state.misc.homeTab
}), {setHomeTab}
)(RealHome);
