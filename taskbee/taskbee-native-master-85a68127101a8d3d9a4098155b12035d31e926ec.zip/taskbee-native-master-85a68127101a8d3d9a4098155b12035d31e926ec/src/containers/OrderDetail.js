import React, {
  Component,
  PropTypes,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
} from 'react-native';
import {connect} from 'react-redux';
import {
  Banner,
  LoadingIndicator,
  NormalButton,
  Icon
} from '../components';
import connectData from '../libs/connectData';
import {loadOrderDetail} from '../modules/order';
import {orderStateMap} from '../utils/dataMap';

import config from '../config';
const styles = StyleSheet.create({
  orderDetail: {
    marginTop: config.bannerHeight,
    flex :1,
  },
  error: {
    alignSelf: 'center',
  },
  info: {
    backgroundColor: '#fff',
    alignItems: 'center',
    padding: config.normalPadding,
  },
  mainTitle: {
    fontSize: config.fontBig,
    color: config.colorMain,
  },
  price: {
    fontSize: config.fontLarge,
    color: config.brandGreen,
    marginVertical: config.normalPadding,
    fontWeight: 'bold',
  },
  pay: {
    marginTop: 12,
  },
  payText: {
    color: '#fff',
  },
  errorMessage: config.styleExtraError,
  disclaimer: {
    backgroundColor: config.colorVerySubtle,
    borderRadius: config.borderRadius,
    marginTop: config.normalPadding * 2,
    padding: config.normalPadding,
    alignItems: 'center',
  },
  disTitle: {
    color: config.colorMain,
    marginBottom: 9,
  }
});

class OrderDetail extends Component {
  static propTypes = {
    order: PropTypes.object,
    loadOrderDetail: PropTypes.func.isRequired,
    orderId: PropTypes.string,
    loading: PropTypes.bool,
    loadError: PropTypes.any,
  };

  onRetryClick = () => {
    this.props.loadOrderDetail(this.props.orderId);
  };

  onPayPress = () => {
    Linking.openURL(this.props.order.link);
  };

  render() {
    const {order, loading, loadError} = this.props;

    return (
      <View style={styles.orderDetail}>
        {
          loading && <LoadingIndicator/>
        }
        {
          loadError && <View style={styles.error}>
            <Text style={styles.errorMessage}>{loadError.message || '迷的错误'}</Text>
            <NormalButton onPress={this.onRetryClick} text="重试"/>
          </View>
        }
        {
          order && order.title ? <View style={styles.info}>
            <Text style={styles.mainTitle}>{order.title}</Text>
            <Text style={styles.price}>¥{order.price}</Text>
            <Text style={styles.status}>状态: {orderStateMap[order.state]}</Text>
            {order.link && <NormalButton style={styles.pay} onPress={this.onPayPress}>
              <Text style={styles.payText}><Icon name="cn-alibabai-alipay"/> 去支付宝担保交易付款</Text>
            </NormalButton>}
            {
              order.link && <View style={styles.disclaimer}>
                <Text style={styles.disTitle}>注意事项</Text>
                <Text>因蜂房团队的条件限制，点击付款后将会跳转到支付宝的担保交易支付网页。在手机上体验会较差，我们对此深表歉意。
                （收款方为蜂房的团队账户：姚天宇(蜂房团队创建人)。我们对每一笔订单进行记录，并由蜂房顶尖的技术团队以及同济大学坚实的后盾保障资金安全。）
                </Text>
              </View>
            }
          </View>
          :
          <View style={styles.info}>
            <Text style={styles.status}>{loading ? '载入订单中' : '无法找到订单'}</Text>
          </View>
        }

      </View>
    );
  }
}

function fetchDataDeferred(getState, dispatch, params) {
  const {orderId} = params;
  return dispatch(loadOrderDetail(orderId));
}

export default connectData(fetchDataDeferred)(
  connect(
    (state, props) => {
      const {orderId} = props;
      return {
        order: state.order[orderId],
        loading: state.order.loadingOrder,
        loadError: state.order.loadOrderError,
        orderId
      };
    },
    {loadOrderDetail}
  )(
    OrderDetail
  )
)
