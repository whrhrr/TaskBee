import { Map, fromJS } from 'immutable';
const LOAD_USER_DETAIL = 'me/LOAD_USER_DETAIL';
const LOAD_USER_DETAIL_SUCCESS = 'me/LOAD_USER_DETAIL_SUCCESS';
const LOAD_USER_DETAIL_FAIL = 'me/LOAD_USER_DETAIL_FAIL';

const LIKE = 'me/LIKE';
const LIKE_SUCCESS = 'me/LIKE_SUCCESS';
const LIKE_FAIL = 'me/LIKE_FAIL';

const UNFRIEND = 'me/UNFRIEND';
const UNFRIEND_SUCCESS = 'me/UNFRIEND_SUCCESS';
const UNFRIEND_FAIL = 'me/UNFRIEND_FAIL';
export const REHYDRATE = 'user/REHYDRATE';

const ONE_USER = 'taskbee/user/ONE_USER';
export const ONE_USER_SUCCESS = 'taskbee/user/ONE_USER_SUCCESS';
const ONE_USER_FAIL = 'taskbee/user/ONE_USER_FAIL';

// 来自messages的问候
import {GET_NEW} from './messages';

import {AsyncStorage} from 'react-native';
import transit from 'transit-immutable-js';
import {debounce} from '../utils/componentEvents';


const INITIAL_STATE = new Map({
  hydrated: false,
});


export default function user(state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    case REHYDRATE:
      return state.withMutations((mutation) => {
        mutation.merge(action.data).set('hydrated', true);
      });
    case ONE_USER_SUCCESS:
      return state.setIn([action.result.data._id], Map(action.result.data));
    case GET_NEW:
      if (action.result) {
        return state.withMutations((mutation) => {
          action.result.users.forEach(user => {
            mutation.mergeIn([user._id], Map(user));
          });
        });
      }
      return state;
    case LOAD_USER_DETAIL:
      return state.withMutations((mutation) => {
        mutation.set('loadingUser', true).set('loadUserError', null);
      });
    case LOAD_USER_DETAIL_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('loadingUser', false).set('loadUserError', null)
          .mergeIn([action.result.data._id], Map(action.result.data))
          .setIn([action.result.data._id, 'votes'], action.result.votes);
      });
    case LOAD_USER_DETAIL_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('loadingUser', false).set('loadUserError', action.error);
      });
    case LIKE:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'liking'], true).setIn([action.key, 'likeError'], null);
      });
    case LIKE_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'liking'], false).setIn([action.key, 'likeError'], null)
          .setIn([action.key, 'liked'], !!action.result.data)
          .setIn([action.key, 'friended'], action.result.data === 'friend' ? true : false);
      });
    case LIKE_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'liking'], false).setIn([action.key, 'likeError'], action.error);
      });
    case UNFRIEND:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'unfriending'], true).setIn([action.key, 'unfriendError'], null)
          .setIn([action.key, 'friended'], false);
      });
    case UNFRIEND_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'unfriending'], false).setIn([action.key, 'unfriendError'], null)
          .setIn([action.key, 'friended'], false).setIn([action.key, 'liked'], false);
      });
    case UNFRIEND_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'unfriending'], false).setIn([action.key, 'unfriendError'], action.error)
          .setIn([action.key, 'friended'], true);
      });
    default:
      return state;
  }
}


// 直接从store里加水
export function rehydrate(dispatch) {
  AsyncStorage.getItem(REHYDRATE).then(str => {
    let state;
    if (str) {
      state = transit.fromJSON(str);
    }
    dispatch({
      type: REHYDRATE,
      data: state,
    });
  })
  .catch(err => {
    console.log('hydrate error', err);
    dispatch({
      type: REHYDRATE,
      data: null,
    });
  });
}

// 这玩意，debounce一发！
export const dehydrate = debounce(function dehydrate() {
  return (dispatch, getState) => {
    const userState = getState().user;
    const toSave = transit.toJSON(
     userState
    );
    AsyncStorage.setItem(REHYDRATE, toSave);
  };
});

// 延迟运行啦！
export const sideDehydrate = debounce(function sideDehydrate(result, dispatch, getState) {
  const userState = getState().user;
  const toSave = transit.toJSON(
    userState
  );
  AsyncStorage.setItem(REHYDRATE, toSave);
});

export function getOneUser(user) {
  return {
    types: [ONE_USER, ONE_USER_SUCCESS, ONE_USER_FAIL],
    promise: (client) => client.get('/user/oneUser', {
      params: {
        user
      }
    }),
    successSide: sideDehydrate,
  };
}

export function loadUserDetail(userId) {
  return {
    types: [LOAD_USER_DETAIL, LOAD_USER_DETAIL_SUCCESS, LOAD_USER_DETAIL_FAIL],
    promise: client => client.get('/user/userDetail', {
      params: {
        user: userId
      }
    }),
    key: userId,
    successSide: sideDehydrate,
  };
}

export function like({toLike, token}) {
  return {
    types: [LIKE, LIKE_SUCCESS, LIKE_FAIL],
    promise: client => client.post('/user/like', {
      data: {
        toLike
      },
      token
    }),
    key: toLike,
    successSide: sideDehydrate,
  };
}

export function unfriend({toUnfriend, token}) {
  return {
    types: [UNFRIEND, UNFRIEND_SUCCESS, UNFRIEND_FAIL],
    promise: client => client.post('/user/unfriend', {
      data: {
        toUnfriend
      },
      token
    }),
    key: toUnfriend,
    successSide: sideDehydrate,
  };
}
