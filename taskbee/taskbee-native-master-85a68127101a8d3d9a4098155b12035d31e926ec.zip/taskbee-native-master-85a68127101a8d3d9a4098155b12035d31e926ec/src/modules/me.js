// 个人信息
import {filterToId} from '../utils/dataProcessor';

import {AsyncStorage} from 'react-native';
import { Map, fromJS } from 'immutable';
import transit from 'transit-immutable-js';
import JPush from 'react-native-jpush';

const LOAD = 'me/load';
const LOAD_SUCCESS = 'me/load_success';
const LOAD_FAIL = 'me/load_fail';

const LOGIN = 'me/LOGIN';
const LOGIN_SUCCESS = 'me/LOGIN_SUCCESS';
const LOGIN_FAIL = 'me/LOGIN_FAIL';

const REGISTER = 'me/REGISTER';
export const REGISTER_SUCCESS = 'me/REGISTER_SUCCESS';
const REGISTER_FAIL = 'me/REGISTER_FAIL';

const CHANGEPASSWORD = 'me/CHANGEPASSWORD';
export const CHANGEPASSWORD_SUCCESS = 'me/CHANGEPASSWORD_SUCCESS';
const CHANGEPASSWORD_FAIL = 'me/CHANGEPASSWORD_FAIL';

const CHANGE_INFO = 'me/CHANGE_INFO';
export const CHANGE_INFO_SUCCESS = 'me/CHANGE_INFO_SUCCESS';
const CHANGE_INFO_FAIL = 'me/CHANGE_INFO_FAIL';

export const LOGOUT = 'me/LOGOUT';
const LOGOUT_SUCCESS = 'me/LOGOUT_SUCCESS';
const LOGOUT_FAIL = 'me/LOGOUT_FAIL';

const UPLOAD = 'me/UPLOAD';
const UPLOAD_SUCCESS = 'me/UPLOAD_SUCCESS';
const UPLOAD_FAIL = 'me/UPLOAD_FAIL';

const GET_TASKS = 'me/GET_TASKS';
export const GET_TASKS_SUCCESS = 'me/GET_TASKS_SUCCESS';
const GET_TASKS_FAIL = 'me/GET_TASKS_FAIL';

const GET_FAV_TASKS = 'me/GET_FAV_TASKS';
export const GET_FAV_TASKS_SUCCESS = 'me/GET_FAV_TASKS_SUCCESS';
const GET_FAV_TASKS_FAIL = 'me/GET_FAV_TASKS_FAIL';

const GET_HISTORY_TASKS = 'me/GET_HISTORY_TASKS';
export const GET_HISTORY_TASKS_SUCCESS = 'me/GET_HISTORY_TASKS_SUCCESS';
const GET_HISTORY_TASKS_FAIL = 'me/GET_HISTORY_TASKS_FAIL';

const GET_POLLENS = 'me/GET_POLLENS';
export const GET_POLLENS_SUCCESS = 'me/GET_POLLENS_SUCCESS';
const GET_POLLENS_FAIL = 'me/GET_POLLENS_FAIL';

import {CREATE_POST_SUCCESS} from './publish';
const SIGN = 'me/SIGN';
const SIGN_SUCCESS = 'me/SIGN_SUCCESS';
const SIGN_FAIL = 'me/SIGN_FAIL';

const GET_SCORE = 'me/GET_SCORE';
const GET_SCORE_SUCCESS = 'me/GET_SCORE_SUCCESS';
const GET_SCORE_FAIL = 'me/GET_SCORE_FAIL';

const LOAD_FRIENDS = 'me/LOAD_FRIENDS';
const LOAD_FRIENDS_SUCCESS = 'me/LOAD_FRIENDS_SUCCESS';
const LOAD_FRIENDS_FAIL = 'me/LOAD_FRIENDS_FAIL';

import {WITHDRAW_SUCCESS, REDPOCKET_SUCCESS} from './order';

export const REHYDRATE = 'me/REHYDRATE';

const INITIAL_STATE = new Map({
  loading: false,
  loaded: false,
  error: null,
  friends: [], // 只做一层的map啦
  changing: Map(),
  changeError: Map(),
  hydrated: false,
  myPollens: [],
});

function isYesterday(date) {
  const tmp = new Date(date);
  const da = new Date();
  da.setDate(da.getDate() - 1);
  return tmp.setHours(0, 0, 0, 0) === da.setHours(0, 0, 0, 0);
}

function getNewTasks(state, action, key) {
  const ids = filterToId(action.result.data[key]);
  const originArry = state.get(key);
    // 从头加载
  if (!originArry || !originArry.length) {
    return ids;
  }

  if (action.start) {
    return originArry.concat(ids);
  }

  // 分析新的任务
  const existIndex = ids.indexOf(originArry[0]);
  if (existIndex < 0) {
    // 已经超过span指定的条数了，我们全部重新加载吧
    return ids;
  }
  return ids.slice(0, existIndex).concat(originArry);
}

function signSuccessReducer(state, action) {
  const signTime = state.getIn(['data', 'signTime']);
  return state.withMutations((mutation) => {
    mutation.set('signing', false).set('signError', null)
      .updateIn(['data', 'score'], score => score + 1)
      .updateIn(['data', 'signCount'], signCount => {
        if (signTime && isYesterday(signTime)) {
          // 如果是昨天，则+1
          return signCount + 1;
        } return 1;
      })
      .setIn(['data', 'signTime'], action.side);
  });
}
function signByPostSuccessReducer(state, action) {
  const signTime = state.getIn(['data', 'signTime']);
  if (action.result.signed) {
    return state.withMutations((mutation) => {
      mutation.set('signing', false).set('signError', null)
        .updateIn(['data', 'score'], score => score + 1)
        .updateIn(['data', 'signCount'], signCount => {
          if (signTime && isYesterday(signTime)) {
            // 如果是昨天，则+1
            return signCount + 1;
          } return 1;
        })
        .setIn(['data', 'signTime'], Date.now());
    });
  }
  return state;
}

function getPollensReducer(state, action) {
  const data = action.result.data;
  let myPollens = state.get('myPollens');
  if (myPollens) {
    if (!action.start && data.length) {
      const lastId = data[data.length - 1]._id;
      const daIndex = myPollens.findIndex(pollen => {
        return pollen._id === lastId;
      });
      if (daIndex < 0) {
        myPollens = data;
      } else {
        myPollens = data.concat(myPollens.slice(daIndex + 1));
      }

    } else {
      myPollens = myPollens.concat(data);
    }
  } else {
    myPollens = data;
  }

  return state.withMutations((mutation) => {
    mutation.set('gettingPollen', false).set('getPollenError', null).
      set('myPollens', myPollens).set('noMorePollens', action.result.data.length < action.span);
  });
}

export default function me(state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    case REHYDRATE:
      return state.withMutations((mutation) => {
        mutation.merge(action.data).set('hydrated', true);
      });
    case LOGIN:
      return state.withMutations((mutation) => {
        mutation.set('logining', true).set('loginError', null);
      });
    case LOGIN_SUCCESS:
      return state.withMutations((mutation) => {
        mutation
          .set('logining', false)
          .set('loginError', null)
          .set('data', Map(action.result.data))
          .set('token', action.result.token)
          .set('meId', action.result.data._id);
      });
    case LOGIN_FAIL:
      return state.withMutations((mutation) => {
        mutation
          .set('logining', false)
          .set('loginError', action.error);
      });
    case REGISTER:
      return state.withMutations((mutation) => {
        mutation.set('registering', true).set('registerError', null);
      });
    case REGISTER_SUCCESS:
      return state.withMutations((mutation) => {
        mutation
          .set('registering', false)
          .set('registerError', null)
          .set('data', Map(action.result.data))
          .set('token', action.result.token)
          .set('meId', action.result.data._id);
      });
    case REGISTER_FAIL:
      return state.withMutations((mutation) => {
        mutation
          .set('registering', false)
          .set('registerError', action.error);
      });
    case CHANGEPASSWORD:
      return state.withMutations((mutation) => {
        mutation.set('changingPassword', true).set('changePasswordError', null);
      });
    case CHANGEPASSWORD_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('changingPassword', false).set('changePasswordError', null);
      });
    case CHANGEPASSWORD_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('changingPassword', false).set('changePasswordError', action.error);
      });
    case CHANGE_INFO:
      return state.withMutations((mutation) => {
        mutation.setIn(['changing', action.key], true).setIn(['changeError', action.key], null);
      });
    case CHANGE_INFO_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn(['changing', action.key], false).setIn(['changeError', action.key], null).setIn(['data', action.key], action.result.data);
      });
    case CHANGE_INFO_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn(['changing', action.key], false).setIn(['changeError', action.key], action.error);
      });
    case GET_TASKS:
      return state.withMutations((mutation) => {
        mutation.set('gettingTasks', true).set('getTasksError', null);
      });
    case GET_TASKS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('gettingTasks', false).set('getTasksError', null)
          .setIn(['data', 'taskPublish'], filterToId(action.result.data.taskPublish).reverse())
          .setIn(['data', 'taskTaken'], filterToId(action.result.data.taskTaken).reverse());
      });
    case GET_TASKS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('gettingTasks', false).set('getTasksError', action.error);
      });
    case GET_FAV_TASKS:
      return state.withMutations((mutation) => {
        mutation.set('gettingFavTasks', true).set('getFavTasksError', null);
      });
    case GET_FAV_TASKS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('gettingFavTasks', false).set('getFavTasksError', null)
          .set('taskFav', getNewTasks(state, action, 'taskFav'))
          .set('noMoreFav', action.result.data.taskFav.length < action.span);
      });
    case GET_FAV_TASKS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('gettingFavTasks', false).set('getFavTasksError', action.error);
      });

    case GET_HISTORY_TASKS:
      return state.withMutations((mutation) => {
        mutation.set('gettingHistoryTasks', true).set('geHistoryTasksError', null);
      });
    case GET_HISTORY_TASKS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('gettingHistoryTasks', false).set('getHistoryTasksError', null)
          .set('taskHistory', getNewTasks(state, action, 'taskHistory'))
          .set('noMoreHistory', action.result.data.taskHistory.length < action.span);
      });
    case GET_HISTORY_TASKS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('gettingHistoryTasks', false).set('getHistoryTasksError', action.error);
      });
    case GET_POLLENS:
      return state.withMutations((mutation) => {
        mutation.set('gettingPollen', true).set('getPollenError', null);
      });
    case GET_POLLENS_SUCCESS:
      return getPollensReducer(state, action);
    case GET_POLLENS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('gettingPollen', false).set('getPollenError', action.error);
      });
    case LOAD_FRIENDS:
      return state.withMutations((mutation) => {
        mutation.set('loadingFriends', true).set('loadingFriendsError', null);
      });
    case LOAD_FRIENDS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('loadingFriends', false).set('friends', action.result.data);
      });
    case LOAD_FRIENDS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('loadingFriends', false).set('loadingFriendsError', action.error);
      });
    case LOAD_SUCCESS:
      return state.withMutations((mutation) => {
        mutation
          .mergeIn(['data'], Map(action.result.data))
          .set('token', action.result.token)
          .set('meId', action.result.data._id);
      });
    case SIGN:
      return state.withMutations((mutation) => {
        mutation.set('signing', true).set('signError', null);
      });
    case CREATE_POST_SUCCESS:
      return signByPostSuccessReducer(state, action);
    case SIGN_SUCCESS:
      return signSuccessReducer(state, action);
    case SIGN_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('signing', false).set('signError', action.error);
      });
    case UPLOAD:
      return state.withMutations((mutation) => {
        mutation
          .set('uploading', true)
          .set('uploadError', null);
      });
    case UPLOAD_SUCCESS:
      if (action.error) {
        return state.withMutations((mutation) => {
          mutation
            .set('uploading', false)
            .set('uploadError', '上传出错，请稍候重试');
        });
      }
      return state.withMutations((mutation) => {
        mutation
          .set('uploading', false)
          .setIn(['data', 'avatar'], action.uploadResult[0].data);
      });
    case UPLOAD_FAIL:
      return state.withMutations((mutation) => {
        mutation
          .set('uploading', false)
          .set('uploadError', action.error);
      });
    case WITHDRAW_SUCCESS:
      return state.updateIn(['data', 'money'], money => money - action.money);
    case REDPOCKET_SUCCESS:
      return state.updateIn(['data', 'money'], money => money + action.money);
    case GET_SCORE_SUCCESS:
      return state.setIn(['data', 'money'], action.result.data.money)
        .setIn(['data', 'score'], action.result.data.score);
    case LOGOUT:
      return INITIAL_STATE.withMutations((mutation) => {
        mutation
          .set('hydrated', true);
      });
      // 直接登出！管它成功不成功呢
    default:
      return state;
  }
}

// 直接从store里加水
export function rehydrate(dispatch) {
  AsyncStorage.getItem(REHYDRATE).then(str => {
    let state;
    if (str) {
      state = transit.fromJSON(str);
    }
    dispatch({
      type: REHYDRATE,
      data: state,
    });
  })
  .catch(err => {
    console.log('hydrate error', err);
    dispatch({
      type: REHYDRATE,
      data: null,
    });
  });
}

// 这玩意，在跟组建上脱水吧 debounce一发！
export function dehydrate() {
  return (dispatch, getState) => {
    const meState = getState().me;
    const toSave = transit.toJSON(
      meState.delete('hydrated').delete('myPollens')
        .filter((value, key) => {
          const testKey = key.toLowerCase();
          if (testKey.indexOf('error') > -1 || testKey.indexOf('ing') > -1) {
            return false;
          }
          return true;
        })
    );
    console.log('will save me');
    AsyncStorage.setItem(REHYDRATE, toSave);
  };
}

function sidePushId(result, dispatch) {
  // 需要有token啦
  if (!result.token) return;
  JPush.getRegistrationID().then((pushId) => {
    console.log('[JPUSH ID]', pushId);
    if (!pushId) return;
    dispatch({
      types: ['PUSHID', 'PUSHID_SUCCESS', 'PUSHID_FAIL'],
      promise: (client) => client.post('/user/setPushId', {
        data: {
          pushId,
        },
        token: result.token,
      }),
    });
  });
}

export function load() {
  return {
    types: [LOAD, LOAD_SUCCESS, LOAD_FAIL],
    promise: (client) => client.post('/user/load'),
    successSide: sidePushId,
  };
}

export function login({phone, password}) {
  return {
    types: [LOGIN, LOGIN_SUCCESS, LOGIN_FAIL],
    promise: (client) => client.post('/user/login', {
      data: {
        phone,
        password
      }
    }),
    successSide: sidePushId,
  };
}


export function changePassword({password, verifyToken}) {
  return {
    types: [CHANGEPASSWORD, CHANGEPASSWORD_SUCCESS, CHANGEPASSWORD_FAIL],
    promise: (client) => client.post('/user/newPassword', {
      data: {
        password,
      },
      token: verifyToken
    })
  };
}

export function register({username, password, gender, schoolId, verifyToken}) {
  return {
    types: [REGISTER, REGISTER_SUCCESS, REGISTER_FAIL],
    promise: (client) => client.post('/user/register', {
      data: {
        username,
        password,
        gender,
        schoolId,
      },
      token: verifyToken
    }),
    successSide: sidePushId,
  };
}

import {REHYDRATE as REHYDRATESys} from './sysMessages';
import {REHYDRATE as REHYDRATEMessage} from './messages';
import {REHYDRATE as REHYDRATEUser} from './user';
export function logout() {
  // clear asyncstorage
  AsyncStorage.removeItem(REHYDRATE);
  AsyncStorage.removeItem(REHYDRATESys);
  AsyncStorage.removeItem(REHYDRATEMessage);
  AsyncStorage.removeItem(REHYDRATEUser);
  return {
    types: [LOGOUT, LOGOUT_SUCCESS, LOGOUT_FAIL],
    promise: (client) => client.post('/user/logout')
  };
}

export function loadUser() {
  return {
    types: [LOADUSER, LOADUSER_SUCCESS, LOADUSER_FAIL],
    promise: (client) => client.post('/user/load')
  };
}

export function sign(token) {
  return {
    types: [SIGN, SIGN_SUCCESS, SIGN_FAIL],
    promise: (client) => client.post('/user/sign', {
      token
    }),
    successSide: () => {
      return new Date();
    }
  };
}

export function changeInfo({data, url, key, token}) {
  return {
    types: [CHANGE_INFO, CHANGE_INFO_SUCCESS, CHANGE_INFO_FAIL],
    promise: (client) => client.post(url, {
      data,
      token
    }),
    key,
  };
}

// 服务端返回头像路径
export function upload({attach, token}) {
  return {
    types: [UPLOAD, UPLOAD_SUCCESS, UPLOAD_FAIL],
    promise: (client) => client.post('/user/uploadAvatar', {
      token
    }),
    uploadImages: [attach],
  };
}

// 获取我的任务 {taskTaken, taskPublish}
export function getTasks(reload) {
  return {
    types: [GET_TASKS, GET_TASKS_SUCCESS, GET_TASKS_FAIL],
    promise: (client) => client.get('/user/tasks', {
    }),
    reload
  };
}

// 获取我收藏任务
export function getTasksFav(start, span = 15) {
  return {
    types: [GET_FAV_TASKS, GET_FAV_TASKS_SUCCESS, GET_FAV_TASKS_FAIL],
    promise: (client) => client.get('/user/tasksFav', {
      params: {
        start,
        span,
      },
    }),
    start,
    span,
  };
}

// 获取我的分数
export function getScore() {
  return {
    types: [GET_SCORE, GET_SCORE_SUCCESS, GET_SCORE_FAIL],
    promise: (client) => client.get('/user/score', {
    }),
  };
}

// 我所有历史的任务（有分页)
export function getTasksHistory(start, span = 15) {
  return {
    types: [GET_HISTORY_TASKS, GET_HISTORY_TASKS_SUCCESS, GET_HISTORY_TASKS_FAIL],
    promise: (client) => client.get('/user/tasksHistory', {
      params: {
        start,
        span,
      },
    // successSide: result => arrayToObject(result.data)
    }),
    start,
    span,
  };
}

// 我所有花粉（有分页)
export function getPollens(start, span = 15) {
  return {
    types: [GET_POLLENS, GET_POLLENS_SUCCESS, GET_POLLENS_FAIL],
    promise: (client) => client.get('/user/myPollens', {
      params: {
        start,
        span,
      },
    }),
    start,
    span,
  };
}

export function loadFriends() {
  return {
    types: [LOAD_FRIENDS, LOAD_FRIENDS_SUCCESS, LOAD_FRIENDS_FAIL],
    promise: client => client.get('/user/friends', {
    }),
  };
}


