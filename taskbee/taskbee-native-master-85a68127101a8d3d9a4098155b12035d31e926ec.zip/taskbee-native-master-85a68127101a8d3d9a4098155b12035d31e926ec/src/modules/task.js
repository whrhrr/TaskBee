const FAV = 'taskbee/task/FAV';
const FAV_SUCCESS = 'taskbee/task/FAV_SUCCESS';
const FAV_FAIL = 'taskbee/task/FAV_FAIL';

const UNFAV = 'taskbee/task/UNFAV';
const UNFAV_SUCCESS = 'taskbee/task/UNFAV_SUCCESS';
const UNFAV_FAIL = 'taskbee/task/UNFAV_FAIL';

const LOAD_DETAIL = 'taskbee/task/LOAD_DETAIL';
const LOAD_DETAIL_SUCCESS = 'taskbee/task/LOAD_DETAIL_SUCCESS';
const LOAD_DETAIL_FAIL = 'taskbee/task/LOAD_DETAIL_FAIL';

const START_COMMENT = 'taskbee/task/START_COMMENT';
const STOP_COMMENT = 'taskbee/task/STOP_COMMENT';
const NEW_COMMENT = 'taskbee/task/NEW_COMMENT';
const NEW_COMMENT_SUCCESS = 'taskbee/task/NEW_COMMENT_SUCCESS';
const NEW_COMMENT_FAIL = 'taskbee/task/NEW_COMMENT_FAIL';

const TAKE_TASK = 'taskbee/task/TAKE_TASK';
const TAKE_TASK_SUCCESS = 'taskbee/task/TAKE_TASK_SUCCESS';
const TAKE_TASK_FAIL = 'taskbee/task/TAKE_TASK_FAIL';

const CONFIRM_TASKER = 'taskbee/task/CONFIRM_TASKER';
const CONFIRM_TASKER_SUCCESS = 'taskbee/task/CONFIRM_TASKER_SUCCESS';
const CONFIRM_TASKER_FAIL = 'taskbee/task/CONFIRM_TASKER_FAIL';

const CONFIRM_PUBLISHER = 'taskbee/task/CONFIRM_PUBLISHER';
const CONFIRM_PUBLISHER_SUCCESS = 'taskbee/task/CONFIRM_PUBLISHER_SUCCESS';
const CONFIRM_PUBLISHER_FAIL = 'taskbee/task/CONFIRM_TASKER_FAIL';

const CANCEL_TASKER = 'taskbee/task/CANCEL_TASKER';
const CANCEL_TASKER_SUCCESS = 'taskbee/task/CANCEL_TASKER_SUCCESS';
const CANCEL_TASKER_FAIL = 'taskbee/task/CANCEL_TASKER_FAIL';

const CANCEL_PUBLISHER = 'taskbee/task/CANCEL_PUBLISHER';
const CANCEL_PUBLISHER_SUCCESS = 'taskbee/task/CANCEL_PUBLISHER_SUCCESS';
const CANCEL_PUBLISHER_FAIL = 'taskbee/task/CANCEL_PUBLISHER_FAIL';

const VOTE = 'taskbee/task/VOTE';
const VOTE_SUCCESS = 'taskbee/task/VOTE_SUCCESS';
const VOTE_FAIL = 'taskbee/task/VOTE_FAIL';


/*
  外来的CONST
*/
import {GET_HISTORY_TASKS_SUCCESS, GET_FAV_TASKS_SUCCESS, GET_TASKS_SUCCESS} from './me';
import {LOAD_SUCCESS} from './lists';
//
import { Map } from 'immutable';
import {arrayToObject} from '../utils/dataProcessor';


const initialState = Map();

function keepObjectMerger(prev, next, key) {
  if (typeof prev === 'object' && typeof next === 'string') {
    return prev;
  };
  return next;
}

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.mergeDeepWith(keepObjectMerger, arrayToObject(action.result.data));
      });
    case GET_TASKS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.mergeDeepWith(keepObjectMerger, arrayToObject(action.result.data.taskTaken.concat(action.result.data.taskPublish)));
      });
    case GET_HISTORY_TASKS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.mergeDeepWith(keepObjectMerger, arrayToObject(action.result.data.taskHistory));
      });
    case GET_FAV_TASKS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.mergeDeepWith(keepObjectMerger, arrayToObject(action.result.data.taskFav));
      });
    case FAV:
      return state.update(action.key, task => task.set('faved', true).update('favs', favs => favs + 1));
    case FAV_SUCCESS:
      return state.setIn([action.key, 'fav'], true);
    case FAV_FAIL:
      return state.update(action.key, task => (
        task.set('faved', false).update('favs', favs => favs - 1)
      ));
    case UNFAV:
      return state.update(action.key, task => (
        task.set('faved', false).update('favs', favs => favs - 1)
      ));
    case UNFAV_SUCCESS:
      return state.setIn([action.key, 'faved'], false);
    case UNFAV_FAIL:
      return state.update(action.key, task => (
        task.set('faved', true).update('favs', favs => favs + 1)
      ));
    case LOAD_DETAIL:
      if (!state.has(action.key)) {
        return state.set(action.key, Map({
          loadingDetail: true,
          detailError: null,
        }));
      }
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'loadingDetail'], true)
          .setIn([action.key, 'detailError'], null);
      });
    case LOAD_DETAIL_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'loadingDetail'], false)
          .setIn([action.key, 'detailError'], null)
          .mergeIn([action.key], Map(action.result.data));
      });
    case LOAD_DETAIL_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'loadingDetail'], false)
          .setIn([action.key, 'detailError'], action.error);
      });
    case START_COMMENT:
      return state.setIn([action.key, 'commentOpen'], true);
    case STOP_COMMENT:
      return state.setIn([action.key, 'commentOpen'], false);
    case NEW_COMMENT:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'commentSubmitting'], true)
          .setIn([action.key, 'commentError'], null)
          .setIn([action.key, 'commentSuccess'], false);
      });
    case NEW_COMMENT_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'commentSubmitting'], false)
          .setIn([action.key, 'commentError'], null)
          .setIn([action.key, 'commentSuccess'], true)
          .setIn([action.key, 'commentOpen'], false)
          .setIn([action.key, 'comments'], mutation.getIn([action.key, 'comments'])
          .concat(action.result.data));
      });
    case NEW_COMMENT_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'commentSubmitting'], false)
          .setIn([action.key, 'commentError'], action.error)
          .setIn([action.key, 'commentSuccess'], false);
      });
    case CANCEL_TASKER:
    case CANCEL_PUBLISHER:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'cancelling'], true)
          .setIn([action.key, 'cancelError'], null);
      });
    case CANCEL_TASKER_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'cancelling'], false)
          .setIn([action.key, 'cancelError'], null)
          .setIn([action.key, 'state'], 0);
      });
    case CANCEL_TASKER_FAIL:
    case CANCEL_PUBLISHER_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'cancelling'], false)
          .setIn([action.key, 'cancelError'], action.error);
      });
    case CANCEL_PUBLISHER_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'cancelling'], false)
          .setIn([action.key, 'cancelError'], null)
          .setIn([action.key, 'state'], 5);
      });
    // 确认完成
    case CONFIRM_TASKER:
    case TAKE_TASK:
    case CONFIRM_PUBLISHER:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('ongoing', true).set('goError', null);
      }));
    case CONFIRM_TASKER_FAIL:
    case TAKE_TASK_FAIL:
    case CONFIRM_PUBLISHER_FAIL:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('ongoing', false).set('goError', action.error);
      }));
    case CONFIRM_TASKER_SUCCESS:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('ongoing', false).set('goError', null).set('state', 2);
      }));
    case TAKE_TASK_SUCCESS:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('ongoing', false).set('goError', null)
          .set('state', 1).set('publisher', action.result.data).set('tasker', action.meId);
      }));
    case CONFIRM_PUBLISHER_SUCCESS:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('ongoing', false).set('goError', null)
          .set('state', 3).set('canVote', [state.get(action.key).get('publisher')._id]);
      }));
    case VOTE:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('voting', true).set('voteError', null);
      }));
    case VOTE_SUCCESS:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('voting', false).set('voteError', null)
          .update('canVote', canVoteArry => canVoteArry.slice().splice(canVoteArry.indexOf(action.meId), 1));
      }));
    case VOTE_FAIL:
      return state.update(action.key, task => task.withMutations((mutation) => {
        mutation.set('voting', true).set('voteError', action.error);
      }));


    default:
      return state;
  }
}

export function fav({id, token}) {
  return {
    types: [FAV, FAV_SUCCESS, FAV_FAIL],
    promise: (client) => client.post('/task/fav', {
      data: {
        taskId: id
      },
      token
    }),
    key: id
  };
}

export function unfav({id, token}) {
  return {
    types: [UNFAV, UNFAV_SUCCESS, UNFAV_FAIL],
    promise: (client) => client.post('/task/unfav', {
      data: {
        taskId: id
      },
      token
    }),
    key: id
  };
}

export function loadDetail(taskId) {
  return {
    types: [LOAD_DETAIL, LOAD_DETAIL_SUCCESS, LOAD_DETAIL_FAIL],
    promise: client => client.get('/task/taskDetail', {
      params: {
        taskId
      }
    }),
    key: taskId,
  };
}

export function newComment({taskId, to, body, token}) {
  return {
    types: [NEW_COMMENT, NEW_COMMENT_SUCCESS, NEW_COMMENT_FAIL],
    promise: (client) => client.post('/task/newComment', {
      data: {
        taskId,
        to,
        body
      },
      token
    }),
    key: taskId
  };
}

export function startComment({taskId}) {
  return {
    type: START_COMMENT,
    key: taskId
  };
}

export function stopComment({taskId}) {
  return {
    type: STOP_COMMENT,
    key: taskId
  };
}

export function take({taskId, meId, token}) {
  return {
    types: [TAKE_TASK, TAKE_TASK_SUCCESS, TAKE_TASK_FAIL],
    promise: (client) => client.post('/task/take', {
      data: {
        taskId
      },
      token
    }),
    key: taskId,
    meId
  };
}

export function confirmTasker({taskId, token}) {
  return {
    types: [CONFIRM_TASKER, CONFIRM_TASKER_SUCCESS, CONFIRM_TASKER_FAIL],
    promise: (client) => client.post('/task/confirmTasker', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}


export function confirmPublisher({taskId, token}) {
  return {
    types: [CONFIRM_PUBLISHER, CONFIRM_PUBLISHER_SUCCESS, CONFIRM_PUBLISHER_FAIL],
    promise: (client) => client.post('/task/confirmPuber', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}

export function cancelTasker({taskId, token}) {
  return {
    types: [CANCEL_TASKER, CANCEL_TASKER_SUCCESS, CANCEL_TASKER_FAIL],
    promise: (client) => client.post('/task/cancelTasker', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}

export function cancelPuber({taskId, token}) {
  return {
    types: [CANCEL_PUBLISHER, CANCEL_PUBLISHER_SUCCESS, CANCEL_PUBLISHER_FAIL],
    promise: (client) => client.post('/task/cancelPuber', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}

export function vote({taskId, meId, token, score, message}) {
  return {
    types: [VOTE, VOTE_SUCCESS, VOTE_FAIL],
    promise: (client) => client.post('/task/vote', {
      data: {
        taskId,
        score,
        message,
      },
      token
    }),
    key: taskId,
    meId,
  };
}
