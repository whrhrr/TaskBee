import {saveMessages} from '../utils/storage';
import {AsyncStorage} from 'react-native';
import { createSelector } from 'reselect';

const READY = 'taskbee/messages/READY';
const SEND = 'taskbee/messages/SEND';
const SEND_SUCCESS = 'taskbee/messages/SEND_SUCCESS';
const SEND_FAIL = 'taskbee/messages/SEND_FAIL';
const GET_MESSAGE = 'taskbee/messages/GET_MESSAGE';

// 登陆时读取服务端的新数据
export const GET_NEW = 'taskbee/messages/GET_NEW';

export const UNREAD = 'taskbee/messages/UNREAD';
const READ = 'taskbee/messages/READ';
const LEAVE = 'taskbee/messages/LEAVE';

export const STATUS = 'taskbee/messages/STATUS';

export const REHYDRATE = 'messages/REHYDRATE';

// 外来
import {LOGOUT} from './me';

const initialState = {
  hydrated: false,
  totalUnread: 0,
  currentChat: null,
};

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case REHYDRATE:
      return {
        ...state,
        ...action.data,
        hydrated: true,
      };
    case UNREAD:
      if (!state[action.from] || state.currentChat === action.from) return state;
      let unreadCount = state[action.from].unread;
      unreadCount = unreadCount ? unreadCount + 1 : 1;
      return {
        ...state,
        totalUnread: state.totalUnread + 1,
        [action.from]: {
          ...state[action.from],
          unread: unreadCount
        }
      };
    case READ:
      if (!state[action.from]) {
        return {
          ...state,
          [action.from]: {
            unread: 0,
            messages: [],
          }
        };
      }
      return {
        ...state,
        currentChat: action.from,
        totalUnread: state.totalUnread - state[action.from].unread,
        [action.from]: {
          ...state[action.from],
          unread: 0
        }
      };
    case LEAVE:
      return {
        ...state,
        currentChat: null,
      };
    /*
    case READY:
      if (!state[action.user._id]) {
        return {
          ...state,
          [action.user._id]: {
            messages: [],
            avatar: action.user.avatar,
            username: action.user.username,
            gender: action.user.gender,
            _id: action.user._id,
          }
        };
      }
      return {
        ...state,
        [action.user._id]: {
          ...state[action.user._id],
          avatar: action.user.avatar,
          username: action.user.username,
          gender: action.user.gender,
          _id: action.user._id,
        }
      };
    */
    case SEND:
      return {
        ...state,
        submitting: true,
        error: null,
      };
    case SEND_SUCCESS:
      return {
        ...state,
        submitting: false,
        error: null,
        [action.data.to]: {
          ...state[action.data.to],
          messages: state[action.data.to].messages.concat(action.data),
        }
      };
    case SEND_FAIL:
      return {
        ...state,
        submitting: false,
        error: action.error
      };
    case GET_MESSAGE:
      return {
        ...state,
        [action.data.from]: {
          ...state[action.data.from],
          messages: state[action.data.from] ? state[action.data.from].messages.concat(action.data) : [action.data],
        }
      };
    case GET_NEW:
      // 麻烦事来了，要处理服务端饭回来的新消息
      if (!action.result) return state;
      const newState = Object.assign({}, state);
      const rawMessages = {};
      action.result.messages.forEach( message => {
        if (!rawMessages[message.from]) rawMessages[message.from] = [];
        rawMessages[message.from].push(message);
      });
      Object.keys(rawMessages).forEach( key => {
        newState[key] = {
          ...newState[key],
          messages: newState[key] ? newState[key].messages.concat(rawMessages[key]) : rawMessages[key]
        };
      });
      return newState;
    case LOGOUT:
      return {
        ...initialState,
        hydrated: true,
      };
    default:
      return state;
  }
}


const messagesSelector = state => state.messages;
const sysMessagesSelector = state => state.sysMessages.messages;
const isInSysSelector = state => state.sysMessages.isInSys;
const unreadSysSelector = state => state.sysMessages.unread;
const tokenSelector = state => state.me.get('token');
const usersSelector = state => state.user;
const totalUnreadSelector = state => state.messages.totalUnread;

export const msgSelector = createSelector(
  messagesSelector,
  sysMessagesSelector,
  isInSysSelector,
  unreadSysSelector,
  tokenSelector,
  usersSelector,
  totalUnreadSelector,
  (messages, sysMessages, isInSys, unreadSys, token, users, totalUnread) => {
    let keys = Object.keys(messages);
    let realMessages = {};
    keys = keys.filter( key => key.length === 24);
    if (keys.length) {
      // 按未读数排列
      keys.sort(function unreadfirst(fir, sec) {
        const first = messages[fir].messages;
        const second = messages[sec].messages;
        if (!first.length) {
          return 1;
        } else if (!second.length) {
          return -1;
        } else {
          return -first[first.length - 1].createdAt
            + second[second.length - 1].createdAt
        }
      });
      keys.forEach( key => {
        const thisMsg = messages[key].messages;
        realMessages[key] = {
          _id: key,
          message: thisMsg.length && thisMsg[thisMsg.length - 1],
          unread: messages[key].unread,
          avatar: users.getIn([key, 'avatar']),
          username: users.getIn([key, 'username']),
          gender: users.getIn([key, 'gender']),
        };

      });

    }
    return {
      messages: realMessages,
      sysMessages,
      isInSys,
      unreadSys,
      token,
      unreadMsg: totalUnread,
    };
  }
);

// 减少localStorage缓存处罚次数
let deferredSave;
function savesave(getState) {
  if (deferredSave) {
    clearTimeout(deferredSave);
  }
  deferredSave = setTimeout(function realSave() {
    saveMessages(getState().messages);
    deferredSave = null;
  }, 2000);
}


export function rehydrate(dispatch) {
  AsyncStorage.getItem(REHYDRATE).then(str => {
    let state;
    if (str) {
      state = JSON.parse(str);
    }
    dispatch({
      type: REHYDRATE,
      data: state,
    });
  })
  .catch(err => {
    dispatch({
      type: REHYDRATE,
      data: null,
    });
  });
}

export function unread(from) {
  return {
    type: UNREAD,
    from
  };
}


// 触发未读消息增加的action
export function checkUnread(dispatch, getState, from) {
  dispatch(unread(from));
}

// 进入聊天界面，清除未读
export function read(from) {
  return (dispatch, getState) => {
    dispatch({
      type: READ,
      from
    });
    savesave(getState);
  };
}

export function leave(from) {
  return ({
    type: LEAVE,
    from
  })
}

import {getOneUser, sideDehydrate} from './user';

/*
export function readyChat(user) {
  return (dispatch, getState) => {
    dispatch({
      type: READY,
      user
    });
    // 保存
    savesave(getState);
  };
}
*/

// 收到新消息
export function getMessage(data) {
  return (dispatch, getState) => {
    dispatch({
      type: GET_MESSAGE,
      data
    });
    if (data.from && !getState().user.get(data.from)) {
      // 没有用户信息
      dispatch(getOneUser(data.from));
    }
    checkUnread(dispatch, getState, data.from);
    savesave(getState);
  };
}

// {to, body} 发送消息
export function send(data) {
  let timeoutHandle;
  return (dispatch, getState) => {
    function timeout() {
      dispatch({
        type: SEND_FAIL,
        error: '发送超时',
      });
    }
    timeoutHandle = setTimeout(timeout, 30 * 1000);
    global.socket.emit('message', {to: data.to, message: data.message}, function sendCb(cbdata) {
      clearTimeout(timeoutHandle);
      if (cbdata && cbdata.statusCode === 200) {
        dispatch({
          type: SEND_SUCCESS,
          data: {
            to: cbdata.to,
            from: data.from,
            message: cbdata.message,
            createdAt: cbdata.createdAt,
          }
        });
        // 保存聊天信息
        savesave(getState);
      } else {
        dispatch({
          type: SEND_FAIL,
          error: cbdata
        });
      }
    });
    return dispatch({
      type: SEND
    });
  };
}

// 获取未读聊天消息
export function getNew(data) {
  return (dispatch, getState) => {
    dispatch({
      type: GET_NEW,
      result: data.result
    });
    if (data.result) {
      const messageSet = new Set();
      data.result.messages.forEach( message => {
        checkUnread(dispatch, getState, message.from);
        messageSet.add(message.from);
      });
      for (const item of messageSet) {
        console.log('messageSet:', item);
        dispatch(getOneUser(item));
      }
      // 模仿successSide
      sideDehydrate(null, dispatch, getState);
    }
    // 保存消息
    savesave(getState);
  };
}

// 收到任务状态更新
export function getStatus() {
  return {
    type: STATUS
  };
}
