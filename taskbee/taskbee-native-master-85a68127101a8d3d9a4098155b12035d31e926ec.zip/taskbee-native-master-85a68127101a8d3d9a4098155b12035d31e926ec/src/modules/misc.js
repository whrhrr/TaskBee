const FEEDBACK = 'taskbee/misc/FEEDBACK';
const FEEDBACK_SUCCESS = 'taskbee/misc/FEEDBACK_SUCCESS';
const FEEDBACK_FAIL = 'taskbee/misc/FEEDBACK_FAIL';
const FEEDBACK_AGAIN = 'taskbee/misc/FEEDBACK_AGAIN';

const REPORT = 'taskbee/misc/REPORT';
const REPORT_SUCCESS = 'taskbee/misc/REPORT_SUCCESS';
const REPORT_FAIL = 'taskbee/misc/REPORT_FAIL';
const REPORT_AGAIN = 'taskbee/misc/REPORT_AGAIN';

export const ARRIVE_MESSAGE = 'taskbee/misc/ARRIVE_MESSAGE';
const ARRIVE_TASK = 'taskbee/misc/ARRIVE_TASL';
/* SOCKET */
const SOCKET_CONNECTED = 'taskbee/misc/SOCKET_CONNECTED';
const SOCKET_DISCONNECTED = 'taskbee/misc/SOCKET_DISCONNECTED';

const NET_CHANGE = 'taskbee/misc/NET_CHANGE';

/* 滚动条 */
const SCROLL_HOME = 'taskbee/misc/SCROLL_HOME';

/* 窗口大小 */
const WINDOW_HEIGHT = 'taskbee/misc/WINDOW_HEIGHT';

const HOME_TAB = 'taskbee/misc/HOME_TAB';
const POLLEN_TAB = 'taskbee/misc/POLLEN_TAB';

const ACTIVE_TASK = 'taskbee/misc/ACTIVE_TASK';
const TOUCH_CARD = 'taskbee/misc/TOUCH_CARD';
const RELEASE_CARD = 'taskbee/misc/RELEASE_CARD';


import {trackEvent} from 'react-native-talkingdata';


/* 外来的 */
import {UNREAD, STATUS} from './messages';
import {LOGOUT} from './me';
import {GET_SYS_MESSAGE, GET_NEW_SYS, CHECK_SYS_MESSAGE} from './sysMessages';

const initialState = {
  connected: false,
  socketConnected: false,
  lastLocation: null,
  currentLocation: null,
  homeTab: 0,
  pollenTab: 0,
};

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case HOME_TAB:
      return {
        ...state,
        homeTab: action.tab,
      };
    case POLLEN_TAB:
      return {
        ...state,
        pollenTab: action.tab,
      };
    case NET_CHANGE:
      return {
        ...state,
        connected: action.isConnected,
      };
    case SOCKET_CONNECTED:
      return {
        ...state,
        socketConnected: true,
      };
    case SOCKET_DISCONNECTED:
      return {
        ...state,
        socketConnected: false,
      };
    case FEEDBACK:
      return {
        ...state,
        feedbacking: true,
        feedbackError: null
      };
    case FEEDBACK_SUCCESS:
      return {
        ...state,
        feedbacking: false,
        feedbackSuccess: true
      };
    case FEEDBACK_FAIL:
      return {
        ...state,
        feedbacking: false,
        feedbackError: action.error
      };
    case FEEDBACK_AGAIN:
      return {
        ...state,
        feedbackSuccess: false,
      };

    case REPORT:
      return {
        ...state,
        reporting: true,
        reportError: null
      };
    case REPORT_SUCCESS:
      return {
        ...state,
        reporting: false,
        reportSuccess: true
      };
    case REPORT_FAIL:
      return {
        ...state,
        reporting: false,
        reportError: action.error
      };
    case REPORT_AGAIN:
      return {
        ...state,
        reportSuccess: false,
      };
    case TOUCH_CARD:
      return {
        ...state,
        touching: true,
      };
    case RELEASE_CARD:
      return {
        ...state,
        touching: false,
      };
    case LOGOUT:
      return {
        ...state,
        socketConnected: false,
      };

    default:
      return state;
  }
}

export function feedback({email, feedback}) { /* eslint no-shadow: 0*/
  return {
    types: [FEEDBACK, FEEDBACK_SUCCESS, FEEDBACK_FAIL],
    promise: (client) => client.post('/misc/feedback', {
      data: {
        email,
        feedback,
      }
    })
  };
}

export function report({type, itemId, message, token}) { /* eslint no-shadow: 0*/
  return {
    types: [REPORT, REPORT_SUCCESS, REPORT_FAIL],
    promise: (client) => client.post('/misc/report', {
      data: {
        type,
        itemId,
        message,
      },
      token,
    })
  };
}

export function reportAgain() {
  return {
    type: REPORT_AGAIN
  };
}

export function feedbackAgain() {
  return {
    type: FEEDBACK_AGAIN
  };
}

export function netChange(isConnected) {
  return {
    type: NET_CHANGE,
    isConnected,
  };
}

export function socketConnected() {
  return {
    type: SOCKET_CONNECTED
  };
}

export function socketDisconnected() {
  return {
    type: SOCKET_DISCONNECTED
  };
}

export function arriveMessage() {
  return {
    type: ARRIVE_MESSAGE
  };
}

export function arriveTask() {
  return {
    type: ARRIVE_TASK
  };
}

export function scrollHome(scrollY) {
  return {
    type: SCROLL_HOME,
    scrollY,
  };
}

export function windowHeight(windowHeight) {
  return {
    type: WINDOW_HEIGHT,
    windowHeight,
  };
}

export function setHomeTab(tab) {
  trackEvent('tabs', 'setHomeTab', {item: tab.toString()});
  return {
    type: HOME_TAB,
    tab
  };
}
export function setPollenTab(tab) {
  trackEvent('tabs', 'setPollenTab', {item: tab.toString()});
  return {
    type: POLLEN_TAB,
    tab
  };
}

export function setActiveTask(key) {
  return {
    type: ACTIVE_TASK,
    key
  };
}

export function touchCard() {
  return {
    type: TOUCH_CARD,
  };
}

export function releaseCard() {
  return {
    type: RELEASE_CARD,
  };
}
