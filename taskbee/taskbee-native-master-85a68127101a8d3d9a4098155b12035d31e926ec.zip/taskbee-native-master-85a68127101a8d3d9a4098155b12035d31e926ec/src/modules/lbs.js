import { Map, fromJS } from 'immutable';
import {AsyncStorage} from 'react-native';
import transit from 'transit-immutable-js';

const LOAD_LBS = 'taskbee/lbs/LOAD';
const LOAD_LBS_SUCCESS = 'taskbee/lbs/LOAD_SUCCESS';
const LOAD_LBS_FAIL = 'taskbee/lbs/LOAD_FAIL';
const REHYDRATE = 'taskbee/lbs/REHYDRATE';

import {LOAD_SUCCESS as USER_LOAD_SUCCESS, LOGIN_SUCCESS} from './me';

const INITIAL_STATE = new Map({
  longitude: 121.496893,
  latitude: 31.284947,
  rehydrated: false,
});

export default function verify(state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    case REHYDRATE:
      return state.withMutations((mutation) => {
        mutation.merge(action.data).set('hydrated', true);
      });
    case LOAD_LBS:
      return state.withMutations((mutation) => {
        mutation.set('loadingLbs', true).set('loadingLbsError', null);
      });
    case LOAD_LBS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('loadingLbs', false).set('loadingLbsError', null)
          .set('loadedLbs', true)
          .set('longitude', action.pos.coords.longitude)
          .set('latitude', action.pos.coords.latitude);
      });
    case LOAD_LBS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('loadingLbs', false).set('loadingLbsError', action.error);
      });
    case LOGIN_SUCCESS:
      return state.withMutations((mutation) => {
        mutation
          .set('longitude', action.result.data.loc.coordinates[0])
          .set('latitude', action.result.data.loc.coordinates[1]);
      });
    case USER_LOAD_SUCCESS:
      // 置入用户的地理位置
      return state.withMutations((mutation) => {
        mutation
          .set('longitude', action.result.data.loc.coordinates[0])
          .set('latitude', action.result.data.loc.coordinates[1]);
      });

    default:
      return state;
  }
}

export function rehydrate(dispatch) {
  AsyncStorage.getItem(REHYDRATE).then(str => {
    let state;
    if (str) {
      state = transit.fromJSON(str);
    }
    dispatch({
      type: REHYDRATE,
      data: state,
    });
  })
  .catch(err => {
    console.log('hydrate error', err);
    dispatch({
      type: REHYDRATE,
      data: null,
    });
  });
}

// 这玩意，在跟组建上脱水吧 debounce一发！
export function dehydrate() {
  return (dispatch, getState) => {
    const meState = getState().lbs;
    const toSave = transit.toJSON(
      meState.delete('hydrated')
        .filter((value, key) => {
          const testKey = key.toLowerCase();
          if (testKey.indexOf('error') > -1 || testKey.indexOf('ing') > -1) {
            return false;
          }
          return true;
        })
    );
    console.log('will save lbs', toSave);
    AsyncStorage.setItem(REHYDRATE, toSave);
  };
}


export function loadLbs() {
  return {
    type: LOAD_LBS,
  };
}

export function loadLbsSuccess(pos) {
  return {
    type: LOAD_LBS_SUCCESS,
    pos,
  };
}

export function loadLbsFail(error) {
  return {
    type: LOAD_LBS_FAIL,
    error,
  };
}
