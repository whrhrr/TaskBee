import { Map, fromJS } from 'immutable';
import {filterToId} from '../utils/dataProcessor';

// 其实是post啦
const LOAD_POST = 'taskbee/post/LOAD_POST';
const LOAD_POST_SUCCESS = 'taskbee/post/LOAD_POST_SUCCESS';
const LOAD_POST_FAIL = 'taskbee/post/LOAD_POST_FAIL';

const START_COMMENT = 'taskbee/post/START_COMMENT';
const STOP_COMMENT = 'taskbee/post/STOP_COMMENT';
const NEW_COMMENT = 'taskbee/post/NEW_COMMENT';
const NEW_COMMENT_SUCCESS = 'taskbee/post/NEW_COMMENT_SUCCESS';
const NEW_COMMENT_FAIL = 'taskbee/post/NEW_COMMENT_FAIL';

const LOAD_HOTEST = 'taskbee/post/LOAD_HOTEST';
const LOAD_HOTEST_SUCCESS = 'taskbee/post/LOAD_HOTEST_SUCCESS';
const LOAD_HOTEST_FAIL = 'taskbee/post/LOAD_HOTEST_FAIL';

import {GET_POLLENS_SUCCESS} from './me';

const INITIAL_STATE = new Map({
  hotPost: [],
});

function loadHotestSuccess(state, action) {
  return state.withMutations((mutation) => {
    if (action.result.data.length < action.start + action.span) {
      mutation.set('noMoreHot', true);
    }
    // 填给post
    action.result.data.forEach(post => {
      mutation.mergeIn([post._id], Map(post));
    });
    mutation.set('loadingHotest', false)
      .set('errorHotest', null)
      .update('hotPost', posts => {
        if (action.start === 0) {
          return action.result.data;
        }
        return posts.slice(0, action.start + 1).concat(action.result.data);
      });
  });
}

export default function user(state = INITIAL_STATE, action = {}) {
  switch (action.type) {
    case GET_POLLENS_SUCCESS:
      return state.withMutations((mutation) => {
        action.result.data.forEach(pollen => {
          const post = pollen.postId;
          mutation.mergeIn([post._id], Map(post));
        });
      });
    case LOAD_POST:
      return state.withMutations((mutation) => {
        mutation.set('loadingPollen', true)
          .set('errorPollen', null);
      });
    case LOAD_POST_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('loadingPollen', false)
          .set('errorPollen', null)
          .mergeIn([action.key], action.result.data); // auto map
      });

    case LOAD_POST_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('loadingPollen', true)
          .set('errorPollen', action.error);
      });

    case START_COMMENT:
      return state.setIn([action.key, 'commentOpen'], true);
    case STOP_COMMENT:
      return state.setIn([action.key, 'commentOpen'], false);
    case NEW_COMMENT:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'commentSubmitting'], true)
          .setIn([action.key, 'commentError'], null)
          .setIn([action.key, 'commentSuccess'], false);
      });
    case NEW_COMMENT_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'commentSubmitting'], false)
          .setIn([action.key, 'commentError'], null)
          .setIn([action.key, 'commentSuccess'], true)
          .setIn([action.key, 'commentOpen'], false)
          .updateIn([action.key, 'comments'], comments => comments.concat(action.result.data))
          .updateIn([action.key, 'commentCount'], count => count + 1);
      });
    case NEW_COMMENT_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn([action.key, 'commentSubmitting'], false)
          .setIn([action.key, 'commentError'], action.error)
          .setIn([action.key, 'commentSuccess'], false);
      });
    case LOAD_HOTEST:
      return state.withMutations((mutation) => {
        mutation.set('loadingHotest', true)
          .set('errorHotest', null);
      });
    case LOAD_HOTEST_SUCCESS:
      return loadHotestSuccess(state, action);
    case LOAD_HOTEST_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('loadingHotest', false)
          .set('errorHotest', action.error);
      });
    default:
      return state;
  }
}

export function loadPost(postId) {
  return {
    types: [LOAD_POST, LOAD_POST_SUCCESS, LOAD_POST_FAIL],
    promise: (client) => client.get('/post/loadPost', { params: {
      postId,
    }}),
    key: postId,
  };
}


/*
  评论
 */
export function newComment({taskId, to, body, token}) {
  return {
    types: [NEW_COMMENT, NEW_COMMENT_SUCCESS, NEW_COMMENT_FAIL],
    promise: (client) => client.post('/post/comment', {
      data: {
        postId: taskId,
        to,
        body
      },
      token
    }),
    key: taskId
  };
}

export function startComment({postId}) {
  return {
    type: START_COMMENT,
    key: postId
  };
}

export function stopComment({postId}) {
  return {
    type: STOP_COMMENT,
    key: postId
  };
}

export function getHotest(start = 0, span = 15) {
  return {
    types: [LOAD_HOTEST, LOAD_HOTEST_SUCCESS, LOAD_HOTEST_FAIL],
    promise: (client) => client.get('/post/hotest', {
      params: {
        start,
        span
      },
    }),
    start,
    span,
  };
}
