import {AsyncStorage} from 'react-native';
import {debounce} from '../utils/componentEvents';

export const GET_SYS_MESSAGE = 'taskbee/sysMessages/GET_SYS_MESSAGE';
export const GET_NEW_SYS = 'taskbee/sysMessage/GET_NEW_SYS';
export const CHECK_SYS_MESSAGE = 'taskbee/sysMessage/CHECK_SYS_MESSAGE';
const LEAVE_SYS_MESSAGE = 'taskbee/sysMessage/LEAVE_SYS_MESSAGE';

export const VISIT = 'sysMessage/VISIT';

export const REHYDRATE = 'sysMessage/REHYDRATE';

// 外来
import {LOGOUT} from './user';

const initialState = {
  messages: [],
  unread: 0,
  isInSys: false, // true for debug
  hydrated: false,
};


function checkSysMessage(state, action) {
  if (state.isInSys) {
    let unread = state.unread;
    const messages = state.messages.map(message => {
      // !!! side effects
      if (!message.read) {
        unread--;
        return {
          ...message,
          read: true,
        };
      }
      return message;
    });
    return {
      ...state,
      unread,
      messages,
    };
  } else return {
    ...state,
    isInSys: true,
  }
}

export default function sysMessage(state = initialState, action = {}) {
  switch (action.type) {
    case REHYDRATE:
      return {
        ...state,
        ...action.data,
        hydrated: true,
      };
    case GET_NEW_SYS:
      return {
        ...state,
        unread: state.unread + action.result.data.length,
        messages: action.result.data.concat(state.messages),
      };
    case GET_SYS_MESSAGE:
      return {
        ...state,
        unread: state.unread + 1,
        messages: [action.result.data, ...state.messages],
      };
    case VISIT:
      let unread = state.unread;
      const messages = state.messages.map(message => {
        // !!! side effects
        if (!message.read && message.href === action.key) {
          unread--;
          return {
            ...message,
            read: true,
          };
        }
        return message;
      });
      return {
        ...state,
        unread,
        messages,
      };
    case CHECK_SYS_MESSAGE:
      return checkSysMessage(state, action);
    case LEAVE_SYS_MESSAGE:
      return {
        ...state,
        isInSys: false,
      };
    case LOGOUT:
      return {
        ...initialState,
        hydrated: true,
      };
    default:
      return state;
  }
}



export function rehydrate(dispatch) {
  AsyncStorage.getItem(REHYDRATE).then(str => {
    let state;
    if (str) {
      state = JSON.parse(str);
    }
    dispatch({
      type: REHYDRATE,
      data: state,
    });
  })
  .catch(err => {
    dispatch({
      type: REHYDRATE,
      data: null,
    });
  });
}

export const dehydrate = debounce(function dehydrate(getState) {
  const messages = getState().sysMessages;
  const store = {};
  store.unread = messages.unread;
  store.messages = messages.messages.slice(0, 40);
  AsyncStorage.setItem(REHYDRATE, JSON.stringify(store));
});


// 收到一堆新消息
export function getSysMessage(data) {
  return (dispatch, getState) => {
    dispatch({
      type: GET_SYS_MESSAGE,
      result: data
    });
    dehydrate(getState);
  };
}

// 获取未读聊天消息
export function getNewSys(data) {
  return (dispatch, getState) => {
    dispatch({
      type: GET_NEW_SYS,
      result: data,
    });
    // 保存
    dehydrate(getState);
  };
}

// 获取未读聊天消息
export function visit(href) {
  return (dispatch, getState) => {
    dispatch({
      type: VISIT,
      key: href,
    });
    // 保存
    dehydrate(getState);
  };
}


/*
  tab跳转到系统消息
*/
export function checkMessage() {
  return (dispatch, getState) => {
    dispatch({
      type: CHECK_SYS_MESSAGE,
    });
    // 保存
    dehydrate(getState);
  };
}

export function leaveMessage() {
  return {
    type: LEAVE_SYS_MESSAGE,
  };
}
