const CREATE = 'taskbee/create/CREATE';
export const CREATE_SUCCESS = 'taskbee/create/CREATE_SUCCESS';
const CREATE_FAIL = 'taskbee/create/CREATE_FAIL';

const CREATE_EVENT = 'taskbee/create/CREATE_EVENT';
export const CREATE_EVENT_SUCCESS = 'taskbee/create/CREATE_EVENT_SUCCESS';
const CREATE_EVENT_FAIL = 'taskbee/create/CREATE_EVENT_FAIL';


const CREATE_POST = 'taskbee/create/CREATE_POST';
export const CREATE_POST_SUCCESS = 'taskbee/create/CREATE_POST_SUCCESS';
const CREATE_POST_FAIL = 'taskbee/create/CREATE_POST_FAIL';

const GET_TAG = 'taskbee/create/GET_TAG';
const GET_TAG_SUCCESS = 'taskbee/create/GET_TAG_SUCCESS';
const GET_TAG_FAIL = 'taskbee/create/GET_TAG_FAIL';

const NEW_TAG = 'taskbee/create/NEW_TAG';
const NEW_TAG_SUCCESS = 'taskbee/create/NEW_TAG_SUCCESS';
const NEW_TAG_FAIL = 'taskbee/create/NEW_TAG_FAIL';

const NEW_PUBLISH = 'taskbee/create/NEW_PUBLISH';
const NEW_PUBLISH_POST = 'taskbee/create/NEW_PUBLISH_POST';

const initialState = {
  tagLoaded: false,
  tags: [],
};

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case NEW_PUBLISH:
      return {
        ...state,
        success: false,
        tmpTag: action.tmpTag
      };
    case NEW_PUBLISH_POST:
      return {
        ...state,
        successPost: false,
      };
    case CREATE:
      return {
        ...state,
        error: null,
        creating: true,
      };
    case CREATE_SUCCESS:
      return {
        ...state,
        // data: action.result.data,
        success: action.error ? '抱歉图片迷路了～' : true,
        creating: false,
      };
    case CREATE_FAIL:
      return {
        ...state,
        error: action.error,
        creating: false,
      };
    case NEW_TAG:
      return {
        ...state,
        newTagError: null
      };
    case NEW_TAG_SUCCESS:
      if (state.tags.some(tag => tag.name === action.result.data.name)) {
        return {
          ...state,
          newTagError: null,
        };
      }
      return {
        ...state,
        newTagError: null,
        tags: state.tags.concat(action.result.data)
      };
    case NEW_TAG_FAIL:
      return {
        ...state,
        newTagError: action.error
      };
    case GET_TAG:
      return {
        ...state,
        gettingTag: true,
        getTagError: null
      };
    case GET_TAG_SUCCESS:
      return {
        ...state,
        gettingTag: false,
        getTagError: null,
        tags: action.result.data,
        tagLoaded: true,
      };
    case GET_TAG_FAIL:
      return {
        ...state,
        gettingTag: false,
        getTagError: action.error
      };
    case CREATE_POST:
      return {
        ...state,
        errorPost: null,
        creatingPost: true,
      };
    case CREATE_POST_SUCCESS:
      return {
        ...state,
        dataPost: action.result.data,
        successPost: action.error ? '抱歉图片迷路了～' : true,
        creatingPost: false,
        signed: action.result.signed,
      };
    case CREATE_POST_FAIL:
      return {
        ...state,
        errorPost: action.error,
        creatingPost: false,
      };
    case CREATE_EVENT:
      return {
        ...state,
        errorEvent: null,
        creatingEvent: true,
      };
    case CREATE_EVENT_SUCCESS:
      return {
        ...state,
        // data: action.result.data,
        successEvent: action.error ? '抱歉图片迷路了～' : true,
        creatingEvent: false,
      };
    case CREATE_EVENT_FAIL:
      return {
        ...state,
        errorEvent: action.error,
        creatingEvent: false,
      };
    default:
      return state;
  }
}

export function isTagLoaded(globalState) {
  return globalState.publish && globalState.publish.tagLoaded;
}

export function newTag({token, tagName}) {
  return {
    types: [NEW_TAG, NEW_TAG_SUCCESS, NEW_TAG_FAIL],
    promise: (client) => client.post('/tag/newTag', {
      data: {
        name: tagName
      },
      token
    }),
  };
}

export function getTags() {
  return {
    types: [GET_TAG, GET_TAG_SUCCESS, GET_TAG_FAIL],
    promise: (client) => client.get('/tag/getTags')
  };
}

export function getTagsMore() {
  return {
    types: [CREATE, CREATE_SUCCESS, CREATE_FAIL],
    promise: (client) => client.get('/tag/getTagsMore')
  };
}

export function create({description, secret, dueTime, startTime, reward, tags, token, pos, images}) {
  return {
    types: [CREATE, CREATE_SUCCESS, CREATE_FAIL],
    promise: (client) => client.post('/task/create', {
      data: {
        description,
        secret,
        dueTime,
        startTime,
        reward,
        tags,
        pos,
      },
      token
    }),
    reward,
    uploadImages: images,
  };
}

export function newPublish(tmpTag) {
  return {
    type: NEW_PUBLISH,
    tmpTag
  };
}

export function createPost({description, token, pos, images}) {
  return {
    types: [CREATE_POST, CREATE_POST_SUCCESS, CREATE_POST_FAIL],
    promise: (client) => client.post('/post/create', {
      data: {
        description,
        pos,
      },
      token,
    }),
    uploadImages: images,
  };
}

export function newPublishPost() {
  return {
    type: NEW_PUBLISH_POST,
  };
}


export function createEvent({description, dueTime, startTime, token, pos, images}) {
  return {
    types: [CREATE_EVENT, CREATE_EVENT_SUCCESS, CREATE_EVENT_FAIL],
    promise: (client) => client.post('/task/createEvent', {
      data: {
        description,
        dueTime,
        startTime,
        pos,
      },
      token
    }),
    uploadImages: images,
  };
}
