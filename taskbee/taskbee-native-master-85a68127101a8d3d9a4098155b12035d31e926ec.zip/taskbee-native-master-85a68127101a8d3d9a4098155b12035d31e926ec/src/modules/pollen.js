// import {filterToId} from '../../utils/dataProcessor';
import {trackEvent} from 'react-native-talkingdata';
const LOAD = 'taskbee/pollen/LOAD';
const LOAD_SUCCESS = 'taskbee/pollen/LOAD_SUCCESS';
const LOAD_FAIL = 'taskbee/pollen/LOAD_FAIL';

const STORAGE = 'taskbee/pollen/STORAGE';
const STORAGE_SUCCESS = 'taskbee/pollen/STORAGE_SUCCESS';
const STORAGE_FAIL = 'taskbee/pollen/STORAGE_FAIL';

const COLLECT = 'taskbee/pollen/COLLECT';
const COLLECT_SUCCESS = 'taskbee/pollen/COLLECT_SUCCESS';
const COLLECT_FAIL = 'taskbee/pollen/COLLECT_FAIL';

const ABANDON = 'taskbee/pollen/ABANDON';
const ABANDON_SUCCESS = 'taskbee/pollen/ABANDON_SUCCESS';

const ABANDON_FAIL = 'taskbee/pollen/ABANDON_FAIL';

const CAST = 'taskbee/pollen/CAST';
const CAST_SUCCESS = 'taskbee/pollen/CAST_SUCCESS';
const CAST_FAIL = 'taskbee/pollen/CAST_FAIL';

import {GET_POLLENS_SUCCESS, LOGOUT} from './me';



const initialState = {
  loaded: false,
  list: [],
  listDead: [],
  collected: [],
  storageLoaded: false,
};

function removeFromCollected(state, action) {
  // 找到被移除的花粉
  const castPollen = state.list.find((elem) => {
    return elem._id === action.key;
  });
  if (!castPollen) {
    return {
      ...state,
      collected: state.collected.slice(1),
    };
  }
  const {postId} = castPollen;
  return {
    ...state,
    collected: state.collected.slice(1),
    list: state.list.filter( item => {
      return item.postId !== postId;
    }),
    listDead: state.listDead.concat(state.list.filter( item => item.postId === postId))
  };
}

export default function pollen(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD:
      return {
        ...state,
        loading: true,
        error: ''
      };
    case LOAD_SUCCESS:
      return {
        ...state,
        loaded: true,
        loading: false,
        list: action.result.data.pollens,
        listDead: action.result.data.deadPollens,
      };
    case LOAD_FAIL:
      return {
        ...state,
        loading: false,
        error: action.error
      };
    case STORAGE:
      return {
        ...state,
        loadingCollect: true,
        errorCollect: null,
      };
    case STORAGE_SUCCESS:
      return {
        ...state,
        loadingCollect: false,
        collected: action.result.data,
        storageLoaded: true,
      };
    case STORAGE_FAIL:
      return {
        ...state,
        loadingCollect: false,
        errorCollect: action.error
      };
    case COLLECT:
      return {
        ...state,
        loadingCollect: true,
        errorCollect: null,
      };
    case COLLECT_SUCCESS:
      return {
        ...state,
        lastCollectTime: action.side,
        loadingCollect: false,
        errorCollect: null,
        collected: state.collected.concat(action.result.data),
      };
    case COLLECT_FAIL:
      return {
        ...state,
        loadingCollect: false,
        errorCollect: action.error
      };

    case ABANDON:
      return removeFromCollected(state, action);
    case CAST:
      return removeFromCollected(state, action);
    case CAST_SUCCESS:
      // 添加新的点~
      return {
        ...state,
        listDead: state.listDead.concat(action.result.data),
        errorCollect: null,
      };

    case LOGOUT:
      return {
        ...initialState,
      };
    default:
      return state;
  }
}

export function isLoaded(globalState) {
  return globalState.pollen && globalState.pollen.loaded;
}

export function load(long, lati) {
  return {
    types: [LOAD, LOAD_SUCCESS, LOAD_FAIL],
    promise: (client) => client.get('/post/nearby', { params: {
      long,
      lati,
    }}),
  };
}

export function collect({long, lati, token}) {
  return {
    types: [COLLECT, COLLECT_SUCCESS, COLLECT_FAIL],
    promise: (client) => client.post('/post/collect', {
      data: {
        pos: [long, lati],
      },
      token,
    }),
    successSide: Date.now
  };
}
export function storage({token}) {
  return {
    types: [STORAGE, STORAGE_SUCCESS, STORAGE_FAIL],
    promise: (client) => client.post('/post/storage', {
      token,
    }),
  };
}

function goCollect(data) { // {long, lati, token}
  return (result, dispatch, getState) => {
    if (getState().pollen.collected.length < 10) {
      dispatch(collect(data));
    }
  };
}

export function abandon({long, lati, id, token}) {
  if(!__DEV__) trackEvent('pollen', 'abandon');
  return {
    types: [ABANDON, ABANDON_SUCCESS, ABANDON_FAIL],
    promise: (client) => client.post('/post/abandon', {
      data: {
        id,
      },
      token,
    }),
    key: id,
    successSide: goCollect({long, lati, token})
  };
}

export function cast({long, lati, id, token}) {
  if(!__DEV__) trackEvent('pollen', 'cast');
  return {
    types: [CAST, CAST_SUCCESS, CAST_FAIL],
    promise: (client) => client.post('/post/cast', {
      data: {
        id,
        pos: [long, lati],
      },
      token,
    }),
    key: id,
    successSide: goCollect({long, lati, token})
  };
}
