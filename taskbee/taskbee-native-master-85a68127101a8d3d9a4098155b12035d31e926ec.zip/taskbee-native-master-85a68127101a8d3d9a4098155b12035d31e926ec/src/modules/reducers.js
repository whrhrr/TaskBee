import {combineReducers} from 'redux';

import {reducer as form} from 'redux-form';
import me from './me';
import verify from './verify';
import task from './task';
import user from './user';
import messages from './messages';
import sysMessages from './sysMessages';
import misc from './misc';
import lists from './lists';
import pollen from './pollen';
import post from './post';
import publish from './publish';
import order from './order';
import lbs from './lbs';

export default combineReducers({
  me,
  form,
  verify,
  task,
  user,
  messages,
  sysMessages,
  misc,
  lists,
  pollen,
  post,
  publish,
  order,
  lbs,
});
