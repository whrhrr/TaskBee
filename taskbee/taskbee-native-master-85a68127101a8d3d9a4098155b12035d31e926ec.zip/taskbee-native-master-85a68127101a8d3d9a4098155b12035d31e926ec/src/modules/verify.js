const LOAD = 'taskbee/verify/LOAD';
const LOAD_SUCCESS = 'taskbee/verify/LOAD_SUCCESS';
const LOAD_FAIL = 'taskbee/verify/LOAD_FAIL';
const VERIFY = 'taskbee/verify/VERIFY';
const VERIFY_SUCCESS = 'taskbee/verify/VERIFY_SUCCESS';
const VERIFY_FAIL = 'taskbee/verify/VERIFY_FAIL';

import {REGISTER_SUCCESS, CHANGEPASSWORD_SUCCESS} from './me';

const initialState = {
  availableTime: Date.now()
};

export default function verify(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD:
      return {
        ...state,
        loading: true,
        error: null,
        phone: action.phone
      };
    case LOAD_SUCCESS:
      return {
        ...state,
        loading: false,
        phone: action.phone,
        availableTime: action.side,
      };
    case LOAD_FAIL:
      action.error.errorCode = 'verify';
      return {
        ...state,
        loading: false,
        error: action.error,
        phone: null
      };
    case VERIFY:
      return {
        ...state,
        verifying: true,
        verifyError: null,
        phone: action.phone
      };
    case VERIFY_SUCCESS:
      return {
        ...state,
        verifying: false,
        verifyToken: action.result.token,
        phone: action.phone
      };
    case VERIFY_FAIL:
      return {
        ...state,
        verifying: false,
        verifyToken: null,
        verifyError: action.error,
        phone: null
      };
    case REGISTER_SUCCESS:
      return {
        ...state,
        verifyToken: null,
      };
    case CHANGEPASSWORD_SUCCESS:
      return {
        ...state,
        verifyToken: null,
      };
    default:
      return state;
  }
}

export function getCode({phone, forget}) {
  return {
    types: [LOAD, LOAD_SUCCESS, LOAD_FAIL],
    promise: (client) => client.post('/user/getCode', {
      data: {
        phone,
        forget
      }
    }),
    phone,
    successSide: () => Date.now() + 1000 * 90
  };
}

export function verifyCode({phone, code, forget}) {
  return {
    types: [VERIFY, VERIFY_SUCCESS, VERIFY_FAIL],
    promise: (client) => client.post('/user/verifyCode', {
      data: {
        phone,
        code,
        forget
      }
    }),
    phone,

  };
}
