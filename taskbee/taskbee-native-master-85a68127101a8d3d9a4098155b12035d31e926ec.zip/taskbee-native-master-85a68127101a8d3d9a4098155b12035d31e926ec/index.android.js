'use strict';

import React, { AppRegistry } from 'react-native';
import App from './src/containers/App';

AppRegistry.registerComponent('taskbee', () => App);
