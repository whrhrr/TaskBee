export const SECRET = 'jiongxiaobujujuju-secret';
export const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost/heart';
export const PORT = process.env.PORT || 7070;
export const TOKEN_EXPIRE = 60 * 60 * 24 * 30 * 2; // x秒jwt到期

export const callbackUrl = process.env.NODE_ENV === 'production' ? 'http://moha.taskbee.cn' : 'http://moha.taskbee.cn/testmo';
export const weAppId = 'wx8e54c0e3fc2f40d2'; // process.env.NODE_ENV === 'production' ? 'wx8e54c0e3fc2f40d2' : 'wxfffba96f903dfd21';
export const weSecret = '3bf60257e8fcc95d2266358cfbe0eb84'; // process.env.NODE_ENV === 'production' ? '3bf60257e8fcc95d2266358cfbe0eb84' : '6af6974a38541577c438317245ac1e98';

import fs from 'fs';
const jiongjubu = 'jiongjubujiongjubujiongjubujiong';
export const wePayConfig = {
  partnerKey: jiongjubu,
  appId: 'wx8e54c0e3fc2f40d2',
  mchId: '1349333101',
  pfx: fs.readFileSync('./apiclient_cert.p12'),
  notifyUrl: callbackUrl + '/wepay',
};
