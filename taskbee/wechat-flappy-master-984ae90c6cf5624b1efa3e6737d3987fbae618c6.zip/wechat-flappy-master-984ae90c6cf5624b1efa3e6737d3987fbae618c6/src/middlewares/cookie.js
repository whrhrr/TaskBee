import cookieParser from 'cookie-parser';
export default cookieParser();