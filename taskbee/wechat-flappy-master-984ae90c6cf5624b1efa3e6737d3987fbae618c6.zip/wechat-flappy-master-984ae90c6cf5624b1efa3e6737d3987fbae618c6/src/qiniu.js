import qiniu from 'qiniu';

qiniu.conf.ACCESS_KEY = 'Dju5t_O9uD6yB_-bjv1-J3oduQjRDP2a7nGHICLO';
qiniu.conf.SECRET_KEY = 'd5_HMDEi6rFtGkzio3NeaNYm7aIxecyd9b6Wh8XX';

export default qiniu;
