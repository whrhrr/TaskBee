/**
 * THIS IS THE ENTRY POINT FOR THE CLIENT, JUST LIKE server.js IS THE ENTRY POINT FOR THE SERVER.
 */
import 'babel/polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/lib/createBrowserHistory';
import useScroll from 'scroll-behavior/lib/useStandardScroll';
import createStore from './redux/create';
import ApiClient from './helpers/ApiClient';
import io from 'socket.io-client';
import {Provider} from 'react-redux';
import {reduxReactRouter, ReduxRouter} from 'redux-router';

import getRoutes from './routes';
import makeRouteHooksSafe from './helpers/makeRouteHooksSafe';
import {connected, disconnected} from './redux/modules/misc';
import {getMessage, getNew, getStatus} from './redux/modules/messages';
import {getNewSys, getSysMessage} from './redux/modules/sysMessages';
import {saveMessages} from './utils/storage';
import moment from 'moment';
moment.locale('zh-cn');

// window.mapboxgl = require('mapboxgl');

const client = new ApiClient();

// Three differnt types of scroll behavior available.
// Documented here: https://github.com/rackt/scroll-behavior
const scrollableHistory = useScroll(createHistory);
const dest = document.getElementById('content');

// 从localStorage读取历史的message store，存入当前store当中
const rawMessages = localStorage.getItem('messages');
let processedMessages;
if (rawMessages) {
  try {
    processedMessages = JSON.parse(rawMessages);
    window.__data.messages = processedMessages;
  } catch (ex) {
    console.log('读取聊天信息错误， 你做了什么！');
  }
}
const store = createStore(reduxReactRouter, makeRouteHooksSafe(getRoutes), scrollableHistory, client, window.__data);

window.onunload = function savesave() {
  saveMessages(store.getState().messages);
};

function initSocket(getState, dispatch) {
  const socket = io('', {path: '/ws'});
  function login() {
    socket.emit('bearer', getState().user.token);
  }
  socket.on('connect', login);
  socket.on('reconnect', login);

  socket.on('bearer', () => {
    dispatch(connected());
    // 载入聊天数据
    socket.emit('getNew', null, function getNewCallback(data) {
      dispatch(getNew(data));
    });
    // 载入系统消息
    socket.emit('getNewSystem', null, function getNewSystemCallback(data) {
      dispatch(getNewSys(data));
    });
  });
  socket.on('disconnect', () => {
    dispatch(disconnected());
  });
  socket.on('message', (data) => {
    // 得到消息的时候，应该给其他地方推送数量增加
    dispatch(getMessage(data));
  });
  socket.on('sysMessage', (data) => {
    dispatch(getSysMessage(data));
  });
  socket.on('status', (data) => {
    dispatch(getStatus(data));
  });
  return socket;
}


// 让我们来把store和io衔接上吧
let lastMeId;
function handleChange() {
  const state = store.getState(); // 获取state tree
  if (state.user.meId) {
    if (!global.socket) {
      global.socket = initSocket(store.getState, store.dispatch);
      if (window.ga) {
        window.ga('set', '&uid', state.user.meId);
      } else {
        setTimeout(function realGa() {
          if (window.ga) window.ga('set', '&uid', state.user.meId);
        }, 15000); // 等待15秒后再set
      }
    } else if (global.socket.disconnected) {
      // 断线重连
      socket.connect();
      if (window.ga) window.ga('set', '&uid', state.user.meId);
    }
  } else if (lastMeId && global.socket.connected && !state.user.meId) {
    global.socket.disconnect();
  }
  lastMeId = state.user.meId;

}
store.subscribe(handleChange); // 会返回一个unscribe，但是因为我们整个生命都需要，所以不必了

const component = (
  <ReduxRouter routes={getRoutes(store)} />
);

ReactDOM.render(
  <Provider store={store} key="provider">
    {component}
  </Provider>,
  dest
);

if (process.env.NODE_ENV !== 'production') {
  window.React = React; // enable debugger

  if (!dest || !dest.firstChild || !dest.firstChild.attributes || !dest.firstChild.attributes['data-react-checksum']) {
    console.error('Server-side React render was discarded. Make sure that your initial render does not contain any client-side code.');
  }
}

if (__DEVTOOLS__ && !window.devToolsExtension) {
  const DevTools = require('./containers/DevTools/DevTools');
  ReactDOM.render(
    <Provider store={store} key="provider">
      <div>
        {component}
        <DevTools />
      </div>
    </Provider>,
    dest
  );
}

console.info('HI, 我们是蜂房！如果你喜欢Javascript、喜欢React、喜欢最新的前端技术，又有一些实战经验，亦或是NodeJS大神，欢迎加入我们，加QQ群：478227215，请注明对技术有兴趣奥');
