import {filterToId, arrayToObject} from 'utils/dataProcessor';

const CREATE = 'taskbee/order/CREATE';
const CREATE_SUCCESS = 'taskbee/order/CREATE_SUCCESS';
const CREATE_FAIL = 'taskbee/order/CREATE_FAIL';

const LOAD = 'taskbee/order/LOAD';
const LOAD_SUCCESS = 'taskbee/order/LOAD_SUCCESS';
const LOAD_FAIL = 'taskbee/order/LOAD_FAIL';

const LOAD_LIST = 'taskbee/order/LOAD_LIST';
const LOAD_LIST_SUCCESS = 'taskbee/order/LOAD_LIST_SUCCESS';
const LOAD_LIST_FAIL = 'taskbee/order/LOAD_LIST_FAIL';

const WITHDRAW = 'taskbee/order/WITHDRAW';
export const WITHDRAW_SUCCESS = 'taskbee/order/WITHDRAW_SUCCESS';
const WITHDRAW_FAIL = 'taskbee/order/WITHDRAW_FAIL';
const WITHDRAW_AGAIN = 'taskbee/order/WITHDRAW_AGAIN';

const LOAD_WITHDRAW_LIST = 'taskbee/order/LOAD_WITHDRAW_LIST';
const LOAD_WITHDRAW_LIST_SUCCESS = 'taskbee/order/LOAD_WITHDRAW_LIST_SUCCESS';
const LOAD_WITHDRAW_LIST_FAIL = 'taskbee/order/LOAD_WITHDRAW_LIST_FAIL';

const REDPOCKET = 'taskbee/order/REDPOCKET';
export const REDPOCKET_SUCCESS = 'taskbee/order/REDPOCKET_SUCCESS';
const REDPOCKET_FAIL = 'taskbee/order/REDPOCKET_FAIL';
const REDPOCKET_AGAIN = 'taskbee/order/REDPOCKET_AGAIN';

const initialState = {
  orders: [],
  withdraws: [],
};

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case CREATE:
      return {
        ...state,
        createError: null,
        creating: true,
      };
    case CREATE_SUCCESS:
      return {
        ...state,
        createError: null,
        creating: false,
        nextOrder: action.result.data._id,
        [action.result.data._id]: action.result.data,
      };
    case CREATE_FAIL:
      return {
        ...state,
        createError: action.error,
        creating: false,
      };
    case LOAD:
      return {
        ...state,
        loadingOrder: true,
        loadOrderError: null,
      };
    case LOAD_SUCCESS:
      return {
        ...state,
        loadingOrder: false,
        loadOrderError: null,
        [action.result.data._id]: {
          ...state[action.result.data._id],
          ...action.result.data,
        }
      };
    case LOAD_FAIL:
      return {
        ...state,
        loadingOrder: false,
        loadOrderError: action.error,
      };
    case LOAD_LIST:
      return {
        ...state,
        loadingList: true,
        loadingListError: null,
      };
    case LOAD_LIST_SUCCESS:
      return {
        ...state,
        loadingList: false,
        loadingListError: null,
        orders: filterToId(action.result.data),
        ...arrayToObject(action.result.data),
      };
    case LOAD_LIST_FAIL:
      return {
        ...state,
        loadingList: false,
        loadingListError: action.error,
      };

    case LOAD_WITHDRAW_LIST:
      return {
        ...state,
        loadingWithdrawList: true,
        loadWithdrawListError: null,
      };
    case LOAD_WITHDRAW_LIST_SUCCESS:
      return {
        ...state,
        loadingWithdrawList: false,
        loadWithdrawListError: null,
        withdraws: action.result.data,
      };
    case LOAD_WITHDRAW_LIST_FAIL:
      return {
        ...state,
        loadingWithdrawList: false,
        loadWithdrawListError: action.error,
      };
    case WITHDRAW_AGAIN:
      return {
        ...state,
        withdrawSuccess: false,
      };
    case WITHDRAW:
      return {
        ...state,
        withdrawing: true,
        withdrawError: null,
      };
    case WITHDRAW_SUCCESS:
      return {
        withdrawing: false,
        withdrawError: null,
        withdrawSuccess: true,
      };
    case WITHDRAW_FAIL:
      return {
        ...state,
        withdrawing: false,
        withdrawError: action.error,
        withdrawSuccess: null,
      };
    case REDPOCKET_AGAIN:
      return {
        ...state,
        redpocketSuccess: false,
      };
    case REDPOCKET:
      return {
        ...state,
        redpocketing: true,
        redpocketError: null,
      };
    case REDPOCKET_SUCCESS:
      return {
        redpocketing: false,
        redpocketError: null,
        redpocketSuccess: action.result.data,
      };
    case REDPOCKET_FAIL:
      return {
        ...state,
        redpocketing: false,
        redpocketError: action.error,
        redpocketSuccess: false,
      };
    default:
      return state;
  }
}

export function createOrder({orderId, token}) {
  return {
    types: [CREATE, CREATE_SUCCESS, CREATE_FAIL],
    promise: (client) => client.post('/order/create', {
      data: {
        orderId
      },
      token
    })
  };
}

export function loadOrderDetail(orderId) {
  return {
    types: [LOAD, LOAD_SUCCESS, LOAD_FAIL],
    promise: (client) => client.get('/order/orderDetail', {
      params: {
        orderId
      }
    })
  };
}

export function loadOrderList() {
  return {
    types: [LOAD_LIST, LOAD_LIST_SUCCESS, LOAD_LIST_FAIL],
    promise: (client) => client.get('/order/orders')
  };
}

export function withdraw({price, money, email, realname, token}) {
  return {
    types: [WITHDRAW, WITHDRAW_SUCCESS, WITHDRAW_FAIL],
    promise: (client) => client.post('/order/withdraw', {
      data: {
        price,
        money,
        realname,
        email,
      },
      token
    }),
    money,
  };
}

export function confirmWithdraw() {
  return {
    type: WITHDRAW_AGAIN
  };
}

export function loadWithdrawList() {
  return {
    types: [LOAD_WITHDRAW_LIST, LOAD_WITHDRAW_LIST_SUCCESS, LOAD_WITHDRAW_LIST_FAIL],
    promise: (client) => client.get('/order/withdraws')
  };
}

export function redpocket({pocketId, token}) {
  return {
    types: [REDPOCKET, REDPOCKET_SUCCESS, REDPOCKET_FAIL],
    promise: (client) => client.post('/order/redpocket', {
      data: {
        pocketId
      },
      token
    }),
  };
}

export function confirmRedpocket() {
  return {
    type: REDPOCKET_AGAIN,
  };
}
