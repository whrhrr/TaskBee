import { combineReducers } from 'redux';
import { routerStateReducer } from 'redux-router';

import user from './user';
import form from './form';
import misc from './misc';
import task from './task';
import verify from './verify';
import publish from './publish';
import lists from './lists';
import messages from './messages';
import sysMessages from './sysMessages';
import order from './order';
import lbs from './lbs';
import pollen from './pollen';
import skill from './skill';

export default combineReducers({
  router: routerStateReducer,
  user,
  form,
  misc,
  task,
  verify,
  publish,
  lists,
  messages,
  sysMessages,
  order,
  lbs,
  pollen,
  skill,
});
