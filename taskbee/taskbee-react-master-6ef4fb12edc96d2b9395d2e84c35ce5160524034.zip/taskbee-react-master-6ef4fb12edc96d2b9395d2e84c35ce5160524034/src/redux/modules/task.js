const FAV = 'taskbee/task/FAV';
const FAV_SUCCESS = 'taskbee/task/FAV_SUCCESS';
const FAV_FAIL = 'taskbee/task/FAV_FAIL';

const UNFAV = 'taskbee/task/UNFAV';
const UNFAV_SUCCESS = 'taskbee/task/UNFAV_SUCCESS';
const UNFAV_FAIL = 'taskbee/task/UNFAV_FAIL';

const LOAD_DETAIL = 'taskbee/task/LOAD_DETAIL';
const LOAD_DETAIL_SUCCESS = 'taskbee/task/LOAD_DETAIL_SUCCESS';
const LOAD_DETAIL_FAIL = 'taskbee/task/LOAD_DETAIL_FAIL';

const START_COMMENT = 'taskbee/task/START_COMMENT';
const STOP_COMMENT = 'taskbee/task/STOP_COMMENT';
const NEW_COMMENT = 'taskbee/task/NEW_COMMENT';
const NEW_COMMENT_SUCCESS = 'taskbee/task/NEW_COMMENT_SUCCESS';
const NEW_COMMENT_FAIL = 'taskbee/task/NEW_COMMENT_FAIL';

const TAKE_TASK = 'taskbee/task/TAKE_TASK';
const TAKE_TASK_SUCCESS = 'taskbee/task/TAKE_TASK_SUCCESS';
const TAKE_TASK_FAIL = 'taskbee/task/TAKE_TASK_FAIL';

const CONFIRM_TASKER = 'taskbee/task/CONFIRM_TASKER';
const CONFIRM_TASKER_SUCCESS = 'taskbee/task/CONFIRM_TASKER_SUCCESS';
const CONFIRM_TASKER_FAIL = 'taskbee/task/CONFIRM_TASKER_FAIL';

const CONFIRM_PUBLISHER = 'taskbee/task/CONFIRM_PUBLISHER';
const CONFIRM_PUBLISHER_SUCCESS = 'taskbee/task/CONFIRM_PUBLISHER_SUCCESS';
const CONFIRM_PUBLISHER_FAIL = 'taskbee/task/CONFIRM_TASKER_FAIL';

const CANCEL_TASKER = 'taskbee/task/CANCEL_TASKER';
const CANCEL_TASKER_SUCCESS = 'taskbee/task/CANCEL_TASKER_SUCCESS';
const CANCEL_TASKER_FAIL = 'taskbee/task/CANCEL_TASKER_FAIL';

const CANCEL_PUBLISHER = 'taskbee/task/CANCEL_PUBLISHER';
const CANCEL_PUBLISHER_SUCCESS = 'taskbee/task/CANCEL_PUBLISHER_SUCCESS';
const CANCEL_PUBLISHER_FAIL = 'taskbee/task/CANCEL_PUBLISHER_FAIL';

const VOTE = 'taskbee/task/VOTE';
const VOTE_SUCCESS = 'taskbee/task/VOTE_SUCCESS';
const VOTE_FAIL = 'taskbee/task/VOTE_FAIL';


/*
  外来的CONST
*/
import {GET_HISTORY_TASKS_SUCCESS, GET_FAV_TASKS_SUCCESS, GET_TASKS_SUCCESS} from './user';
import {LOAD_SUCCESS} from './lists';


function mergeNewTasks(state, data) {
  const newState = {...state};
  data.forEach( task => {
    if (newState[task._id]) {
      // 存在,就merge
      newState[task._id] = {
        ...newState[task._id],
        ...task
      };
    } else newState[task._id] = task;
  });
  return newState;
}

const initialState = {

};

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD_SUCCESS:
      return mergeNewTasks(state, action.result.data);
    case GET_TASKS_SUCCESS:
      return mergeNewTasks(state, action.result.data.taskTaken.concat(action.result.data.taskPublish));
    case GET_HISTORY_TASKS_SUCCESS:
      return mergeNewTasks(state, action.result.data.taskHistory);
    case GET_FAV_TASKS_SUCCESS:
      return mergeNewTasks(state, action.result.data.taskFav);
    case FAV:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          faved: true,
          favs: state[action.key].favs + 1
        }
      };
    case FAV_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          faved: true,
        }
      };
    case FAV_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          faved: false,
          favs: state[action.key].favs - 1
        }
      };
    case UNFAV:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          faved: false,
          favs: state[action.key].favs - 1
        }
      };
    case UNFAV_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          faved: false
        }
      };
    case UNFAV_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          faved: true,
          favs: state[action.key].favs + 1
        }
      };
    case LOAD_DETAIL:
      if (action.reload) {
        return {
          ...state,
          [action.key]: {
            ...state[action.key],
            reloadDetailError: null,
            reloadingDetail: true,
          }
        };
      }
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          detailError: null,
          loadingDetail: true,
        }
      };
    case LOAD_DETAIL_SUCCESS:
      if (action.reload) {
        return {
          ...state,
          [action.key]: {
            ...state[action.key],
            ...action.result.data,
            reloadingDetail: false,
          }
        };
      }
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ...action.result.data,
          loadingDetail: false,
          loadedDetail: true
        }
      };
    case LOAD_DETAIL_FAIL:
      if (action.reload) {
        return {
          ...state,
          [action.key]: {
            ...state[action.key],
            reloadDetailError: action.error,
            reloadingDetail: false
          }
        };
      }
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          detailError: action.error,
          loadingDetail: false
        }
      };
    case START_COMMENT:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          commentOpen: true,
        }
      };
    case STOP_COMMENT:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          commentOpen: false
        }
      };
    case NEW_COMMENT:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          commentError: null,
          commentSuccess: false,
          commentSubmitting: true,
        }
      };
    case NEW_COMMENT_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          comments: state[action.key].comments.concat(action.result.data),
          commentOpen: false,
          commentSuccess: true,
          commentSubmitting: false,
        }
      };
    case NEW_COMMENT_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          commentError: action.error,
          commentSubmitting: false,
        }
      };
    case TAKE_TASK:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: true,
          goError: null,
        }
      };
    case TAKE_TASK_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: false,
          publisher: action.result.data,
          tasker: action.meId,
          state: 1
        }
      };
    case TAKE_TASK_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: false,
          goError: action.error
        }
      };
    case CONFIRM_TASKER:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: true,
          goError: null,
        }
      };
    case CONFIRM_TASKER_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: false,
          state: 2
        }
      };
    case CONFIRM_TASKER_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: false,
          goError: action.error
        }
      };
    case CONFIRM_PUBLISHER:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: true,
          goError: null,
        }
      };
    case CONFIRM_PUBLISHER_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: false,
          state: 3,
          canVote: [state[action.key].publisher._id]
        }
      };
    case CONFIRM_PUBLISHER_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          ongoing: false,
          goError: action.error
        }
      };
    case CANCEL_TASKER:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          cancelling: true,
          cancelError: null
        }
      };
    case CANCEL_TASKER_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          cancelling: false,
          tasker: null,
          state: 0
        }
      };
    case CANCEL_TASKER_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          cancelling: false,
          cancelError: action.error
        }
      };
    case CANCEL_PUBLISHER:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          cancelling: true,
          cancelError: null
        }
      };
    case CANCEL_PUBLISHER_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          cancelling: false,
          state: 5
        }
      };
    case CANCEL_PUBLISHER_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          cancelling: false,
          cancelError: action.error
        }
      };
    case VOTE:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          voting: true,
          voteError: null
        }
      };
    case VOTE_SUCCESS:
      const canVoteArry = state[action.key].canVote;
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          voting: false,
          canVote: canVoteArry.slice().splice(canVoteArry.indexOf(action.meId), 1),
        }
      };
    case VOTE_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          voting: false,
          voteError: action.error,
        }
      };
    default:
      return state;
  }
}

export function fav({id, token}) {
  return {
    types: [FAV, FAV_SUCCESS, FAV_FAIL],
    promise: (client) => client.post('/task/fav', {
      data: {
        taskId: id
      },
      token
    }),
    key: id
  };
}

export function unfav({id, token}) {
  return {
    types: [UNFAV, UNFAV_SUCCESS, UNFAV_FAIL],
    promise: (client) => client.post('/task/unfav', {
      data: {
        taskId: id
      },
      token
    }),
    key: id
  };
}

export function loadDetail({taskId, reload}) {
  return {
    types: [LOAD_DETAIL, LOAD_DETAIL_SUCCESS, LOAD_DETAIL_FAIL],
    promise: client => client.get('/task/taskDetail', {
      params: {
        taskId
      }
    }),
    key: taskId,
    reload
  };
}

export function newComment({taskId, to, body, token}) {
  return {
    types: [NEW_COMMENT, NEW_COMMENT_SUCCESS, NEW_COMMENT_FAIL],
    promise: (client) => client.post('/task/newComment', {
      data: {
        taskId,
        to,
        body
      },
      token
    }),
    key: taskId
  };
}

export function startComment({taskId}) {
  return {
    type: START_COMMENT,
    key: taskId
  };
}

export function stopComment({taskId}) {
  return {
    type: STOP_COMMENT,
    key: taskId
  };
}

export function take({taskId, meId, token}) {
  return {
    types: [TAKE_TASK, TAKE_TASK_SUCCESS, TAKE_TASK_FAIL],
    promise: (client) => client.post('/task/take', {
      data: {
        taskId
      },
      token
    }),
    key: taskId,
    meId
  };
}

export function confirmTasker({taskId, token}) {
  return {
    types: [CONFIRM_TASKER, CONFIRM_TASKER_SUCCESS, CONFIRM_TASKER_FAIL],
    promise: (client) => client.post('/task/confirmTasker', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}


export function confirmPublisher({taskId, token}) {
  return {
    types: [CONFIRM_PUBLISHER, CONFIRM_PUBLISHER_SUCCESS, CONFIRM_PUBLISHER_FAIL],
    promise: (client) => client.post('/task/confirmPuber', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}

export function cancelTasker({taskId, token}) {
  return {
    types: [CANCEL_TASKER, CANCEL_TASKER_SUCCESS, CANCEL_TASKER_FAIL],
    promise: (client) => client.post('/task/cancelTasker', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}

export function cancelPuber({taskId, token}) {
  return {
    types: [CANCEL_PUBLISHER, CANCEL_PUBLISHER_SUCCESS, CANCEL_PUBLISHER_FAIL],
    promise: (client) => client.post('/task/cancelPuber', {
      data: {
        taskId
      },
      token
    }),
    key: taskId
  };
}

export function vote({taskId, meId, token, score, message}) {
  return {
    types: [VOTE, VOTE_SUCCESS, VOTE_FAIL],
    promise: (client) => client.post('/task/vote', {
      data: {
        taskId,
        score,
        message,
      },
      token
    }),
    key: taskId,
    meId,
  };
}
