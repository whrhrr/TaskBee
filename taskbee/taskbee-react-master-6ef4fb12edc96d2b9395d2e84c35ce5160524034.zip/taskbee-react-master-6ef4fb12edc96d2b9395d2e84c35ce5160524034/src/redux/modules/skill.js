import {Map, List, fromJS } from 'immutable';
import {filterToId, arrayToObject as arrayToPlainObject } from 'utils/dataProcessor';

const CREATE = 'taskbee/skill/CREATE';
export const CREATE_SUCCESS = 'taskbee/skill/CREATE_SUCCESS';
const CREATE_FAIL = 'taskbee/skill/CREATE_FAIL';

const EDIT = 'taskbee/skill/EDIT';
export const EDIT_SUCCESS = 'taskbee/skill/EDIT_SUCCESS';
const EDIT_FAIL = 'taskbee/skill/EDIT_FAIL';

const NEW_PUBLISH = 'taskbee/skill/NEW_PUBLISH';

const LOAD = 'taskbee/skill/LOAD';
export const LOAD_SUCCESS = 'taskbee/skill/LOAD_SUCCESS';
const LOAD_FAIL = 'taskbee/skill/LOAD_FAIL';

const LOAD_DETAIL = 'taskbee/skill/LOAD_DETAIL';
export const LOAD_DETAIL_SUCCESS = 'taskbee/skill/LOAD_DETAIL_SUCCESS';
const LOAD_DETAIL_FAIL = 'taskbee/skill/LOAD_DETAIL_FAIL';


const SWITCH_TAG = 'taskbee/skill.SWITCH_TAG';

const FAV = 'taskbee/skill/FAV';
const FAV_SUCCESS = 'taskbee/skill/FAV_SUCCESS';
const FAV_FAIL = 'taskbee/skill/FAV_FAIL';

const UNFAV = 'taskbee/skill/UNFAV';
const UNFAV_SUCCESS = 'taskbee/skill/UNFAV_SUCCESS';
const UNFAV_FAIL = 'taskbee/skill/UNFAV_FAIL';

const BOOK = 'taskbee/skill/BOOK';
const BOOK_SUCCESS = 'taskbee/skill/BOOK_SUCCESS';
const BOOK_FAIL = 'taskbee/skill/BOOK_FAIL';

const CHANGE_STATE = 'taskbee/skill/CHANGE_STATE';
const CHANGE_STATE_SUCCESS = 'taskbee/skill/CHANGE_STATE_SUCCESS';
const CHANGE_STATE_FAIL = 'taskbee/skill/CHANGE_STATE_FAIL';

const GET_FAV_SKILLS = 'taskbee/skill/GET_FAV_SKILLS';
export const GET_FAV_SKILLS_SUCCESS = 'taskbee/skill/GET_FAV_SKILLS_SUCCESS';
const GET_FAV_SKILLS_FAIL = 'taskbee/skill/GET_FAV_SKILLS_FAIL';

const GET_MY_SKILLS = 'taskbee/skill/GET_MY_SKILLS';
export const GET_MY_SKILLS_SUCCESS = 'taskbee/skill/GET_MY_SKILLS_SUCCESS';
const GET_MY_SKILLS_FAIL = 'taskbee/skill/GET_MY_SKILLS_FAIL';

const LOAD_ORDERS = 'taskbee/skill/LOAD_ORDERS';
const LOAD_ORDERS_SUCCESS = 'taskbee/skill/LOAD_ORDERS_SUCCESS';
const LOAD_ORDERS_FAIL = 'taskbee/skill/LOAD_ORDERS_FAIL';

const LOAD_ORDER_DETAIL = 'taskbee/skill/LOAD_ORDER_DETAIL';
const LOAD_ORDER_DETAIL_SUCCESS = 'taskbee/skill/LOAD_ORDER_DETAIL_SUCCESS';
const LOAD_ORDER_DETAIL_FAIL = 'taskbee/skill/LOAD_ORDER_DETAIL_FAIL';

const CONFIRM_ORDER = 'taskbee/skill/CONFIRM_ORDER';
const CONFIRM_ORDER_SUCCESS = 'taskbee/skill/CONFIRM_ORDER_SUCCESS';
const CONFIRM_ORDER_FAIL = 'taskbee/skill/CONFIRM_ORDER_FAIL';

const CANCEL_ORDER = 'taskbee/skill/CANCEL_ORDER';
const CANCEL_ORDER_SUCCESS = 'taskbee/skill/CANCEL_ORDER_SUCCESS';
const CANCEL_ORDER_FAIL = 'taskbee/skill/CANCEL_ORDER_FAIL';

const CANCEL_ORDER_BUYER = 'taskbee/skill/CANCEL_ORDER_BUYER';
const CANCEL_ORDER_BUYER_SUCCESS = 'taskbee/skill/CANCEL_ORDER_BUYER_SUCCESS';
const CANCEL_ORDER_BUYER_FAIL = 'taskbee/skill/CANCEL_ORDER_BUYER_FAIL';

const COMPLETE_ORDER = 'taskbee/skill/COMPLETE_ORDER';
const COMPLETE_ORDER_SUCCESS = 'taskbee/skill/COMPLETE_ORDER_SUCCESS';
const COMPLETE_ORDER_FAIL = 'taskbee/skill/COMPLETE_ORDER_FAIL';

const VOTE = 'taskbee/skill/VOTE';
const VOTE_SUCCESS = 'taskbee/skill/VOTE_SUCCESS';
const VOTE_FAIL = 'taskbee/skill/VOTE_FAIL';

const LOAD_REVIEW = 'taskbee/skill/LOAD_REVIEW';
export const LOAD_REVIEW_SUCCESS = 'taskbee/skill/LOAD_REVIEW_SUCCESS';
const LOAD_REVIEW_FAIL = 'taskbee/skill/LOAD_REVIEW_FAIL';

const LOAD_SKILL_ORDERS = 'taskbee/skill/LOAD_SKILL_ORDERS';
const LOAD_SKILL_ORDERS_SUCCESS = 'taskbee/skill/LOAD_SKILL_ORDERS_SUCCESS';
const LOAD_SKILL_ORDERS_FAIL = 'taskbee/skill/LOAD_SKILL_ORDERS_FAIL';

const UPLOAD = 'taskbee/skill/UPLOAD';
const UPLOAD_SUCCESS = 'taskbee/skill/UPLOAD_SUCCESS';
const UPLOAD_FAIL = 'taskbee/skill/UPLOAD_FAIL';

const DELETE = 'taskbee/skill/DELETE';
const DELETE_SUCCESS = 'taskbee/skill/DELETE_SUCCESS';
const DELETE_FAIL = 'taskbee/skill/DELETE_FAIL';


const initialState = new Map({
  data: new Map(),
  list: new List(),
  tag: '',
  orderData: new Map(),
});

function loadReviewSuccess(state, action) {
  return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
    return mutation.set('loadingReview', false).set('loadingReviewError', null).update('reviews', reviews => {
      if (!reviews) {
        return new List(action.result.data);
      }
      if (action.start) {
        return reviews.concat(action.result.data);
      }
      return new List(action.result.data);
    }).set('noMoreReviews', action.span > action.result.data.length);
  }));
}

function loadSkillOrderSuccess(state, action) {
  return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
    return mutation.set('loadingSkillOrder', false).set('loadingSkillOrderError', null).update('orderList', orderList => {
      if (!orderList) {
        return new List(action.result.data);
      }
      if (action.start) {
        return orderList.concat(action.result.data);
      }
      return new List(action.result.data);
    }).set('noMoreOrders', action.span > action.result.data.length);
  }));
}

function getNewTasks(state, action, key) {
  const ids = new List(filterToId(action.result.data));
  const originArry = state.get(key);
  // 从头加载
  if (!originArry || !originArry.size) {
    return ids;
  }
  // 继续加载
  if (action.start) {
    return originArry.concat(ids);
  }

  // 分析新的任务
  const existIndex = ids.indexOf(originArry.first());
  if (existIndex < 0) {
    // 已经超过span指定的条数了，我们全部重新加载吧
    return ids;
  }
  return ids.slice(0, existIndex).concat(originArry);
}


function getOrderKey(action) {
  return `o${action.isBuyer ? 'buy' : 'sell'}${action.state}`;
}

function processLoadOrders(state, action) {
  const key = getOrderKey(action);
  return state.withMutations(mutation => {
    return mutation.set(`${key}loading`, true).set(`${key}error`, null);
  });
}

function processLoadOrdersSuccess(state, action) {
  const key = getOrderKey(action);
  return state.withMutations(mutation => {
    return mutation.set(`${key}loading`, false).set(`${key}error`, null)
      .set(key, getNewTasks(state, action, key))
      .set(`${key}noMore`, action.result.data.length < action.span)
      .mergeDeepIn(['orderData'], arrayToPlainObject(action.result.data));
  });
}

function processLoadOrdersFail(state, action) {
  const key = getOrderKey(action);
  return state.withMutations(mutation => {
    return mutation.set(`${key}loading`, false).set(`${key}error`, action.error);
  });
}

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD:
      return state.withMutations((mutation) => {
        mutation.set('loading', true).set('loadingError', null);
        if (state.get('tag') !== action.tag) {
          mutation.set('list', new List());
        }
      });
    case LOAD_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.set('loading', false).set('loadingError', null)
          .set('list', getNewTasks(state, action, 'list'))
          .set('noMoreList', action.result.data.length < action.span)
          .mergeDeepIn(['data'], arrayToPlainObject(action.result.data));
      });
    case LOAD_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('loading', false).set('loadingError', action.error);
      });
    case LOAD_DETAIL:
      if (!state.get('data').has(action.key)) {
        return state.setIn(['data', action.key], new Map({
          loadingDetail: true,
          detailError: null,
        }));
      }
      return state.withMutations((mutation) => {
        mutation.setIn(['data', action.key, 'loadingDetail'], true)
          .setIn(['data', action.key, 'detailError'], null);
      });
    case LOAD_DETAIL_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn(['data', action.key, 'loadingDetail'], false)
          .setIn(['data', action.key, 'detailError'], null)
          .mergeIn(['data', action.key], action.result.data);
      });
    case LOAD_DETAIL_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn(['data', action.key, 'loadingDetail'], false)
          .setIn(['data', action.key, 'detailError'], action.error);
      });
    case SWITCH_TAG:
      return state.set('tag', action.tag).update('list', list => list.clear());

    case NEW_PUBLISH:
      return state.set('createSuccess', false);
    case CREATE:
      return state.withMutations(mutation => {
        mutation.set('createError', null).set('creating', true);
      });
    case CREATE_SUCCESS:
      return state.withMutations(mutation => {
        mutation
          .set('createError', null)
          .set('creating', false)
          .set('createSuccess', action.error ? '抱歉图片迷路了～' : true);
      });
    case CREATE_FAIL:
      return state.withMutations(mutation => {
        mutation
          .set('createError', action.error)
          .set('creating', false);
      });
    case EDIT:
      return state.withMutations(mutation => {
        mutation.set('createError', null).set('creating', true);
      });
    case EDIT_SUCCESS:
      return state.withMutations(mutation => {
        mutation
          .set('createError', null)
          .set('creating', false)
          .set('createSuccess', true);
      });
    case EDIT_FAIL:
      return state.withMutations(mutation => {
        mutation
          .set('createError', action.error)
          .set('creating', false);
      });
    case FAV:
      return state.updateIn(['data', action.key], skill => skill.set('faved', true).update('favs', favs => favs + 1));
    case FAV_SUCCESS:
      return state.setIn(['data', action.key, 'fav'], true);
    case FAV_FAIL:
      return state.updateIn(['data', action.key], skill => (
        skill.set('faved', false).update('favs', favs => favs - 1)
      ));
    case UNFAV:
      return state.updateIn(['data', action.key], skill => (
        skill.set('faved', false).update('favs', favs => favs - 1)
      ));
    case UNFAV_SUCCESS:
      return state.setIn(['data', action.key, 'faved'], false);
    case UNFAV_FAIL:
      return state.updateIn(['data', action.key], skill => (
        skill.set('faved', true).update('favs', favs => favs + 1)
      ));
    case BOOK:
      return state.withMutations(mutation => {
        mutation.set('bookError', null).set('booking', true);
      });
    case BOOK_SUCCESS:
      return state.withMutations(mutation => {
        mutation
          .set('bookError', null)
          .set('booking', false)
          .setIn(['data', action.key, 'ordered'], action.result.data)
          .set('bookSuccess', action.result.data);
      });
    case BOOK_FAIL:
      return state.withMutations(mutation => {
        mutation
          .set('bookError', action.error)
          .set('booking', false);
      });
    case CHANGE_STATE:
      return state.withMutations(mutation =>{
        mutation
          .set('changingState', true)
          .set('changeStateError', null);
      });
    case CHANGE_STATE_SUCCESS:
      return state.withMutations(mutation =>{
        mutation
          .set('changingState', false)
          .set('changeStateError', null)
          .setIn(['data', action.key, 'state'], action.state);
      });
    case CHANGE_STATE_FAIL:
      return state.withMutations(mutation =>{
        mutation
          .set('changingState', false)
          .set('changeStateError', action.error);
      });
    case GET_FAV_SKILLS:
      return state.withMutations((mutation) => {
        mutation.set('gettingFavSkills', true).set('getFavSkillsError', null);
      });
    case GET_FAV_SKILLS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation
          .set('gettingFavSkills', false)
          .set('getFavSkillsError', null)
          .set('favSkills', getNewTasks(state, action, 'favSkills'))
          .set('noMoreFav', action.result.data.length < action.span)
          .mergeDeepIn(['data'], arrayToPlainObject(action.result.data));
      });
    case GET_FAV_SKILLS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('gettingFavSkills', false).set('getFavSkillsError', action.error);
      });
    case GET_MY_SKILLS:
      return state.withMutations((mutation) => {
        mutation.set('gettingMySkills', true).set('getMySkillsError', null);
      });
    case GET_MY_SKILLS_SUCCESS:
      return state.withMutations((mutation) => {
        mutation
          .set('gettingMySkills', false)
          .set('getMySkillsError', null)
          .set('mySkills', getNewTasks(state, action, 'mySkills'))
          .set('noMoreMy', action.result.data.length < action.span)
          .mergeDeepIn(['data'], arrayToPlainObject(action.result.data));
      });
    case GET_MY_SKILLS_FAIL:
      return state.withMutations((mutation) => {
        mutation.set('gettingMySkills', false).set('getMySkillsError', action.error);
      });
    case LOAD_ORDERS:
      return processLoadOrders(state, action);
    case LOAD_ORDERS_SUCCESS:
      return processLoadOrdersSuccess(state, action);
    case LOAD_ORDERS_FAIL:
      return processLoadOrdersFail(state, action);
    case LOAD_ORDER_DETAIL:
      if (!state.get('orderData').has(action.key)) {
        return state.setIn(['orderData', action.key], new Map({
          loadingDetail: true,
          detailError: null,
        }));
      }
      return state.withMutations((mutation) => {
        mutation.setIn(['orderData', action.key, 'loadingDetail'], true)
          .setIn(['orderData', action.key, 'detailError'], null);
      });
    case LOAD_ORDER_DETAIL_SUCCESS:
      return state.withMutations((mutation) => {
        mutation.setIn(['orderData', action.key, 'loadingDetail'], false)
          .setIn(['orderData', action.key, 'detailError'], null)
          .mergeIn(['orderData', action.key], action.result.data);
      });
    case LOAD_ORDER_DETAIL_FAIL:
      return state.withMutations((mutation) => {
        mutation.setIn(['orderData', action.key, 'loadingDetail'], false)
          .setIn(['orderData', action.key, 'detailError'], action.error);
      });
    case CONFIRM_ORDER:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('confirmingOrder', true).set('miscError', null);
      }));
    case CONFIRM_ORDER_SUCCESS:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('confirmingOrder', false).set('state', 2).set('confirmTime', action.side);
      }));
    case CONFIRM_ORDER_FAIL:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('confirmingOrder', false).set('miscError', action.error);
      }));
    case CANCEL_ORDER:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('cancellingOrder', true).set('miscError', null);
      }));
    case CANCEL_ORDER_SUCCESS:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('cancellingOrder', false).set('state', 5).set('cancelTime', action.side);
      }));
    case CANCEL_ORDER_FAIL:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('cancellingOrder', false).set('miscError', action.error);
      }));
    case CANCEL_ORDER_BUYER:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('cancellingOrderBuyer', true).set('miscError', null);
      }));
    case CANCEL_ORDER_BUYER_SUCCESS:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('cancellingOrderBuyer', false).set('state', 5).set('cancelTime', action.side);
      }));
    case CANCEL_ORDER_BUYER_FAIL:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('cancellingOrderBuyer', false).set('miscError', action.error);
      }));
    case COMPLETE_ORDER:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('completingOrder', true).set('miscError', null);
      }));
    case COMPLETE_ORDER_SUCCESS:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('completingOrder', false).set('state', 3).set('finishTime', action.side);
      }));
    case COMPLETE_ORDER_FAIL:
      return state.updateIn(['orderData', action.key], order => order.withMutations(mutation => {
        return mutation.set('completingOrder', false).set('miscError', action.error);
      }));
    case VOTE:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation.set('voting', true).set('voteError', null);
      }));
    case VOTE_SUCCESS:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation.set('voting', false).set('voteError', null);
      })).updateIn(['orderData', action.orderId], order => order.set('state', 4));
    case VOTE_FAIL:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation.set('voting', false).set('voteError', action.error);
      }));
    case LOAD_REVIEW:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation.set('loadingReview', true).set('loadingReviewError', null);
      }));
    case LOAD_REVIEW_SUCCESS:
      return loadReviewSuccess(state, action);
    case LOAD_REVIEW_FAIL:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation.set('loadingReview', false).set('loadingReviewError', action.error);
      }));
    case LOAD_SKILL_ORDERS:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation.set('loadingSkillOrder', true).set('loadingSkillOrderError', null);
      }));
    case LOAD_SKILL_ORDERS_SUCCESS:
      return loadSkillOrderSuccess(state, action);
    case LOAD_SKILL_ORDERS_FAIL:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation.set('loadingSkillOrder', false).set('loadingSkillOrderError', action.error);
      }));
    case UPLOAD:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation
          .set('uploadingImage', true)
          .set('uploadImageError', null);
      }));
    case UPLOAD_SUCCESS:
      if (action.error) {
        return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
          mutation
            .set('uploadingImage', false)
            .set('uploadImageError', '上传出错，请稍候重试');
        }));
      }
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation
          .set('uploadingImage', false)
          .set('uploadImageError', null)
          .set('imgs', fromJS(action.uploadResult[0].data));
      }));
    case UPLOAD_FAIL:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation
          .set('uploadingImage', false)
          .set('uploadImageError', action.error);
      }));
    case DELETE:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation
          .set('deletingImage', true)
          .set('deletImageError', null);
      }));
    case DELETE_SUCCESS:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation
          .set('deletingImage', false)
          .set('deletImageError', null)
          .set('imgs', fromJS(action.result.data));
      }));
    case DELETE_FAIL:
      return state.updateIn(['data', action.key], skill => skill.withMutations((mutation) => {
        mutation
          .set('deletingImage', false)
          .set('deletImageError', action.error);
      }));
    default:
      return state;
  }
}

export function create({isPrivate, title, description, unit, tag, pos, price, maxBook, requiredGender, images, token}) {
  return {
    types: [CREATE, CREATE_SUCCESS, CREATE_FAIL],
    promise: (client) => client.post('/skill/create', {
      data: {
        isPrivate,
        title,
        description,
        unit,
        tag,
        price,
        maxBook,
        requiredGender,
        pos,
      },
      token
    }),
    uploadImages: images,
  };
}

export function newPublish() {
  return {
    type: NEW_PUBLISH,
  };
}

export function load(options = {}) {
  const {start = 0, tag = '', span = 8} = options;
  return {
    types: [LOAD, LOAD_SUCCESS, LOAD_FAIL],
    promise: (client) => client.get('/skill/skills', { params: {
      start,
      span,
      tag,
    }}),
    tag,
    start,
    span,
  };
}

export function switchTag(tag) {
  return (dispatch) => {
    // const globalState = getState();
    dispatch({
      type: SWITCH_TAG,
      tag,
    });
    dispatch(load({tag}));

  };
}

export function loadDetail(skillId) {
  return {
    types: [LOAD_DETAIL, LOAD_DETAIL_SUCCESS, LOAD_DETAIL_FAIL],
    promise: client => client.get('/skill/skillDetail', {
      params: {
        skillId
      }
    }),
    key: skillId,
  };
}

export function fav({id, token}) {
  return {
    types: [FAV, FAV_SUCCESS, FAV_FAIL],
    promise: (client) => client.post('/skill/fav', {
      data: {
        skillId: id
      },
      token
    }),
    key: id
  };
}

export function unfav({id, token}) {
  return {
    types: [UNFAV, UNFAV_SUCCESS, UNFAV_FAIL],
    promise: (client) => client.post('/skill/unFav', {
      data: {
        skillId: id
      },
      token
    }),
    key: id
  };
}


export function book({skillId, time, message, amount, token}) {
  return {
    types: [BOOK, BOOK_SUCCESS, BOOK_FAIL],
    promise: (client) => client.post('/skill/book', {
      data: {skillId, time, message, amount},
      token
    }),
    key: skillId,
  };
}

export function changeState({skillId, state, token}) {
  return {
    types: [CHANGE_STATE, CHANGE_STATE_SUCCESS, CHANGE_STATE_FAIL],
    promise: (client) => client.post('/skill/changeState', {
      data: {
        skillId,
        state,
      },
      token
    }),
    key: skillId,
    state,
  };
}

// 获取我收藏的
export function getFavSkill(start, span = 8) {
  return {
    types: [GET_FAV_SKILLS, GET_FAV_SKILLS_SUCCESS, GET_FAV_SKILLS_FAIL],
    promise: (client) => client.get('/skill/skillFav', {
      params: {
        start,
        span,
      },
    }),
    start,
    span,
  };
}

export function getMySkill(start, span = 8) {
  return {
    types: [GET_MY_SKILLS, GET_MY_SKILLS_SUCCESS, GET_MY_SKILLS_FAIL],
    promise: (client) => client.get('/skill/skillMy', {
      params: {
        start,
        span,
      },
    }),
    start,
    span,
  };
}

export function loadOrders(options = {}) {
  const {
    start,
    state,
    span = 8,
    isBuyer,
} = options;
  return {
    types: [LOAD_ORDERS, LOAD_ORDERS_SUCCESS, LOAD_ORDERS_FAIL],
    promise: (client) => client.get('/skill/orders', { params: {
      start,
      span,
      state,
      isBuyer: isBuyer ? true : null,
    }}),
    isBuyer,
    state,
    start,
    span,
  };
}

export function loadOrderDetail(orderId) {
  return {
    types: [LOAD_ORDER_DETAIL, LOAD_ORDER_DETAIL_SUCCESS, LOAD_ORDER_DETAIL_FAIL],
    promise: client => client.get('/skill/orderDetail', {
      params: {
        orderId
      }
    }),
    key: orderId,
  };
}


export function confirmOrder(orderId, token) {
  return {
    types: [CONFIRM_ORDER, CONFIRM_ORDER_SUCCESS, CONFIRM_ORDER_FAIL],
    promise: client => client.post('/skill/confirmOrder', {
      data: {
        orderId,
      },
      token,
    }),
    key: orderId,
    successSide: Date.now,
  };
}

export function cancelOrder(orderId, token) {
  return {
    types: [CANCEL_ORDER, CANCEL_ORDER_SUCCESS, CANCEL_ORDER_FAIL],
    promise: client => client.post('/skill/cancelOrder', {
      data: {
        orderId,
      },
      token,
    }),
    key: orderId,
    successSide: Date.now,
  };
}

export function cancelOrderBuyer(orderId, token) {
  return {
    types: [CANCEL_ORDER_BUYER, CANCEL_ORDER_BUYER_SUCCESS, CANCEL_ORDER_BUYER_FAIL],
    promise: client => client.post('/skill/cancelOrderBuyer', {
      data: {
        orderId,
      },
      token,
    }),
    key: orderId,
    successSide: Date.now,
  };
}

export function completeOrder(orderId, token) {
  return {
    types: [COMPLETE_ORDER, COMPLETE_ORDER_SUCCESS, COMPLETE_ORDER_FAIL],
    promise: client => client.post('/skill/completeOrder', {
      data: {
        orderId,
      },
      token,
    }),
    key: orderId,
    successSide: Date.now,
  };
}

export function edit({skillId, isPrivate, title, description, unit, tag, pos, price, maxBook, requiredGender, token}) {
  return {
    types: [EDIT, EDIT_SUCCESS, EDIT_FAIL],
    promise: (client) => client.post('/skill/edit', {
      data: {
        skillId,
        title,
        description,
        unit,
        tag,
        price,
        maxBook,
        requiredGender,
        pos,
        isPrivate,
      },
      token
    }),
  };
}


export function vote({skillId, orderId, meId, token, score, message}) {
  return {
    types: [VOTE, VOTE_SUCCESS, VOTE_FAIL],
    promise: (client) => client.post('/skill/vote', {
      data: {
        orderId,
        score,
        message,
      },
      token
    }),
    key: skillId,
    orderId,
    meId,
  };
}

// 获取我收藏的
export function loadReviews(skillId, start, span = 8) {
  return {
    types: [LOAD_REVIEW, LOAD_REVIEW_SUCCESS, LOAD_REVIEW_FAIL],
    promise: (client) => client.get('/skill/reviews', {
      params: {
        skillId,
        start,
        span,
      },
    }),
    key: skillId,
    start,
    span,
  };
}

export function loadSkillOrders(skillId, start, span = 8) {
  return {
    types: [LOAD_SKILL_ORDERS, LOAD_SKILL_ORDERS_SUCCESS, LOAD_SKILL_ORDERS_FAIL],
    promise: (client) => client.get('/skill/skillOrders', {
      params: {
        skillId,
        start,
        span,
      },
    }),
    key: skillId,
    start,
    span,
  };
}

// 上传编辑图片
export function upload({attach, skillId, index, token}) {
  return {
    types: [UPLOAD, UPLOAD_SUCCESS, UPLOAD_FAIL],
    promise: (client) => client.post('/skill/modifyImage', {
      data: {
        skillId,
        index,
      },
      token,
    }),
    key: skillId,
    index,
    uploadImages: [attach],
  };
}


// 上传编辑图片
export function deleteImage({skillId, key, token}) {
  return {
    types: [DELETE, DELETE_SUCCESS, DELETE_FAIL],
    promise: (client) => client.post('/skill/removeImage', {
      data: {
        skillId,
        key,
      },
      token,
    }),
    key: skillId,
    imageKey: key,
  };
}
