const FEEDBACK = 'taskbee/misc/FEEDBACK';
const FEEDBACK_SUCCESS = 'taskbee/misc/FEEDBACK_SUCCESS';
const FEEDBACK_FAIL = 'taskbee/misc/FEEDBACK_FAIL';
const FEEDBACK_AGAIN = 'taskbee/misc/FEEDBACK_AGAIN';

export const ARRIVE_MESSAGE = 'taskbee/misc/ARRIVE_MESSAGE';
const ARRIVE_TASK = 'taskbee/misc/ARRIVE_TASL';
/* SOCKET */
const SOCKET_CONNECTED = 'taskbee/misc/SOCKET_CONNECTED';
const SOCKET_DISCONNECTED = 'taskbee/misc/SOCKET_DISCONNECTED';

/* 滚动条 */
const SCROLL_HOME = 'taskbee/misc/SCROLL_HOME';

/* 窗口大小 */
const WINDOW_HEIGHT = 'taskbee/misc/WINDOW_HEIGHT';

const HOME_TAB = 'taskbee/misc/HOME_TAB';

const ACTIVE_TASK = 'taskbee/misc/ACTIVE_TASK';

const TOGGLE_MAP = 'taskbee/misc/TOGGLE_MAP';

/* 外来的 */
import {UNREAD, STATUS} from './messages';
import {LOGOUT_SUCCESS} from './user';
import {GET_SYS_MESSAGE, GET_NEW_SYS, CHECK_SYS_MESSAGE} from './sysMessages';

const initialState = {
  connected: false,
  heightHome: 1024,
  lastLocation: null,
  currentLocation: null,
  homeTab: 1,
};

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case '@@reduxReactRouter/routerDidChange':
      if (action.payload.location.action === 'REPLACE') {
        // 这是一额有问题的实现，没有判断后退等情况，这只是为了登录后能够更优雅的跳转
        return state;
      }
      return {
        ...state,
        lastLocation: state.currentLocation ? state.currentLocation : null,
        currentLocation: action.payload.location.pathname,
      };

    case HOME_TAB:
      return {
        ...state,
        homeTab: action.tab,
      };
    case ACTIVE_TASK:
      return {
        ...state,
        activeItem: action.key,
      };
    case CHECK_SYS_MESSAGE:
      return {
        ...state,
        tabMessage: false,
      };
    case GET_NEW_SYS:
      if (action.result.data.length) {
        return {
          ...state,
          tabMessage: true,
        };
      }
      return state;
    case GET_SYS_MESSAGE:
      return {
        ...state,
        tabMessage: true,
      };
    case UNREAD:
      return {
        ...state,
        tabMessage: true
      };
    case ARRIVE_MESSAGE:
      return {
        ...state,
        tabMessage: false
      };

    case STATUS:
      return {
        ...state,
        tabTask: true
      };
    case ARRIVE_TASK:
      return {
        ...state,
        tabTask: false,
      };

    case FEEDBACK:
      return {
        ...state,
        feedbacking: true,
        feedbackError: null
      };
    case FEEDBACK_SUCCESS:
      return {
        ...state,
        feedbacking: false,
        feedbackSuccess: true
      };
    case FEEDBACK_FAIL:
      return {
        ...state,
        feedbacking: false,
        feedbackError: action.error
      };
    case FEEDBACK_AGAIN:
      return {
        ...state,
        feedbackSuccess: false,
      };
    case SCROLL_HOME:
      return {
        ...state,
        scrollHome: action.scrollY,
      };
    case WINDOW_HEIGHT:
      return {
        ...state,
        heightHome: action.windowHeight,
      };
    case LOGOUT_SUCCESS:
      return {
        ...state,
        connect: false,
        lastLocation: null,
        currentLocation: null,
      };
    case TOGGLE_MAP:
      return {
        ...state,
        showMap: !state.showMap,
      };
    default:
      return state;
  }
}

export function feedback({email, feedback}) { /* eslint no-shadow: 0*/
  return {
    types: [FEEDBACK, FEEDBACK_SUCCESS, FEEDBACK_FAIL],
    promise: (client) => client.post('/misc/feedback', {
      data: {
        email,
        feedback,
      }
    })
  };
}

export function feedbackAgain() {
  return {
    type: FEEDBACK_AGAIN
  };
}

export function connected() {
  return {
    type: SOCKET_CONNECTED
  };
}

export function disconnected() {
  return {
    type: SOCKET_DISCONNECTED
  };
}

export function arriveMessage() {
  return {
    type: ARRIVE_MESSAGE
  };
}

export function arriveTask() {
  return {
    type: ARRIVE_TASK
  };
}

export function scrollHome(scrollY) {
  return {
    type: SCROLL_HOME,
    scrollY,
  };
}

export function windowHeight(windowHeight) {
  return {
    type: WINDOW_HEIGHT,
    windowHeight,
  };
}

export function setHomeTab(tab) {
  return {
    type: HOME_TAB,
    tab
  };
}

export function setActiveTask(key) {
  return {
    type: ACTIVE_TASK,
    key
  };
}

export function toggleMap() {
  return {
    type: TOGGLE_MAP,
  };
}
