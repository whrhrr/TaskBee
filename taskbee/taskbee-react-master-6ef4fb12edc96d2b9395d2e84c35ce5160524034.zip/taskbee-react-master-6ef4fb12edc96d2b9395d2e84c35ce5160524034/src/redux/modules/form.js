import {reducer as formReducer} from 'redux-form';
// import memoize from 'lru-memoize';

/* 再见！ 我的破烂自定义输入空间！
let validTime = (value, previousValue) => {
  if (!value || !previousValue) {
    return value;
  }
  if (previousValue.length === 1 && value.length === 2 && value[1] === ':') {
    return '0' + value;
  }
  const onlyNums = value.replace(/[^\d]/g, '');
  if (onlyNums.length === 1) {
    return onlyNums;
  } else if (onlyNums.length === 2) {
    if (onlyNums >= 24) {
      return '23:';
    }
    if (!previousValue || value.length > previousValue.length) {
      return onlyNums + ':';
    }
    return onlyNums;
  } else if (onlyNums.length >= 3) {
    const val = parseInt(onlyNums.slice(2, 3), 10);
    if (val > 5) {
      return onlyNums.slice(0, 2) + ':5' + onlyNums.slice(3, 4);
    }
  }
  return onlyNums.slice(0, 2) + ':' + onlyNums.slice(2, 4);
};
validTime = memoize(10)(validTime);
function doNothing(value) {return value;}
*/
const NEW_TAG_SUCCESS = 'taskbee/create/NEW_TAG_SUCCESS';

export default formReducer.plugin({
  create: (state, action) => {
    switch (action.type) {
      case NEW_TAG_SUCCESS:
        // 判断value中是否已经有
        if (state.tags.value.some(tag => tag.name === action.result.data.name)) {
          return state;
        }
        return {
          ...state,
          tags: {
            // ...state.tags,
            value: state.tags.value.concat(action.result.data)
          }
        };
      default:
        return state;
    }
  },
  tag: (state, action) => {
    switch (action.type) {
      case NEW_TAG_SUCCESS:
        return {
          ...state,
          tagName: {}
        };
      default:
        return state;
    }
  }
});
