import {saveMessages} from '../../utils/storage';

const READY = 'taskbee/messages/READY';
const SEND = 'taskbee/messages/SEND';
const SEND_SUCCESS = 'taskbee/messages/SEND_SUCCESS';
const SEND_FAIL = 'taskbee/messages/SEND_FAIL';
const GET_MESSAGE = 'taskbee/messages/GET_MESSAGE';
const GET_NEW = 'taskbee/messages/GET_NEW';
export const UNREAD = 'taskbee/messages/UNREAD';
const READ = 'taskbee/messages/READ';

const ONE_USER = 'taskbee/messages/ONE_USER';
const ONE_USER_SUCCESS = 'taskbee/messages/ONE_USER_SUCCESS';
const ONE_USER_FAIL = 'taskbee/messages/ONE_USER_FAIL';

export const STATUS = 'taskbee/messages/STATUS';
// 外来
import {LOGOUT_SUCCESS} from './user';

const initialState = {
};

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case UNREAD:
      if (!state[action.from]) return state;
      let unreadCount = state[action.from].unread;
      unreadCount = unreadCount ? unreadCount + 1 : 1;
      return {
        ...state,
        [action.from]: {
          ...state[action.from],
          unread: unreadCount
        }
      };
    case READ:
      return {
        ...state,
        [action.from]: {
          ...state[action.from],
          unread: 0
        }
      };
    case READY:
      if (!state[action.user._id]) {
        return {
          ...state,
          [action.user._id]: {
            messages: [],
            avatar: action.user.avatar,
            username: action.user.username,
            gender: action.user.gender,
            _id: action.user._id,
          }
        };
      }
      return {
        ...state,
        [action.user._id]: {
          ...state[action.user._id],
          avatar: action.user.avatar,
          username: action.user.username,
          gender: action.user.gender,
          _id: action.user._id,
        }
      };
    case SEND:
      return {
        ...state,
        submitting: true,
        error: null,
      };
    case SEND_SUCCESS:
      return {
        ...state,
        submitting: false,
        error: null,
        [action.data.to]: {
          ...state[action.data.to],
          messages: state[action.data.to].messages.concat(action.data),
        }
      };
    case SEND_FAIL:
      return {
        ...state,
        submitting: false,
        error: action.error
      };
    case GET_MESSAGE:
      return {
        ...state,
        [action.data.from]: {
          ...state[action.data.from],
          messages: state[action.data.from] ? state[action.data.from].messages.concat(action.data) : [action.data],
        }
      };
    case GET_NEW:
      // 麻烦事来了，要处理服务端饭回来的新消息
      if (!action.result) return state;
      const newState = Object.assign({}, state);
      const rawMessages = {};
      action.result.users.forEach( user => {
        if (!newState[user._id]) {
          newState[user._id] = {
            ...user,
            messages: []
          };
        } else {
          newState[user._id] = {
            ...newState[user._id],
            ...user
          };
        }
        // 暂时存放的数组，减少immutable的复制
        rawMessages[user._id] = [];
      });
      action.result.messages.forEach( message => {
        if (newState[message.from]) {
          rawMessages[message.from].push(message);
        } else {
          rawMessages[message.to].push(message);
        }
      });
      Object.keys(rawMessages).forEach( key => {
        newState[key] = {
          ...newState[key],
          messages: newState[key].messages.concat(rawMessages[key])
        };
      });
      return newState;
    case ONE_USER_SUCCESS:
      return {
        ...state,
        [action.result.data._id]: {
          ...state[action.result.data._id],
          _id: action.result.data._id,
          username: action.result.data.username,
          avatar: action.result.data.avatar,
          gender: action.result.data.gender,
          messages: state[action.result.data._id] ? state[action.result.data._id].messages : [],
        }
      };
    case LOGOUT_SUCCESS:
      return initialState;
    default:
      return state;
  }
}


// 减少localStorage缓存处罚次数
let deferredSave;
function savesave(getState) {
  if (deferredSave) {
    clearTimeout(deferredSave);
  }
  deferredSave = setTimeout(function realSave() {
    saveMessages(getState().messages);
    deferredSave = null;
  }, 5000);
}

export function unread(from) {
  return {
    type: UNREAD,
    from
  };
}


// 触发未读消息增加的action
export function checkUnread(dispatch, getState, from) {
  const {userId} = getState().router.params;
  if (!userId || userId && userId !== from) {
    // 这条消息未读
    dispatch(unread(from));
  }
}


export function read(from) {
  return {
    type: READ,
    from
  };
}

export function getOneUser(user) {
  return {
    types: [ONE_USER, ONE_USER_SUCCESS, ONE_USER_FAIL],
    promise: (client) => client.get('/user/oneUser', {
      params: {
        user
      }
    })
  };
}

export function readyChat(user) {
  return (dispatch, getState) => {
    dispatch({
      type: READY,
      user
    });
    // 保存
    savesave(getState);
  };
}

// 收到新消息
export function getMessage(data) {
  return (dispatch, getState) => {
    dispatch({
      type: GET_MESSAGE,
      data
    });
    if (data.from && !getState().messages[data.from]._id) {
      dispatch(getOneUser(data.from));
    } else {
      // 保存
      savesave(getState);
    }
    checkUnread(dispatch, getState, data.from);
    // 新消息通知
  };
}

// {to, body} 发送消息
export function send(data) {
  let timeoutHandle;
  return (dispatch, getState) => {
    function timeout() {
      dispatch({
        type: SEND_FAIL,
        error: '发送超时',
      });
    }
    timeoutHandle = setTimeout(timeout, 30 * 1000);
    global.socket.emit('message', {to: data.to, message: data.message}, function sendCb(cbdata) {
      clearTimeout(timeoutHandle);
      if (cbdata && cbdata.statusCode === 200) {
        dispatch({
          type: SEND_SUCCESS,
          data
        });
        // 保存聊天信息
        savesave(getState);
      } else {
        dispatch({
          type: SEND_FAIL,
          error: cbdata
        });
      }
    });
    return dispatch({
      type: SEND
    });
  };
}

// 获取未读聊天消息
export function getNew(data) {
  return (dispatch, getState) => {
    dispatch({
      type: GET_NEW,
      result: data.result
    });
    if (data.result) {
      const messageSet = new Set();
      data.result.messages.forEach( message => {
        checkUnread(dispatch, getState, message.from);
        messageSet.add(message.from);
      });
      for (const item of messageSet) {
        dispatch(getOneUser(item));
      }
    }
    // 保存
    savesave(getState);
  };
}

// 收到任务状态更新
export function getStatus() {
  return {
    type: STATUS
  };
}
