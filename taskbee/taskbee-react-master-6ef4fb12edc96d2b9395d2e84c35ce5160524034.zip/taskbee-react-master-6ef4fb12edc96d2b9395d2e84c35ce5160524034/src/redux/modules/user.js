import {filterToId} from '../../utils/dataProcessor';

const LOAD = 'taskbee/user/LOAD';
export const LOAD_SUCCESS = 'taskbee/user/LOAD_SUCCESS';
const LOAD_FAIL = 'taskbee/user/LOAD_FAIL';

const LOADUSER = 'taskbee/user/LOAD';
const LOADUSER_SUCCESS = 'taskbee/user/LOAD_SUCCESS';
const LOADUSER_FAIL = 'taskbee/user/LOAD_FAIL';


const LOGIN = 'taskbee/user/LOGIN';
const LOGIN_SUCCESS = 'taskbee/user/LOGIN_SUCCESS';
const LOGIN_FAIL = 'taskbee/user/LOGIN_FAIL';

const REGISTER = 'taskbee/user/REGISTER';
export const REGISTER_SUCCESS = 'taskbee/user/REGISTER_SUCCESS';
const REGISTER_FAIL = 'taskbee/user/REGISTER_FAIL';

const CHANGEPASSWORD = 'taskbee/user/CHANGEPASSWORD';
export const CHANGEPASSWORD_SUCCESS = 'taskbee/user/CHANGEPASSWORD_SUCCESS';
const CHANGEPASSWORD_FAIL = 'taskbee/user/CHANGEPASSWORD_FAIL';

const CHANGE_INFO = 'taskbee/user/CHANGE_INFO';
export const CHANGE_INFO_SUCCESS = 'taskbee/user/CHANGE_INFO_SUCCESS';
const CHANGE_INFO_FAIL = 'taskbee/user/CHANGE_INFO_FAIL';

const LOGOUT = 'taskbee/user/LOGOUT';
export const LOGOUT_SUCCESS = 'taskbee/user/LOGOUT_SUCCESS';
const LOGOUT_FAIL = 'taskbee/user/LOGOUT_FAIL';

const UPLOAD = 'taskbee/user/UPLOAD';
const UPLOAD_SUCCESS = 'taskbee/user/UPLOAD_SUCCESS';
const UPLOAD_FAIL = 'taskbee/user/UPLOAD_FAIL';

const GET_TASKS = 'taskbee/user/GET_TASKS';
export const GET_TASKS_SUCCESS = 'taskbee/user/GET_TASKS_SUCCESS';
const GET_TASKS_FAIL = 'taskbee/user/GET_TASKS_FAIL';

const GET_FAV_TASKS = 'taskbee/user/GET_FAV_TASKS';
export const GET_FAV_TASKS_SUCCESS = 'taskbee/user/GET_FAV_TASKS_SUCCESS';
const GET_FAV_TASKS_FAIL = 'taskbee/user/GET_FAV_TASKS_FAIL';

const GET_HISTORY_TASKS = 'taskbee/user/GET_HISTORY_TASKS';
export const GET_HISTORY_TASKS_SUCCESS = 'taskbee/user/GET_HISTORY_TASKS_SUCCESS';
const GET_HISTORY_TASKS_FAIL = 'taskbee/user/GET_HISTORY_TASKS_FAIL';

const GET_POLLENS = 'taskbee/user/GET_POLLENS';
export const GET_POLLENS_SUCCESS = 'taskbee/user/GET_POLLENS_SUCCESS';
const GET_POLLENS_FAIL = 'taskbee/user/GET_POLLENS_FAIL';


const LOAD_USER_DETAIL = 'taskbee/user/LOAD_USER_DETAIL';
const LOAD_USER_DETAIL_SUCCESS = 'taskbee/user/LOAD_USER_DETAIL_SUCCESS';
const LOAD_USER_DETAIL_FAIL = 'taskbee/user/LOAD_USER_DETAIL_FAIL';

const SIGN = 'taskbee/user/SIGN';
const SIGN_SUCCESS = 'taskbee/user/SIGN_SUCCESS';
const SIGN_FAIL = 'taskbee/user/SIGN_FAIL';

const GET_SCORE = 'taskbee/user/GET_SCORE';
const GET_SCORE_SUCCESS = 'taskbee/user/GET_SCORE_SUCCESS';
const GET_SCORE_FAIL = 'taskbee/user/GET_SCORE_FAIL';

const LOAD_FRIENDS = 'taskbee/user/LOAD_FRIENDS';
const LOAD_FRIENDS_SUCCESS = 'taskbee/user/LOAD_FRIENDS_SUCCESS';
const LOAD_FRIENDS_FAIL = 'taskbee/user/LOAD_FRIENDS_FAIL';

const LIKE = 'taskbee/user/LIKE';
const LIKE_SUCCESS = 'taskbee/user/LIKE_SUCCESS';
const LIKE_FAIL = 'taskbee/user/LIKE_FAIL';

const UNFRIEND = 'taskbee/user/UNFRIEND';
const UNFRIEND_SUCCESS = 'taskbee/user/UNFRIEND_SUCCESS';
const UNFRIEND_FAIL = 'taskbee/user/UNFRIEND_FAIL';


import {CREATE_SUCCESS, CREATE_POST_SUCCESS} from './publish';
import {WITHDRAW_SUCCESS, REDPOCKET_SUCCESS} from './order';
/*
  各种个人信息
 */

// 重构，用户信息直接存在intitialState之中，每个用户的状态直接存在用户对应的object中
const initialState = {
  loaded: false,
  changeError: Object.create(null),
  changing: Object.create(null),
  friends: [],
  myPollens: [],
};

function getNewTasks(state, action, key) {
  const ids = filterToId(action.result.data[key]);
  const originArry = state[state.meId][key];
  if (action.start) {
    return originArry.concat(ids);
  }
  // 从头加载
  if (!originArry || !originArry.length) {
    return ids;
  }

  // 分析新的任务
  const existIndex = ids.indexOf(originArry[0]);
  if (existIndex < 0) {
    // 已经超过span指定的条数了，我们全部重新加载吧
    return ids;
  }
  return ids.slice(0, existIndex).concat(originArry);
}

function isYesterday(date) {
  const tmp = new Date(date);
  const da = new Date();
  da.setDate(da.getDate() - 1);
  return tmp.setHours(0, 0, 0, 0) === da.setHours(0, 0, 0, 0);
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD:
      return {
        ...state,
        // loading: true
      };
    case LOAD_SUCCESS:
      return {
        ...state,
        loaded: true,
        token: action.result.token,
        meId: action.result.data._id,
        [action.result.data._id]: action.result.data
      };
    case LOAD_FAIL:
      return {
        ...state,
        loaded: true,
      };
    case LOAD_USER_DETAIL:
      return {
        ...state,
        loadingUser: true,
        loadUserError: null,
      };
    case LOAD_USER_DETAIL_SUCCESS:
      return {
        ...state,
        loadingUser: false,
        [action.result.data._id]: {
          ...state[action.result.data._id],
          ...action.result.data,
          votes: action.result.votes
        }
      };
    case LOAD_USER_DETAIL_FAIL:
      return {
        ...state,
        loadingUser: false,
        loadUserError: action.error,
      };
    case CREATE_SUCCESS:
      return {
        ...state,
        [state.meId]: {
          ...state[state.meId],
          score: state[state.meId].score - 2, // 更新分数
          money: state[state.meId].money - action.reward, // 更新钱
        }
      };
    case LOGIN:
      return {
        ...state,
        loggingIn: true,
        loginError: null
      };
    case LOGIN_SUCCESS:
    // 设定我的用户ID，并将我的数据存入用户表当中。
      return {
        ...state,
        loggingIn: false,
        meId: action.result.data._id,
        [action.result.data._id]: action.result.data,
        token: action.result.token
      };
    case LOGIN_FAIL:
      return {
        ...state,
        loggingIn: false,
        user: null,
        loginError: action.error
      };
    case REGISTER:
      return {
        ...state,
        registering: true,
        registerError: null
      };
    case REGISTER_SUCCESS:
      return {
        ...state,
        registering: false,
        token: action.result.token,
        meId: action.result.data._id,
        [action.result.data._id]: action.result.data,
        verifyToken: null
      };
    case REGISTER_FAIL:
      return {
        ...state,
        registering: false,
        registerError: action.error
      };
    case CHANGEPASSWORD:
      return {
        ...state,
        changingPassword: true,
        changePasswordError: null
      };
    case CHANGEPASSWORD_SUCCESS:
      return {
        ...state,
        changingPassword: false,
        verifyToken: null,
      };
    case CHANGEPASSWORD_FAIL:
      return {
        ...state,
        changingPassword: false,
        changePasswordError: action.error
      };

    // 各种个人信息的修改
    case CHANGE_INFO:
      return {
        ...state,
        changing: {
          ...state.changing,
          [action.key]: true
        },
        changeError: {
          ...state.changeError,
          [action.key]: null
        }
      };
    case CHANGE_INFO_SUCCESS:
      const {meId} = state;
      const newState = {
        ...state,
        changing: {
          ...state.changing,
          [action.key]: false
        },
        [meId]: {
          ...state[meId],
          [action.key]: action.result.data
        },
        changeError: {
          ...state.changeError,
          [action.key]: null
        },
      };
      if (action.key === 'schoolId' && action.result.token !== undefined) {
        newState.token = action.result.token;
      }
      return newState;
    case CHANGE_INFO_FAIL:
      return {
        ...state,
        changing: {
          ...state.changing,
          [action.key]: false
        },
        changeError: {
          ...state.changeError,
          [action.key]: action.error
        }
      };
    case UPLOAD:
      return {
        ...state,
        uploading: true,
        uploadError: null,
        // _pathAppend: state._pathAppend === undefined ? '?1' : (state._pathAppend + '1')
      };
    case UPLOAD_SUCCESS:
      const {meId: meIda} = state;
      if (action.error) {
        return {
          ...state,
          uploading: false,
          uploadError: '上传出错，请稍候重试',
        };
      }
      return {
        ...state,
        uploading: false,
        uploadError: null,
        [meIda]: {
          ...state[meIda],
          avatar: action.uploadResult[0].data, // + state._pathAppend
        },
      };
    case UPLOAD_FAIL:
      return {
        ...state,
        uploading: false,
        uploadError: action.error
      };
    case LOGOUT:
      return {
        ...state,
        loggingOut: true,
        logoutError: null
      };
    case LOGOUT_SUCCESS:
      return {
        ...state,
        loggingOut: false,
        meId: null,
        token: null,
        logoutError: null,
        friends: [],
      };
    case LOGOUT_FAIL:
      return {
        ...state,
        loggingOut: false,
        logoutError: action.error
      };
    case SIGN:
      return {
        ...state,
        signing: true,
        signError: null,
      };
    case CREATE_POST_SUCCESS:
      if (action.result.signed) {
        return {
          [state.meId]: {
            ...state[state.meId],
            score: state[state.meId].score + 1,
            signTime: Date.now, // side effect
            signCount: state[state.meId].signCount + 1,
          }
        };
      }
      return state;
    // legacy
    case SIGN_SUCCESS:
      const {meId: meIdsign} = state;
      let signCount;
      if (state[meIdsign].signTime && isYesterday(state[meIdsign].signTime)) {
        // 如果是昨天，则+1
        signCount = state[meIdsign].signCount + 1;
      } else signCount = 1;
      return {
        ...state,
        signing: false,
        signError: null,
        [meIdsign]: {
          ...state[meIdsign],
          score: state[meIdsign].score + 1,
          signCount,
          signTime: action.side,
        },
      };
    case SIGN_FAIL:
      return {
        ...state,
        signing: false,
        signError: action.error,
      };
    case GET_TASKS:
      if (action.reload) {
        return {
          ...state,
          reloadingTasks: true,
          reloadingTasksError: null,
          getTasksError: null,
        };
      }
      return {
        ...state,
        gettingTasks: true,
        getTasksError: null,
        reloadingTasksError: null,
      };
    case GET_TASKS_SUCCESS:
      const {meId: meIdb} = state;
      if (action.reload) {
        return {
          ...state,
          reloadingTasks: false,
          [meIdb]: {
            ...state[meIdb],
            taskPublish: filterToId(action.result.data.taskPublish).reverse(),
            taskTaken: filterToId(action.result.data.taskTaken).reverse(),
          }
        };
      }
      return {
        ...state,
        gettingTasks: false,
        [meIdb]: {
          ...state[meIdb],
          taskPublish: filterToId(action.result.data.taskPublish).reverse(),
          taskTaken: filterToId(action.result.data.taskTaken).reverse(),
        }
      };
    case GET_TASKS_FAIL:
      if (action.reload) {
        return {
          ...state,
          reloadingTasks: false,
          reloadingTasksError: action.error,
        };
      }
      return {
        ...state,
        gettingTasks: false,
        getTasksError: action.error,
      };
    case GET_FAV_TASKS:
      return {
        ...state,
        gettingFavTasks: true,
        getFavTasksError: null,
      };
    case GET_FAV_TASKS_SUCCESS:
      return {
        ...state,
        gettingFavTasks: false,
        [state.meId]: {
          ...state[state.meId],
          taskFav: getNewTasks(state, action, 'taskFav'),
          noMoreFav: action.result.data.taskFav.length < action.span
        }
      };
    case GET_FAV_TASKS_FAIL:
      return {
        ...state,
        gettingFavTasks: false,
        getFavTasksError: action.error,
      };
    case GET_HISTORY_TASKS:
      return {
        ...state,
        gettingHistoryTasks: true,
        getHistoryTasksError: null,
      };
    case GET_HISTORY_TASKS_SUCCESS:
      return {
        ...state,
        gettingHistoryTasks: false,
        [state.meId]: {
          ...state[state.meId],
          taskHistory: getNewTasks(state, action, 'taskHistory'),
          noMoreHistory: action.result.data.taskHistory.length < action.span
        }
      };
    case GET_HISTORY_TASKS_FAIL:
      return {
        ...state,
        gettingHistoryTasks: false,
        getHistoryTasksError: action.error,
      };
    case GET_POLLENS:
      return {
        ...state,
        gettingPollen: true,
        getPollenError: null,
      };
    case GET_POLLENS_SUCCESS:
      let nextPollens;
      const data = action.result.data;
      if (action.firstLoad && data.length) {
        // 有东西
        const lastId = data[data.length - 1]._id;
        const daIndex = state.myPollens.findIndex( pollen => {
          return pollen._id === lastId;
        });
        if (daIndex < 0) {
          nextPollens = data;
        } else {
          nextPollens = data.concat(state.myPollens.slice(daIndex + 1));
        }
      } else {
        nextPollens = state.myPollens.concat(data);
      }

      return {
        ...state,
        gettingPollen: false,
        myPollens: nextPollens,
        noMorePollens: action.result.data.length < action.span,
      };
    case GET_POLLENS_FAIL:
      return {
        ...state,
        gettingPollen: false,
        getPollenError: action.error,
      };
    case GET_SCORE_SUCCESS:
      return {
        ...state,
        [state.meId]: {
          ...state[state.meId],
          score: action.result.data.score,
          money: action.result.data.money,
        }
      };
    case WITHDRAW_SUCCESS:
      return {
        ...state,
        [state.meId]: {
          ...state[state.meId],
          money: state[state.meId].money - action.money, // 更新钱
        }
      };
    case REDPOCKET_SUCCESS:
      return {
        ...state,
        [state.meId]: {
          ...state[state.meId],
          money: state[state.meId].money + action.result.data.price, // 更新钱
        }
      };
    case LOAD_FRIENDS:
      return {
        ...state,
        loadingFriends: true,
        loadingFriendsError: null
      };
    case LOAD_FRIENDS_SUCCESS:
      return {
        ...state,
        loadingFriends: false,
        friends: action.result.data,
      };
    case LOAD_FRIENDS_FAIL:
      return {
        ...state,
        loadingFriends: false,
        loadingFriendsError: action.error
      };
    case LIKE:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          liking: true,
          likeError: null,
          liked: true,
        }
      };
    case LIKE_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          liking: false,
          liked: true,
          friended: action.result.data === 'friend' ? true : false,
        }
      };
    case LIKE_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          liking: false,
          likeError: action.error,
          liked: false,
        }
      };
    case UNFRIEND:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          unfriending: true,
          unfriendError: null,
          friended: false,
        }
      };
    case UNFRIEND_SUCCESS:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          unfriending: false,
          friended: false,
          liked: false,
        }
      };
    case UNFRIEND_FAIL:
      return {
        ...state,
        [action.key]: {
          ...state[action.key],
          unfriending: false,
          unfriendError: action.error,
          friended: true,
        }
      };

    default:
      return state;
  }
}

export function isLoaded(globalState) {
  return globalState.user && globalState.user.loaded;
}

export function isLoggedIn(globalState) {
  return globalState.user && globalState.user.meId;
}

export function load() {
  return {
    types: [LOAD, LOAD_SUCCESS, LOAD_FAIL],
    promise: (client) => client.post('/user/load')
  };
}

export function login({phone, password}) {
  return {
    types: [LOGIN, LOGIN_SUCCESS, LOGIN_FAIL],
    promise: (client) => client.post('/user/login', {
      data: {
        phone,
        password
      }
    }),
    successSide: (result) => {
      if (window.ga) {
        window.ga('set', '&uid', result.data._id);
      }
    }
  };
}


export function changePassword({password, verifyToken}) {
  return {
    types: [CHANGEPASSWORD, CHANGEPASSWORD_SUCCESS, CHANGEPASSWORD_FAIL],
    promise: (client) => client.post('/user/newPassword', {
      data: {
        password,
      },
      token: verifyToken
    })
  };
}

export function register({username, password, gender, school, code, verifyToken}) {
  return {
    types: [REGISTER, REGISTER_SUCCESS, REGISTER_FAIL],
    promise: (client) => client.post('/user/register', {
      data: {
        username,
        password,
        gender,
        school,
        code,
      },
      token: verifyToken
    }),
    successSide: (result) => {
      if (window.ga) {
        window.ga('set', '&uid', result.data._id);
      }
    }
  };
}

export function logout(token) {
  return {
    types: [LOGOUT, LOGOUT_SUCCESS, LOGOUT_FAIL],
    promise: (client) => client.post('/user/logout', {
      token
    }),
  };
}

export function loadUser() {
  return {
    types: [LOADUSER, LOADUSER_SUCCESS, LOADUSER_FAIL],
    promise: (client) => client.post('/user/load')
  };
}

export function sign(token) {
  return {
    types: [SIGN, SIGN_SUCCESS, SIGN_FAIL],
    promise: (client) => client.post('/user/sign', {
      token
    }),
    successSide: () => {
      return new Date();
    }
  };
}

export function changeInfo({data, url, key, token}) {
  return {
    types: [CHANGE_INFO, CHANGE_INFO_SUCCESS, CHANGE_INFO_FAIL],
    promise: (client) => client.post(url, {
      data,
      token
    }),
    key,
  };
}

// 服务端返回头像路径
export function upload({attach, token}) {
  return {
    types: [UPLOAD, UPLOAD_SUCCESS, UPLOAD_FAIL],
    promise: (client) => client.post('/user/uploadAvatar', {
      token
    }),
    uploadImages: [attach],
  };
}

// 获取我的任务 {taskTaken, taskPublish}
export function getTasks(reload) {
  return {
    types: [GET_TASKS, GET_TASKS_SUCCESS, GET_TASKS_FAIL],
    promise: (client) => client.get('/user/tasks', {
    }),
    reload
  };
}

// 获取我收藏任务
export function getTasksFav(start, span = 15) {
  return {
    types: [GET_FAV_TASKS, GET_FAV_TASKS_SUCCESS, GET_FAV_TASKS_FAIL],
    promise: (client) => client.get('/user/tasksFav', {
      params: {
        start,
        span,
      },
    }),
    start,
    span,
  };
}

// 获取我的分数
export function getScore() {
  return {
    types: [GET_SCORE, GET_SCORE_SUCCESS, GET_SCORE_FAIL],
    promise: (client) => client.get('/user/score', {
    }),
  };
}

// 我所有历史的任务（有分页)
export function getTasksHistory(start, span = 15) {
  return {
    types: [GET_HISTORY_TASKS, GET_HISTORY_TASKS_SUCCESS, GET_HISTORY_TASKS_FAIL],
    promise: (client) => client.get('/user/tasksHistory', {
      params: {
        start,
        span,
      },
    // successSide: result => arrayToObject(result.data)
    }),
    start,
    span,
  };
}

// 我所有花粉（有分页)
export function getPollens(start, span = 15, firstLoad) {
  return {
    types: [GET_POLLENS, GET_POLLENS_SUCCESS, GET_POLLENS_FAIL],
    promise: (client) => client.get('/user/myPollens', {
      params: {
        start,
        span,
      },
    }),
    start,
    span,
    firstLoad,
  };
}


export function loadUserDetail(userId) {
  return {
    types: [LOAD_USER_DETAIL, LOAD_USER_DETAIL_SUCCESS, LOAD_USER_DETAIL_FAIL],
    promise: client => client.get('/user/userDetail', {
      params: {
        user: userId
      }
    }),
    key: userId,
  };
}

export function loadFriends() {
  return {
    types: [LOAD_FRIENDS, LOAD_FRIENDS_SUCCESS, LOAD_FRIENDS_FAIL],
    promise: client => client.get('/user/friends', {
    }),
  };
}

export function like({toLike, token}) {
  return {
    types: [LIKE, LIKE_SUCCESS, LIKE_FAIL],
    promise: client => client.post('/user/like', {
      data: {
        toLike
      },
      token
    }),
    key: toLike,
  };
}

export function unfriend({toUnfriend, token}) {
  return {
    types: [UNFRIEND, UNFRIEND_SUCCESS, UNFRIEND_FAIL],
    promise: client => client.post('/user/unfriend', {
      data: {
        toUnfriend
      },
      token
    }),
    key: toUnfriend,
  };
}

