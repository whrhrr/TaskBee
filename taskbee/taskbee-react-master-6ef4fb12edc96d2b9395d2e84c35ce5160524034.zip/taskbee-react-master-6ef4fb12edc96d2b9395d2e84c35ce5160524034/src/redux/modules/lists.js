import {filterToId} from '../../utils/dataProcessor';

const LOAD = 'taskbee/lists/LOAD';
export const LOAD_SUCCESS = 'taskbee/lists/LOAD_SUCCESS';
const LOAD_FAIL = 'taskbee/lists/LOAD_FAIL';

const SWITCH_TAG = 'taskbee/lists/SWITCH_TAG';

import {LOGOUT_SUCCESS, CHANGE_INFO_SUCCESS} from './user';
import { createSelector } from 'reselect';

const initialState = {
  loaded: false,
  tag: null, // 当前列表
  data: [],
  noMore: {},

  /*
    新蜂房
   */
};

export default function info(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD:
      if (action.reload) {
        return {
          ...state,
          reloading: true,
          reloadError: null
        };
      }
      return {
        ...state,
        loading: true,
        error: ''
      };
    case LOAD_SUCCESS:
      // 在这里处理列表
      const key = action.tag || 'data';
      const ids = filterToId(action.result.data);
      let noMore = state.noMore;
      if (ids.length < action.span && !noMore[key]) {
        // 加载完了
        noMore = {
          ...noMore,
          [key]: true
        };
      }
      const newArry = ids;
      /*
      if (action.start) {
        // 继续加载
        newArry = state[key].concat(ids);
      } else {
        // 从头加载
        if (!state[key] || !state[key].length) {
          newArry = ids;
        } else {
          // 分析新的任务
          const existIndex = ids.indexOf(state[key][0]);
          if (existIndex < 0) {
            // 已经超过span指定的条数了，我们全部重新加载吧
            newArry = ids;
          } else {
            newArry = ids.slice(0, existIndex).concat(state[key]);
          }
        }
      }
      */

      if (action.reload) {
        return {
          ...state,
          reloading: false,
          [key]: newArry,
          noMore
        };
      }
      return {
        ...state,
        loading: false,
        loaded: true,
        [key]: newArry,
        noMore
      };
    case LOAD_FAIL:
      if (action.reload) {
        return {
          ...state,
          reloading: false,
          reloadError: action.error
        };
      }
      return {
        ...state,
        loading: false,
        error: action.error
      };
    case SWITCH_TAG:
      return {
        ...state,
        tag: action.tag
      };
    case CHANGE_INFO_SUCCESS:
      if (action.key === 'schoolId') {
        return {
          ...initialState,
          tag: state.tag
        };
      }
      return state;
    case LOGOUT_SUCCESS:
      return {
        ...initialState,
        tag: state.tag,
      };
    default:
      return state;
  }
}

export function isLoaded(globalState) {
  return globalState.info && globalState.info.loaded;
}

export function load({start, tag, span = 15, reload = true, loc}) {
  return {
    types: [LOAD, LOAD_SUCCESS, LOAD_FAIL],
    promise: (client) => client.get('/task/tasks', { params: {
      start,
      span,
      tag,
      long: loc[0],
      lati: loc[1]
    }}),
    start,
    span,
    tag,
    reload,
  };
}

export function switchTag(tag) {
  return (dispatch) => {
    dispatch(load(null, tag));
    dispatch({
      type: SWITCH_TAG,
      tag
    });
  };
}


/*

  reselector

 */
const taskSelector = state => state.lists.data;
const realDataSelector = state => state.task;
const lbses = state => state.lbs;
const locationPollen = state => state.pollen.list;
const locationPollenDead = state => state.pollen.listDead;
const meIdSelector = state => state.user.meId;

const processPollenLoc = data => {
  return {
    geometry: data.loc,
    type: 'Feature',
    id: data._id,
    typeId: data.type,
  };
};
export const locsOnMapSelector = createSelector(
  taskSelector,
  realDataSelector,
  lbses,
  locationPollen,
  locationPollenDead,
  meIdSelector,
  (list, realData, lbsData, pollenList, deadPollenList, meId) => {
    return {
      locations: list.map((id) => {
        return {
          geometry: {...realData[id].loc},
          type: 'Feature',
          properties: {
            id,
            aboutMe: realData[id].publisher._id === meId || realData[id].tasker === meId,
            state: realData[id].state,
            type: realData[id].type,
            publisher: {...realData[id].publisher},
            description: realData[id].description,
          }
        };
      }),
      pollenLocations: pollenList.map(processPollenLoc),
      deadPollenLocations: deadPollenList.map(processPollenLoc),
      lbsLoaded: lbsData.loaded,
      lbsLoading: lbsData.loading,
      lbsError: lbsData.error,
      longitude: lbsData.longitude,
      latitude: lbsData.latitude,
    };
  }
);

