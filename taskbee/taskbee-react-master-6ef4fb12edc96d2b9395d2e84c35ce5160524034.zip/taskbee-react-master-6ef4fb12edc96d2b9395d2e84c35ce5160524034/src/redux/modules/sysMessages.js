export const GET_SYS_MESSAGE = 'taskbee/sysMessages/GET_SYS_MESSAGE';
export const GET_NEW_SYS = 'taskbee/sysMessage/GET_NEW_SYS';
export const CHECK_SYS_MESSAGE = 'taskbee/sysMessage/CHECK_SYS_MESSAGE';
const LEAVE_SYS_MESSAGE = 'taskbee/sysMessage/LEAVE_SYS_MESSAGE';

export const STATUS = 'taskbee/messages/STATUS';
// 外来
import {LOGOUT_SUCCESS} from './user';
import {ARRIVE_MESSAGE} from './misc';
const initialState = {
  messages: [],
  unread: 0,
  isInSys: false,
};

export default function sysMessage(state = initialState, action = {}) {
  switch (action.type) {
    case GET_NEW_SYS:
      return {
        ...state,
        unread: state.unread + action.result.data.length,
        messages: action.result.data.concat(state.messages),
      };
    case GET_SYS_MESSAGE:
      return {
        ...state,
        unread: state.unread + 1,
        messages: [action.result.data, ...state.messages],
      };
    case CHECK_SYS_MESSAGE:
      return {
        ...state,
        unread: 0,
        isInSys: true,
      };
    case LEAVE_SYS_MESSAGE:
      return {
        ...state,
        isInSys: false,
      };
    case ARRIVE_MESSAGE:
      if (state.isInSys) {
        return {
          ...state,
          unread: 0
        };
      }
      return state;
    case LOGOUT_SUCCESS:
      return initialState;
    default:
      return state;
  }
}

// 收到新消息
export function getSysMessage(data) {
  return {
    type: GET_SYS_MESSAGE,
    result: data
  };
}

// 获取未读聊天消息
export function getNewSys(data) {
  return {
    type: GET_NEW_SYS,
    result: data
  };
}

export function checkMessage() {
  return {
    type: CHECK_SYS_MESSAGE,
  };
}

export function leaveMessage() {
  return {
    type: LEAVE_SYS_MESSAGE,
  };
}
