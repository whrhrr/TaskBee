const LOAD = 'taskbee/lbs/LOAD';
const LOAD_SUCCESS = 'taskbee/lbs/LOAD_SUCCESS';
const LOAD_FAIL = 'taskbee/lbs/LOAD_FAIL';
import {LOAD_SUCCESS as USER_LOAD_SUCCESS} from './user';

const initialState = {
  loading: false,
  loaded: false,
  longitude: 121.496893,
  latitude: 31.284947,
};

export default function verify(state = initialState, action = {}) {
  switch (action.type) {
    case LOAD:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case LOAD_SUCCESS:
      console.log(action.pos);
      return {
        ...state,
        loading: false,
        loaded: true,
        error: null,
        longitude: action.pos.coords.longitude,
        latitude: action.pos.coords.latitude,
        accuracy: action.pos.coords.accuracy,
      };
    case LOAD_FAIL:
      return {
        ...state,
        loading: false,
        error: action.error,
      };
    case USER_LOAD_SUCCESS:
      // 置入用户的地理位置
      const {loc} = action.result.data;
      return {
        ...state,
        longitude: loc.coordinates[0],
        latitude: loc.coordinates[1],
      };
    default:
      return state;
  }
}

export function load() {
  return {
    type: LOAD,
  };
}

export function loadSuccess(pos) {
  return {
    type: LOAD_SUCCESS,
    pos,
  };
}

export function loadFail(error) {
  console.log(error);
  return {
    type: LOAD_FAIL,
    error,
  };
}

export function isLocLoaded(globalState) {
  return globalState.lbs.loaded;
}
