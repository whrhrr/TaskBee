import request from 'superagent';

export default function clientMiddleware(client) {
  return ({dispatch, getState}) => {
    return next => action => {
      if (typeof action === 'function') {
        return action(dispatch, getState);
      }

      // successSide func 成功时运行side effect
      // failureSid func 失败时运行side effect
      const { promise, types, successSide, failureSide, uploadImages, ...rest } = action; // eslint-disable-line no-redeclare
      if (!promise) {
        return next(action);
      }

      const [REQUEST, SUCCESS, FAILURE] = types;
      next({...rest, type: REQUEST});
      return promise(client).then(
        (result) => {
          if (successSide) {
            return next({...rest, result, type: SUCCESS, side: successSide(result, dispatch, getState)});
          }

          if (!uploadImages) return next({...rest, result, type: SUCCESS});

          // 狗日的七牛上传
          const uploadPromises = uploadImages.map( image => {
            return new Promise( (resolve, reject) => {
              request
                .post('https://up.qbox.me')
                .field('token', result.data)
                .attach('file', image)
                .end((err, { body } = {}) => err ? reject(body || err) : resolve(body));
            });
          });
          Promise.all(uploadPromises).then((uploadResult) => {
            return next({...rest, result, uploadResult, type: SUCCESS});
          }).catch((error)=> {
            next({...rest, result, error, type: SUCCESS});
          });

        },
        (error) => {
          if (error && error.errorCode === 'NEED_RELOGIN') {
            // 需要登录
            dispatch({
              type: 'taskbee/user/LOGOUT_SUCCESS'
            });
          } else if (error && error.crossDomain) {
            error.message = '网络错误，请检查你的网络连接';
          }
          if (failureSide) {
            return next({...rest, error, side: failureSide(error), type: FAILURE});
          }
          return next({...rest, error, type: FAILURE});
        }
      ).catch((error)=> {
        console.error('MIDDLEWARE ERROR:', error);
        next({...rest, error, type: FAILURE});
      });
    };
  };
}
