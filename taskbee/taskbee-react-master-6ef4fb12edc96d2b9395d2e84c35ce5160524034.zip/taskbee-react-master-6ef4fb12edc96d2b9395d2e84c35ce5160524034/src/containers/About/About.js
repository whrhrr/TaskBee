import React, { Component } from 'react';
import { Banner, Downloads } from 'components';
import DocumentMeta from 'react-document-meta';
import {Link} from 'react-router';

export default class About extends Component {
  render() {
    const styles = require('./About.scss');
    return (
      <div className={styles.about}>
        <DocumentMeta title="关于 - 蜂房"/>
        <Banner main="关于"/>
        <Downloads stick/>
        <div className={styles.mainText}>
          <span className={styles.bigHi}>HI!</span>
          <p>这里是蜂房taskbee.cn，在同济大学试运行的高校任务+社交平台。<br/>蜂房现在为最早期的测试版，期望能得到更多同学的反馈。</p>

          <span className={styles.bigHi}><br/>关于我们</span>
          <p>我们是一支来自同济大学计算机系大四学生组成的团队</p>
          <p>蜂房如果没有以下同学的贡献，不会存在</p>
          <ul>
            <li>小不</li>
            <li>May</li>
            <li>HeartRunner</li>
            <li>汪汪</li>
            <li>BlackSheepWall</li>
            <li>IT界的志明</li>
            <li>小白菜</li>
            <li><del>淫窝</del>503的小伙子们</li>
            <li>计科班级的同学们</li>
            <li>所有早期的测试者们</li>
          </ul>
          <span className={styles.bigHi}><br/>参与蜂房</span>
          <p>我们尚处于非常早期的阶段，如果对我们的项目有兴趣</p>
          <b>我们非常欢迎你：</b>
          <ul>
            <li><Link to="/feedback">在程序中直接向我们提交反馈</Link></li>
            <li>加入我们的QQ交流群：478227215</li>
            <li>加入我们，让我们一起把蜂房建立的更好</li>
            <li><a href="mailto:xiaobu@taskbee.cn">联系Email: xiaobu@taskbee.cn</a></li>
            <li>多多使用我们的程序，帮助整个蜂房社区的活跃</li>
            <li>推荐给身边的同学们尝试</li>
          </ul>
        </div>
      </div>
    );
  }
}
