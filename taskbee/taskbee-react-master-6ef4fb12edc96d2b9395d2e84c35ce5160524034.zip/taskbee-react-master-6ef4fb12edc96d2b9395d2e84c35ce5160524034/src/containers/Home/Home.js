import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { load, switchTag } from 'redux/modules/lists';
import DocumentMeta from 'react-document-meta';
import { Link } from 'react-router';
import { SkillItem, Banner, TabToggle, Ripple, Mapbox, LoadingIndicator, TaskItem, NormalButton } from 'components'; // Tag
import {onFavClick} from 'utils/componentEvents';
import {fav, unfav} from 'redux/modules/task';
import {newPublish} from 'redux/modules/publish'; // isTagLoaded, getTags,
import {scrollHome, setHomeTab, setActiveTask, toggleMap} from 'redux/modules/misc';
import connectData from 'helpers/connectData';
import {debounce} from 'utils/componentEvents';
import { load as loadSkill} from 'redux/modules/skill';

// import {isLocLoaded} from 'redux/modules/lbs';
// import {requireLogin} from 'utils/componentEvents';
import {Map, List} from 'immutable';

const styles = require('./Home.scss');

// todo 现在只有reload没有load了
let firstLoad = true;

function fetchDataDeferred(getState, dispatch) {
  const promises = [];
  promises.push(dispatch(loadSkill()));
  return Promise.all(promises);
}
@connectData(null, fetchDataDeferred)
@connect(state => {
  const {error, loading, tag, reloading, reloadError} = state.lists;
  return {
    // 技能
    skills: state.skill.get('list'),
    skillData: state.skill.get('data'),
    noMore: state.skill.get('noMoreList'),
    loadingSkill: state.skill.get('loading'),
    errorSkill: state.skill.get('loadingError'),
    tasks: state.lists[tag || 'data'] || [],
    tag,
    loading,
    briefTasks: state.task,
    error,
    token: state.user.token,
    reloading,
    reloadError,
    tags: state.publish.tags || [],
    scrollY: state.misc.scrollHome,
    windowHeight: state.misc.heightHome,
    user: state.user[state.user.meId] || {},
    meId: state.user.meId,
    lbsLoaded: state.lbs.loaded,
    lbsLoading: state.lbs.loading,
    lbsError: state.lbs.error,
    lbsLongitude: state.lbs.longitude,
    lbsLatitude: state.lbs.latitude,
    homeTab: state.misc.homeTab,
    activeItem: state.misc.activeItem,
    showMap: state.misc.showMap,
  }; }, {toggleMap, scrollHome, newPublish,
   fav, unfav, load, switchTag, setHomeTab, setActiveTask, loadSkill})
export default class Home extends Component {
  static propTypes = {
    tasks: PropTypes.array.isRequired,
    briefTasks: PropTypes.object.isRequired,
    loading: PropTypes.bool,
    loadingSkill: PropTypes.bool,
    loadSkill: PropTypes.func,
    errorSkill: PropTypes.any,
    noMore: PropTypes.bool,
    skills: List.isList,
    skillData: Map.isMap,
    reloading: PropTypes.bool,
    reloadError: PropTypes.any,
    error: PropTypes.any,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    load: PropTypes.func.isRequired,
    switchTag: PropTypes.func.isRequired,
    newPublish: PropTypes.func.isRequired,
    scrollHome: PropTypes.func.isRequired,
    token: PropTypes.string,
    tag: PropTypes.string,
    history: PropTypes.object.isRequired,
    tags: PropTypes.array,
    windowHeight: PropTypes.number,
    scrollY: PropTypes.number,
    user: PropTypes.object,
    meId: PropTypes.string,
    lbsLoaded: PropTypes.bool,
    lbsLoading: PropTypes.bool,
    lbsLongitude: PropTypes.number,
    lbsLatitude: PropTypes.number,
    lbsError: PropTypes.any,
    homeTab: PropTypes.number.isRequired,
    setHomeTab: PropTypes.func.isRequired,
    activeItem: PropTypes.string,
    showMap: PropTypes.bool,
    setActiveTask: PropTypes.func.isRequired,
    toggleMap: PropTypes.func,
    lastCollectTime: PropTypes.number,
  };

  componentDidMount() {
    // this.refs.scrollElem.scrollTop = this.props.scrollY;
    // this.refs.scrollElem.addEventListener('scroll', this.onScroll);
    const {lbsLongitude, lbsLatitude} = this.props;
    this.props.load({
      loc: [lbsLongitude, lbsLatitude],
    }); // 有地理位置就载入
    if (firstLoad) {
      setTimeout(() => this.props.setHomeTab(0), 1000);
      firstLoad = false;
    }
  }

  componentWillReceiveProps(nextProps) {
    if (!this.props.lbsLoaded && nextProps.lbsLoaded) {
      const {tag, lbsLongitude, lbsLatitude} = nextProps;
      this.props.load({tag, loc: [lbsLongitude, lbsLatitude], reload: true});
    }
  }

  componentWillUnmount() {
    // this.refs.scrollElem.removeEventListener('scroll', this.onScroll);
    clearInterval(this.autoUpdateHandler);
  }

  onScroll = debounce(() => {
    const scrollTop = this.refs.scrollElem.scrollTop;
    this.props.scrollHome(scrollTop);
  }, 250);

  onReloadClick = () => {
    if (!this.props.loading) {
      const {tasks, tag, lbsLongitude, lbsLatitude} = this.props;
      this.props.load({start: tasks[Math.max(tasks.length - 1, 0)], loc: [lbsLongitude, lbsLatitude], tag});
    }
  }

  onReloadConfirm = () => {
    if (!this.props.reloading) {
      const {tag, lbsLongitude, lbsLatitude} = this.props;
      this.props.load({tag, loc: [lbsLongitude, lbsLatitude], reload: true});
    }
  }
  onLoadMoreSkill = () => {
    const {skills} = this.props;
    if (!this.props.noMore && !(!skills.size && this.props.errorSkill) && !this.props.loadingSkill) {
      if (skills.size) {
        this.props.loadSkill({
          start: skills.size,
        });
      }
      else this.props.load();
    }
  }

  onTagClick = (name) => {
    return ()=>{
      return this.props.switchTag(name);
    };
  }

  onGoCreateClick = () => {
    const {tag, tags} = this.props;
    let tmpTag;
    if (tag) {
      for (let ind = 0; ind < tags.length; ind++) {
        if (tags[ind].name === tag) {
          tmpTag = tags[ind];
          break;
        }
      }
    }
    this.props.newPublish(tmpTag);
  }

  onBindedFavClick = onFavClick.bind(this)

  onSetHomeTab = (tab) => {
    return () => {
      this.props.setHomeTab(tab);
    };
  }

  onMapTaskClick = (feature) => {
    this.props.setActiveTask(feature.properties.id);
  }

  onRefreshClick = () => {
    const {tag, lbsLongitude, lbsLatitude, reloading} = this.props;
    if (!reloading) {
      this.props.load({tag, loc: [lbsLongitude, lbsLatitude], reload: true});
    }
    this.props.loadSkill();

  }

  tagActive = (tag) => {
    if (this.props.tag === tag) {
      return styles.tagActive;
    }
  }

  render() {
    const {activeItem,
      lbsLongitude, lbsLatitude, homeTab,
      lbsLoaded, lbsLoading, lbsError, meId,
      reloading, reloadError, history, briefTasks, tasks,
      loadingSkill, errorSkill, skills, skillData, noMore,
  } = this.props;
    // const scrollHeight = this.props.windowHeight - 300 - 48 - 24;
    let content;
    let centerStyle = styles.center;
    if (!tasks.length) {
      centerStyle = centerStyle + ' ' + styles.noOther;
    }

    let listContent;
    if (homeTab === 0) {
      if (reloading) {
        content = <div className={centerStyle}><LoadingIndicator /></div>;
      } else if (reloadError) {
        content = (<div className={centerStyle}>
        <h3>载入出错了</h3>
        <p>{reloadError.message || reloadError.reason || '网络错误，请稍后再试'}</p>
        <NormalButton onClick={this.onReloadClick}>重试</NormalButton>
        </div>);
      } else if (lbsLoading && !lbsLoaded) {
        content = <div className={centerStyle}><p className={styles.subtle}>获取地理位置中……</p></div>;
      } else if (lbsError) {
        content = <div className={centerStyle}><p className={styles.subtle}>获取地理位置出错，请尝试刷新网页</p></div>;
      } else if (!lbsLoaded) {
        content = (<div className={centerStyle}>
          <p className={styles.subtle}>蜂房需要地理位置才能工作，请先启用地理位置</p>
        </div>);
      } else if (!tasks.length) {
        content = (<div className={centerStyle}>
          <h2 className={styles.subtle}>所有任务都被领完了～</h2>
          <Link onClick={this.onGoCreateClick} className={styles.button} to="/new">去发布任务</Link>
        </div>);
      } else { // 有东西
        content = <div className={centerStyle + ' ' + styles.action} >以上是附近30KM内的所有任务</div>;
      }
      listContent = tasks.length ? (<div className={styles.tasks}>
                {tasks.map( id => {
                  const item = briefTasks[id];
                  return (<TaskItem key={item._id}
                    ref={activeItem === item._id ? 'activeItem' : null }
                    {...item} meId={meId}
                    onFavClick={this.onBindedFavClick(item._id)}
                    myPos={[lbsLongitude, lbsLatitude]}
                    pushState={history.pushState}/>);
                })} </div>) : null;
    } else if (homeTab === 1) {
      if (loadingSkill) {
        content = <div className={centerStyle}><LoadingIndicator /></div>;
      } else if (errorSkill) {
        content = (<div className={centerStyle}>
        <h3>载入出错了</h3>
        <p>{errorSkill.message || errorSkill.reason || '网络错误，请稍后再试'}</p>
        <NormalButton onClick={this.onReloadClick}>重试</NormalButton>
        </div>);
      } else if (!skills.size) {
        content = (<div className={centerStyle}>
          <h2 className={styles.subtle}>老司机们都休息了</h2>
        </div>);
      } else if (noMore) { // 有东西
        content = <div className={styles.action} >没有更多老司机啦</div>;
      } else {
        content = <div className={styles.loadMoreContainer}><NormalButton onClick={this.onLoadMoreSkill}>载入更多</NormalButton></div>;
      }
      listContent = skills.size ? (<div className={styles.tasks}>
                {skills.toArray().map( id => {
                  const item = skillData.get(id);
                  return (<SkillItem
                    key={id}
                    data={item}
                    pushState={history.pushState}
                    meId={this.props.meId}
                    // onFavClick={this.onFavClick(id)}
                    long={this.props.lbsLongitude}
                    lati={this.props.lbsLatitude}
                  />);
                })} </div>) : null;
    }

    let status = '';
    if (lbsLoading) {
      status = '载入位置中……';
    } else if (lbsError) {
      status = '未知位置';
    } else if (this.props.showMap) {
      status = '关闭地图';
    } else {
      status = '打开地图';
    }
    return (
      <div className={styles.home}>
        <Banner
          left={<span className={styles.status} onClick={this.props.toggleMap}>
            {status}
          </span>}
          /*
          left={<div className={styles.status} onClick={this.props.toggleMap}>
            {status}
          </div>}
          */
          right={<span className={styles.refresh} onClick={this.onRefreshClick}>
            <Ripple/>
            刷新
          </span>}
          main={<TabToggle
            left="老司机"
            right="任务"
            onLeftClick={this.onSetHomeTab(1)}
            onRightClick={this.onSetHomeTab(0)}
            isRight={homeTab === 0}
          />}
        />
        {
          /*
          <div className={styles.tags}>
            <div className={styles.status} onClick={this.props.toggleMap}>
              {status}
            </div>
            <div className={styles.refresh} onClick={this.onRefreshClick}>
              <Ripple/>
              刷新
            </div>
            <span className={homeTab === 0 ? styles.active : null} onClick={this.onSetHomeTab(0)}>任务</span>
            <span className={homeTab === 1 ? styles.active : null} onClick={this.onSetHomeTab(1)}>老司机</span>
          </div>
          */
        }
        {
          this.props.showMap ? <Mapbox className={styles.map} pushState={history.pushState}/> : null
        }
          {
            /*
            <PullToAction className={styles.taskList}
              normal={reloadError ? reloadError.message || '网络错误请稍候重试 ' : '下拉刷新'}
              pulled="释放刷新" working={<Spinner/>} doingWork={reloading}
              onConfirm={this.onReloadConfirm}
              pullTrigger={30} elementHeight={60}
              scrollElem={this.refs.scrollElem}>

            <div className={styles.tags}>
              <Tag className={this.tagActive(null)} key="所有任务" name="所有任务" onClick={this.onTagClick(null)}/>
              {tags.map( tag => <Tag className={this.tagActive(tag.name)} key={tag.name} name={tag.name} onClick={this.onTagClick(tag.name)}/>)}
            </div>
             */
          }
          <div ref="scrollElem" className={styles.taskScroll + (this.props.showMap ? ' ' + styles.showMap : '')}>
            {listContent}
            {content}
          </div>
      </div>
    );
  }
}
// console.log(Home.fetchDataDeferred);
