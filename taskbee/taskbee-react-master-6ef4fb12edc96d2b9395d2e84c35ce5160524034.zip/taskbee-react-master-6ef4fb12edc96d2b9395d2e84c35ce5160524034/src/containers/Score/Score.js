import React, { Component, PropTypes } from 'react';
import { Banner } from 'components';
import DocumentMeta from 'react-document-meta';
import {connect} from 'react-redux';

@connect(
  state => ({
    user: state.user[state.user.meId]
  })
)
export default class Score extends Component {
  static propTypes = {
    user: PropTypes.object,
  }

  render() {
    const styles = require('./Score.scss');
    const scoreImg = require('./Score.png');
    return (
      <div className={styles.score}>
        <DocumentMeta title="蜂蜜 - 蜂房"/>
        <Banner main="蜂蜜"/>
        <div className={styles.intro}>
          <div className={styles.img}>
            <img src={scoreImg}/>
          </div>
          <p>{this.props.user.score}</p>
        </div>
        <p className={styles.mainText}>
          蜂蜜是你在使用蜂房过程中获得的积分
        </p>
        <ul className={styles.rules}>
          <li>蜂蜜不多于 0 时不得发布/接手任务</li>
          <li>每日签到(每天发布的第一条花粉) ＋1</li>
          <li>接手任务 ＋1</li>
          <li>发布任务 －2</li>
          <li>任务顺利完成 发布者 ＋1/ 接手者 ＋1</li>
          <li>接手任务者，若接手后不能完成任务 －6</li>
          <li>发布任务者，若在有人接手后撤销任务 －6</li>
          <li>完成任务后评价对方，可为对方增加（0～2）蜂蜜</li>
        </ul>
      </div>
    );
  }
}
