import React, { Component, PropTypes } from 'react';
import DocumentMeta from 'react-document-meta';
import { Ripple, Banner, Contact, TabToggle, SysMessage } from 'components';
import {connect} from 'react-redux';
import {arriveMessage} from 'redux/modules/misc';
import {checkMessage, leaveMessage} from 'redux/modules/sysMessages';
import {Link} from 'react-router';

@connect(state => {
  return {
    messages: state.messages,
    sysMessages: state.sysMessages.messages,
    isInSys: state.sysMessages.isInSys,
    unread: state.sysMessages.unread,
    user: state.user[state.user.meId] || {},
  };
}, {arriveMessage, checkMessage, leaveMessage})
export default class Messages extends Component {
  static propTypes = {
    messages: PropTypes.object.isRequired,
    sysMessages: PropTypes.array.isRequired,
    checkMessage: PropTypes.func.isRequired,
    leaveMessage: PropTypes.func.isRequired,
    arriveMessage: PropTypes.func.isRequired,
    isInSys: PropTypes.bool,
    unread: PropTypes.number.isRequired,
    history: PropTypes.object.isRequired,
  }

  componentDidMount() {
    this.props.arriveMessage();
  }

  render() {
    const styles = require('./Message.scss');
    const {unread, messages, isInSys, sysMessages, history} = this.props;
    let contacts;
    if (isInSys) {
      if (sysMessages.length) {
        contacts = sysMessages.map( (sys, ind) => <SysMessage key={ind} {...sys} pushState={history.pushState}/>);
      } else {
        contacts = (<div className={styles.noContact}>
            还没有系统消息<br/>这里会显示一些系统消息<br/>系统消息不会保存
          </div>);
      }
    } else {
      let keys = Object.keys(messages);
      if (keys.length) {
        // 按未读数排列
        keys = keys.filter( key => key.length === 24);
        keys.sort(function unreadfirst(fir, sec) {return messages[fir].unread > messages[sec].unread; });
        contacts = [];
        for (let ind = keys.length - 1; ind >= 0; ind--) {
          const key = keys[ind];
          const thisMsg = messages[key];
          contacts.push(
            <Contact key={thisMsg._id} {...thisMsg}/>
          );
        }
      } else {
        contacts = (<div className={styles.noContact}>
            还没有联系<br/>接手任务或发布任务后，可以向对方发送私信<br/>
            (这里会存储10名联系人<br/>退出程序再次进入依然可以联系)
          </div>);
      }
    }

    return (
      <div className={styles.message}>
        <DocumentMeta title="私信 - 蜂房"/>
        <Banner right={<Link className={styles.friend} to="/friends"><Ripple/>好友</Link>} main={<TabToggle left="私信" right={<span>系统消息{unread ? <i className={styles.unread}>{unread}</i> : null} </span>}
        isRight={isInSys} onLeftClick={this.props.leaveMessage} onRightClick={this.props.checkMessage}/>} left=""/>
        {contacts}
      </div>
    );
  }
}
