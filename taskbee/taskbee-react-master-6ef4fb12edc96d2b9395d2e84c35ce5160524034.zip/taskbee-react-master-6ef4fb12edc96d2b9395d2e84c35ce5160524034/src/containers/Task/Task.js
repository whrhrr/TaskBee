import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import DocumentMeta from 'react-document-meta';
import { Link } from 'react-router';
import { Banner, LoadingIndicator, TaskItem, NormalButton, PullToAction, Spinner, Ripple } from 'components';
import {getTasks} from 'redux/modules/user';
import connectData from 'helpers/connectData';
import {fav, unfav} from 'redux/modules/task';
import {arriveTask} from 'redux/modules/misc';
import {onFavClick} from 'utils/componentEvents';

function fetchDataDeferred(getState, dispatch) {
  return dispatch(getTasks());
}
@connectData(null, fetchDataDeferred)
@connect(state => ({
  user: state.user[state.user.meId] || {},
  briefTasks: state.task,
  loading: state.user.gettingTasks,
  error: state.user.getTasksError,
  token: state.user.token,
  reloadError: state.user.reloadingTasksError,
  reloading: state.user.reloadingTasks,
}), {fav, unfav, onFavClick, getTasks, arriveTask})

export default class Task extends Component {
  static propTypes = {
    user: PropTypes.object.isRequired,
    briefTasks: PropTypes.object.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
    reloading: PropTypes.bool,
    reloadError: PropTypes.any,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    onFavClick: PropTypes.func.isRequired,
    getTasks: PropTypes.func.isRequired,
    arriveTask: PropTypes.func.isRequired,
    history: PropTypes.object.isRequired,
  };

  componentDidMount() {
    this.props.arriveTask();
  }

  onReload() {
    this.props.getTasks(true);
  }

  onBindedFavClick = onFavClick.bind(this)

  render() {
    const styles = require('./Task.scss');
    const {history, reloading, reloadError, briefTasks, loading, user: {_id, gender, avatar, username, score, taskPublish, taskTaken}, error} = this.props;
    const partUser = {_id, gender, avatar, username, score, };
    let content;
    let centerStyle = styles.center;
    if (!taskTaken && !taskPublish) {
      centerStyle = centerStyle + ' ' + styles.noOther;
    }
    if (loading) {
      content = <div className={centerStyle}><LoadingIndicator /></div>;
    } else if (error) {
      content = (<div className={centerStyle}>
        <h3>载入出错了</h3>
        <p>{error.message || error}</p>
        <NormalButton onClick={this.props.getTasks}>重试</NormalButton>
      </div>);
    }
    return (
      <div className={styles.task}>
        <DocumentMeta title="我的任务 - 蜂房"/>
        <Banner main="我的任务" left=""/>
        <PullToAction normal={reloadError ? reloadError.message || reloadError : '下拉刷新'}
            pulled="释放刷新" working={<Spinner/>} doingWork={reloading}
            pullTrigger={15} elementHeight={30} onConfirm={::this.onReload}>
          <div className={styles.controls}>
            <Link to="/task/historyTasks" className={styles.whiteButton}>
              <span>历史任务</span>
              <div className="icon-check-clipboard-1"/>
              <Ripple/>
            </Link>
            <Link to="/task/favTasks" className={styles.whiteButton}>
              <span>点赞任务</span>
              <div className="icon-heart-1"/>
              <Ripple/>
            </Link>
          </div>
          {content}
          {(taskTaken || taskPublish) && (<div className={styles.taskList}>
            <div className={styles.section}>
              <h3>我接手的任务</h3>
              {taskTaken.length ? taskTaken.map( id => {
                const item = briefTasks[id];
                if (item) return <TaskItem key={item._id} nofav timeline {...item} onFavClick={this.onBindedFavClick(item._id)} pushState={history.pushState}/>;
              }) :
                <p className={styles.placeholder}>{"还没有接手的任务"}</p>
              }
            </div>
            <div className={styles.section}>
              <h3>我发布的任务</h3>
              {taskPublish.length ? taskPublish.map( id => {
                const item = briefTasks[id];
                if (item) return <TaskItem key={item._id} nofav timeline {...item} publisher={partUser} onFavClick={this.onBindedFavClick(item._id)} pushState={history.pushState}/>;
              }) :
                <p className={styles.placeholder}>{"还没有发布的任务"}</p>
              }
            </div>
            </div>)}
        </PullToAction>
      </div>
    );
  }
}
