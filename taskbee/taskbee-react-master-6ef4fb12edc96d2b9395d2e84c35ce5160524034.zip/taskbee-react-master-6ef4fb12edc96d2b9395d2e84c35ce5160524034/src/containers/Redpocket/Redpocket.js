/*
  因为逻辑和Withdraw基本重合，所以拷贝了一份代码，这锅我背锅
 */

import React, { Component, PropTypes } from 'react';
import { Banner, NormalButton, Spinner, TextInput } from 'components';
import DocumentMeta from 'react-document-meta';
import {connect} from 'react-redux';
import {redpocket as withdraw, confirmRedpocket as confirmWithdraw} from 'redux/modules/order';
import redpocketValidation from './RedpocketValidation';
import {reduxForm} from 'redux-form';

@reduxForm({
  form: 'user',
  fields: ['pocketId'],
  validate: redpocketValidation,
})
@connect(
  state => ({
    // user: state.user[state.user.meId],
    token: state.user.token,
    withdrawing: state.order.redpocketing,
    withdrawSuccess: state.order.redpocketSuccess,
    withdrawError: state.order.redpocketError,
  }), {withdraw, confirmWithdraw}
)
export default class Withdraw extends Component {
  static propTypes = {
    // user: PropTypes.object,
    token: PropTypes.string,
    withdrawing: PropTypes.bool,
    withdrawError: PropTypes.any,
    withdrawSuccess: PropTypes.object,
    history: PropTypes.object.isRequired,
    fields: PropTypes.object.isRequired,
    withdraw: PropTypes.func.isRequired,
    confirmWithdraw: PropTypes.func.isRequired,
    invalid: PropTypes.bool.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    initializeForm: PropTypes.func.isRequired,
  }

  onSubmit = (data) => {
    data.preventDefault();
    const {withdrawing} = this.props;
    if (!withdrawing) {
      this.props.handleSubmit(this.prepareToSubmit)(data);
    }
  }

  prepareToSubmit = (data) => {
    data.token = this.props.token;
    this.props.withdraw(data);
  }

  render() {
    const styles = require('./Redpocket.scss');
    const {fields: {pocketId}, invalid,
      withdrawing, withdrawError, withdrawSuccess} = this.props;
    return (
      <div className={styles.withdraw}>
        <DocumentMeta title="红包 - 蜂房"/>
        <Banner main="红包"/>
          {withdrawSuccess ? <div className={styles.success}>
              <h2>红包兑换成功！</h2>
              <div className={styles.pocketCard}>
                <p className={styles.price}>¥{withdrawSuccess.price}</p>
                <p>{withdrawSuccess.title}</p>
              </div>
              <NormalButton onClick={this.props.confirmWithdraw}>
              再兑一个
              </NormalButton>
            </div>
            :
            <form onSubmit={this.onSubmit}>
              <TextInput type="text" label="兑换码" placeholder="请输入红包兑换码" {...pocketId} />
              <p className={styles.subtle}>蜂房不定期会举办活动送红包~</p>
              <NormalButton type="submit" disabled={invalid} onClick={this.onCreateOrderClick}>
                {
                  withdrawing ? <Spinner/>
                  : <span>兑换</span>
                }
              </NormalButton>
              {withdrawError && <div className={styles.error}>
                <p>{withdrawError.message || '网络错误，请稍候重试'}</p>
              </div>}
            </form>
          }
      </div>
    );
  }
}
