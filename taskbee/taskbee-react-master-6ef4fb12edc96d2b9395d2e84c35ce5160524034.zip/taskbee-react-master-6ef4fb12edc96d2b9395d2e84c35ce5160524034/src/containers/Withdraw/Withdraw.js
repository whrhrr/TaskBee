import React, { Component, PropTypes } from 'react';
import { Banner, NormalButton, Spinner, TextInput } from 'components';
import DocumentMeta from 'react-document-meta';
import {connect} from 'react-redux';
import {withdraw, confirmWithdraw} from 'redux/modules/order';
import {Link} from 'react-router';
import withdrawValidation from './withdrawValidation';
import {reduxForm} from 'redux-form';

@reduxForm({
  form: 'user',
  fields: ['money', 'email', 'realname'],
  validate: withdrawValidation,
})
@connect(
  state => ({
    user: state.user[state.user.meId],
    token: state.user.token,
    withdrawing: state.order.withdrawing,
    withdrawSuccess: state.order.withdrawSuccess,
    withdrawError: state.order.withdrawError,
  }), {withdraw, confirmWithdraw}
)
export default class Withdraw extends Component {
  static propTypes = {
    user: PropTypes.object,
    token: PropTypes.string,
    withdrawing: PropTypes.bool,
    withdrawError: PropTypes.any,
    withdrawSuccess: PropTypes.bool,
    history: PropTypes.object.isRequired,
    fields: PropTypes.object.isRequired,
    withdraw: PropTypes.func.isRequired,
    confirmWithdraw: PropTypes.func.isRequired,
    invalid: PropTypes.bool.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    initializeForm: PropTypes.func.isRequired,
  }

  componentDidMount() {
    const {user} = this.props;
    this.props.initializeForm({
      money: user.money.toString(),
      realname: user.realname,
    });
  }

  onSubmit = (data) => {
    data.preventDefault();
    const {withdrawing} = this.props;
    if (!withdrawing) {
      this.props.handleSubmit(this.prepareToSubmit)(data);
    }
  }

  prepareToSubmit = (data) => {
    data.token = this.props.token;
    this.props.withdraw(data);
  }

  render() {
    const styles = require('./Withdraw.scss');
    const {fields: {money, email, realname}, invalid,
      user, withdrawing, withdrawError, withdrawSuccess} = this.props;
    return (
      <div className={styles.withdraw}>
        <DocumentMeta title="提款 - 蜂房"/>
        <Banner main="提款" right={<Link className={styles.ordersLink} to="/me/wallet/withdraws">提款记录</Link>}/>
          {withdrawSuccess ? <div className={styles.success}>
              <h2>提交提款成功！</h2>
              <p>预计5个工作日内到账！</p>
              <NormalButton onClick={this.props.confirmWithdraw}>
              OK
              </NormalButton>
            </div>
            :
            <form onSubmit={this.onSubmit}>
              <p>钱包余额：¥{user.money}</p>
              <TextInput type="number" label="金额" placeholder="请输入提款金额" serverError={(withdrawError && withdrawError.errorCode === 'money') ? withdrawError.message : null} {...money} />
              <TextInput type="text" label="支付宝" placeholder="请输入支付宝账户" serverError={(withdrawError && withdrawError.errorCode === 'email') ? withdrawError.message : null} {...email} />
              <TextInput type="text" label="姓名" placeholder="请输入对应支付宝的姓名以确保提款安全" serverError={(withdrawError && withdrawError.errorCode === 'realname') ? withdrawError.message : null} {...realname} />
              <p className={styles.subtle}>10元及以上可以提款<br/>预计5个工作日内到账</p>
              <NormalButton type="submit" disabled={invalid}>
                {
                  withdrawing ? <Spinner/>
                  : <span>提款</span>
                }
              </NormalButton>
              {withdrawError && !withdrawError.errorCode && <div className={styles.error}>
                <p>{withdrawError.message || '网络错误，请稍候重试'}</p>
              </div>}
            </form>
          }
      </div>
    );
  }
}
