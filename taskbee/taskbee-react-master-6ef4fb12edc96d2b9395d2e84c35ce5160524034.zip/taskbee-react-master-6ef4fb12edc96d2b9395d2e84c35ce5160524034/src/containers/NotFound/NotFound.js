import React, {Component, PropTypes} from 'react';
import {Banner, NormalButton} from 'components';

export default class NotFound extends Component {
  static propTypes = {
    history: PropTypes.object.isRequired,
  }
  onGoHomeClick = () => {
    this.props.history.replaceState(null, '/');
  }
  render() {
    const styles = require('./NotFound.scss');
    return (
      <div className={styles.notFound}>
        <Banner main="走错了"/>
        <h1>这里什么都没有~</h1>
        <p>奇怪，作为一个应用，不该有404的页面</p>
        <p>可能，你需要发个任务压压惊</p>
        <NormalButton onClick={this.onGoHomeClick}>
          进入首页
        </NormalButton>
      </div>
    );
  }
}
