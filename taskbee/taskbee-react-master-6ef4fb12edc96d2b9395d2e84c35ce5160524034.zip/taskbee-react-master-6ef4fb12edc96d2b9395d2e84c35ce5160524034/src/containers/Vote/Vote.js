import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import { Banner, NormalButton, LongTextInput, Spinner} from 'components';
import DocumentMeta from 'react-document-meta';
import connectData from 'helpers/connectData';
import {loadDetail, vote} from 'redux/modules/task';
import Rating from 'belle/lib/components/Rating';
import {reduxForm} from 'redux-form';
function fetchDataDeferred(getState, dispatch, location, params) {
  const {taskId} = params;
  if (!getState().task[taskId]) return dispatch(loadDetail({taskId}));
}

@connectData(null, fetchDataDeferred)
@connect(state => {
  const taskId = state.router.params.taskId;
  return {
    taskId,
    task: state.task[taskId] || {},
    meId: state.user.meId,
    token: state.user.token,
  };
},
{vote})
@reduxForm({
  form: 'user',
  fields: ['score', 'message'],
  initialValues: {
    score: 3,
    message: '',
  }
})

export default class MyAccount extends Component {
  static propTypes = {
    loading: PropTypes.bool,
    loadError: PropTypes.any,
    task: PropTypes.object,
    meId: PropTypes.string,
    fields: PropTypes.object.isRequired,
    vote: PropTypes.func.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    taskId: PropTypes.string.isRequired,
    token: PropTypes.string.isRequired,
    history: PropTypes.object.isRequired,
  }

  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去
    if (this.props.task.voting && !nextProps.task.voting && !nextProps.task.voteError) {
      this.props.history.goBack();
    }
  }

  onVoteSubmit = (data) => {
    if (!this.props.task.voting) {
      this.props.handleSubmit(this.processVoteSubmit)(data);
    }
  }

  onKeyEnter = () => {
    if (event.keyCode === 13) {
      event.preventDefault();
      this.onVoteSubmit();
    }
  }

  processVoteSubmit = (data) => {
    const {token, meId, taskId} = this.props;
    this.props.vote({
      token,
      meId,
      taskId,
      ...data
    });
  }

  render() {
    const styles = require('./Vote.scss');
    const {meId, task, fields: {score, message}} = this.props;
    const {canVote, voting, voteError} = task;
    const votable = canVote && canVote.indexOf(meId) > -1;
    const mutateScore = score.value - 3 || 0;
    return (
      <div className={styles.vote}>
        <Banner main="评价"/>
        <DocumentMeta title="评价- 蜂房"/>
        {
          votable ?
          <form className={styles.voteForm} onSubmit={this.onVoteSubmit}>
            <div className={styles.rating}>
              <div className={styles.score}>{'蜂蜜' + (mutateScore < 0 ? mutateScore : '+' + mutateScore)}</div>
              <Rating {...score}/>
            </div>
            <LongTextInput {...message} onKeyDown={this.onKeyEnter} maxCount={280} rows={6} placeholder="（可选）输入对对方的评价，让更多人更好的了解TA"/>
            {
              voteError && <div className={styles.error}>
                <p>{voteError.message || '网络错误，请稍候重试'}</p>
              </div>
            }
            <NormalButton>{voting ? <Spinner/> : '提交评价'}</NormalButton>
          </form>
          :
          <div className={styles.error}>不能评价，请退回重试</div>
        }
      </div>
    );
  }
}
