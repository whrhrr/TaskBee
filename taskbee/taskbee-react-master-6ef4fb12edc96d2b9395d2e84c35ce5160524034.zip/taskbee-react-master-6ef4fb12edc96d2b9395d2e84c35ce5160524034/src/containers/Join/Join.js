import React, {Component} from 'react';
import DocumentMeta from 'react-document-meta';
import { Banner, ReplaceLink } from 'components';
// import { Link } from 'react-router';

export default class Join extends Component {
  render() {
    const styles = require('./Join.scss');
    const logo = require('../../../static/logo.png');
    return (
      <div>
        <Banner main="欢迎回来"/>
        <div className={styles.join}>
          <DocumentMeta title="加入蜂房"/>
          <img src={logo}/>
          <h1>蜂房</h1>
          <h2>名校技能经验分享平台</h2>
          <p>共享技能•解决困难•结识好友</p>
          <div className={styles.control}>
            <ReplaceLink to="/login">登录</ReplaceLink>
            <ReplaceLink to="/reg">注册</ReplaceLink>
          </div>
        </div>
      </div>
    );
  }
}
