import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from 'utils/userValidation';
import DocumentMeta from 'react-document-meta';
import {register} from 'redux/modules/user';
import { Banner, VerifyForm, SubtleButtons, NormalButton, TextInput, PasswordInput, SelectInput, Spinner } from 'components';
import Autosuggest from 'react-autosuggest';

import ApiClient from 'helpers/ApiClient';

function getCookie(name) {
  const value = '; ' + document.cookie;
  const parts = value.split('; ' + name + '=');
  if (parts.length === 2) return parts.pop().split(';').shift();
}

const client = new ApiClient();

const initialSchools = [
  {
    name: '同济大学',
  }, {
    name: '上海交通大学',
  }, {
    name: '复旦大学',
  }, {
    name: '上海财经大学',
  }, {
    name: '上海外国语大学',
  }, {
    name: '华东师大',
  },
];

function getSuggestionValue(suggestion) {
  return suggestion.name;
}

function renderSuggestion(suggestion) {
  return (
    <span>{suggestion.name}</span>
  );
}


@reduxForm({
  form: 'user',
  fields: ['username', 'password', 'code'],
  validate: userValidation,
})
@connect(
  state => ({
    phone: state.verify.phone,
    verifyToken: state.verify.verifyToken,
    registering: state.user.registering,
    registerError: state.user.registerError,
  }),
  {register})
export default class Register extends Component {
  static propTypes = {
    registering: PropTypes.bool,
    registerError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    register: PropTypes.func.isRequired,
    verifyToken: PropTypes.string,
    phone: PropTypes.string,
    initializeForm: PropTypes.func.isRequired,
  }

  state = {
    gender: '0',
    suggestions: initialSchools,
    school: '',
  } // , school: '0'

  componentWillReceiveProps(nextProps) {
    if (__CLIENT__ && nextProps.verifyToken && !this.props.verifyToken) {
      setTimeout(() => {
        const ref = getCookie('ref');
        if (ref) {
          this.props.initializeForm({
            code: ref,
          });
        }
      }, 80);
    }
  }

  onSubmit = (event) => {
    event.preventDefault();
    const {registering, fields, valid, verifyToken} = this.props;
    if (!registering && valid) {
      this.props.register({
        username: fields.username.value,
        password: fields.password.value,
        gender: this.state.gender,
        school: this.state.school,
        code: fields.code.value,
        // schoolId: this.state.school,
        verifyToken,
      });
    }
  }

  onGenderChange = (event) => {
    this.setState({gender: event.target.value});
  }

  onSchoolChange = (event, { newValue }) => {
    this.setState({school: newValue});
  }

  onSuggestionsUpdateRequested = ({ value }) => {
    client.get('/misc/school', {
      params: {school: value},
    }).then((result) => {
      this.setState({suggestions: result.data});
    });
  }

  render() {
    // 使用login的样式
    const styles = require('../Login/Login.scss');
    const theme = require('./Theme.scss');
    const {
      verifyToken,
      registering,
      fields: {username, password, code},
      valid,
      registerError,
      phone,
    } = this.props;
    const inputProps = {
      placeholder: '请输入或选择学校',
      value: this.state.school,
      onChange: this.onSchoolChange,
    };
    const schoolError = (registerError && registerError.errorCode === 'school') ? registerError.message : null;
    return (
      <div className={styles.login}>
        <DocumentMeta title="注册 - 蜂房"/>
        <Banner main="注册"/>
        {
          verifyToken ?
          <form onSubmit={this.onSubmit}>
            {registerError && (!registerError.errorCode || typeof registerError.errorCode === 'number') && <div className={styles.extraError}>{registerError.message || '网络错误，请稍候重试'}</div>}
            <p className={styles.subtleInfo}>正在注册手机号: {phone}</p>
            <TextInput type="text" label="昵称" placeholder="请输入昵称(2-10位，未来不可变)" serverError={(registerError && registerError.errorCode === 'username') ? registerError.message : null} {...username}/>
            <PasswordInput label="密码" placeholder="请输入密码(8-60位)" serverError={(registerError && registerError.errorCode === 'password') ? registerError.message : null} {...password}/>
            <SelectInput label="性别" onChange={this.onGenderChange} value={this.state.gender} serverError={(registerError && registerError.errorCode === 'gender') ? registerError.message : null}>
              <option value="0">男</option>
              <option value="1">女</option>
            </SelectInput>
            <div className={styles.textInput}>
              <label>学校</label>
              <Autosuggest
                theme={theme}
                suggestions={this.state.suggestions}
                onSuggestionsUpdateRequested={this.onSuggestionsUpdateRequested}
                getSuggestionValue={getSuggestionValue}
                renderSuggestion={renderSuggestion}
                inputProps={inputProps}
              />
              {schoolError && <div className={styles.errorMsg}>{schoolError}</div>}
            </div>
            <TextInput type="text" label="邀请码" placeholder="（选填）可获得积分奖励" serverError={(registerError && registerError.errorCode === 'code') ? registerError.message : null} {...code}/>

            <div className={styles.cta}>
              <NormalButton type="submit" disabled={!valid}>
                {registering ? <Spinner/> : '注册'}
              </NormalButton>
            </div>
          </form>
          :
          <div>
            <SubtleButtons rightText="登录" rightTo="/login"/>
            <VerifyForm />
          </div>
        }
      </div>
    );
  }
}
