import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import DocumentMeta from 'react-document-meta';
import { isLoaded as isAuthLoaded, load as loadAuth } from 'redux/modules/user';
import { load, loadSuccess, loadFail } from 'redux/modules/lbs';
import { windowHeight } from 'redux/modules/misc';
import { pushState } from 'redux-router';
import config from '../../config';
import connectData from 'helpers/connectData';
import {throttle} from 'utils/componentEvents';
import {UserGuide} from 'containers';

function fetchData(getState, dispatch) { /* eslint no-unused-vars: 0 */
  const promises = [];
  if (!isAuthLoaded(getState())) {
    promises.push(dispatch(loadAuth()));
  }
  return Promise.all(promises);
}

@connectData(fetchData)
@connect(
  state => ({
    token: state.user.token,
    lastLocation: state.misc.lastLocation,
  }),
  {pushState, windowHeight, load, loadSuccess, loadFail})
export default class App extends Component {
  static propTypes = {
    children: PropTypes.object.isRequired,
    token: PropTypes.string,
    pushState: PropTypes.func.isRequired,
    windowHeight: PropTypes.func.isRequired,
    load: PropTypes.func.isRequired,
    loadSuccess: PropTypes.func.isRequired,
    loadFail: PropTypes.func.isRequired,
    history: PropTypes.object.isRequired,
    lastLocation: PropTypes.string,
  };

  static contextTypes = {
    store: PropTypes.object.isRequired
  };

  componentDidMount() {
    // 页面跳转发给ga，这里不用unmount了，因为app死也不会unmount
    this.props.history.listenBefore((location) => {
      if (window.ga) window.ga('set', 'page', location.pathname);
    });
    this.props.windowHeight(window.innerHeight);
    window.addEventListener('resize', this.onResize);
    this.updateLocation();
    // setInterval(::this.updateLocation, 1000 * 60);
    navigator.geolocation.watchPosition(this.props.loadSuccess, this.props.loadFail, {
      enableHgihAccuracy: true,
      maximumAge: 60000
    });
  }

  componentWillReceiveProps(nextProps) {
    if (!this.props.token && nextProps.token) {
      // logged in
      let redirLocation;
      if (this.props.lastLocation && this.props.lastLocation.indexOf('/join') === -1 && this.props.lastLocation.indexOf('/login') === -1 && this.props.lastLocation.indexOf('/reg') === -1) {
        redirLocation = this.props.lastLocation;
      } else redirLocation = '/';
      this.props.pushState(null, redirLocation);
    } else if (this.props.token && !nextProps.token) {
      // logout
      this.props.pushState(null, '/');
    }
  }

  onResize = throttle(() => {
    this.props.windowHeight(window.innerHeight);
  }, 80);

  updateLocation() {
    this.props.load();
    navigator.geolocation.getCurrentPosition(this.props.loadSuccess, this.props.loadFail,
      {
        enableHgihAccuracy: true, // 避免googleapi错误
        maximumAge: 60000 * 2
      }
    );
  }

  render() {
    // const {user} = this.props;
    const styles = require('./App.scss');
    return (
      <div className={styles.app}>
        <DocumentMeta {...config.app}/>
        <div className={styles.appContent}>
          {this.props.children}
        </div>
      </div>
    );
  }
}
