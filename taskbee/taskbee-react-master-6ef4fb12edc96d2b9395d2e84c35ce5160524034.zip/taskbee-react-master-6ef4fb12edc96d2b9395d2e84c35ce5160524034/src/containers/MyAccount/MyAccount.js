import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import { Avatar, Banner, LineButton, NormalButton, Modal } from 'components';
import DocumentMeta from 'react-document-meta';
import { pushState } from 'redux-router';
import {gender, } from 'utils/dataMap'; // schoolMap
import {logout, upload} from 'redux/modules/user';

@connect(
  state => ({
    // token: state.user.token,
    user: state.user[state.user.meId] || {},
    loggingOut: state.user.loggingOut,
    logoutError: state.user.logoutError,
    uploading: state.user.uploading,
    uploadError: state.user.uploadError,
    token: state.user.token
  }),
  {pushState, logout, upload}
)
export default class MyAccount extends Component {
  static propTypes = {
    user: PropTypes.object,
    pushState: PropTypes.func.isRequired,
    logout: PropTypes.func.isRequired,
    loggingOut: PropTypes.bool,
    logoutError: PropTypes.any,
    upload: PropTypes.func.isRequired,
    uploading: PropTypes.bool,
    uploadError: PropTypes.any,
    token: PropTypes.string,
    history: PropTypes.object.isRequired,
    // token: PropTypes.string,
  }
  state = {
    logoutOpen: false
  }

  onLineClick = (url) => {
    return () => {
      this.props.pushState(null, url);
    };
  }

  onLogoutLineClick = () => {
    this.setState({logoutOpen: true});
  }

  onCloseClick = () => {
    this.setState({logoutOpen: false});
  }

  onLogOutClick = () => {
    if (!this.props.loggingOut) {
      this.props.logout(this.props.token);
    }
  }

  onUploadChange = (event) => {
    if (!this.props.uploading && event.target.files[0]) {
      this.props.upload({
        /*
        attach: [{
          name: 'avatar',
          path: event.target.files[0]
        }],
        */
        attach: event.target.files[0],
        token: this.props.token,
      });
    }
  }

  render() {
    const styles = require('./MyAccount.scss');
    const {user, loggingOut, logoutError, uploading, uploadError} = this.props;

    return (
      <div className={styles.myAccount}>
        <Banner main="我的信息" />
        <DocumentMeta title="我的信息"/>
        <div className={styles.info}>
          <label htmlFor="upload" disabled={uploading}>
            <div className={styles.image}>
              <Avatar src={user.avatar} size={60}/>
              {uploading && <div className={styles.uploading}>上传中</div>}
            </div>
            {uploadError && <p className={styles.modalError}>{uploadError.message || '网络错误，请稍候重试'}</p>}
          </label>
          <input className={styles.fileInput} id="upload" type="file" accept="image/*" onChange={this.onUploadChange}/>
          <h3>{user.username}</h3>
          <p>{user.phone}</p>
        </div>
        <div className={styles.controlls}>
          <LineButton label="个人评价" content={<div className="icon-right-open-big"></div>} onClick={this.onLineClick('/users/' + user._id)}/>
          <LineButton label="个性签名" content={user.signature || '暂无签名'} onClick={this.onLineClick('/me/info/sign')}/>
          <LineButton label="真实姓名" content={user.realname || '匿名'} onClick={this.onLineClick('/me/info/name')}/>
          <LineButton label="性别" content={gender[user.gender]} onClick={this.onLineClick('/me/info/gender')}/>
          {/* <LineButton label="校区" content={schoolMap[user.schoolId]} onClick={this.onLineClick('/me/info/school')} /> */}
          <LineButton label="修改密码" content={<div className="icon-right-open-big"></div>} onClick={this.onLineClick('/forget')}/>
          <LineButton label="退出登录" content={<div className="icon-right-open-big"></div>} onClick={this.onLogoutLineClick}/>
        </div>
        <Modal isOpen={this.state.logoutOpen} closeTimeoutMS={200} onRequestClose={this.onCloseClick}>
          <div className={styles.modal}>
            <div className={styles.modalInfo}>
              <h3>退出登录</h3>
              <p>真的要退出登录了吗？</p>
              {logoutError && <p className={styles.modalError}>{logoutError.message || '网络错误，请稍候重试'}</p>}
            </div>
            <div className={styles.controls}>
              <NormalButton onClick={this.onCloseClick}>取消</NormalButton>
              <NormalButton onClick={this.onLogOutClick}>{loggingOut ? '正在登出' : '登出'}</NormalButton>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}
