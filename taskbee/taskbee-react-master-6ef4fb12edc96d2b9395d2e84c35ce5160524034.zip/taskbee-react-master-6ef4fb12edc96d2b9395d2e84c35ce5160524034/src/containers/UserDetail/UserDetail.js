import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import { Avatar, ImageViewer, Spinner, Banner, Gender, LoadingIndicator, NormalButton, VoteItem} from 'components';
import DocumentMeta from 'react-document-meta';
import connectData from 'helpers/connectData';
import {loadUserDetail, like, unfriend} from 'redux/modules/user';
import Rating from 'belle/lib/components/Rating';
import {requireLogin} from 'utils/componentEvents';

// import {schoolMap} from 'utils/dataMap';

function fetchDataDeferred(getState, dispatch, location, params) {
  const {userId} = params;
  return dispatch(loadUserDetail(userId));
}

@connectData(null, fetchDataDeferred)
@connect(
  state => {
    const {userId} = state.router.params;
    return {
      user: state.user[userId] || {},
      loading: state.user.loadingUser,
      loadError: state.user.loadUserError,
      token: state.user.token,
      meId: state.user.meId,
      userId,
    };
  },
  {loadUserDetail, like, unfriend}
)
export default class UserDetail extends Component {
  static propTypes = {
    user: PropTypes.object,
    loadUserDetail: PropTypes.func.isRequired,
    userId: PropTypes.string,
    loading: PropTypes.bool,
    loadError: PropTypes.any,
    history: PropTypes.object.isRequired,
    like: PropTypes.func.isRequired,
    unfriend: PropTypes.func.isRequired,
    token: PropTypes.string,
    meId: PropTypes.string,
  }

  state = {
    showImage: false,
  }

  onModalClose = () => {
    this.setState({showImage: false});
  }

  onImageClick = () => {
    this.setState({
      showImage: true,
    });
  }

  onRetryClick = () => {
    this.props.loadUserDetail(this.props.userId);
  }

  onLikeClick = () => {
    if (requireLogin.bind(this)() && !this.props.user.liking) { // 未感兴趣
      this.props.like({toLike: this.props.userId, token: this.props.token});
    }
  }

  onUnfriendClick = () => {
    if (requireLogin.bind(this)() && !this.props.user.unfriending) { // 未感兴趣
      this.props.unfriend({toUnfriend: this.props.userId, token: this.props.token});
    }
  }

  render() {
    const styles = require('./UserDetail.scss');
    const {meId, userId, history, user, loading, loadError} = this.props;
    let likeMessage;
    let favStyle = styles.fav;
    if (user.friended) {
      console.log(styles.friended);
      likeMessage = '已成为好友';
      favStyle += (' ' + styles.faved + ' ' + styles.friended);
      console.log(favStyle);
    } else if (user.liked) {
      likeMessage = '已感兴趣';
      favStyle += ' ' + styles.faved;
    } else {
      likeMessage = '未感兴趣';
    }
    return (
      <div className={styles.userDetail}>
        <Banner main={user.username ? user.username + '的个人信息' : '查看个人信息'}/>
        <DocumentMeta title={user.username ? user.username + ' - 蜂房' : '蜂房'}/>
        {
            loading && <div className={styles.loading}><LoadingIndicator/></div>
          }
          {
            loadError && <div className={styles.error}>
              <p>{loadError.message || '网络错误，请稍候重试'}</p>
              <NormalButton onClick={this.onRetryClick}>重试</NormalButton>
            </div>
        }
        {
          user.avatar ? <ImageViewer show={this.state.showImage} index={0} onRequestClose={this.onModalClose} images={[{key: user.avatar}]}/> : null
        }
        <div className={styles.info}>
          <div className={styles.image} onClick={this.onImageClick}>
            <Avatar src={user.avatar} size={60}/>
          </div>
          { user.accountType === 1 ? <span className={styles.confirmed}>活动认证</span> : null}
          { user.accountType === 2 ? <span className={styles.confirmed}>官方账号</span> : null}
          {/* <div className={styles.school}>来自{schoolMap[user.schoolId]}</div> */}
          <h3>{user.username}<Gender className={styles.gender} gender={user.gender} /></h3>
          <p className={styles.signature}>{user.signature || '暂无签名'}</p>
          {
            meId === userId ? null :
            <div className={styles.interest}>
              {
                user.friended ? <div className={styles.toUnfriend} onClick={this.onUnfriendClick}>
                  删除好友
                  {user.unfriending ? <Spinner/> : null}
                  {user.unfriendError ? <p>{user.unfriendError.message || '网络错误，请稍候重试'}</p> : null}
                </div> : null
              }
              <div className={favStyle} onClick={this.onLikeClick}></div>
               {likeMessage}
               {user.liking ? <Spinner/> : null}
               {user.likeError ? <p>{user.likeError.message || '网络错误，请稍候重试'}</p> : null}
            </div>
          }
        </div>
        <ul className={styles.misc}>
          <li>
            <p>{user.likedCount}</p>
            <span className={styles.title}>被感兴趣</span>
          </li>
          <li>
            <p>{user.countTotalTaken}</p>
            <span className={styles.title}>接手的任务</span>
          </li>
          <li>
            <p>{user.skills ? user.skills.length : 0}</p>
            <span className={styles.title}>发布的技能</span>
          </li>
          <li>
            <p>{user.score}</p>
            <span className={styles.title}>蜂蜜</span>
          </li>
        </ul>
        <div className={styles.vote}>
          <h3>评价</h3>
          {user.voteCount ? <Rating defaultValue={user.voteScore / user.voteCount} disabled/> : null}
          <div className={styles.votes}>
          {
            user.votes && user.votes.length ? user.votes.map( vote => <VoteItem key={vote._id} {...vote} pushState={history.pushState}/>)
            : <div className={styles.nothing}>尚无评价</div>
          }
          </div>
        </div>
      </div>
    );
  }
}
