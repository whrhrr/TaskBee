import React, { Component, PropTypes } from 'react';
import DocumentMeta from 'react-document-meta';
import { Banner, OrderItem, LoadingIndicator, NormalButton } from 'components';
import {connect} from 'react-redux';
import {loadOrderList} from 'redux/modules/order';
import connectData from 'helpers/connectData';


function fetchDataDeferred(getState, dispatch) {
  return dispatch(loadOrderList());
}

@connectData(null, fetchDataDeferred)
@connect(state => {
  return {
    orderList: state.order.orders,
    order: state.order,
    loading: state.order.loadingList,
    error: state.order.loadingListError,
  };
}, {loadOrderList})
export default class OrderList extends Component {
  static propTypes = {
    loadOrderList: PropTypes.func.isRequired,
    order: PropTypes.object.isRequired,
    orderList: PropTypes.array.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
    history: PropTypes.object.isRequired,
  }

  render() {
    const styles = require('./OrderList.scss');
    const {history, orderList, order, loading, error} = this.props;
    let content;
    let centerStyle = styles.center;
    if (!orderList || !orderList.length) {
      centerStyle = centerStyle + ' ' + styles.noOther;
    }
    if (loading) {
      content = <div className={centerStyle}><LoadingIndicator /></div>;
    } else if (error) {
      content = (<div className={centerStyle}>
      <h2>载入出错了</h2><p>{error.message || '网络错误，请稍候重试'}</p>
      <NormalButton onClick={this.props.loadOrderList}>重试</NormalButton>
      </div>);
    } else if (!orderList.length) {
      content = (<div className={centerStyle}>
        <h2 className={styles.subtle}>还没有充值订单</h2>
      </div>);
    } else {
      content = (<div className={centerStyle + ' ' + styles.action}>
        {orderList.map(orderId => {
          const orderItem = order[orderId];
          return <OrderItem key={orderItem._id} {...orderItem} pushState={history.pushState}/>;
        })}
      </div>);
    }
    return (
      <div className={styles.orderList}>
        <DocumentMeta title="订单记录 - 蜂房"/>
        <Banner main="订单记录" />
        {content}
      </div>
    );
  }
}
