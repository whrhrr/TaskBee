import React, { Component, PropTypes } from 'react';
import DocumentMeta from 'react-document-meta';
import { FriendItem, Banner } from 'components';
import {connect} from 'react-redux';
import {loadFriends} from 'redux/modules/user';
import connectData from 'helpers/connectData';

function fetchDataDeferred(getState, dispatch) {
  return dispatch(loadFriends());
}

@connectData(null, fetchDataDeferred)
@connect(state => {
  return {
    friends: state.user.friends,
    loading: state.user.loadingUser,
    error: state.user.loadingUserError,
  };
}, {loadFriends})
export default class Friends extends Component {
  static propTypes = {
    friends: PropTypes.array.isRequired,
    loadFriends: PropTypes.func.isRequired,
    history: PropTypes.object.isRequired,
  }

  componentDidMount() {
  }

  render() {
    const styles = require('./Friend.scss');
    const {friends} = this.props;
    return (
      <div className={styles.friends}>
        <DocumentMeta title="好友"/>
        <Banner main="好友"/>
        {
          friends.length ? friends.map((friend) => <FriendItem key={friend._id} {...friend}/>) :
          <div className={styles.notFound}>
            还没有好友，去给别人点赞吧～
          </div>
        }
      </div>
    );
  }
}
