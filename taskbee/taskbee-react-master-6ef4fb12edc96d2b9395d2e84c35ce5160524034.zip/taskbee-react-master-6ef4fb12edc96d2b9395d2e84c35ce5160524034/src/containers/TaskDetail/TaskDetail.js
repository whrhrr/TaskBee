import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import DocumentMeta from 'react-document-meta';
import { ShareButton, Mapbox, Avatar, ImageViewer, Carousel, LoadingIndicator, Banner, Spinner, Timeline, NormalButton, CommentInput, Comment, Gender, Modal, PullToAction } from 'components';
import connectData from 'helpers/connectData';
import {fav, unfav} from 'redux/modules/task';
import {onFavClick, requireLogin} from 'utils/componentEvents';
import {loadDetail, startComment, stopComment, take, confirmTasker, confirmPublisher, cancelPuber, cancelTasker} from 'redux/modules/task';
import {readyChat} from 'redux/modules/messages';
import {Link} from 'react-router';
import moment from 'moment';
import {calcCrow} from 'utils/dataProcessor';
import {Downloads} from 'components';

const publisherStateToButton = {
  0: '等待同学接单',
  1: '提前确认完成',
  2: '确认完成',
  3: '已完成\(￣▽￣)/',
  4: '已超时',
  5: '已取消'
};

const taskerStateToButton = {
  0: '我来接手',
  1: '确认完成',
  2: '等待发布者确认',
  3: '已完成，感谢你的付出！',
  4: '已超时',
  5: '已取消'
};

const normalStateToButton = {
  0: '我来接手',
  1: '已被接手，来晚了',
  2: '等待发布者确认',
  3: '已完成',
  4: '已超时',
  5: '已取消'
};

const stateToDescription = {
  0: '接手后，可以看到任务发布者的具体联系方式。接手任务后，请务必完成',
  1: '请确保已经完成了任务发布者的要求，确认后请让发布人确认，才能收到线上报酬',
  2: '在确认完成后，对方将收到您的报酬～',
};

function fetchDataDeferred(getState, dispatch, location, params) {
  const {taskId} = params;
  return dispatch(loadDetail({taskId}));
}

@connectData(null, fetchDataDeferred)
@connect(state => {
  const taskId = state.router.params.taskId;
  return {
    user: state.user[state.user.meId] || {},
    taskId,
    task: state.task[taskId] || {},
    meId: state.user.meId,
    token: state.user.token,
    long: state.lbs.longitude,
    lati: state.lbs.latitude,
    pathname: state.router.location.pathname,
  };
},
{readyChat, loadDetail, fav, unfav, startComment, stopComment, take, confirmTasker, confirmPublisher, cancelPuber, cancelTasker})
export default class TaskDetail extends Component {
  static propTypes = {
    user: PropTypes.object.isRequired,
    commentOpen: PropTypes.bool,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    startComment: PropTypes.func.isRequired,
    stopComment: PropTypes.func.isRequired,
    meId: PropTypes.string,
    task: PropTypes.object,
    dueTime: PropTypes.string,
    startTime: PropTypes.string,
    taskId: PropTypes.string,
    token: PropTypes.string,
    take: PropTypes.func.isRequired,
    confirmTasker: PropTypes.func.isRequired,
    confirmPublisher: PropTypes.func.isRequired,
    cancelTasker: PropTypes.func.isRequired,
    cancelPuber: PropTypes.func.isRequired,
    loadDetail: PropTypes.func.isRequired,
    readyChat: PropTypes.func.isRequired,
    history: PropTypes.object.isRequired,
    long: PropTypes.number.isRequired,
    lati: PropTypes.number.isRequired,
    pathname: PropTypes.string.isRequired,

  };

  state = {
    to: null,
    modalOpen: false,
    cancelOpen: false,
    showImage: false,
    showIndex: 0,
    mapOpen: false,
  }

  componentWillReceiveProps(nextProps) {
    // 评论成功后拉到页面底部
    if (!this.props.task.commentSuccess && nextProps.task.commentSuccess) {
      setTimeout(function scorllBottom() {window.scrollTo(0, 9999); }, 200);
    }
    if (this.props.task.ongoing && !nextProps.ongoing && !nextProps.task.goError) {
      this.setState({modalOpen: false});
    }
    if (this.props.task.cancelling && !nextProps.cancelling && !nextProps.task.cancelError) {
      this.setState({cancelOpen: false});
    }
  }

  onCommentClick = () => {
    if (requireLogin.bind(this)()) {
      this.props.startComment({taskId: this.props.taskId});
    }
  }

  onCommentClose = () => {
    this.props.stopComment({taskId: this.props.taskId});
    this.setState({
      to: null
    });
  }

  onCommentSelect = (from) => {
    return () => {
      if (this.props.token) {
        this.setState({
          to: {
            id: from._id,
            username: from.username
          }
        });
        this.props.startComment({taskId: this.props.taskId});
      }
    };
  }

  onComplexClick = () => {
    if (requireLogin.bind(this)()) {
      this.setState({modalOpen: true});
    }
  }

  onVoteClick = () => {
    this.props.history.pushState(null, '/vote/' + this.props.taskId);
  }

  onRealActionClick = () => {
    const {task: {_id: taskId, state, ongoing, tasker}, token, meId} = this.props;
    if (requireLogin.bind(this) && !ongoing) {
      if (state === 0) {
        this.props.take({taskId, meId, token});
      } else if (state === 1) {
        if (meId === tasker) this.props.confirmTasker({taskId, token});
        else this.props.confirmPublisher({taskId, token});
      } else if (state === 2) {
        this.props.confirmPublisher({taskId, token});
      }
    }
  }

  onCloseModalClick = () => {
    this.setState({modalOpen: false});
  }

  onCancelActionClick = () => {
    // cancel
    const {task: {_id: taskId, cancelling, tasker, publisher}, token, meId} = this.props;
    if (!cancelling) {
      if (tasker && tasker === meId) {
        this.props.cancelTasker({taskId, token});
      } else if (publisher._id === meId) {
        this.props.cancelPuber({taskId, token});
      }
    }
  }

  onCancelClick = () => {
    this.setState({cancelOpen: true});
  }

  onCloseCancelClick = () => {
    this.setState({cancelOpen: false});
  }

  onRetryClick = () => {
    this.props.loadDetail({taskId: this.props.taskId});
  }

  onChatClick = () => {
    // 私信接手人
    const {task} = this.props;
    if (task.tasker._id) {
      this.props.readyChat(task.tasker);
      this.props.history.pushState(null, '/chat/' + task.tasker._id);
    }
  }
  onChatPuberClick = () => {
    // 私信发布人
    const {task} = this.props;
    this.props.readyChat(task.publisher);
    this.props.history.pushState(null, '/chat/' + task.publisher._id);
  }

  onReload = () => {
    this.props.loadDetail({taskId: this.props.taskId, reload: true});
  }

  onBindedFavClick = onFavClick.bind(this)


  onModalClose = () => {
    this.setState({showImage: false});
  }

  onImageClick = (index) => {
    return (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.setState({
        showImage: true,
        showIndex: index,
      });
    };
  }

  onLocationClick = () => {
    this.setState({mapOpen: true});
  }

  onMapCloseClick = () => {
    this.setState({mapOpen: false});
  }

  render() {
    const styles = require('./TaskDetail.scss');
    const {long, lati, history, meId, user, task: rawTask} = this.props;
    const {type, loc, imgs, canVote, secret, cancelling, cancelError, ongoing, goError: error, commentOpen, comments, publisher = {}, tasker = {}, state, reward, favs, faved, _id: id, description, loadingDetail: loading, detailError, reloadingDetail: reloading, reloadDetailError: reloadError} = rawTask;
    const {avatar, username, signature, score, gender} = publisher;
    const dueTime = moment(rawTask.dueTime).format('MM/D HH:mm');
    const startTime = moment(rawTask.startTime).format('MM/D HH:mm');
    const {to} = this.state;
    let additional;
    let buttonText;
    let buttonDisabled;
    let canCancel;
    let cancelText;
    let cancelDescription;
    let voteEnabled;
    if (type === 1) {
      buttonDisabled = true;
    } else if (meId === publisher._id) {
      // 我是任务发布人
      voteEnabled = canVote && canVote.indexOf(meId) > -1;
      if ((state < 1 || state > 2) && !voteEnabled) {
        // 不能操作
        buttonDisabled = true;
      }
      if (state < 2) {
        // 可以取消
        canCancel = true;
        cancelText = '取消任务';
        cancelDescription = '如果任务已经有人接手，取消任务会减少蜂蜜，最好提前和任务进行人提前取得联系，是否要取消任务？';
      }
      buttonText = publisherStateToButton[state];
      if (state < 3 || tasker && tasker._id) {
        // 任务没有被取消，或者已经取消，但是有接单人
        additional = (<div className={styles.additional}>
        {
          tasker && tasker._id ? <div>
            <Link to={'/users/' + tasker._id}><Avatar src={tasker.avatar} size={60}/></Link>
            <p className={styles.user}>{tasker.username}<Gender className={styles.subtle} gender={tasker.gender}/></p>
            <p>{tasker.description || '暂无签名'}</p>
            <p>真实姓名：{tasker.realname || '匿名'}</p>
            { secret &&
              <div className={styles.secret}>
                {secret}
              </div>
            }
            <NormalButton onClick={this.onChatClick}>
              私信接手人
            </NormalButton>
          </div> :
          <div>
            <Avatar />
            <p className={styles.user}>等待同学接手</p>
            { secret &&
              <div className={styles.secret}>
                {secret}
              </div>
            }
          </div>
        }
      </div>);
      }
    } else if (meId === tasker) {
      // 我是任务接手人
      voteEnabled = canVote && canVote.indexOf(meId) > -1;
      if (state !== 1 && !voteEnabled) {
        buttonDisabled = true;
      }
      if (state < 2) {
        canCancel = true;
        cancelText = '放弃任务';
        cancelDescription = '中途放弃任务对于任务发布者是不小的麻烦，并且会降低蜂蜜，最好和任务发布者提前取得联系，进行通知，是否要放弃任务？';
      }
      buttonText = taskerStateToButton[state];
      additional = (<div className={styles.additional}>
        <Link to={'/users/' + publisher._id}><Avatar src={publisher.avatar} size={60}/></Link>
        <p className={styles.user}>{publisher.username}<Gender className={styles.subtle} gender={publisher.gender}/></p>
        <p>{publisher.description || '暂无签名'}</p>
        <p>真实姓名：{publisher.realname || '匿名'}</p>
        <p><a href={'tel:' + publisher.phone}>手机号：{publisher.phone}</a></p>
        { secret &&
              <div className={styles.secret}>
                {secret}
              </div>
        }
        <NormalButton onClick={this.onChatPuberClick}>
          私信发布人
        </NormalButton>
      </div>);
    } else {
      // 我是围观群众
      if (state !== 0) {
        buttonDisabled = true;
      }
      buttonText = normalStateToButton[state];
    }
    return (
      <div className={styles.taskDetail}>
        <DocumentMeta
         title={username + '的任务详情 - 蜂房'}
         description={`${username}: ${description}`}
        />
        <Banner main={type === 1 ? '活动详情' : '任务详情'} right={<ShareButton pathname={this.props.pathname}/>} />
        <Downloads/>
        {
          imgs && imgs.length ? <ImageViewer
             show={this.state.showImage}
             index={this.state.showIndex}
             onRequestClose={this.onModalClose}
             images={imgs} /> : null
        }
        <PullToAction normal={reloadError ? reloadError.message || reloadError : '下拉刷新'}
            pulled="释放刷新" working={<Spinner/>} doingWork={reloading}
            pullTrigger={40} elementHeight={55} onConfirm={this.onReload}>
          {
            loading && <div className={styles.loading}><LoadingIndicator/></div>
          }
          {
            detailError && <div className={styles.error}>
              <p>{detailError.message || '网络错误，请稍候重试'}</p>
              <NormalButton onClick={this.onRetryClick}>重试</NormalButton>
            </div>
          }
          {
              id && <div>
              {type === 1 ? null : <Timeline state={state}/>}
              {additional}
              {canCancel && <div className={styles.cancelTask} onClick={this.onCancelClick}>
                <span className={styles.cancelSpan}>{cancelText}</span>
              </div>}
              <div className={styles.info}>
                <div className={styles.description}>
                  <span className={styles.words}>{description}</span>
                  {loc && <span className={styles.distance} onClick={this.onLocationClick}>距离我{calcCrow(loc.coordinates, [long, lati]).toFixed(1)}米</span>}
                   {
                      imgs && imgs.length ? <Carousel className={styles.images} cellAlign="center">
                        {imgs.map((img, index) => <img onClick={this.onImageClick(index)} key={img.key} src={IMAGE_HOST + img.key + '?imageView2/2/h/420'}/>)}
                      </Carousel> : null
                   }
                  <div className={styles.fav + (faved ? ' ' + styles.faved : '')} onClick={this.onBindedFavClick(id, rawTask)}>
                    <span className={styles.favCount}>{favs}</span>
                  </div>
                </div>
                <ul className={styles.misc}>
                  <li>
                    <span className={styles.title}>开始时间</span>
                    <p>{startTime}</p>
                  </li>
                  <li>
                    <span className={styles.title}>截止时间</span>
                    <p>{dueTime}</p>
                  </li>
                  <li>
                    <span className={styles.title}>奖赏</span>
                    <p><span className={styles.yuan}>¥</span>{reward}</p>
                  </li>
                </ul>
              </div>
              <Link className={styles.publisher} to={'/users/' + publisher._id}>
                <Avatar src={avatar} size={42}/>
                <div className={styles.userInfo}>
                  <p>{username}<Gender gender={gender}/></p>
                  <p className={styles.signature}>{signature}</p>
                </div>
                <div className={styles.score}>
                  <p>蜂蜜</p>
                  <p>{score}</p>
                </div>
              </Link>
              <div className={styles.comments}>
                <h3>评论</h3>
                {
                  comments && comments.length ?
                  comments.map( (comment, index) => {
                    if (!comment.from) {
                      return <Comment key={index} {...comment} from={user} onCommentSelect={this.onCommentSelect} pushState={history.pushState}/>;
                    }
                    return <Comment key={index} {...comment} onCommentSelect={this.onCommentSelect} pushState={history.pushState}/>;
                  })
                  :
                  <p className={styles.empty}>暂时没有评论</p>
                }
              </div>
            </div>
          }
        </PullToAction>
        {
          commentOpen ? <div className={styles.controls}>
            <CommentInput onCommentClose={this.onCommentClose} taskId={id} to={to}/>
          </div>
          :
            id && <div className={styles.controls}>
            <NormalButton onClick={this.onCommentClick}>
            评论
            </NormalButton>
            {voteEnabled ? <NormalButton onClick={this.onVoteClick}>评价对方</NormalButton>
            :
            <NormalButton disabled={buttonDisabled} onClick={this.onComplexClick}>
              {buttonText}
            </NormalButton>
            }
          </div>
        }
        <Modal isOpen={!buttonDisabled && this.state.modalOpen} closeTimeoutMS={200} onRequestClose={this.onCloseModalClick}>
          <div className={styles.modal}>
            <div className={styles.modalInfo}>
              <h3 key="buttonText">{buttonText}</h3>
              <p key="show">{stateToDescription[state]}</p>
              {error && <p className={styles.modalError}>{error.message || '网络错误，请稍候重试'}</p>}
            </div>
            <div className={styles.modalControls}>
              <NormalButton onClick={this.onCloseModalClick}>取消</NormalButton>
              <NormalButton onClick={this.onRealActionClick}>{ongoing ? <Spinner/> : <span>{buttonText}</span>}</NormalButton>
            </div>
          </div>
        </Modal>

        <Modal isOpen={canCancel && this.state.cancelOpen} closeTimeoutMS={200} onRequestClose={this.onCloseCancelClick}>
          <div className={styles.modal}>
            <div className={styles.modalInfo}>
              <h3 key="buttonText">{cancelText + '!'}</h3>
              <p key="show">{cancelDescription}</p>
              {cancelError && <p className={styles.modalError}>{cancelError.message || '网络错误，请稍候重试'}</p>}
            </div>
            <div className={styles.modalControls}>
              <NormalButton onClick={this.onCloseCancelClick}>取消</NormalButton>
              <NormalButton onClick={this.onCancelActionClick}>{cancelling ? <Spinner/> : <span>{cancelText}</span>}</NormalButton>
            </div>
          </div>
        </Modal>

        <Modal isOpen={this.state.mapOpen} closeTimeoutMS={200} onRequestClose={this.onMapCloseClick}>
          {loc && <div className={styles.modal}>
            <div className={styles.mapContainer}>
              <Mapbox place={loc.coordinates}/>
            </div>
          </div>}
        </Modal>

      </div>
    );
  }
}
