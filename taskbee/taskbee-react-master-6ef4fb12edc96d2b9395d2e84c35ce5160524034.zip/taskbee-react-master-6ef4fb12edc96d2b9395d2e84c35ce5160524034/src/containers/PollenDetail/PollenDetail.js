import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import { Downloads, ShareButton, Avatar, ImageViewer, Carousel, Banner, LoadingIndicator, NormalButton, Gender, CommentInputPost as CommentInput, Comment} from 'components';
import DocumentMeta from 'react-document-meta';
import connectData from 'helpers/connectData';
import {loadPollen, startComment, stopComment} from 'redux/modules/pollen';

import {calcCrow} from 'utils/dataProcessor';
import {requireLogin} from 'utils/componentEvents';

function fetchDataDeferred(getState, dispatch, location, params) {
  const {postId} = params;
  return dispatch(loadPollen(postId));
}

@connectData(null, fetchDataDeferred)
@connect(
  state => {
    const {postId} = state.router.params;
    return {
      pollen: state.pollen[postId] || {},
      loading: state.pollen.loadingPollen,
      loadError: state.pollen.errorPollen,
      postId,
      long: state.lbs.longitude,
      lati: state.lbs.latitude,
      token: state.user.token,
      user: state.user[state.user.meId] || {},
      pathname: state.router.location.pathname,
    };
  },
  {loadPollen, startComment, stopComment}
)
export default class PollenDetail extends Component {
  static propTypes = {
    pollen: PropTypes.object,
    user: PropTypes.object,
    loadPollen: PropTypes.func.isRequired,
    startComment: PropTypes.func.isRequired,
    stopComment: PropTypes.func.isRequired,
    postId: PropTypes.string,
    loading: PropTypes.bool,
    loadError: PropTypes.any,
    history: PropTypes.object.isRequired,
    long: PropTypes.number.isRequired,
    lati: PropTypes.number.isRequired,
    pathname: PropTypes.string.isRequired,
  }

  state = {
    to: null,
    showImage: false,
    showIndex: 0,
    distanceOrig: undefined,
  }

  componentDidMount() {
    if (this.props.long && this.props.pollen.loc) {
      this.setState({ /* eslint react/no-did-mount-set-state: 0 */
        distanceOrig: calcCrow(this.props.pollen.loc.coordinates, [this.props.long, this.props.lati])
      });
    }
  }

  componentWillReceiveProps(nextxProps) {
    if (!this.props.pollen.loc && nextxProps.pollen.loc) {
      if (nextxProps.long) {
        this.setState({
          distanceOrig: calcCrow(nextxProps.pollen.loc.coordinates, [nextxProps.long, nextxProps.lati])
        });
      }
    }
  }

  onRetryClick = () => {
    this.props.loadPollen(this.props.postId);
  }

  onAvatarClick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    this.props.history.pushState(null, '/users/' + this.props.pollen.from._id);
  };

  onModalClose = () => {
    this.setState({showImage: false});
  }

  onImageClick = (index) => {
    return () => {
      this.setState({
        showImage: true,
        showIndex: index,
      });
    };
  }
  onCommentClick = () => {
    if (requireLogin.bind(this)()) {
      this.props.startComment({postId: this.props.postId});
    }
  }

  onCommentClose = () => {
    this.props.stopComment({postId: this.props.postId});
    this.setState({
      to: null
    });
  }
  onCommentSelect = (from) => {
    return () => {
      if (requireLogin.bind(this)()) {
        this.setState({
          to: {
            id: from._id,
            username: from.username
          }
        });
        this.props.startComment({postId: this.props.postId});
      }
    };
  }

  render() {
    const styles = require('./PollenDetail.scss');
    const { history, user, postId, pollen, loading, loadError} = this.props;
    const { commentOpen, imgs, comments, spreadCount, readerCount, content: description, from: {avatar, username, gender} = {} } = pollen;
    return (
      <div className={styles.pollenDetail}>
        <Banner main="花粉详情" right={<ShareButton pathname={this.props.pathname}/>}/>
        <Downloads />
        <DocumentMeta
          title={'匿名花粉详情 - 蜂房'}
          description={description}
        />
        {
          loading && <div className={styles.loading}><LoadingIndicator/></div>
        }
        {
          loadError && <div className={styles.error}>
            <p>{loadError.message || '网络错误，请稍候重试'}</p>
            <NormalButton onClick={this.onRetryClick}>重试</NormalButton>
          </div>
        }
        { pollen._id === postId ? <div className={styles.content}>
          <p onClick={this.onDetailClick}>{description}</p>
          {
            imgs && imgs.length ? <ImageViewer
             show={this.state.showImage}
             index={this.state.showIndex}
             onRequestClose={this.onModalClose}
             images={imgs} /> : null
          }
          {
            imgs && imgs.length ? <Carousel lassName={styles.images} cellAlign="center">
              {imgs.map((img, index) => <img onClick={this.onImageClick(index)} key={img.key} src={IMAGE_HOST + img.key + '?imageView2/0/w/500/h/400'}/>)}
            </Carousel> : null
          }
          <div className={styles.more}>
            <span>阅读{readerCount}</span>
            <span>传播{spreadCount}</span>
            <span>评论{comments ? comments.length : 0}</span>
          </div>
        </div> : !loading ? <div className={styles.error}>
            <p>找不到内容</p>
          </div> : null /* eslint no-nested-ternary: 0*/}
          <div className={styles.comments}>
            {comments && comments.length ? comments.map( (comment, index) => {
              if (!comment.from) {
                return <Comment key={index} {...comment} from={user} onCommentSelect={this.onCommentSelect} pushState={history.pushState}/>;
              }
              return <Comment key={index} {...comment} onCommentSelect={this.onCommentSelect} pushState={history.pushState}/>;
            }) : <h3 className={styles.noComment}>添上你的评论吧</h3>}
          </div>
          {
            commentOpen ? <div className={styles.controls}>
            <CommentInput onCommentClose={this.onCommentClose} postId={postId} to={this.state.to}/>
            </div>
            :
              description && <div className={styles.controls}>
                <NormalButton onClick={this.onCommentClick}>
                评论
                </NormalButton>
                <div className={styles.user}>
                  <Avatar src={avatar} size={26}/>
                  <div className={styles.username}>
                    <Gender gender={gender}/>
                  </div>
                  {this.state.distanceOrig !== undefined ? Math.floor(this.state.distanceOrig) + '米' : null}
                </div>
            </div>
          }
      </div>
    );
  }
}
