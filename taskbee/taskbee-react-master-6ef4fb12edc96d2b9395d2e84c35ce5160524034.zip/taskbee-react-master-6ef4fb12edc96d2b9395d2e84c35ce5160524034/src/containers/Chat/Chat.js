import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import DocumentMeta from 'react-document-meta';
import { Banner, Spinner, Message, Gender } from 'components';
import {send, read, getOneUser} from 'redux/modules/messages';
import connectData from 'helpers/connectData';


function fetchDataDeferred(getState, dispatch, location, params) {
  const {userId} = params;
  const user = getState().messages[userId];
  if (!user) return dispatch(getOneUser(userId));
}
@connectData(null, fetchDataDeferred)
@connect(state => {
  const userId = state.router.params.userId;
  return {
    user: state.messages[userId] || {},
    me: state.user[state.user.meId] || {},
    meId: state.user.meId,
    token: state.user.token,
    chatSubmitting: state.messages.submitting,
    error: state.messages.error,
    userId
  };
}, {send, read})
export default
class Chat extends Component {
  static propTypes = {
    user: PropTypes.object.isRequired,
    me: PropTypes.object.isRequired,
    token: PropTypes.string,
    meId: PropTypes.string,
    userId: PropTypes.string,
    chatSubmitting: PropTypes.bool,
    send: PropTypes.func.isRequired,
    read: PropTypes.func.isRequired,
    error: PropTypes.any,
    history: PropTypes.object.isRequired,
  };
  state = {
    value: '',
  }

  componentDidMount() {
    if (this.props.user._id) this.props.read(this.props.userId);
    window.scrollTo(0, 999999);
  }
  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去
    if (this.props.user.messages && this.props.user.messages.length < nextProps.user.messages.length) {
      setTimeout( function scrollDown() {window.scrollTo(0, 9999);}, 200);
    }
    if (this.props.chatSubmitting && !nextProps.chatSubmitting && !nextProps.error) {
      this.setState({value: ''});
    }
  }

  onInputChange = (event) => {
    this.setState({value: event.target.value});
  }

  onSubmit = (event) => {
    event.preventDefault();
    if (!this.props.chatSubmitting && this.props.user._id) {
      this.props.send({
        to: this.props.user._id,
        from: this.props.meId,
        message: this.state.value,
      });
    }

  }

  onAvatarClick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    this.props.history.pushState(null, '/users/' + this.props.user._id);
  }

  render() {
    const styles = require('./Chat.scss');
    const {error, me, meId, chatSubmitting, user: {messages = [], username, avatar, gender}} = this.props;
    return (
      <div className={styles.chat}>
        <DocumentMeta title="私信 - 蜂房"/>
        <Banner main={username ? <div className={styles.userBanner} onClick={this.onAvatarClick}>{username} <Gender gender={gender}/></div> : '找不到人啦～'} />
        {
          messages.length ?
          messages.map( (message, index) => {
            if (message.from === meId) {
              return <Message key={index} message={message.message} me avatar={me.avatar}/>;
            }
            return <Message key={index} message={message.message} avatar={avatar}/>;

          })
          :
          <div className={styles.nothing}>这里会显示你和对方的私信消息。消息为本地存储，最多存储50条消息。</div>
        }
        <form className={styles.controls} onSubmit={this.onSubmit}>
          {error && <div className={styles.errorMsg}>{error.message || error}</div>}
          <input autoComplete="off" autoFocus value={this.state.value} type="text" placeholder="输入消息" onChange={this.onInputChange}/>
          <button disabled={!username}>
          {
            chatSubmitting ? <Spinner/>
            :
            <span className="icon-paper-plane"></span>
          }
          </button>
        </form>
      </div>
    );
  }
}
