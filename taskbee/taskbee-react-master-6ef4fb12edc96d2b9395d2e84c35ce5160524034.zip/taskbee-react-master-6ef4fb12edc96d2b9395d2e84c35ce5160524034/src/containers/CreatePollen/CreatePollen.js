import React, { Component, PropTypes } from 'react';
import DocumentMeta from 'react-document-meta';
import {reduxForm} from 'redux-form';
import {connect} from 'react-redux';
// import connectData from 'helpers/connectData';
import { ImagePicker, Banner, LongTextInput, NormalButton, Spinner} from 'components'; // TagEditor
import {createPost as create, newPublishPost as newPublish} from 'redux/modules/publish'; // isTagLoaded, getTags
// import createValidation from './CreateValidation';
import {replaceState} from 'redux-router';
import {Link} from 'react-router';


// function fetchDataDeferred(getState, dispatch) { /* eslint no-unused-vars: 0 */
/*
  if (!isTagLoaded(getState())) {
    return dispatch(getTags());
  }
}
*/

// @connectData(null, fetchDataDeferred)
@reduxForm({
  form: 'create',
  fields: ['description', 'images'],
})
@connect(
  state => ({
    user: state.user[state.user.meId] || {},
    token: state.user.token,
    createError: state.publish.errorPost,
    success: state.publish.successPost,
    signed: state.publish.signed,
    creating: state.publish.creatingPost,
    long: state.lbs.longitude,
    lati: state.lbs.latitude,
  }), {replaceState, create, newPublish})
export default class Create extends Component {
  static propTypes = {
    creating: PropTypes.bool,
    registerError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    initializeForm: PropTypes.func.isRequired,
    create: PropTypes.func.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    newPublish: PropTypes.func.isRequired,
    replaceState: PropTypes.func.isRequired,
    token: PropTypes.string,
    createError: PropTypes.any,
    success: PropTypes.any,
    tmpTag: PropTypes.object,
    user: PropTypes.object.isRequired,
    long: PropTypes.number,
    lati: PropTypes.number,
    signed: PropTypes.bool,
  }

  componentDidMount() {
    this.props.initializeForm({
      description: '',
      images: [
        {src: '', path: null},
        {src: '', path: null},
        {src: '', path: null},
      ],
    });
  }

  onSubmitClick = (data) => {
    const {creating} = this.props;
    if (!creating) {
      this.props.handleSubmit(this.prepareToCreate)(data);
    }
  }

  onContinueClick = () => {
    this.props.initializeForm({
      description: '',
      images: [
        {src: '', path: null},
        {src: '', path: null},
        {src: '', path: null},
      ],
    });
    this.props.newPublish();
  }

  onGoToTaskClick = () => {
    // 进入/task
    this.props.replaceState(null, '/');
    this.props.newPublish();
    // 初始化
    // this.onContinueClick();
  }

  onSetImage = (index) => {
    return (data) => {
      const {images} = this.props.fields;
      // mutate 不知道是否可行
      images.value[index] = data;
      images.onBlur(images.value);
    };
  }

  prepareToCreate = (data) => {
    data.pos = [this.props.long, this.props.lati];
    data.token = this.props.token;
    data.images = data.images.map( item => item.path).filter(item => item !== null);
    this.props.create(data);
  }

  render() {
    const styles = require('../Create/Create.scss');
    const logo = require('../../../static/logo.png');
    const {signed, creating, success, createError, fields: {description, images}} = this.props;

    return (
      <div className={styles.create}>
        <DocumentMeta title="发布"/>
        <Banner main="发布花粉" right={<Link className={styles.createTask} to="/new">去发任务</Link>}/>
        {
          success ?
          <div className={styles.success}>
            <div className={styles.center}>
              <img src={logo}/>
              <h3>状态已散播</h3>
              { success.length ? success : null}
              { signed ? '又是崭新的一天，蜂蜜＋1' : null}
              <div className={styles.twoButton}>
                <NormalButton onClick={this.onGoToTaskClick}>
                  进入首页
                </NormalButton>
                <NormalButton onClick={this.onContinueClick}>
                  继续发布状态
                </NormalButton>
              </div>
            </div>
          </div>
          :
          <div>
            {createError && <p className={styles.errorMsg}>{createError.message || '网络错误，请稍候重试'}</p>}
            <div className={styles.images}>
              <label>传照片</label>
              {
                images.value && images.value.map( (data, index) => <ImagePicker key={index} index={index} src={data.src} onSetImage={this.onSetImage(index)}/>)
              }
            </div>

            <LongTextInput label="写一写"
             placeholder="不来吐槽一发？(至少一个字～）" rows="6" maxCount={280} {...description}/>
             <div className={styles.cta}>
              <NormalButton onClick={this.onSubmitClick}>
                {creating ? <Spinner/> : '发布'}
              </NormalButton>
            </div>
          </div>
        }

      </div>
    );
  }
}
