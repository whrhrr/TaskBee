import React, {Component, PropTypes} from 'react';
import {NormalButton, Modal, Carousel, Downloads} from 'components';

const THISID = 'guideGirl';

export default class UserGuide extends Component {
  static propTypes = {
    children: PropTypes.any,
    index: PropTypes.number,
  };

  state = {
    show: false,
  }

  componentDidMount() {
    const data = window.localStorage.getItem('guide');
    if (data !== THISID) {
      this.setState({show: true}); /* eslint react/no-did-mount-set-state: 0 */
    }
  }

  onRequestClose = () => {
    this.setState({show: false});
    window.localStorage.setItem('guide', THISID);
  }

  changeIndex(index) {
    setTimeout(() => {
      if (this.refs.carousel) {
        this.refs.carousel.goToSlide(index);
      }
    }, 10);
  }

  render() {
    const styles = require('./UserGuide.scss');
    const {show} = this.state;
    return (
      <Modal isOpen={show} className={styles.imageViewer} onRequestClose={this.onRequestClose}>
        <Carousel ref="carousel" className={styles.images} cellAlign="center">
          <div className={styles.card}>
            <h1>蜂房</h1>
            <h2>享受身边的精彩</h2>
            <Downloads/>
          </div>
          <div className={styles.card + ' ' + styles.blue}>
            <h1>蜂房+任务 = Friend</h1>
            <p>我们都是勤劳的taskbee。<br/>
              把你的需求发布到蜂房面对面任务，课程经验，考试指导，自习伙伴，运动健身，说不定还会有意料之外的收获哟！<br/>
            </p>
          </div>
          <div className={styles.card}>
            <h1>蜂房+花粉 = Free</h1>
            <p>自由得分享和吐槽！</p>
            <p>查看身边一定范围内的花粉消息</p>
            <p>乃是上课群聊，八卦吐槽，匿名表白，争做大V之利器是也～</p>
          </div>

          <div className={styles.card}>
            <h1>蜂房+你 更精彩！<br/>Fire your life！</h1>
            <NormalButton onClick={this.onRequestClose}>体验蜂房</NormalButton>
            <p>PS：新蜂房有特殊的加好友方式yooooo～～～</p>
          </div>
        </Carousel>
      </Modal>
    );
  }

}
