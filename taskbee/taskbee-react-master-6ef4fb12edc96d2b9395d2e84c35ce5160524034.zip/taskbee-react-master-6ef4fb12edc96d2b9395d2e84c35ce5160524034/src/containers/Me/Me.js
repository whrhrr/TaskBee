import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import { Downloads, Avatar, Banner, LineButton, Spinner, Ripple } from 'components'; // NormalButton
import {Link} from 'react-router';
import DocumentMeta from 'react-document-meta';
import {sign, getScore, isLoggedIn} from 'redux/modules/user';
import connectData from 'helpers/connectData';

function isToday(date) {
  const tmp = new Date(date);
  return tmp.setHours(0, 0, 0, 0) === (new Date()).setHours(0, 0, 0, 0);
}
// 读取任务  无视校区先
function fetchDataDeferred(getState, dispatch) {
  if (isLoggedIn(getState())) return dispatch(getScore());
}
@connectData(null, fetchDataDeferred)
@connect(
  state => ({
    user: state.user[state.user.meId],
    signing: state.user.signing,
    signError: state.user.signError,
    token: state.user.token,
  }), {sign}
)
export default class Me extends Component {
  static propTypes = {
    user: PropTypes.object,
    token: PropTypes.string,
    history: PropTypes.object.isRequired,
    signing: PropTypes.bool,
    signError: PropTypes.any,
    sign: PropTypes.func.isRequired,
  }

  onGoto = (path) => {
    return () => {
      this.props.history.pushState(null, path);
    };
  }

  onSignClick = () => {
    /*
    if (!this.props.signing) {
      this.props.sign(this.props.token);
    }
    */
  }

  onOpen = () => {
    window.open('http://hot.taskbee.cn');
  }

  render() {
    const styles = require('./Me.scss');
    const {user, signing, signError} = this.props;
    let signTime;
    let signCount;
    let signText;
    let alreadSigned;
    if (user) {
      signTime = user.signTime;
      signCount = user.signCount;
      alreadSigned = signTime && isToday(signTime);
      if (signing) {
        signText = <Spinner/>;
      } else if (alreadSigned) {
        signText = <div>今日已签到<span className={styles.signCount}>已连续签到<span className={styles.number}>{signCount}</span>天</span></div>;
      } else {
        signText = <div><span className="icon-heart"/> 每天第一条花粉，可增加1蜂蜜</div>;
      }
    }
    return (
      <div className={styles.me}>
        <Banner main="个人" left=""/>
        <DocumentMeta title="个人信息"/>
        {user ?
          <div className={styles.loggedIn}>
            {
              user.accountType > 0 ?
              <div className={styles.special}>
                <p className={styles.specialText}>蜂房的贵宾用户，您好！</p>
                <LineButton icon={<div className="icon-heart"/>} label="发布活动" content={<div className="icon-right-open-big"></div>} onClick={this.onGoto('/newEvent')}/>
              </div>
              : null
            }
            <Link to="/me/info" className={styles.userButton}>
                <div className={styles.avatar}>
                  <Avatar src={user.avatar} size={48}/>
                </div>
                <div className={styles.info}>
                  <h3>{user.username}</h3>
                  <p>{user.signature}</p>
                </div>
                <div className={styles.right}>
                  <div className="icon-right-open-big"></div>
                </div>
                <Ripple/>
            </Link>
            <LineButton icon={<div className="icon-food-ice-cream-streamline"/>} label="我的花粉" onClick={this.onGoto('/me/pollen')}/>
            <LineButton icon={<div className="icon-heart"/>} label="蜂蜜" content={user.score} onClick={this.onGoto('/me/score')}/>
            <LineButton icon={<div className="icon-vallet"></div>} label="钱包" content={'¥' + user.money} onClick={this.onGoto('/me/wallet')}/>
            <LineButton icon={<div className="icon-bulb"></div>} label={<span>提交反馈</span>} content={<div className="icon-right-open-big"></div>} onClick={this.onGoto('/feedback')}/>
            <LineButton icon={<div className="icon-study"/>} label="关于" content={<div className="icon-right-open-big"></div>} onClick={this.onGoto('/about')}/>
            <LineButton icon={<div className="icon-heart"/>} label="前往同济热脸" content={<div className="icon-right-open-big"></div>} onClick={this.onOpen}/>
            <div className={styles.sign}>
              <Link disabled={signing || alreadSigned} to="newM">
               {signText}
              </Link>
              {signError && !signError.errorCode && <div className={styles.extraError}>{signError.message || '网络错误，请稍候重试'}</div>}
            </div>
          </div>
          :
          <div className={styles.loggedOut}>
            <Link to="/join" className={styles.userButton}>
                <div className={styles.avatar}>
                  <Avatar/>
                </div>
                <div className={styles.info}>
                  <h3>还没有登录</h3>
                  <p>现在就去登录/注册</p>
                </div>
                <div className={styles.right}>
                  <div className="icon-right-open-big"></div>
                </div>
            </Link>
            <LineButton icon={<div className="icon-bulb"></div>} label="反馈" content={<div className="icon-right-open-big"></div>} onClick={this.onGoto('/feedback')}/>
            <LineButton icon={<div className="icon-study"/>} label="关于" content={<div className="icon-right-open-big"></div>} onClick={this.onGoto('/about')}/>
          </div>
        }
        <Downloads />
      </div>
    );
  }
}
