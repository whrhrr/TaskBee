import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from 'utils/userValidation';
import DocumentMeta from 'react-document-meta';
import {login} from 'redux/modules/user';
import { Banner, TextInput, PasswordInput, NormalButton, SubtleButtons, Spinner } from 'components';

@reduxForm({
  form: 'user',
  fields: ['phone', 'password'],
  validate: userValidation
})
@connect(
  state => ({
    loggingIn: state.user.loggingIn,
    loginError: state.user.loginError
  }),
  {login})
export default class Login extends Component {
  static propTypes = {
    loggingIn: PropTypes.bool,
    login: PropTypes.func.isRequired,
    loginError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    invalid: PropTypes.bool.isRequired,
    valid: PropTypes.bool.isRequired,
  }

  onSubmit = (event) => {
    event.preventDefault();
    const {loggingIn, valid} = this.props;
    if (!loggingIn && valid) {
      this.props.login({phone: this.props.fields.phone.value, password: this.props.fields.password.value});
    }
  }

  render() {
    const styles = require('./Login.scss');
    const {
        fields: {phone, password},
        loggingIn,
        valid,
        loginError
      } = this.props;
    return (
      <div className={styles.login}>
        <DocumentMeta title="登录 - 蜂房"/>
        <Banner main="登录"/>
        {loginError && !loginError.errorCode && <div className={styles.extraError}>{loginError.message || '网络错误，请稍候重试'}</div>}
        <SubtleButtons leftText="忘记密码" leftTo="/forget" rightText="注册账号" rightTo="/reg"/>
        <form onSubmit={this.onSubmit}>
          <TextInput type="number" label="手机号" placeholder="请输入注册时所用手机号" serverError={(loginError && loginError.errorCode === 'phone') ? loginError.message : null} {...phone} />
          <PasswordInput label="密码" placeholder="请输入密码" serverError={(loginError && loginError.errorCode === 'password') ? loginError.message : null} {...password} />
          <div className={styles.cta}>
            <NormalButton type="submit" disabled={!valid}>
              {loggingIn ? <Spinner/> : '登录'}
            </NormalButton>
          </div>
        </form>
      </div>
    );
  }
}
