import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import { Downloads, Avatar,
  Banner, Gender,
  ImageViewer,
  Carousel,
  NormalButton,
} from 'components';
import DocumentMeta from 'react-document-meta';
import connectData from 'helpers/connectData';
import Rating from 'belle/lib/components/Rating';
import { Link } from 'react-router';


import {
  loadDetail,
  loadReviews,
  fav,
  unfav,
  changeState,
} from 'redux/modules/skill';

// import {schoolMap} from 'utils/dataMap';

function fetchDataDeferred(getState, dispatch, location, params) {
  const {skillId} = params;
  return dispatch(loadDetail(skillId));
}

@connectData(null, fetchDataDeferred)
@connect(
   (state, props) => {
     const {skillId} = props.params;
     return {
       skillId,
       data: state.skill.getIn(['data', skillId]),
     };
   }, { loadDetail, loadReviews, fav, unfav, changeState}
)
export default class SkillDetail extends Component {
  static propTypes = {
    data: PropTypes.object.isRequired,
    skillId: PropTypes.string.isRequired,
    params: PropTypes.object.isRequired,
  }
  state = {
    showImage: false,
    showIndex: 0,
  }
  onImageClick = (index) => {
    return (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.setState({
        showImage: true,
        showIndex: index,
      });
    };
  }
  onModalClose = () => {
    this.setState({showImage: false});
  }

  onOpenClick() {
    window.location = 'http://a.app.qq.com/o/simple.jsp?pkgname=com.taskbee';
  }

  render() {
    const styles = require('./SkillDetail.scss');
    const {data} = this.props;
    const plainData = data ? data.toJS() : {};
    const {
      description,
      publisher = {},
      title,
      imgs,
      unit,
      price,
      requiredGender,
      averageScore,
      orders,
      favs,
      reviewCount,
      /*
      state,
      maxBook = 10,
      loadingDetail,
      detailError,
      tag, title, price = 0,
       canVote, _id,
      faved,
      loc,
      orders = 0,
      favs = 0,
      requiredGender = 2,
      averageScore,
      reviewCount,
      ordered,
      favBy,
      */
    } = plainData; // tags,

    const {avatar, realname, signature, gender} = publisher;

    return (
      <div className={styles.skillDetail}>
        {
          imgs && imgs.length ? <ImageViewer
            show={this.state.showImage}
            index={this.state.showIndex}
            onRequestClose={this.onModalClose}
            images={imgs} /> : null
        }
        <Banner main="老司机详情"/>
        <Downloads />
        <DocumentMeta
          title={title + ' | 老司机－校园大神聚集地 | 蜂房'}
          description={`${realname}: ${description}`}
        />
        <div className={styles.container}>
          <div className={styles.skillDescription}>
            <h2 className={styles.title}>{title}</h2>
            <Rating value={Math.round(averageScore)} disabled style={{ fontSize: 12, lineHeight: 1 }} />
            <span className={styles.reviewCount}>{reviewCount ? (reviewCount + '条评价') : '暂无评价'}</span>
            <div className={styles.info}>
              <span className={styles.misc}>
                预约<span className={styles.count}>{orders}</span>
              </span>
              <span className={styles.misc}>
                点赞<span className={styles.count}>{favs}</span>
              </span>
            </div>
            {
              imgs && imgs.length ? <Carousel className={styles.images} cellAlign="center" decorators={null}>
                {imgs.map((img, index) => <img onClick={this.onImageClick(index)} key={img.key} src={IMAGE_HOST + img.key + '?imageView2/2/h/420'}/>)}
              </Carousel> : null
            }
            <p className={styles.description}>{description}</p>


            <div className={styles.priceText}>¥{price}/{unit}</div>

          </div>
          <Link className={styles.publisher} to={'/users/' + publisher._id}>
            <Avatar src={avatar} size={42}/>
            <div className={styles.userInfo}>
              <p>{realname || '匿名'}<Gender gender={gender}/></p>
              <p className={styles.signature}>{signature || '暂无签名'}</p>
            </div>
          </Link>

        </div>

        <div className={styles.hint}>
          <h3>大神在蜂房应用内等候预约！</h3>
          <p>
            进入蜂房APP，参与讨论，预约大神，和大神直接聊！
            可不止这一位校园大牛，千万不要再错过了～
          </p>
          <NormalButton onClick={this.onOpenClick}>打开蜂房APP</NormalButton>
        </div>

      </div>
    );
  }
}
