import React, { Component, PropTypes } from 'react';
import { Banner, TextInput, LongTextInput, NormalButton, Spinner } from 'components';
import DocumentMeta from 'react-document-meta';
import {reduxForm} from 'redux-form';
import {connect} from 'react-redux';
import feedbackValidation from './FeedbackValidation';
import {feedbackAgain, feedback} from 'redux/modules/misc';

@reduxForm({
  form: 'misc',
  fields: ['email', 'feedback'],
  validate: feedbackValidation
})
@connect(
  state => ({
    feedbackError: state.misc.feedbackError,
    feedbackSuccess: state.misc.feedbackSuccess,
    feedbacking: state.misc.feedbacking,
  }),
  {feedbackAgain, feedback})
export default class Feedback extends Component {
  static propTypes = {
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    feedback: PropTypes.func.isRequired,
    feedbackAgain: PropTypes.func.isRequired,
    feedbacking: PropTypes.bool,
    feedbackSuccess: PropTypes.bool,
    feedbackError: PropTypes.any
  }

  onSubmitClick = (data) => {
    const {feedbacking} = this.props;
    if (!feedbacking) {
      this.props.handleSubmit(this.props.feedback)(data);
    }
  }

  onAgainClick = () => {
    this.props.feedbackAgain();
  }

  render() {
    const styles = require('./Feedback.scss');
    const {feedbackSuccess, feedbacking, feedbackError, fields: {email, feedback}} = this.props; /* eslint no-shadow: 0*/
    return (
      <div className={styles.feedback}>
        <DocumentMeta title="反馈 - 蜂房"/>
        <Banner main="反馈"/>
        <div className={styles.intro}>
          <span className="icon-bulb"></span>
        </div>
        <div className={styles.mainText}>
          任何意见建议都会对我们有非常大的帮助<br/>
          欢迎加蜂房QQ群：478227215
          {
            feedbackSuccess ? <div className={styles.success}>
              <h2>非常感谢您的反馈</h2>
              <p>我们会尽快研究，并和您取的联系</p>
              <NormalButton type="button" onClick={this.onAgainClick}>
                再提交个反馈
              </NormalButton>
            </div> :
            <form onSubmit={this.onSubmitClick}>
              {feedbackError && (!feedbackError.errorCode || typeof feedbackError.errorCode === 'number') && <div className={styles.extraError}>{feedbackError.message || '网络错误，请稍候重试'}</div>}
              <LongTextInput placeholder="请输入反馈" rows="10" maxCount={700} {...feedback} serverError={(feedbackError && feedbackError.errorCode === 'feedback') ? feedbackError.message : null}/>
              <TextInput label="邮箱" placeholder="若希望收到我们回复，请输入邮箱" {...email} serverError={(feedbackError && feedbackError.errorCode === 'email') ? feedbackError.message : null}/>
              <NormalButton type="submit">
                {feedbacking ? <Spinner/> : '提交反馈'}
              </NormalButton>

            </form>

          }
        </div>
      </div>
    );
  }
}
