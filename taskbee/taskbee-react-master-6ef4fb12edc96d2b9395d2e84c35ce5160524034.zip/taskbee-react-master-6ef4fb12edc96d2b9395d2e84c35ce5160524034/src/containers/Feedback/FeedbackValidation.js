import {createValidator, email, required, minLength, maxLength} from 'utils/validation';

const feedbackValidation = createValidator({
  feedback: [required, minLength(1), maxLength(1000)],
  email: [email],
});
export default feedbackValidation;
