import React, { Component, PropTypes } from 'react';
import { Banner, NormalButton, Spinner, BackButton, Ripple } from 'components';
import DocumentMeta from 'react-document-meta';
import {connect} from 'react-redux';
import {orderArray} from 'utils/dataMap';
import {createOrder} from 'redux/modules/order';
import {Link} from 'react-router';

@connect(
  state => ({
    user: state.user[state.user.meId],
    token: state.user.token,
    creating: state.order.creating,
    createError: state.order.createError,
    nextOrder: state.order.nextOrder,
  }), {createOrder}
)
export default class Wallet extends Component {
  static propTypes = {
    user: PropTypes.object,
    token: PropTypes.string,
    creating: PropTypes.bool,
    createError: PropTypes.any,
    createOrder: PropTypes.func.isRequired,
    history: PropTypes.object.isRequired,
  }

  state = {
    select: 1,
  }

  componentWillReceiveProps(nextProps) {
    // 成功之后进入到订单详情页面
    if (this.props.creating && !nextProps.creating && !nextProps.createError) {
      this.props.history.pushState(null, '/order/' + nextProps.nextOrder);
    }
  }

  onOrderClick = (ind) => {
    return () => {
      this.setState({select: ind});
    };
  }

  onCreateOrderClick = () => {
    const {creating, token} = this.props;
    if (!creating) {
      this.props.createOrder({
        orderId: this.state.select,
        token,
      });
    }
  }

  render() {
    const styles = require('./Wallet.scss');
    const {creating, createError, user} = this.props;
    const {select} = this.state;
    return (
      <div className={styles.wallet}>
        <DocumentMeta title="钱包 - 蜂房"/>
        <Banner left ={<BackButton forceLocation="/me"/>} main="钱包" right={<Link className={styles.ordersLink} to="/me/wallet/orders">
          订单记录
          <Ripple/>
        </Link>}/>
        <div className={styles.intro}>
          <div className={styles.img}>
            <span className="icon-vallet"></span>
          </div>
          <div className={styles.amount}>
            <Link className={styles.redpocket} to="/me/wallet/redpocket">红包</Link>
            <p>¥{user.money}</p>
            <Link className={styles.withdraw} to="/me/wallet/withdraw">提现</Link>
          </div>
        </div>
        <p className={styles.mainText}>
          钱包里的钱用来给同学支付报酬
        </p>
        <div className={styles.buy}>
          <h3>给钱包充{orderArray[select].price}元</h3>
          <ul>
            {orderArray.map((order, ind) => <li
             className={styles.offer + (ind === select ? ' ' + styles.active : '')}
             key={order.price} onClick={this.onOrderClick(ind)}>
                {order.price}元
                <Ripple/>
              </li>
            )}
          </ul>
          <NormalButton disabled onClick={this.onCreateOrderClick}>
          {
            creating ? <Spinner/>
            :
            <span><span className={styles.icon + ' icon-cn-alibabai-alipay'}/>抱歉，网页充值已关闭</span>
          }
          </NormalButton>
          {createError && <div className={styles.error}>
              <p>{createError.message || '网络错误，请稍候重试'}</p>
            </div>}
        </div>
      </div>
    );
  }
}
