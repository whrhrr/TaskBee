import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from 'utils/userValidation';
import DocumentMeta from 'react-document-meta';
import {setInfoValue} from 'redux/modules/form';
import { Banner, NormalButton, LongTextInput, SimpleRadios, Spinner, SchoolRadios } from 'components';
import {changeInfo} from 'redux/modules/user';

function getDisplayName(Comp) {
  return Comp.displayName || Comp.name || 'Component';
}
// 生成对应的修改个人信息页面
function factory({key, name, introduction, url, component, props}) {
  // 将异步获取数据移动到这里，以获取apiKey
  return DecoratedComponent =>
    @reduxForm({
      form: 'userInfo',
      fields: [key],
      validate: userValidation
    },
    state => ({
      initialValues: {
        [key]: state.user[state.user.meId][key]
      }
    }))
    @connect(
      state => {
        return ({
          changing: state.user.changing[key],
          error: state.user.changeError[key],
          token: state.user.token
        });
      },
      { setInfoValue, changeInfo })
    class RealChangeInfo extends Component {
      static propTypes = {
        setInfoValue: PropTypes.func.isRequired,
      }
      static displayName = `RealChangeInfo(${getDisplayName(DecoratedComponent)})`;
      static DecoratedComponent = DecoratedComponent;
      render() {
        return <DecoratedComponent name={name} actionKey={key} introduction={introduction} url={url} props={props} component={component} {...this.props}/>;
      }
    };
}

class ChangeInfo extends Component {
  static propTypes = {
    changing: PropTypes.bool,
    fields: PropTypes.object.isRequired,
    invalid: PropTypes.bool.isRequired,
    valid: PropTypes.bool.isRequired,
    name: PropTypes.string.isRequired,
    actionKey: PropTypes.string.isRequired,
    error: PropTypes.any,
    introduction: PropTypes.string,
    changeInfo: PropTypes.func.isRequired,
    url: PropTypes.string.isRequired,
    history: PropTypes.object.isRequired,
    token: PropTypes.string.isRequired,
    component: PropTypes.func.isRequired,
    props: PropTypes.object,
  }

  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去
    if (this.props.changing && !nextProps.changing && !nextProps.error) {
      this.props.history.goBack();
    }
  }

  onSubmit = () => {
    const {changing, actionKey, url, token} = this.props;
    if (!changing) {
      this.props.changeInfo({
        data: {[actionKey]: this.props.fields[actionKey].value},
        key: actionKey,
        url,
        token
      });
    }
  }

  onKeyEnter = (event) => {
    if (event.keyCode === 13) {
      event.preventDefault();
      this.onSubmit();
    }
  }

  render() {
    const styles = require('./ChangeInfos.scss');
    const {
        changing,
        valid,
        name,
        introduction,
        actionKey,
        error,
        props
      } = this.props;
    const CustomComp = this.props.component;
    const singleField = this.props.fields[actionKey];

    return (
      <div className={styles.changeInfo}>
        <DocumentMeta title={name}/>
        <Banner main={name}/>
        <form>
          {error && !error.errorCode && <div className={styles.extraError}>{error.message || '网络错误，请稍候重试'}</div>}
          <CustomComp autoFocus {...props} onKeyDown={this.onKeyEnter} serverError={error && error.errorCode === 'input' && error.message} {...singleField}/>
          <p className={styles.introduction}>{introduction}</p>
          <div className={styles.cta}>
            <NormalButton type="button" disabled={!valid} onClick={this.onSubmit}>
              {changing ? <Spinner/> : '提交'}
            </NormalButton>
          </div>
        </form>
      </div>
    );
  }
}

@factory({
  key: 'signature',
  name: '个性签名',
  introduction: '简单的签名能够让同学更好得了解你',
  url: '/user/changeSig',
  component: LongTextInput,
  props: {
    maxCount: 32,
    placeholder: '输入您的个性签名',
    rows: '3'
  }

})
export class ChangeSignature extends ChangeInfo {}

@factory({
  key: 'realname',
  name: '真实姓名',
  introduction: '输入真实姓名，方便任务发布者和接收者交流',
  url: '/user/changeName',
  component: LongTextInput,
  props: {
    maxCount: 10,
    placeholder: '输入您的真实姓名',
    row: '1'
  }
})
export class ChangeName extends ChangeInfo {}

@factory({
  key: 'gender',
  name: '性别',
  introduction: '',
  url: '/user/changeGender',
  component: SimpleRadios,
})
export class ChangeGender extends ChangeInfo {}

@factory({
  key: 'schoolId',
  name: '校区',
  introduction: '',
  url: '/user/changeSchool',
  component: SchoolRadios,
})
export class ChangeSchool extends ChangeInfo {}
