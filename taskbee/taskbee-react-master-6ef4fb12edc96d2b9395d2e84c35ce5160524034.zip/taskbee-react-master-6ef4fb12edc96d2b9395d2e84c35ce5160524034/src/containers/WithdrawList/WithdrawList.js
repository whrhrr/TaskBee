import React, { Component, PropTypes } from 'react';
import DocumentMeta from 'react-document-meta';
import { Banner, LoadingIndicator, NormalButton, WithdrawItem } from 'components';
import {connect} from 'react-redux';
import {loadWithdrawList} from 'redux/modules/order';
import connectData from 'helpers/connectData';


function fetchDataDeferred(getState, dispatch) {
  return dispatch(loadWithdrawList());
}

@connectData(null, fetchDataDeferred)
@connect(state => {
  return {
    orderList: state.order.withdraws,
    loading: state.order.loadWithdrawList,
    error: state.order.loadWithdrawListError,
  };
}, {loadWithdrawList})
export default class WithdrawList extends Component {
  static propTypes = {
    loadWithdrawList: PropTypes.func.isRequired,
    orderList: PropTypes.array.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
  }

  render() {
    const styles = require('./WithdrawList.scss');
    const {orderList, loading, error} = this.props;
    let content;
    let centerStyle = styles.center;
    if (!orderList || !orderList.length) {
      centerStyle = centerStyle + ' ' + styles.noOther;
    }
    if (loading) {
      content = <div className={centerStyle}><LoadingIndicator /></div>;
    } else if (error) {
      content = (<div className={centerStyle}>
      <h2>载入出错了</h2><p>{error.message || '网络错误，请稍候重试'}</p>
      <NormalButton onClick={this.props.loadWithdrawList}>重试</NormalButton>
      </div>);
    } else if (!orderList.length) {
      content = (<div className={centerStyle}>
        <h2 className={styles.subtle}>还没有提现记录</h2>
      </div>);
    } else {
      content = (<div className={centerStyle + ' ' + styles.action}>
        {orderList.map(orderItem => {
          return (<WithdrawItem key={orderItem._id} {...orderItem}/>);
        })}
      </div>);
    }
    return (
      <div className={styles.withdrawList}>
        <DocumentMeta title="提现记录 - 蜂房"/>
        <Banner main="提现记录" />
        {content}
      </div>
    );
  }
}
