import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import DocumentMeta from 'react-document-meta';
import { Link } from 'react-router';
import { Banner, LoadingIndicator, PostItemLite } from 'components';
import {getPollens} from 'redux/modules/user';
// import {fav, unfav} from 'redux/modules/task';
import {onFavClick, throttle} from '../../utils/componentEvents.js';
// import connectData from 'helpers/connectData';

@connect(
  state => {
    const meId = state.user.meId;
    return ({
      loading: state.user.gettingPollen,
      error: state.user.getPollenError,
      pollens: state.user.myPollens,
      token: state.user.token,
      noMore: state.user.noMorePollens,
      long: state.lbs.longitude,
      lati: state.lbs.latitude,
      meId,
    });
  },
  { getPollens })
export default class PollenList extends Component {
  static propTypes = {
    loading: PropTypes.bool,
    error: PropTypes.any,
    getPollens: PropTypes.func.isRequired,
    pollens: PropTypes.array.isRequired,
    noMore: PropTypes.bool,
    meId: PropTypes.string,
    history: PropTypes.object.isRequired,
    long: PropTypes.number,
    lati: PropTypes.number,
  };

  componentDidMount() {
    this.windowHeight = window.innerHeight;
    window.addEventListener('scroll', this.onScroll);
    window.addEventListener('resize', this.onResize);
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll);
    window.removeEventListener('resize', this.onResize);
  }

  onResize = throttle(() => {
    this.windowHeight = window.innerHeight;
  }, 200);

  onScroll = throttle(() => {
    if (!this.props.noMore) {
      if (!this.props.loading && window.pageYOffset + this.windowHeight > this.props.pollens.length * 145) { // 估算高度，不需要到底部就加载
        this.onReloadClick();
      }
    }
  }, 500);

  onReloadClick = () => {
    if (!this.props.loading) {
      const {pollens} = this.props;
      if (pollens.length) {
        this.props.getPollens(pollens[pollens.length - 1].createdAt);
      } else {
        this.props.getPollens();
      }
    }
  }

  onBindedFavClick = onFavClick.bind(this)

  static fetchDataDeferred(getState, dispatch) { return dispatch(getPollens(undefined, 10, true)); }

  render() {
    const styles = require('./PollenList.scss');
    const {history, meId, noMore, loading, pollens, error} = this.props;
    const myPos = [this.props.long, this.props.lati];
    let content;
    let centerStyle = styles.center;
    if (!pollens || !pollens.length) {
      centerStyle = centerStyle + ' ' + styles.noOther;
    }
    if (loading) {
      content = <div className={centerStyle}><LoadingIndicator /></div>;
    } else if (error) {
      content = (<div className={centerStyle}>
      <h2>载入出错了</h2><p>{error.message || error}</p></div>);
    } else if (noMore && pollens.length) {
      content = (<div className={centerStyle + ' ' + styles.action}>
          没有更多了
        </div>);
    } else if (!pollens.length) {
      content = (<div className={centerStyle}>
        <h2 className={styles.subtle}>还没有花粉</h2>
        <Link className={styles.button} to="/newM">去发布花粉</Link>
      </div>);
    } else {
      content = <div className={centerStyle + ' ' + styles.action} onClick={this.onReloadClick}>载入更多</div>;
    }

    return (
      <div className={styles.otherTasks}>
        <DocumentMeta title={'我的花粉'}/>
        <Banner main={'我的花粉'}/>
        {
          pollens && pollens.length && (<div className={styles.taskList}>
          {pollens.map( pollen => {
            return <PostItemLite key={pollen._id} {...pollen} meId={meId} myPos={myPos} pushState={history.pushState}/>;
          })}
        </div>)
        }
        {content}
      </div>
    );
  }
}
