import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';
import { Banner, LoadingIndicator, NormalButton, Ripple} from 'components';
import DocumentMeta from 'react-document-meta';
import connectData from 'helpers/connectData';
import {loadOrderDetail} from 'redux/modules/order';
import {orderStateMap} from 'utils/dataMap';

function fetchDataDeferred(getState, dispatch, location, params) {
  const {orderId} = params;
  return dispatch(loadOrderDetail(orderId));
}

@connectData(null, fetchDataDeferred)
@connect(
  state => {
    const {orderId} = state.router.params;
    return {
      order: state.order[orderId] || {},
      loading: state.order.loadingOrder,
      loadError: state.order.loadOrderError,
      orderId
    };
  },
  {loadOrderDetail}
)
export default class OrderDetail extends Component {
  static propTypes = {
    order: PropTypes.object,
    loadOrderDetail: PropTypes.func.isRequired,
    orderId: PropTypes.string,
    loading: PropTypes.bool,
    loadError: PropTypes.any,
  }
  onRetryClick = () => {
    this.props.loadOrderDetail(this.props.orderId);
  }
  render() {
    const styles = require('./OrderDetail.scss');
    const {order, loading, loadError} = this.props;

    return (
      <div className={styles.orderDetail}>
        <Banner main={order.title ? order.title : '查看订单详情'}/>
        <DocumentMeta title={order.title ? order.title + '- 蜂房' : '蜂房'}/>
        {
          loading && <div className={styles.loading}><LoadingIndicator/></div>
        }
        {
          loadError && <div className={styles.error}>
            <p>{loadError.message || '网络错误，请稍候重试'}</p>
            <NormalButton onClick={this.onRetryClick}>重试</NormalButton>
          </div>
        }
        {
          order.title ? <div className={styles.info}>
            <h2>{order.title}</h2>
            <p className={styles.price}>¥{order.price}</p>
            <p className={styles.status}>状态: {orderStateMap[order.state]}</p>
            {order.link && <a className={styles.pay} href={order.link}>
              <span className={styles.icon + ' icon-cn-alibabai-alipay'}/>去支付宝付款
              <Ripple/>
            </a>}
            {order.link && <div className={styles.disclaimer}>
              <h3>注意事项</h3>
              <p>由于蜂房团队目前没有成立公司，我门使用的是支付宝的担保交易接口，
              收款方为蜂房的团队账户：<b>姚天宇</b>(蜂房团队创建人)。我们对每一笔订单进行记录，
              并由蜂房顶尖的技术团队以及同济大学坚实的后盾保障资金安全。<br/>
              由于支付宝的限制，点击付款后将会跳转到支付宝的付款网页。在手机上体验会较差，我们对此深表歉意。
              </p>
            </div>}

          </div> :
          <div className={styles.info}>
            <p className={styles.status}>无法找到订单</p>
          </div>
        }

      </div>
    );
  }
}
