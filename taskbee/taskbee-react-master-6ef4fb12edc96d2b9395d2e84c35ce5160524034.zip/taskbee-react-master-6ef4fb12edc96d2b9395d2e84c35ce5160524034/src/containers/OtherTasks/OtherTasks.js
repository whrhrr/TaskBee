import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import DocumentMeta from 'react-document-meta';
import { Link } from 'react-router';
import { Banner, LoadingIndicator, TaskItem } from 'components';
import {getTasksFav, getTasksHistory} from 'redux/modules/user';
import {fav, unfav} from 'redux/modules/task';
import {onFavClick, throttle} from '../../utils/componentEvents.js';
// import connectData from 'helpers/connectData';

function getDisplayName(Comp) {
  return Comp.displayName || Comp.name || 'Component';
}
// 生成对应的修改个人信息页面
function factory({loadingKey, errorKey, taskKey, load, name, noMoreKey}) {
  // 将异步获取数据移动到这里，以获取apiKey
  return DecoratedComponent =>
    // @connectData(function fetchDataDeferred(getState, dispatch) { return dispatch(load); })
    @connect(
      state => {
        const meId = state.user.meId;
        return ({
          loading: state.user[loadingKey],
          error: state.user[errorKey],
          briefTasks: state.task,
          tasks: state.user[meId][taskKey] ? state.user[meId][taskKey] : [],
          token: state.user.token,
          noMore: state.user[meId] ? state.user[meId][noMoreKey] : false,
          meId,
        });
      },
      { load, fav, unfav })
    class RealOtherTasks extends Component {
      static displayName = `${name}(${getDisplayName(DecoratedComponent)})`;
      static fetchDataDeferred(getState, dispatch) { return dispatch(load()); }
      static DecoratedComponent = DecoratedComponent;
      render() {
        return <DecoratedComponent name={name} {...this.props}/>;
      }
    };
}

class OtherTasks extends Component {
  static propTypes = {
    tasks: PropTypes.array.isRequired,
    loading: PropTypes.bool,
    error: PropTypes.any,
    name: PropTypes.string.isRequired,
    load: PropTypes.func.isRequired,
    fav: PropTypes.func.isRequired,
    unfav: PropTypes.func.isRequired,
    briefTasks: PropTypes.object.isRequired,
    noMore: PropTypes.bool,
    meId: PropTypes.string,
    history: PropTypes.object.isRequired,
  };

  componentDidMount() {
    this.windowHeight = window.innerHeight;
    window.addEventListener('scroll', this.onScroll);
    window.addEventListener('resize', this.onResize);
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll);
    window.removeEventListener('resize', this.onResize);
  }

  onResize = throttle(() => {
    this.windowHeight = window.innerHeight;
  }, 200);

  onScroll = throttle(() => {
    if (!this.props.noMore) {
      if (!this.props.loading && window.pageYOffset + this.windowHeight > this.props.tasks.length * 145) { // 估算高度，不需要到底部就加载
        this.onReloadClick();
      }
    }
  }, 500);

  onReloadClick = () => {
    if (!this.props.loading) {
      const {tasks} = this.props;
      this.props.load(tasks[Math.max(tasks.length - 1, 0)]);
    }
  }

  onBindedFavClick = onFavClick.bind(this)

  render() {
    const styles = require('./OtherTasks.scss');
    const {history, meId, noMore, briefTasks, loading, tasks, error, name} = this.props;
    let content;
    let centerStyle = styles.center;
    if (!tasks || !tasks.length) {
      centerStyle = centerStyle + ' ' + styles.noOther;
    }
    if (loading) {
      content = <div className={centerStyle}><LoadingIndicator /></div>;
    } else if (error) {
      content = (<div className={centerStyle}>
      <h2>载入出错了</h2><p>{error.message || error}</p></div>);
    } else if (noMore && tasks.length) {
      content = (<div className={centerStyle + ' ' + styles.action}>
          没有更多了
        </div>);
    } else if (!tasks.length) {
      content = (<div className={centerStyle}>
        <h2 className={styles.subtle}>还没有{name}</h2>
        <Link className={styles.button} to="/">去浏览任务</Link>
      </div>);
    } else {
      content = <div className={centerStyle + ' ' + styles.action} onClick={this.onReloadClick}>载入更多</div>;
    }
    return (
      <div className={styles.otherTasks}>
        <DocumentMeta title={name + '- 蜂房'}/>
        <Banner main={name}/>
        {
        tasks && tasks.length && (<div className={styles.taskList}>
          {tasks.map( id => {
            const item = briefTasks[id];
            if (item) return <TaskItem key={item._id} {...item} onFavClick={this.onBindedFavClick(item._id)} meId={meId} pushState={history.pushState}/>;
          })}
        </div>)
        }
        {content}
      </div>
    );
  }
}

export const FavTasks = factory({
  loadingKey: 'gettingFavTasks',
  errorKey: 'getFavTasksError',
  taskKey: 'taskFav',
  load: getTasksFav,
  name: '收藏的任务',
  noMoreKey: 'noMoreFav'
})(OtherTasks);

export const HistoryTasks = factory({
  loadingKey: 'gettingHistoryTasks',
  errorKey: 'getHistoryTasksError',
  taskKey: 'taskHistory',
  load: getTasksHistory,
  name: '历史任务',
  noMoreKey: 'noMoreHistory',
})(OtherTasks);
