import React, { Component, PropTypes } from 'react';
import { Tab } from 'components';
// import { Link } from 'react-router';
export default class TabPage extends Component {
  static propTypes = {
    children: PropTypes.object.isRequired
  }
  render() {
    return (
      <div>
        {this.props.children}
        <Tab />
      </div>
    );
  }
}
