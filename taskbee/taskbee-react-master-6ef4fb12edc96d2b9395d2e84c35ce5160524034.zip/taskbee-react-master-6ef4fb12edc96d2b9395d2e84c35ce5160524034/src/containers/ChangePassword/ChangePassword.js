import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from 'utils/userValidation';
import DocumentMeta from 'react-document-meta';
import {changePassword} from 'redux/modules/user';
import { Banner, VerifyForm, NormalButton, PasswordInput, SubtleButtons, Spinner } from 'components';

@reduxForm({
  form: 'user',
  fields: ['password'],
  validate: userValidation
})
@connect(
  state => ({
    token: state.user.token,
    codeError: state.verify.error,
    verifyToken: state.verify.verifyToken,
    changingPassword: state.user.changingPassword,
    changePasswordError: state.user.changePasswordError,
  }),
  {changePassword})
export default class ChangePassword extends Component {
  static propTypes = {
    changingPassword: PropTypes.bool,
    changePasswordError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    changePassword: PropTypes.func.isRequired,
    verifyToken: PropTypes.string,
    token: PropTypes.string,
    history: PropTypes.object.isRequired,
  }

  componentWillReceiveProps(nextProps) {
    // 当成功之后返回上一级, 因为所有组建都只在一处使用，这里全部硬写进去
    if (this.props.changingPassword && !nextProps.changingPassword && !nextProps.changePasswordError) {
      if (this.props.token) this.props.history.goBack();
      else this.props.history.replaceState(null, '/login');
    }
  }

  onSubmit = (event) => {
    event.preventDefault();
    const {changingPassword, fields, valid, verifyToken} = this.props;
    if (!changingPassword && valid) {
      this.props.changePassword({
        password: fields.password.value,
        verifyToken
      });
    }
  }

  render() {
    // 使用login的样式
    const styles = require('../Login/Login.scss');
    const {
      verifyToken,
      changingPassword,
      fields: {password},
      valid,
      token,
      changePasswordError,
    } = this.props;
    return (
      <div className={styles.login}>
        <DocumentMeta title="修改密码 - 蜂房"/>
        <Banner main="修改密码"/>
        {!token && <SubtleButtons leftText="登录" leftTo="/login" rightText="注册账号" rightTo="/reg"/>}
        {
          verifyToken ?
          <form onSubmit={this.onSubmit}>
            {changePasswordError && (!changePasswordError.errorCode || typeof changePasswordError.errorCode === 'number') && <div className={styles.extraError}>{changePasswordError.message || '网络错误，请稍候重试'}</div>}
            <PasswordInput label="密码" placeholder="输入你的新密码" serverError={(changePasswordError && changePasswordError.errorCode === 'password') ? changePasswordError.message : null} {...password}/>
            <div className={styles.cta}>
              <NormalButton type="submit" disabled={!valid}>
                {changingPassword ? <Spinner/> :
                '修改密码'}
              </NormalButton>
            </div>
          </form>
          :
          <div>
            <VerifyForm forget/>
          </div>
        }
      </div>
    );
  }
}
