import React, { Component, PropTypes } from 'react';
import DocumentMeta from 'react-document-meta';
import {reduxForm} from 'redux-form';
import {connect} from 'react-redux';
import ReactDOM from 'react-dom';
import moment from 'moment';
// import connectData from 'helpers/connectData';
import { ImagePicker, Mapbox, Banner, LongTextInput, Modal, NormalButton, Spinner} from 'components'; // TagEditor
import {create, newPublish} from 'redux/modules/publish'; // isTagLoaded, getTags
import createValidation from './CreateValidation';
import {replaceState} from 'redux-router';
// import {schoolMap} from 'utils/dataMap';
import {Link} from 'react-router';

const localDateTimeFomrat = 'YYYY-MM-DDTHH:mm:ss';

// function fetchDataDeferred(getState, dispatch) { /* eslint no-unused-vars: 0 */
/*
  if (!isTagLoaded(getState())) {
    return dispatch(getTags());
  }
}
*/

// @connectData(null, fetchDataDeferred)
@reduxForm({
  form: 'create',
  fields: ['startTime', 'dueTime', 'reward', 'description', 'secret', 'images'],
  validate: createValidation
})
@connect(
  state => ({
    user: state.user[state.user.meId] || {},
    token: state.user.token,
    createError: state.publish.error,
    success: state.publish.success,
    creating: state.publish.creating,
    tmpTag: state.publish.tmpTag,
    long: state.lbs.longitude,
    lati: state.lbs.latitude,
  }), {replaceState, create, newPublish})
export default class Create extends Component {
  static propTypes = {
    creating: PropTypes.bool,
    registerError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    initializeForm: PropTypes.func.isRequired,
    create: PropTypes.func.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    newPublish: PropTypes.func.isRequired,
    replaceState: PropTypes.func.isRequired,
    token: PropTypes.string,
    createError: PropTypes.any,
    success: PropTypes.any,
    tmpTag: PropTypes.object,
    user: PropTypes.object.isRequired,
    long: PropTypes.number,
    lati: PropTypes.number,
  }

  state = {
    moneyOpen: false,
    startTimeOpen: false,
    dueTimeOpen: false
  }

  componentDidMount() {
    this.initForm();
    this.dateMin = moment().format(localDateTimeFomrat);
    this.dateMax = moment().add(2, 'M').format(localDateTimeFomrat);
  }

  onCloseClick = (key) => {
    return () => {
      this.setState({[key]: false});
    };
  }

  onOpenClick = (key) => {
    return () => {
      this.setState({[key]: true});
    };
  }

  onRewardOpen = () => {
    this.setState({moneyOpen: true});
    // 等待元素被mount
    setTimeout(() => {
      const dom = ReactDOM.findDOMNode(this.refs.rewardInput);
      dom.focus();
      dom.setSelectionRange(dom.value.length, dom.value.length);
    }, 300);
  }
  onStartTimeOpen = () => {
    this.setState({startTimeOpen: true});
    setTimeout(() => {
      const dom = ReactDOM.findDOMNode(this.refs.startTimeInput);
      dom.focus();
    }, 300);
  }
  onDueTimeOpen = () => {
    this.setState({dueTimeOpen: true});
    setTimeout(() => {
      const dom = ReactDOM.findDOMNode(this.refs.dueTimeInput);
      dom.focus();
    }, 300);
  }

  onRewardKeyDown = (event) => {
    if (event.keyCode === 13) {
      event.preventDefault();
      this.confirmReward();
    }
  }

  onStartTimeKeyDown = (event) => {
    if (event.keyCode === 13) {
      event.preventDefault();
      this.confirmStartTime();
    }
  }

  onDueTimeKeyDown = (event) => {
    if (event.keyCode === 13) {
      event.preventDefault();
      this.confirmDueTime();
    }
  }

  onSubmitClick = (data) => {
    const {creating} = this.props;
    if (!creating) {
      this.props.handleSubmit(this.prepareToCreate)(data);
    }
  }

  onContinueClick = () => {
    this.initForm();
    this.props.newPublish();
  }

  onGoToTaskClick = () => {
    // 进入/task
    this.props.replaceState(null, '/');
    this.props.newPublish();
    // 初始化
    // this.onContinueClick();
  }

  onSetImage = (index) => {
    return (data) => {
      const {images} = this.props.fields;
      // mutate 不知道是否可行
      images.value[index] = data;
      images.onBlur(images.value);
    };
  }

  initForm() {
    // const {tmpTag} = this.props;
    this.props.initializeForm({
      startTime: moment().format(localDateTimeFomrat),
      dueTime: moment().add(30, 'd').format(localDateTimeFomrat),
      reward: '0',
      description: '',
      secret: '',
      images: [
        {src: '', path: null},
        {src: '', path: null},
        {src: '', path: null},
      ],
      // tags: tmpTag ? [tmpTag] : [],
    });
  }

  prepareToCreate = (data) => {
    // 处理正确的提交数据
    data.startTime = moment(data.startTime).toDate().getTime();
    data.dueTime = moment(data.dueTime).toDate().getTime();
    // data.tags = data.tags.map( tag => tag._id);
    data.token = this.props.token;
    data.pos = this.pos;
    data.images = data.images.map( item => item.path).filter(item => item !== null);
    this.props.create(data);
  }

  confirmReward = () => {
    const val = parseInt(this.props.fields.reward.value, 10);
    if ( val < 0 || isNaN(val)) {
      this.props.fields.reward.onChange('0');
    } else if ( val > this.props.user.money) {
      this.props.fields.reward.onChange(this.props.user.money);
    }
    this.setState({moneyOpen: false});
  }
  confirmStartTime = () => {
    if (!this.props.fields.startTime.value.length) {
      this.props.fields.startTime.onChange(moment().format(localDateTimeFomrat));
    }
    this.setState({startTimeOpen: false});
  }
  confirmDueTime = () => {
    if (!this.props.fields.dueTime.value.length) {
      this.props.fields.dueTime.onChange(moment().add(30, 'd').format(localDateTimeFomrat));
    }
    this.setState({dueTimeOpen: false});
  }

  updateCenter = (pos) => {
    this.pos = pos;
  }

  render() {
    const styles = require('./Create.scss');
    const logo = require('../../../static/logo.png');
    const {user, creating, success, createError, fields: {images, startTime, dueTime, reward, description, secret}} = this.props;
    let confirmMoney = '我不想给报酬';
    if (reward.value > 500) {
      confirmMoney = '任性';
    } else if (reward.value > 50) {
      confirmMoney = '嗯，我就是壕';
    } else if (reward.value > 10) {
      confirmMoney = '好好奖励小伙伴';
    } else if (reward.value > 0) {
      confirmMoney = '确定就这个报酬了';
    }

    return (
      <div className={styles.create}>
        <DocumentMeta title="创建新任务 - 求陪伴，求教学……"/>
        <Banner main={'发布任务'} right={<Link className={styles.createTask} to="/newM">去发花粉</Link>}/>
        {
          success ?
          <div className={styles.success}>
            <div className={styles.center}>
              <img src={logo}/>
              <h3>任务提交成功~</h3>
              { success.length ? success : null}
              <div className={styles.twoButton}>
                <NormalButton onClick={this.onGoToTaskClick}>
                  进入首页
                </NormalButton>
                <NormalButton onClick={this.onContinueClick}>
                  继续提交任务
                </NormalButton>
              </div>
            </div>
          </div>
          :
          <div>
            {createError && <p className={styles.errorMsg}>{createError.message || '网络错误，请稍候重试'}</p>}
            <ul className={styles.controls}>
              <li onClick={this.onStartTimeOpen}>
                <span className={styles.title}>开始时间</span>
                <p>{moment(startTime.value).fromNow()}</p>
              </li>
              <li onClick={this.onDueTimeOpen}>
                <span className={styles.title}>截止时间</span>
                <p>{moment(dueTime.value).fromNow()}</p>
              </li>
              <li onClick={this.onRewardOpen}>
                <span className={styles.title}>奖赏</span>
                <p><span className={styles.yuan}>¥</span>{reward.value}</p>
              </li>
            </ul>
            <LongTextInput label="任务信息" placeholder="（至少10个字）求技能/求陪伴" rows="7" maxCount={280} {...description}/>
            <div className={styles.images}>
              <label>传照片</label>
              {
                images.value && images.value.map( (data, index) => <ImagePicker key={index} index={index} src={data.src} onSetImage={this.onSetImage(index)}/>)
              }
            </div>
            <Mapbox className={styles.map} needCenter updateCenter={this.updateCenter}/>
            {
              /*
                <div className={styles.tags}>
                  <TagEditor {...tags}/>
                </div>
               */
            }
            <LongTextInput label="私密信息" placeholder="（选填）这里的信息只有接手人能够看到，可以发一些不便公开的任务信息" rows="5" maxCount={280} {...secret}/>
            <div className={styles.cta}>
              <NormalButton onClick={this.onSubmitClick}>
                {creating ? <Spinner/> : '提交任务'}
              </NormalButton>
            </div>
            <Modal isOpen={this.state.moneyOpen} closeTimeoutMS={200} onRequestClose={this.confirmReward}>
              <div className={styles.modal}>
                <div className={styles.modalInfo}>
                  <p>男生们也是一片心意，不用给报酬了吧～<br/>接手人会在任务确认完成后收到报酬。如果是非金钱的报酬，请在任务信息中注明哦～
                  <br/>
                  当前钱包余额：¥{user.money}<Link className={styles.link} to="/me/wallet">给钱包充钱</Link>
                  </p>
                  <span className={styles.yuan}>¥</span>
                  <input step="1" ref="rewardInput" placeholder="请输入个整数"
                   className={styles.rewardInput} type="nubmer" {...reward} onKeyDown={this.onRewardKeyDown}/>
                </div>
                <div className={styles.actions}>
                  <NormalButton onClick={this.confirmReward}>
                    {confirmMoney}
                  </NormalButton>
                </div>
              </div>
            </Modal>

            <Modal isOpen={this.state.startTimeOpen} closeTimeoutMS={200} onRequestClose={this.confirmStartTime}>
              <div className={styles.modal}>
                <div className={styles.modalInfo}>
                  <p>设定任务可以开始进行的时间，仅用来方便其他同学查看</p>
                  <input min={this.dateMin} ref="startTimeInput" className={styles.rewardInput} type="datetime-local" onKeyDown={this.onStartTimeKeyDown} {...startTime}/>
                </div>
                <div className={styles.actions}>
                  <NormalButton onClick={this.confirmStartTime}>
                    确定
                  </NormalButton>
                </div>
              </div>
            </Modal>

             <Modal isOpen={this.state.dueTimeOpen} closeTimeoutMS={200} onRequestClose={this.confirmDueTime}>
              <div className={styles.modal}>
                <div className={styles.modalInfo}>
                  <p>设定任务截止的时间。任务超过截止时间后，没有被接手则自动取消</p>
                  <input min={startTime.value} max={this.dateMax} ref="dueTimeInput" className={styles.rewardInput} type="datetime-local" onKeyDown={this.onDueTimeKeyDown} {...dueTime}/>
                </div>
                <div className={styles.actions}>
                  <NormalButton onClick={this.confirmDueTime}>
                    确定
                  </NormalButton>
                </div>
              </div>
            </Modal>
          </div>
        }

      </div>
    );
  }
}
