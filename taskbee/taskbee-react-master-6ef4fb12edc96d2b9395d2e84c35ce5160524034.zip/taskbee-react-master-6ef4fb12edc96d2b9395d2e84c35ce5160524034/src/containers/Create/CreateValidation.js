// import memoize from 'lru-memoize';
import {createValidator, required, minLength, maxLength, maxLengthArray, minLengthArray} from 'utils/validation';

const createValidation = createValidator({
  description: [required, minLength(10), maxLength(280)],
  secret: [maxLength(280)],
  tags: [minLengthArray(1), maxLengthArray(5)]
});
export default createValidation;
