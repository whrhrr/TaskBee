export function requireLogin() {
  if (!this.props.token) {
    this.props.history.pushState(null, '/join');
    return false;
  }
  return true;
}


// 点击了添加收藏 需要fav,unfav,pushState
export function onFavClick(id, task) {
  return (event) => {
    event.preventDefault();
    event.stopPropagation();
    const {token} = this.props;
    const theTask = task || this.props.briefTasks[id];
    if (requireLogin.bind(this)()) {
      if (theTask.faved) {
        this.props.unfav({id, token});
      } else {
        this.props.fav({id, token});
      }
    }
  };
}

export function throttle(fn, delay) {
  let allowSample = true;
  return function throttled(ev) {
    if (allowSample) {
      allowSample = false;
      setTimeout(function allowNext() { allowSample = true; }, delay);
      fn(ev);
    }
  };
}


export function debounce(fn, delay) {
  // 不应该throttle 应该debounce
  let timeout;
  return function debounced(ev) {
    const later = function later() {
      timeout = null;
      fn(ev);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, delay);
    // if (!timeout) fn(ev);
  };
}
