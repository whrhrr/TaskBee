export function enterThen() {
  if (event.targe.value)
}
