// 最多存储10个私信，每个最多存50条消息
export function saveMessages(messages) {
  const store = {};
  let left = 15;
  const keys = Object.keys(messages);
  for (let ind = 0; ind < keys.length && left; ind++) {
    const key = keys[ind];
    if (key.length === 24) {
      store[key] = {
        ...messages[key],
        messages: messages[key].messages.slice(-50),
      };
      left--;
    }
  }
  localStorage.setItem('messages', JSON.stringify(store));
}
