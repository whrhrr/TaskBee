export function arrayToObject(array) {
  const value = {};
  array.forEach( item => value[item._id] = item);
  return value;
}

export function filterToId(array) {
  if (array) return array.map( item => item._id);
  return [];
}


/*
// Converts numeric degrees to radians
function toRad(Value) {
  return Value * Math.PI / 180;
}

export function calcCrow([lat1, lon1], [lat2, lon2]) {
  const earthR = 6378137; // m
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const rlat1 = toRad(lat1);
  const rlat2 = toRad(lat2);

  const angel = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(rlat1) * Math.cos(rlat2);
  const dis = 2 * Math.atan2(Math.sqrt(angel), Math.sqrt(1 - angel));
  return earthR * dis;
}
*/

export function calcCrow([lat1, lon1], [lat2, lon2]) {
  const Ra = 6371000;
  const an = 0.5 - Math.cos((lat2 - lat1) * Math.PI / 180) / 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * (1 - Math.cos((lon2 - lon1) * Math.PI / 180)) / 2;
  return Ra * 2 * Math.asin(Math.sqrt(an));
}
