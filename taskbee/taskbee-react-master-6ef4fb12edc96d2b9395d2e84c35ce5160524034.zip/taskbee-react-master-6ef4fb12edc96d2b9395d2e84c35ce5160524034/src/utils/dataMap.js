export const gender = {
  0: '男',
  1: '女',
  2: '其他'
};

export const genderToClassName = {
  0: 'icon-symbol-man',
  1: 'icon-symbol-woman',
  2: 'icon-symbol-mixed'
};

export const stateMap = {
  0: '等待接手',
  1: '任务进行中',
  2: '等待发布人确认',
  3: '已完成',
  4: '已超时',
  5: '已取消',
  6: '等待审核',
};

export const schoolMap = {
  0: '同济嘉定',
  1: '同济本部',
};

export const orderArray = [
  {
    title: '蜂房-给钱包存钱 - 1元尝鲜',
    price: 1,
  },
  {
    title: '蜂房-给钱包存钱 - 10元',
    price: 10,
  },
  {
    title: '蜂房-给钱包存钱 - 30元',
    price: 30,
  },
  {
    title: '蜂房-给钱包存钱 - 任性50元',
    price: 50,
  },
  {
    title: '蜂房-给钱包存钱 - 小土豪100元',
    price: 100,
  },
  {
    title: '蜂房-给钱包存钱 - 大土豪300元',
    price: 300,
  }
];

export const orderStateMap = {
  0: '等待付款',
  1: '等待付款',
  2: '即将给钱包充值',
  3: '充值完毕',
  4: '充值完毕',
  5: '订单取消',
};
