import React from 'react';
import {IndexRoute, Route} from 'react-router';
import { isLoaded as isAuthLoaded, load as loadAuth } from 'redux/modules/user';
import {
    App,
    Chat,
    Home,
    About,
    Login,
    NotFound,
    TabPage,
    Me,
    Message,
    Create,
    Task,
    Join,
    Register,
    ChangePassword,
    MyAccount,
    ChangeSignature,
    ChangeName,
    ChangeGender,
    ChangeSchool,
    FavTasks,
    HistoryTasks,
    TaskDetail,
    Wallet,
    Score,
    Feedback,
    UserDetail,
    Vote,
    OrderDetail,
    OrderList,
    Withdraw,
    WithdrawList,
    Redpocket,
    CreatePollen,
    PollenDetail,
    Friends,
    CreateEvent,
    PollenList,
    SkillDetail,
  } from './containers';

export default (store) => {
  const requireLogin = (nextState, replaceState, cb) => {
    function checkAuth() {
      const { user: { token }} = store.getState();
      if (!token) {
        // oops, not logged in, so can't be here!
        replaceState(null, '/join');
      }
      cb();
    }

    if (!isAuthLoaded(store.getState())) {
      store.dispatch(loadAuth()).then(checkAuth);
    } else {
      checkAuth();
    }
  };

  const requireNotLogin = (nextState, replaceState, cb) => {
    function checkAuth() {
      const { user: { token }} = store.getState();
      if (token) {
        replaceState(null, '/');
      }
      cb();
    }
    if (!isAuthLoaded(store.getState())) {
      store.dispatch(loadAuth()).then(checkAuth);
    } else {
      checkAuth();
    }
  };

  /**
   * Please keep routes in alphabetical order
   */
  return (
    <Route path="/" component={App}>
      { /* Home (main) route */ }

      { /* Routes requiring login */ }
      <Route onEnter={requireLogin}>
        <Route path="chat/:userId" component={Chat}/>
        <Route path="/vote/:taskId" component={Vote}/>
        <Route path="/order/:orderId" component={OrderDetail}/>
        <Route component={TabPage}>
          <Route path="/task" component={Task}/>
          <Route path="/message" component={Message}/>
        </Route>
        <Route path="/friends" component={Friends}/>
        <Route path="/new" component={Create}/>
        <Route path="/newM" component={CreatePollen}/>
        <Route path="/newEvent" component={CreateEvent}/>
        <Route path="/me/info" component={MyAccount}/>
        <Route path="/me/pollen" component={PollenList}/>
        <Route path="/me/info/sign" component={ChangeSignature}/>
        <Route path="/me/info/name" component={ChangeName}/>
        <Route path="/me/info/gender" component={ChangeGender}/>
        <Route path="/me/info/school" component={ChangeSchool}/>
        <Route path="/me/wallet" component={Wallet}/>
        <Route path="/me/wallet/withdraw" component={Withdraw}/>
        <Route path="/me/wallet/withdraws" component={WithdrawList}/>
        <Route path="/me/wallet/orders" component={OrderList}/>
        <Route path="/me/wallet/redpocket" component={Redpocket}/>
        <Route path="/me/score" component={Score}/>
        <Route path="/task/favTasks" component={FavTasks}/>
        <Route path="/task/historyTasks" component={HistoryTasks}/>
      </Route>

      <Route path="/tasks/:taskId" component={TaskDetail}/>
      <Route path="/users/:userId" component={UserDetail}/>
      <Route path="/pollens/:postId" component={PollenDetail}/>

      { /* Main page */ }
      <Route component={TabPage}>
        <IndexRoute component={Home}/>
        <Route path="/me" component={Me}/>
      </Route>

      <Route onEnter={requireNotLogin}>
        <Route path="join" component={Join}/>
        <Route path="login" component={Login}/>
        <Route path="reg" component={Register}/>
      </Route>

      { /* Routes */ }
      <Route path="/skills/:skillId" component={SkillDetail}/>
      <Route path="about" component={About}/>
      <Route path="feedback" component={Feedback}/>
      <Route path="forget" component={ChangePassword}/>

      { /* Catch all route */ }
      <Route path="*" component={NotFound} status={404} />
    </Route>
  );
};
