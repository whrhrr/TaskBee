require('babel/polyfill');

const environment = {
  development: {
    isProduction: false
  },
  production: {
    isProduction: true
  }
}[process.env.NODE_ENV || 'development'];

module.exports = Object.assign({
  host: process.env.HOST || 'localhost',
  port: process.env.PORT,
  apiHost: process.env.APIHOST || 'localhost',
  apiPort: process.env.APIPORT,
  app: {
    title: '蜂房 | 名校技能经验共享平台，同济、北邮、交通大学大神亲自教学，学习考研、出国、编程、设计等经验技能',
    description: '名校技能经验共享平台，同济、北邮、交通大学大神亲自教学,求技能,求陪伴,有困难上蜂房',
    meta: {
      charSet: 'utf-8',
      property: {
        'og:site_name': '蜂房',
        'og:image': 'https://taskbee.cnandroid-chrome-192x192.png',
        'og:locale': 'zh-cn',
        'og:title': '蜂房',
        'og:description': '蜂房：求技能,求陪伴,求帮助',
      }
    }
  }
}, environment);
