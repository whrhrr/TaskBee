import React, {Component, PropTypes} from 'react';
import {Ripple} from 'components';

export default class LineButton extends Component {
  static propTypes = {
    children: PropTypes.any,
    onClick: PropTypes.func,
    icon: PropTypes.any,
    label: PropTypes.any,
    content: PropTypes.any
  }

  render() {
    const {children, icon, label, content, onClick, ...props} = this.props;
    const styles = require('./LineButton.scss');
    return (
      <button type="button" className={styles.lineButton} onClick={onClick} {...props}>
        {icon && <div className={styles.icon}>{icon}</div>}
        <div className={styles.label}>{label}</div>
        <div className={styles.content}>{content}</div>
        <Ripple/>
      </button>
    );
  }
}
