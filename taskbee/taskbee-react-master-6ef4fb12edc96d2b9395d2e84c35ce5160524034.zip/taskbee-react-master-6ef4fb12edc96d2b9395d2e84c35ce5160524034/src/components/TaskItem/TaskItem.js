import React, {Component, PropTypes} from 'react';
import { Avatar, Tag, Timeline, Gender} from 'components'; // Tag,
import {stateMap} from 'utils/dataMap';
import moment from 'moment';
import {Link} from 'react-router';
import {calcCrow} from 'utils/dataProcessor';
moment.locale('zh-cn');

export default class TaskItem extends Component {
  static propTypes = {
    _id: PropTypes.string,
    onFavClick: PropTypes.func,
    faved: PropTypes.bool,
    timeline: PropTypes.bool,
    nofav: PropTypes.bool,
    state: PropTypes.number,
    reward: PropTypes.number,
    dueTime: PropTypes.string,
    startTime: PropTypes.string,
    tags: PropTypes.array,
    description: PropTypes.string,
    publisher: PropTypes.object,
    pushState: PropTypes.func,
    meId: PropTypes.string,
    canVote: PropTypes.array,
    tasker: PropTypes.any,
    loc: PropTypes.object,
    myPos: PropTypes.array,
    imgs: PropTypes.array,
    favs: PropTypes.number,
    type: PropTypes.number,
  }

  state = {
    dueMoment: '',
    startMomen: '',
  }

  componentDidMount() {
    // 需要使用did mount来解决moment效率问题
    // 防止大量的同时计算
    setTimeout(() => {
      this.setState({ /* eslint react/no-did-mount-set-state: 0 */
        startMoment: moment(this.props.startTime).format('MM/D HH:mm'),
      });
      if (this.props.myPos) {
        this.setState({
          distance: calcCrow(this.props.loc.coordinates, this.props.myPos)
        });
      }
    }, 50);
  }

  render() {
    const styles = require('./TaskItem.scss');
    const {type, favs, imgs, meId, canVote, _id, onFavClick, faved, timeline, nofav, state, reward, description, tasker, publisher: {_id: pubId, school, avatar, username, gender}} = this.props; // tags,
    const { startMoment} = this.state;
    const onAvatarClick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.props.pushState(null, '/users/' + this.props.publisher._id);
    };
    let stateStyle = styles.state;
    if (state === 0) {
      stateStyle = stateStyle + ' ' + styles.stand;
    } else if (state < 3) {
      stateStyle = stateStyle + ' ' + styles.ongoing;
    }
    if (meId === pubId || tasker && ((tasker._id && tasker._id === meId) || tasker === meId)) stateStyle = stateStyle + ' ' + styles.mine;
    const voteIndicator = meId && canVote && canVote.indexOf(meId) > -1 ? <div className={styles.canVote}>可评价</div> : null;
    return (
      <Link className={type === 1 ? styles.taskItem + ' ' + styles.schoolEvent : styles.taskItem} to={'/tasks/' + _id}>
        <div className={styles.user} onClick={onAvatarClick}>
          <Avatar src={avatar}/>
          <div className={styles.score}>
            {this.state.distance !== undefined ? Math.floor(this.state.distance) + '米' : null}
          </div>
        </div>
        <div className={styles.content}>
          {
            type === 1 ? <Tag name="校园活动"/> : null
          }
          {
            timeline ?
            <Timeline state={state}/>
            : null
            /*
            <div className={styles.tags}>
              {
                tags.map( tag => <Tag key={tag} name={tag}/>)
              }
            </div>
            */
          }
          <div className={styles.username}>
            <span className={styles.nameText}>{username}</span><Gender gender={gender}/>
          </div>
          <div className={styles.description}>
            {description}
            {
              imgs && imgs.length ? <div className={styles.images}>
                {imgs.map((img) => <img key={img.key} src={IMAGE_HOST + img.key + '?imageView2/1/w/60/h/60'}/>)}
              </div>
               : null
            }
            <div className={styles.oneLine}>
              {type !== 1 && <span className={stateStyle}>{stateMap[state]}</span>}
              <Tag className={styles.school} name={school}/>
            </div>
          </div>
          <ul className={styles.misc}>
            {type !== 1 && <li><span className="icon-vallet"/>¥{reward}</li>}
            <li><span className="icon-clock"/>{startMoment}</li>
          </ul>
          {!nofav &&
          <div className={styles.fav + (faved ? ' ' + styles.faved : '')} onClick={onFavClick}>
            {favs ? <span className={styles.favCount}>{favs}</span> : null}
          </div>
          }
          {voteIndicator}
        </div>
      </Link>
    );
  }
}

