import React, {PropTypes} from 'react';

const Avatar = (props) => {
  const {src, onClick} = props;
  let size = props.size || 42;
  if (size < 42) size = 42;
  const defaultAvatar = require('../../../static/defaultAvatar.jpg');
  return (
    <img src={src ? IMAGE_HOST + src + `?imageView2/1/w/${size}/h/${size}/format/jpg` : defaultAvatar} onClick={onClick}/>
  );
};
Avatar.propTypes = {
  size: PropTypes.any,
  src: PropTypes.string,
  onClick: PropTypes.func,
};

export default Avatar;
