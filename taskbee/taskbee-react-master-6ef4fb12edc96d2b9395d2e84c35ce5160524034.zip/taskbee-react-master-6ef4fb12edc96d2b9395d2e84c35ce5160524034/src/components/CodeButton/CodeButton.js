import React, {Component, PropTypes} from 'react';
import { connect } from 'react-redux';
import {Ripple} from 'components';

@connect(state => ({
  availableTime: state.verify.availableTime,
  loading: state.verify.loading,
}))
export default class CodeButton extends Component {
  static propTypes = {
    availableTime: PropTypes.number.isRequired,
    loading: PropTypes.bool,
    onClick: PropTypes.func
  }

  state = { countDown: 0}

  componentWillReceiveProps(nextProps) {
    if (nextProps.availableTime !== this.props.availableTime) {
      // 新建倒计时, 假定同一页面只会存在一个该空间
      const time = Math.round((nextProps.availableTime - Date.now()) / 1000);
      this.setState({countDown: time});
      this.countDownHandle = setInterval( () => {
        const nextCountDown = this.state.countDown - 1;
        this.setState({countDown: nextCountDown});
        if (nextCountDown <= 0) {
          clearInterval(this.countDownHandle);
        }
      }, 1000);
    }
  }

  componentWillUnmount() {
    if (this.countDownHandle) {
      clearInterval(this.countDownHandle);
    }
  }

  onButtonClick() {
    this.props.onClick();
  }

  render() {
    const styles = require('./CodeButton.scss');
    const { loading } = this.props;
    const { countDown } = this.state;
    let content;
    if (loading) {
      content = '正在获取手机验证码';
    } else if (countDown > 0) {
      content = `${countDown}秒后可再次获取`;
    } else {
      content = '获取验证码';
    }

    return (
      <button type="button" className={styles.codeButton} disabled={loading || countDown > 0} onClick={::this.onButtonClick}>
        {content}
        <Ripple/>
      </button>
    );
  }
}
