/*eslint-disable */
/*
  直接从React-Modal里拿来用，进行修改
  后期可以进行符合代码规范的整合
 */
module.exports = require('./components/Modal');

