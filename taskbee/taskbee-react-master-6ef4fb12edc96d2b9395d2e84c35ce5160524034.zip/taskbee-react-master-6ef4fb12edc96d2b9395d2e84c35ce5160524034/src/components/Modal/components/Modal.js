/*eslint-disable */

const React = require('react');
const ReactDOM = require('react-dom');
//const ExecutionEnvironment = require('exenv');
const ModalPortal = React.createFactory(require('./ModalPortal'));
const ariaAppHider = require('../helpers/ariaAppHider');
const elementClass = require('element-class');
const renderSubtreeIntoContainer = require('react-dom').unstable_renderSubtreeIntoContainer;

const SafeHTMLElement = __CLIENT__ ? window.HTMLElement : {};


function sanitizeProps(props) {
  delete props.ref;
}

const Modal = module.exports = React.createClass({

  displayName: 'Modal',

  propTypes: {
    isOpen: React.PropTypes.bool.isRequired,
    appElement: React.PropTypes.instanceOf(SafeHTMLElement),
    onRequestClose: React.PropTypes.func,
    closeTimeoutMS: React.PropTypes.number,
    ariaHideApp: React.PropTypes.bool
  },

  statics: {
    setAppElement: ariaAppHider.setElement,
  },

  getDefaultProps() {
    return {
      isOpen: false,
      ariaHideApp: true,
      closeTimeoutMS: 0
    };
  },

  componentDidMount() {
    this.node = document.createElement('div');
    this.node.className = 'ReactModalPortal';
    document.body.appendChild(this.node);
    this.renderPortal(this.props);
  },

  componentWillReceiveProps(newProps) {
    this.renderPortal(newProps);
  },

  componentWillUnmount() {
    ReactDOM.unmountComponentAtNode(this.node);
    document.body.removeChild(this.node);
  },

  renderPortal(props) {
    if (props.isOpen) {
      elementClass(document.body).add('ReactModal__Body--open');
    } else {
      elementClass(document.body).remove('ReactModal__Body--open');
    }

    if (props.ariaHideApp) {
      ariaAppHider.toggle(props.isOpen, props.appElement);
    }
    sanitizeProps(props);
    this.portal = renderSubtreeIntoContainer(this, ModalPortal(props), this.node);
  },

  render() {
    return React.DOM.noscript();
  }
});
