import React from 'react';

const animationDelay = (delay) => {
  return {
    MozAnimationDelay: delay,
    WebkitAnimationDelay: delay,
    OAnimationDelay: delay,
    animationDelay: delay,
  };
};

export default function Spinner() {
  const styles = require('./Spinner.scss');
  return (
    <span className={styles.spinner}>
      <span className={styles.inner}>
        .
      </span>
      <span className={styles.inner} style={animationDelay('400ms')}>
        .
      </span>
      <span className={styles.inner} style={animationDelay('800ms')}>
        .
      </span>
    </span>
  );
}
