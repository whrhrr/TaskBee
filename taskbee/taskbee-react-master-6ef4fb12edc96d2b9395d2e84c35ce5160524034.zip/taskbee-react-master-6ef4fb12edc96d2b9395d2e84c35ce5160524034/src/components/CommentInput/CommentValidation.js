// import memoize from 'lru-memoize';
import {createValidator, required, minLength, maxLength} from 'utils/validation';

const commentValidation = createValidator({
  comment: [required, minLength(2), maxLength(280)],
});
export default commentValidation;
