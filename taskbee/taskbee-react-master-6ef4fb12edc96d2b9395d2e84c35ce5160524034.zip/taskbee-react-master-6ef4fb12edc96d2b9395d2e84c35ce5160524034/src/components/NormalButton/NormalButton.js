import React, {Component, PropTypes} from 'react';
import {Ripple} from 'components';

export default class NormalButton extends Component {
  static propTypes = {
    children: PropTypes.any,
    onClick: PropTypes.func
  }

  render() {
    const {children, onClick, ...props} = this.props;
    const styles = require('./NormalButton.scss');
    return (
      <button className={styles.normalButton} onClick={onClick} {...props}>
        {children}
        <Ripple />
      </button>
    );
  }
}
