import React, {PropTypes} from 'react';
import {Link} from 'react-router';
import {Avatar, Ripple, Gender} from 'components';

const Contact = (props) => {
  const styles = require('./Contact.scss');
  const {unread, _id, messages, username, avatar, gender} = props;
  return (
    <Link to={'/chat/' + _id} className={styles.contact}>
      <Avatar src={avatar} size={46}/>
      <div className={styles.info}>
        <div className={styles.username}>{username} <Gender gender={gender}/></div>
        {messages && messages.length ? <div className={styles.message}>{messages[messages.length - 1].message}</div> : null }
      </div>
      {
        unread !== undefined && unread !== 0 && <div className={styles.unread}><div className={styles.center}><span>{unread}</span></div></div>
      }
      <Ripple/>
    </Link>
  );
};

Contact.propTypes = {
  _id: PropTypes.string,
  avatar: PropTypes.string,
  messages: PropTypes.array,
  username: PropTypes.string,
  unread: PropTypes.number,
  gender: PropTypes.number,
};

export default Contact;
