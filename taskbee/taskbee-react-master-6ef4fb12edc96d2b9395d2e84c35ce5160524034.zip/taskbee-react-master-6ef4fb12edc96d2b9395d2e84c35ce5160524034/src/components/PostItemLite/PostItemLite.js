import React, {Component, PropTypes} from 'react';
import { Avatar, ImageViewer, Tag, Gender} from 'components';
// import {stateMap} from 'utils/dataMap';
import moment from 'moment';
// import {Link} from 'react-router';
import {calcCrow} from 'utils/dataProcessor';
moment.locale('zh-cn');

export default class PostItem extends Component {
  static propTypes = {
    _id: PropTypes.string,
    meId: PropTypes.string,
    postId: PropTypes.object.isRequired,
    loc: PropTypes.object.isRequired,
    myPos: PropTypes.array,
    type: PropTypes.number.isRequired,
    pushState: PropTypes.func.isRequired,
  }

  state = {
    distance: undefined,
    distanceOrig: undefined,
    showImage: false,
    showIndex: 0,
  }

  componentDidMount() {
    // 需要使用did mount来解决moment效率问题
    // 防止大量的同时计算
    setTimeout(() => {
      if (this.props.myPos) {
        this.setState({
          distance: calcCrow(this.props.loc.coordinates, this.props.myPos),
          distanceOrig: calcCrow(this.props.postId.loc.coordinates, this.props.myPos)
        });
      }
    }, 50);
  }

  onDetailClick = () => {
    this.props.pushState(null, '/pollens/' + this.props.postId._id);
  }

  onModalClose = () => {
    this.setState({showImage: false});
  }

  onImageClick = (index) => {
    return () => {
      this.setState({
        showImage: true,
        showIndex: index,
      });
    };
  }

  render() {
    const styles = require('./PostItemLite.scss');
    const { type, postId} = this.props; // _id
    const { imgs, comments, readerCount, commentCount, content: description, from } = postId;
    const onOriginAvatarClick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      this.props.pushState(null, '/users/' + from._id);
    };
    return (
      <div className={styles.postItem}>
        {
          imgs.length ? <ImageViewer
           show={this.state.showImage}
           index={this.state.showIndex}
           onRequestClose={this.onModalClose}
           images={imgs} /> : null
        }
        <div className={styles.type}>
            {
              type === 0 ? <Tag name="原创"/> : <Tag name="传播"/>
            }
        </div>
        <div className={styles.misc}>

          <div className={styles.user} onClick={onOriginAvatarClick}>
            <Avatar src={from.avatar} size={32}/>
            <div className={styles.username}>
              <span className={styles.nameText}>{from.username}</span><Gender gender={from.gender}/>
            </div>
            {this.state.distance !== undefined ? Math.floor(this.state.distance) + '米' : null}
          </div>

        </div>
        <div className={styles.content}>
          <p onClick={this.onDetailClick}>{description}</p>
          {
            imgs && imgs.length ? <div className={styles.images}>
              {imgs.map((img) => <img key={img.key} src={IMAGE_HOST + img.key + '?imageView2/1/w/60/h/60'}/>)}
            </div>
             : null
          }
          <div className={styles.more} onClick={this.onDetailClick}>
            <span>阅读{readerCount}</span>
            <span>评论{commentCount || comments && comments.length || 0}</span>
          </div>
        </div>
      </div>
    );
  }
}

