import React, {PropTypes} from 'react';

import {stateMap} from 'utils/dataMap';

const Timeline = (props) => {
  const styles = require('./Timeline.scss');
  const styleMap = {
    0: styles.zero,
    1: styles.one,
    2: styles.two,
    3: styles.three, // 完成
    4: styles.three, // 超时
    5: styles.three, // 取消
  };
  const {state} = props;
  let lastSection;
  if (state < 4) {
    lastSection = '已完成';
  } else {
    lastSection = stateMap[state];
  }
  return (
    <ul className={styles.timeline + ' ' + styleMap[state]}>
      <li>等待中<div className={styles.dot}></div></li>
      <li>已被接手<div className={styles.dot}></div></li>
      <li>接手人完成<div className={styles.dot}></div></li>
      <li>{lastSection}<div className={styles.dot}></div></li>
    </ul>
  );
};

Timeline.propTypes = {
  state: PropTypes.number.isRequired,
};

export default Timeline;
