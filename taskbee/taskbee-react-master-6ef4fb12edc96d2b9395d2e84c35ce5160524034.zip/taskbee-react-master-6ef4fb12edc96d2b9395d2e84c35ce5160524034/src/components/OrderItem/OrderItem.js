import React, {PropTypes} from 'react';
import {orderStateMap} from 'utils/dataMap';
import {Ripple} from 'components';
import moment from 'moment';

const OrderItem = (props) => {
  const styles = require('./OrderItem.scss');
  const {_id, price, state, createdDate, email, pushState} = props;
  const date = moment(createdDate).format('MM/D HH:mm');
  function onClick() {
    pushState(null, '/order/' + _id);
  }
  return (
    <div className={styles.orderItem} onClick={onClick}>
      <div className={styles.clearfix}>
        <div className={styles.price}>¥{price}</div>
        <div className={styles.date}>{date}</div>
      </div>
      <div className={styles.clearfix}>
        <div className={styles.state}>{orderStateMap[state]}</div>
        <div className={styles.email}>支付宝账户：{email || '无'}</div>
      </div>
      <Ripple/>
    </div>
  );
};

OrderItem.propTypes = {
  price: PropTypes.number,
  state: PropTypes.number,
  _id: PropTypes.string,
  createdDate: PropTypes.string,
  email: PropTypes.string,
  pushState: PropTypes.func.isRequired,
};


export default OrderItem;
