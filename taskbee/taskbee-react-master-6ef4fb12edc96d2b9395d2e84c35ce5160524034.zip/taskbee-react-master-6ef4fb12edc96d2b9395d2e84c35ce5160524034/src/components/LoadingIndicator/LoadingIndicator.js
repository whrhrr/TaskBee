import React from 'react';
import {Spinner} from 'components';
const LoadingIndicator = () => {
  const styles = require('./LoadingIndicator.scss');
  return (
    <div className={styles.loadingIndicator}>
      <Spinner/>
    </div>
  );
};

export default LoadingIndicator;
