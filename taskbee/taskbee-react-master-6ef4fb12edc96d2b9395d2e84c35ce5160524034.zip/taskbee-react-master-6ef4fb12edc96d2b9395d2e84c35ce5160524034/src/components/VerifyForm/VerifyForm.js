import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import userValidation from 'utils/userValidation';
import {getCode, verifyCode} from 'redux/modules/verify';
import { TextInput, NormalButton, CodeInput } from 'components';

@reduxForm({
  form: 'user',
  fields: ['phone', 'verify'],
  validate: userValidation
})
@connect(
  state => ({
    codeError: state.verify.error,
    verifying: state.verify.verifing,
    verifyError: state.verify.verifyError
  }),
  {verifyCode, getCode})
export default class VerifyForm extends Component {
  static propTypes = {
    codeError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    valid: PropTypes.bool.isRequired,
    getCode: PropTypes.func.isRequired,
    verifyCode: PropTypes.func.isRequired,
    verifying: PropTypes.bool,
    verifyError: PropTypes.any,
    forget: PropTypes.bool
  }

  onCodeClick = () => {
    this.props.getCode({phone: this.props.fields.phone.value, forget: this.props.forget});
  }

  onSubmit = (event) => {
    event.preventDefault();
    event.stopPropagation();
    const {verifying, fields, valid} = this.props;
    if (!verifying && valid) {
      this.props.verifyCode({phone: fields.phone.value, code: fields.verify.value});
    }
  }

  render() {
    const styles = require('./VerifyForm.scss');
    const {
        fields: {phone, verify},
        valid,
        verifying,
        codeError,
        verifyError
      } = this.props;
    const loginError = codeError || verifyError;
    return (
      <form className={styles.verifyForm} onSubmit={this.onSubmit}>
        {loginError && !loginError.errorCode && <div className={styles.extraError}>{loginError.message || '网络错误，请稍候重试'}</div>}
        <TextInput type="number" label="手机号" placeholder="请输入你的手机号" serverError={(loginError && loginError.errorCode === 'phone') ? loginError.message : null} {...phone} />
        <CodeInput type="number" label="验证码" getCode={this.onCodeClick} placeholder="请输入验证码" serverError={(loginError && loginError.errorCode === 'verify') ? loginError.message : null} {...verify} />
        <div className={styles.cta}>
          <NormalButton type="submit" disabled={!valid}>
            {
              verifying ?
              '正在进入最后一步' :
              '进入最后一步'
            }
          </NormalButton>
        </div>
      </form>
    );
  }
}
