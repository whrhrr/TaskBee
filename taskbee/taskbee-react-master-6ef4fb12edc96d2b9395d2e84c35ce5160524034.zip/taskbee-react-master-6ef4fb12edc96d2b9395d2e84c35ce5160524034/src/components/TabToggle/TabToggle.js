import React, {PropTypes} from 'react';

function TabToggle(props) {
  const styles = require('./TabToggle.scss');
  return (
    <div className={styles.tabToggle}>
      <span className={props.isRight ? '' : styles.active} onClick={props.onLeftClick}>{props.left}</span>
      <span className={props.isRight ? styles.active : '' } onClick={props.onRightClick}>{props.right}</span>
    </div>
  );
}

TabToggle.propTypes = {
  left: PropTypes.any.isRequired,
  right: PropTypes.any.isRequired,
  onLeftClick: PropTypes.func.isRequired,
  onRightClick: PropTypes.func.isRequired,
  isRight: PropTypes.bool,
};

export default TabToggle;
