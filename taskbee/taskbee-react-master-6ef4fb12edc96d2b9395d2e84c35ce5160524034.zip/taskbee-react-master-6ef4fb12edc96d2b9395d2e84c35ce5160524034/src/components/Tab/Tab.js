import React, {Component, PropTypes} from 'react';
import {Link, IndexLink} from 'react-router';
import { connect } from 'react-redux';
import {newPublish} from 'redux/modules/publish';
import {Ripple} from 'components';

const NavbarLink = ({to, className, activeClassName, children, onClick}) => {
  const Comp = (to === '/' ? IndexLink : Link);

  return (
    <Comp to={to} className={className} activeClassName={activeClassName} onClick={onClick}>
      {children}
      <Ripple/>
    </Comp>
  );
};

@connect(state => ({
  tabMessage: state.misc.tabMessage,
  tabTask: state.misc.tabTask,
  path: state.router.location.pathname,
  meId: state.user.meId,
  homeTab: state.misc.homeTab,
}), {newPublish})
export default class Tab extends Component {
  static propTypes = {
    info: PropTypes.object,
    tabMessage: PropTypes.bool,
    tabTask: PropTypes.bool,
    meId: PropTypes.string,
    newPublish: PropTypes.func.isRequired,
    homeTab: PropTypes.number,
  }

  onCreateClick = () => {
    this.props.newPublish(); // 刷新
  }

  render() {
    const styles = require('./Tab.scss');
    const {meId, tabMessage, tabTask} = this.props;
    /*
    const home = require('./home.png');
    const person = require('./person.png');
    const tasks = require('./tasks.png');
    const messages = require('./messages.png');
    const add = require('./add.png');
    */
    return (
      <footer className={styles.tab}>
        <NavbarLink className={styles.section} activeClassName={styles.active} to="/">
          <div className={styles.icon}><div className="icon-home-house-streamline"/></div>
          首页
        </NavbarLink>
        <NavbarLink className={styles.section} activeClassName={styles.active} to="/message">
          <div className={styles.icon}><div className="icon-bubble-comment-streamline-talk"/></div>
          私信
          {tabMessage && <div className={styles.notification}></div>}
        </NavbarLink>
        <NavbarLink onClick={this.onCreateClick} className={styles.section + ' ' + styles.add} activeClassName={styles.active} to={this.props.homeTab ? '/newM' : 'new'}>
          <div className="icon-plus-circle"/>
        </NavbarLink>
        <NavbarLink className={styles.section} activeClassName={styles.active} to="/task">
          <div className={styles.icon}><div className="icon-food-ice-cream-streamline"/></div>
          任务
          {tabTask && <div className={styles.notification}></div>}
        </NavbarLink>
        <NavbarLink className={styles.section} activeClassName={styles.active} to="/me">
          <div className={styles.icon}><div className="icon-man-people-streamline-user"/></div>
          {meId ? '个人' : '未登录'}
        </NavbarLink>
      </footer>
    );
  }
}
