import React, {Component, PropTypes} from 'react';
import {Modal, Carousel} from 'components';

export default class ImageViewer extends Component {
  static propTypes = {
    children: PropTypes.any,
    show: PropTypes.bool,
    index: PropTypes.number,
    onRequestClose: PropTypes.func.isRequired,
    images: PropTypes.array.isRequired,
  };

  componentDidMount() {
    this.changeIndex(this.props.index);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.index !== nextProps.index) {
      console.log('should fking go');
      this.changeIndex(nextProps.index);
    }
  }

  onImageClick = () => {
    this.props.onRequestClose();
  }

  changeIndex(index) {
    setTimeout(() => {
      if (this.refs.carousel) {
        this.refs.carousel.goToSlide(index);
      }
    }, 10);
  }

  render() {
    const styles = require('./ImageViewer.scss');
    const {images, show, onRequestClose} = this.props;
    return (
      <Modal isOpen={show} className={styles.imageViewer} onRequestClose={onRequestClose}>
        <Carousel ref="carousel" className={styles.images} cellAlign="center">
          {images.map(img => <img onClick={this.onImageClick} key={img.key} src={IMAGE_HOST + img.key + '?imageView2/2/w/640'}/>)}
        </Carousel>
      </Modal>
    );
  }

}
