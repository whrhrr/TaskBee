import React, {PropTypes} from 'react';
import {Avatar, Gender} from 'components';
import moment from 'moment';
import Rating from 'belle/lib/components/Rating';

const Comment = (props) => {
  const styles = require('./VoteItem.scss');
  const {pushState, type, score, from, message} = props;
  const date = moment(props.createdAt).format('MM/D HH:mm');
  const onAvatarClick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    pushState(null, '/users/' + from._id);
  };
  return (
    <div className={styles.voteItem}>
      <Avatar src={from.avatar} onClick={onAvatarClick}/>
      <div className={styles.message}>
        <p>{from.username}<Gender gender={from.gender}/></p>
        <p>评价{type ? '接手人' : '发布人'}</p>
        <p className={styles.comment}>{message || '没有评论'}</p>
      </div>
      <div className={styles.date}>
        <div className={styles.rating}>
          <Rating defaultValue={score} disabled style={{fontSize: 12, lineHeight: 1}}/>
        </div>
        {date}
      </div>
    </div>
  );
};
Comment.propTypes = {
  createdAt: PropTypes.string.isRequired,
  from: PropTypes.any.isRequired,
  message: PropTypes.string.isRequired,
  score: PropTypes.number.isRequired,
  type: PropTypes.bool,
  pushState: PropTypes.func.isRequired,
};

export default Comment;
