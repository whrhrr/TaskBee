import React from 'react';

export default function Tag({className, name, onClick, canClose}) {
  const styles = require('./Tag.scss');
  return (
    <span className={className ? className + ' ' + styles.tag : styles.tag} onClick={onClick}>
      {name}
      {canClose && <span className={styles.close}>x</span>}
    </span>
  );
}
