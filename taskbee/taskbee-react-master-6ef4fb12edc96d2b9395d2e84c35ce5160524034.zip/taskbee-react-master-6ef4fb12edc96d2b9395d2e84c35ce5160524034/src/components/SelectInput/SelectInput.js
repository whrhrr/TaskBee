import React, {Component, PropTypes} from 'react';

export default class SelectInput extends Component {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.string
  }

  render() {
    const styles = require('./SelectInput.scss');
    const { serverError, type, label, placeholder, value, error, touched, active, ...others} = this.props;
    let outerClass = styles.textInput;
    if (active) {
      outerClass = outerClass + ' ' + styles.active;
    }
    if (error && touched) {
      outerClass = outerClass + ' ' + styles.error;
    }
    return (
      <div className={outerClass}>
        <label>{label}</label>
        <div className="styles.select">
          <select value={value} placeholder={placeholder} {...others}/>
        </div>
        {serverError && <div className={styles.errorMsg}>{serverError}</div>}
        {!serverError && error && touched && (others.dirty || !active) && <div className={styles.errorMsg}>{error}</div>}
      </div>
    );
  }
}
