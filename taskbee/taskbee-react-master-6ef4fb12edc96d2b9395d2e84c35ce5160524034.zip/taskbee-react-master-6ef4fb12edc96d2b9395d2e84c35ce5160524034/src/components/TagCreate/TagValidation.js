// import memoize from 'lru-memoize';
import {createValidator, required, minLength, maxLength} from 'utils/validation';

const tagValidation = createValidator({
  tagName: [required, minLength(2), maxLength(5)],
});
export default tagValidation;
