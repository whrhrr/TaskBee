import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {reduxForm} from 'redux-form';
import {NormalButton, Spinner, TextInput} from 'components';
import tagValidation from './TagValidation';
import {newTag} from 'redux/modules/publish';
@connect(
  state => ({
    availableTags: state.publish.tags,
    newTagError: state.publish.newTagError,
    token: state.user.token,
    creating: state.publish.creating,
  }), {newTag})
@reduxForm({
  form: 'tag',
  fields: ['tagName'],
  validate: tagValidation
})
export default class TagCreate extends Component {
  static propTypes = {
    value: PropTypes.array,
    type: PropTypes.string,
    error: PropTypes.any,
    touched: PropTypes.bool,
    availableTags: PropTypes.array,
    gettingTag: PropTypes.bool,
    getTagError: PropTypes.any,
    fields: PropTypes.object.isRequired,
    creating: PropTypes.bool,
    handleSubmit: PropTypes.func.isRequired,
    onCancelCreate: PropTypes.func.isRequired,
    newTag: PropTypes.func.isRequired,
    token: PropTypes.string.isRequired,
    newTagError: PropTypes.any
  }

  onCreateTagSubmit = (data) => {
    const {creating, fields: {tagName: {valid}}} = this.props;
    if (!creating && valid) {
      this.props.handleSubmit(this.handleNewTagSubmit)(data);
    }

  }

  handleNewTagSubmit = (data) => {
    this.props.newTag({...data, token: this.props.token});
  }
  render() {
    // !!!这里直接从TagEditor里获取样式
    const styles = require('../TagEditor/TagEditor.scss');
    const { newTagError, availableTags, error, fields: {tagName}, creating, ...others} = this.props;
    return (
      <div className={styles.createTag}>
        <TextInput autoFocus label="创建标签" placeholder="请输入2-5个字的标签" {...tagName} serverError={newTagError || error}/>
        <div className={styles.controls}>
          <NormalButton onClick={this.props.onCancelCreate}>
            取消创建
          </NormalButton>
          <NormalButton onClick={this.onCreateTagSubmit}>
            {creating ? <Spinner/> : '创建标签'}
          </NormalButton>
        </div>
      </div>
    );
  }
}
