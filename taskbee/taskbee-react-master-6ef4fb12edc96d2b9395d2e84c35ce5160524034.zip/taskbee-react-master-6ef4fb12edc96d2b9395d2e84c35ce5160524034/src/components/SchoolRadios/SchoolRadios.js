import React, {Component, PropTypes} from 'react';

export default class SchoolRadios extends Component {
  static propTypes = {
    value: PropTypes.any,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    checked: PropTypes.bool,
    serverError: PropTypes.string,
  }

  render() {
    const styles = require('./SchoolRadios.scss');
    const { serverError, value, error, touched, active, checked, ...others} = this.props;
    let outerClass = styles.schoolRadio;
    if (active) {
      outerClass = outerClass + ' ' + styles.active;
    }
    if (error && touched) {
      outerClass = outerClass + ' ' + styles.error;
    }
    return (
      <div className={outerClass}>
        <p>请点选后提交</p>
        <div className={styles.radio}>
          <input tabIndex="0" name="school" type="radio" id="sex-male" value="0" checked={value === '0' ? 'checked' : ''} {...others} />
          <label htmlFor="sex-male" className={styles.radioLabel}>同济大学嘉定校区</label>
        </div>
        <div className={styles.radio}>
          <input tabIndex="1" name="school" type="radio" id="sex-female" value="1" checked={value === '1' ? 'checked' : ''} {...others} />
          <label htmlFor="sex-female" className={styles.radioLabel}>同济大学本部校区</label>
        </div>
        {serverError && <div className={styles.errorMsg}>{serverError}</div>}
        {!serverError && error && touched && (others.dirty || !active) && <div className={styles.errorMsg}>{error}</div>}
      </div>
    ); /* eslint eqeqeq: 0 */
  }
}
