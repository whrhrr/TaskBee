import React, {Component, PropTypes} from 'react';

export default class PasswordInput extends Component {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.string
  }

  state = {type: 'password'}

  onRevealClick = () => {
    if (this.state.type === 'password') {
      this.setState({type: 'text'});
    } else {
      this.setState({type: 'password'});
    }
  }

  render() {
    // 使用TextInput样式
    const styles = require('./PasswordInput.scss');
    const { serverError, label, placeholder, value, error, touched, active, ...others} = this.props;
    const { type } = this.state;
    let outerClass = styles.textInput;
    if (active) {
      outerClass = outerClass + ' ' + styles.active;
    }
    if (error && touched) {
      outerClass = outerClass + ' ' + styles.error;
    }
    return (
      <div className={outerClass}>
        <label>{label}</label>
        <input type={type} value={value} placeholder={placeholder} {...others}/>
        <button type="button" className={styles.revealPassword} onClick={this.onRevealClick}>
          <div className={type === 'password' ? 'icon-eye-slash' : 'icon-eye'}></div>
        </button>
        {serverError && <div className={styles.errorMsg}>{serverError}</div>}
        {!serverError && error && touched && (others.dirty || !active) && <div className={styles.errorMsg}>{error}</div>}
      </div>
    );
  }
}
