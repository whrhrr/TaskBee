import React, {Component, PropTypes} from 'react';
import {throttle} from 'utils/componentEvents';
import memoize from 'lru-memoize';

const DEFAULT_ELEMENT_HEIGHT = 50;
const actualTransform = memoize(10)((move, elementHeight, spring, friction) => {
  const actualMove = move / friction;
  if (actualMove <= elementHeight) {
    return actualMove;
  }
  // const force = elementHeight / (Math.sqrt(spring * elementHeight));
  // const force = elementHeight / friction / Math.sqrt(spring * elementHeight);
  return Math.sqrt(spring * (actualMove - elementHeight)) + elementHeight;

});

export default class PullToAction extends Component {
  static propTypes = {
    children: PropTypes.any, // 正常的元素
    spring: PropTypes.number, // 用来给一点弹出的空间
    friction: PropTypes.number, // 摩擦力，减慢页面滑动速度
    elementHeight: PropTypes.number, // 隐藏内容的高度
    // onPulled: PropTypes.func, // 拉出隐藏内容操作
    pullTrigger: PropTypes.number, // 拉出隐藏内容的阀值
    onConfirm: PropTypes.func, // 释放后确认操作
    doingWork: PropTypes.bool, // 是否在进行操作
    normal: PropTypes.any,
    working: PropTypes.any,
    pulled: PropTypes.any,
    style: PropTypes.object,
    scrollElem: PropTypes.object,
  }
  state = {
    pullTransform: 0,
  }

  componentDidMount() {
    this.hookEvents();
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.doingWork && !nextProps.doingWork) {
      // 恢复
      this.setState({pullTransform: 0});
      this.hookEvents();
    } else if (!this.props.doingWork && nextProps.doingWork) {
      // 在载入了，别瞎闹
      this.unhookEvents();
    }
  }

  componentWillUnmount() {
    this.unhookEvents();
  }

  onTouchStart = (ev) => {
    this.touchY = parseInt(ev.changedTouches[0].clientY, 10);
    this.initialScroll = this.scrollY();
  }

  onTouchMove = throttle((ev) => {
    const {friction = 2, spring = 10, elementHeight = DEFAULT_ELEMENT_HEIGHT} = this.props;
    const touchY = parseInt(ev.changedTouches[0].clientY, 10);
    const scroll = this.scrollY();
    const move = touchY - this.touchY - this.initialScroll;
    if ( this.state.pullTransform > 0 || scroll === 0 && move > 0) {
      ev.preventDefault();
      const actualMove = actualTransform(move, elementHeight, spring, friction);
      this.setState({pullTransform: actualMove});
    }
  }, 60)

  onTouchEnd = () => {
    if (this.state.pullTransform > this.props.pullTrigger) {
      // 确认操作
      if (this.props.onConfirm) this.props.onConfirm();
      this.setState({pullTransform: this.props.elementHeight || DEFAULT_ELEMENT_HEIGHT});
    } else {
      this.setState({pullTransform: 0});
    }
  }

  hookEvents = () => {
    setTimeout(() => {
      const elem = this.props.scrollElem || window;
      elem.addEventListener('touchstart', this.onTouchStart);
      elem.addEventListener('touchmove', this.onTouchMove);
      elem.addEventListener('touchend', this.onTouchEnd);
    }, 500);
  }

  unhookEvents = () => {
    const elem = this.props.scrollElem || window;
    elem.removeEventListener('touchstart', this.onTouchStart);
    elem.removeEventListener('touchmove', this.onTouchMove);
    elem.removeEventListener('touchend', this.onTouchEnd);
  }

  scrollY = () => {
    if (this.props.scrollElem) {
      return this.props.scrollElem.scrollTop;
    }
    return window.pageYOffset;
  }

  render() {
    const {style, normal, pulled, working, pullTrigger = 30, doingWork, children, elementHeight = DEFAULT_ELEMENT_HEIGHT, ...props} = this.props;
    const {pullTransform} = this.state;
    const styles = require('./PullToAction.scss');
    const translate = `translate3d(0, ${pullTransform}px, 0)`;
    const translateElem = `translate3d(0, -${elementHeight}px, 0)`;
    let element;
    if (doingWork) {
      element = working;
    } else if (pullTransform > pullTrigger) {
      element = pulled;
    } else if (pullTransform === 0 ) {
      element = <span className={styles.initial}>normal</span>;
    } else {
      element = normal;
    }
    return (
      <div {...props} style={{...style, position: 'relative', transform: translate, WebkitTransform: translate, msTransform: translate, MozTransform: translate, OTransform: translate}}>
        <div className={styles.element} style={{ transform: translateElem, WebkitTransform: translateElem, msTransform: translateElem, MozTransform: translateElem, OTransform: translateElem }}>
          {element}
        </div>
        {children}
      </div>
    );
  }
}
