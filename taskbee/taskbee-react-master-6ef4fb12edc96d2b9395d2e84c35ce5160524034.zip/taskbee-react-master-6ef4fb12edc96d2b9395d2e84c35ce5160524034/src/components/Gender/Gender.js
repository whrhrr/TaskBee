import React, {PropTypes} from 'react';
import {genderToClassName} from 'utils/dataMap';

const Gender = (props) => {
  const {gender} = props;
  return (
    <span className={genderToClassName[gender] + (props.className ? ' ' + props.className : '')}>
    </span>
  );
};
Gender.propTypes = {
  gender: PropTypes.number,
  className: PropTypes.string,
};

export default Gender;
