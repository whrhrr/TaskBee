import React, {Component, PropTypes} from 'react';

export default class ImagePicker extends Component {
  static propTypes = {
    onSetImage: PropTypes.func.isRequired,
    index: PropTypes.number.isRequired,
    src: PropTypes.string,
  };

  onFileChange = (ev) => {

    if ( ev.target.files && ev.target.files[0] ) {
      const file = ev.target.files[0];
      const FR = new FileReader();
      FR.onload = (ev2) => {
        this.props.onSetImage({
          src: ev2.target.result,
          path: file
        });
      };
      FR.readAsDataURL(file);
    }
  }

  render() {
    const styles = require('./ImagePicker.scss');
    const {index, src} = this.props;
    return (
      <div className={styles.imagePicker}>
        <input id={'imagePicker' + index} type="file" accept="image/*" onChange={this.onFileChange}/>
        <label htmlFor={'imagePicker' + index}>{src ? <img src={src}/> : '+'}</label>
      </div>
    );
  }

}
