import React, {
  Component,
  PropTypes,
} from 'react';

export default class Downloads extends Component {
  state = {
    isWechat: false,
    closed: false,
  }
  /*
  componentDidMount() {
    const ua = window.navigator.userAgent;
    if (ua.toLowerCase().indexOf('micromessenger') > -1) {
      this.setState({isWechat: true}); /* eslint react/no-did-mount-set-state: 0 */
  //  }
  // }

  onClose = () => {
    this.setState({closed: true});
  };

  render() {
    const styles = require('./Downloads.scss');
    const logo = require('./logo.png');
    if (this.state.closed) return null;
    return (
      <div className={styles.downloads}>
        {/* this.state.isWechat ? <p className={styles.inWechat}>您现在在微信中, 请在右上角菜单中选择浏览器中打开下载哦~</p> : null */}

        <img className={styles.logo} src={logo}/>
        <div className={styles.wordsPannel}>
          <p className={styles.title}>精彩尽在APP内</p>
          <p className={styles.description}>名校技能经验分享平台<br/>高校老司机等你来</p>
        </div>
        <a className={styles.link} href="http://a.app.qq.com/o/simple.jsp?pkgname=com.taskbee" target="blank">
          打开蜂房APP
        </a>
        { this.props.stick ? null :
          <div className={styles.close} onClick={this.onClose}>
            X
          </div>
        }
      </div>
    );
  }
}

Downloads.propTypes = {
  stick: PropTypes.bool,
};

export default Downloads;
