import React, {Component, PropTypes} from 'react';

export default class TextInput extends Component {
  static propTypes = {
    placeholder: PropTypes.string,
    value: PropTypes.string,
    label: PropTypes.string,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.string,
    maxCount: PropTypes.number
  }

  render() {
    const styles = require('./LongTextInput.scss');
    const { label, maxCount, serverError, placeholder, value, error, touched, active, ...others} = this.props;
    let outerClass = styles.longTextInput;
    if (active) {
      outerClass = outerClass + ' ' + styles.active;
    }
    if (error && touched) {
      outerClass = outerClass + ' ' + styles.error;
    }
    return (
      <div className={outerClass}>
        {label && <label>{label}</label>}
        <div className={styles.inputArea}>
          <textarea value={value} placeholder={placeholder} {...others}/>
          <div className={styles.wordsCount}>
            {value ? value.length : 0} / {maxCount}
          </div>
          {serverError && <div className={styles.errorMsg}>{serverError}</div>}
        </div>
        {!serverError && error && touched && (others.dirty || !active) && <div className={styles.errorMsg}>{error}</div>}

      </div>
    );
  }
}
