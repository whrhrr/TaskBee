import React, {Component, PropTypes} from 'react';
import {reduxForm} from 'redux-form';
import commentValidation from '../CommentInput/CommentValidation';
import {connect} from 'react-redux';
import {newComment} from 'redux/modules/pollen';
import {Spinner} from 'components';

@connect(
  (state, props) => ({
    serverError: state.pollen[props.postId].commentError,
    commentSubmitting: state.pollen[props.postId].commentSubmitting,
    token: state.user.token,
  }), {newComment})
@reduxForm({
  form: 'pollen',
  fields: ['comment'],
  validate: commentValidation
})
export default class CommentInput extends Component {
  static propTypes = {
    postId: PropTypes.string.isRequired,
    touched: PropTypes.bool,
    active: PropTypes.string,
    serverError: PropTypes.any,
    error: PropTypes.any,
    commentSubmitting: PropTypes.bool,
    handleSubmit: PropTypes.func.isRequired,
    onCommentClose: PropTypes.func.isRequired,
    newComment: PropTypes.func.isRequired,
    fields: PropTypes.object.isRequired,
    to: PropTypes.object
  }

  onSendClick = (data) => {
    data.preventDefault();
    const {commentSubmitting, fields: {comment: {valid}}} = this.props;
    if (!commentSubmitting && valid) {
      this.props.handleSubmit(this.handleNewComment)(data);
    }
  }

  handleNewComment = (data) => {
    const {postId, to, token} = this.props;
    this.props.newComment({
      postId,
      to: to ? to.id : null,
      body: data.comment,
      token
    });
  }

  render() {
    // 引用textinput
    const styles = require('../CommentInput/CommentInput.scss');
    const { to, commentSubmitting, onCommentClose, serverError, fields: { comment: rawComment} } = this.props;
    const { error, valid, dirty, active, touched, ...comment} = rawComment;
    let outerClass = styles.textInput;
    if (active) {
      outerClass = outerClass + ' ' + styles.active;
    }
    if ((error || serverError) && touched) {
      outerClass = outerClass + ' ' + styles.error;
    }
    return (
      <form className={outerClass} onSubmit={this.onSendClick}>
        <button type="button" className={styles.close} onClick={onCommentClose}><span className="icon-cross-mark"></span></button>
        <input autoComplete="off" autoFocus placeholder={to ? ('@' + to.username ) : '发个评论'} type="text" {...comment}/>
        <button type="submit" className={styles.send} disabled={commentSubmitting}>
          {
            commentSubmitting ? <Spinner/>
            :
            <span className="icon-paper-plane"></span>
          }
        </button>
        {serverError && <div className={styles.errorMsg}>{serverError.message || serverError}</div>}
        {!serverError && error && touched && (dirty || !active) && <div className={styles.errorMsg}>{error}</div>}
      </form>
    );
  }
}
