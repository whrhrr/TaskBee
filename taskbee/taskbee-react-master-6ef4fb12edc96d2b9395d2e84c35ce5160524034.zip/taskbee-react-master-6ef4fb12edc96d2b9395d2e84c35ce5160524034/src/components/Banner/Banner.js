import React, {Component, PropTypes} from 'react';
import { BackButton } from 'components';

export default class InfoBar extends Component {
  static propTypes = {
    main: PropTypes.any,
    left: PropTypes.any,
    right: PropTypes.any
  }

  render() {
    const styles = require('./Banner.scss');
    const {left, main, right} = this.props;
    return (
      <nav className={styles.banner}>
        <div className={styles.left}>
          {left === undefined ? <BackButton/> : left}
        </div>
        <div className={styles.main}>
          {main}
        </div>
        <div className={styles.right}>
          {right}
        </div>
      </nav>
    );
  }
}
