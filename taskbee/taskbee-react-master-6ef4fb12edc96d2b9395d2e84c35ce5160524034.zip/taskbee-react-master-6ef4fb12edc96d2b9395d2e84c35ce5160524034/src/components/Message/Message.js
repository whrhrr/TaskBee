import React, {PropTypes} from 'react';
import {Avatar} from 'components';
const Message = (props) => {
  const styles = require('./Message.scss');
  const {message, me, avatar} = props;
  return (
    <div className={styles.message + (me ? (' ' + styles.me) : '')}>
      <div>{message}</div>
      <Avatar src={avatar} size={40}/>
    </div>
  );
};

Message.propTypes = {
  me: PropTypes.bool,
  avatar: PropTypes.string,
  message: PropTypes.string.isRequired,
};


export default Message;
