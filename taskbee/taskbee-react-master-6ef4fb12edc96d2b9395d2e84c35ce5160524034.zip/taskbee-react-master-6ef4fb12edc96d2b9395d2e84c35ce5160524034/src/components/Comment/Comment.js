import React, {PropTypes} from 'react';
import {Avatar, Gender} from 'components';
import moment from 'moment';

const Comment = (props) => {
  const styles = require('./Comment.scss');
  const {pushState, from, body, onCommentSelect, to} = props;
  const date = moment(props.date).format('MM/D HH:mm');
  const onAvatarClick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    pushState(null, '/users/' + from._id);
  };
  return (
    <div className={styles.comment} onClick={onCommentSelect(from)}>
      <Avatar src={from.avatar} size={42} onClick={onAvatarClick}/>
      <div className={styles.message}>
        <p>{from.username}<Gender gender={from.gender}/></p>
        <p>{to && <span className={styles.at}>@{to.username}</span>}{body}</p>
      </div>
      <div className={styles.date}>
        {date}
      </div>
    </div>
  );
};
Comment.propTypes = {
  date: PropTypes.string.isRequired,
  onCommentSelect: PropTypes.func,
  from: PropTypes.any.isRequired,
  to: PropTypes.any,
  body: PropTypes.string.isRequired,
  pushState: PropTypes.func.isRequired,
};

export default Comment;
