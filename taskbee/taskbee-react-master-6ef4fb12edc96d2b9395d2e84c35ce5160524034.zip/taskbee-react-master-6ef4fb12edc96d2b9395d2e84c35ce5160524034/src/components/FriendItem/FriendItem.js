import React, {PropTypes} from 'react';
import {Link} from 'react-router';
import {Avatar, Ripple, Gender} from 'components';

const FriendItem = (props) => {
  const styles = require('./FriendItem.scss');
  const {_id, username, avatar, gender} = props;
  return (
    <Link to={'/chat/' + _id} className={styles.friendItem}>
      <Avatar src={avatar} size={46}/>
      <div className={styles.info}>
        <div className={styles.username}>{username} <Gender gender={gender}/></div>
      </div>
      <Ripple/>
    </Link>
  );
};

FriendItem.propTypes = {
  _id: PropTypes.string,
  avatar: PropTypes.string,
  username: PropTypes.string,
  gender: PropTypes.number,
};

export default FriendItem;
