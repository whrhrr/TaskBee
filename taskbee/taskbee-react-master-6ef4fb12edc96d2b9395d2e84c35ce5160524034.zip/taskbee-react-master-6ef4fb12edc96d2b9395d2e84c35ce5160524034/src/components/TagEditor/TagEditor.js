import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {NormalButton, Spinner, Tag, TagCreate} from 'components';
import {newTag} from 'redux/modules/publish';

@connect(
  state => {
    let value;
    if (state.form && state.form.create && state.form.create.tags) {
      value = state.form.create.tags.value;
    } else value = [];
    return {
      availableTags: state.publish.tags,
      value
    };
  }, {newTag})
export default class TagEditor extends Component {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.array,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    serverError: PropTypes.any,
    availableTags: PropTypes.array,
    gettingTag: PropTypes.bool,
    getTagError: PropTypes.any,
    onBlur: PropTypes.func.isRequired,
  }

  state = {
    showTags: true,
    createTagOpen: false
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.error && !this.props.error) {
      this.setState({showTags: true});
    }
  }

  onShowClick = () => {
    this.setState({showTags: true});
  }
  onShowCloseClick = () => {
    this.setState({showTags: false});
  }
  onAddTag = (tag) => {
    return () => {
      this.props.onBlur(this.props.value.concat(tag));
    };
  }
  onCloseTag = (index) => {
    return () => {
      this.props.onBlur(this.props.value.slice(0, index).concat(this.props.value.slice(index + 1)));
    };
  }
  onCreateTagClick = () => {
    this.setState({createTagOpen: true});
  }
  onCancelCreate = () => {
    this.setState({createTagOpen: false});
  }

  render() {
    const styles = require('./TagEditor.scss');
    const { gettingTag, getTagError, availableTags,
      serverError, type, placeholder, value, error, touched,
      ...others} = this.props;
    const count = value ? value.length : 0;

    const outerClass = styles.tagEditor;
    const realAvailableTags = value ? availableTags.filter(tag => !value.some(choosen => choosen.name === tag.name)) : availableTags;
    return (
      <div className={outerClass}>
        <label>标签</label>
        {error && touched && <p className={styles.outerError}>{error}</p>}
        {
          count === 0 ? <p className={styles.placeholder} onClick={this.onShowClick}>请选择至少一个标签，方便你的任务被了解</p> :
          value.map((tag, index) => <Tag key={tag.name} name={tag.name} canClose onClick={this.onCloseTag(index)}/>)
        }
        {
          !this.state.showTags && count < 5 && <button type="button" onClick={this.onShowClick} className={styles.addButton}><div className="icon-plus-circle"/></button>
        }
        <div className={styles.tagsCount}>
          {value ? value.length : 0} / 5
        </div>
        {
          this.state.showTags && <div className={styles.moreTags}>
            { gettingTag ? <Spinner/> :
              <ul className={styles.tags}>
                {
                  realAvailableTags.map(tag => <Tag key={tag.name} name={tag.name} onClick={this.onAddTag(tag)}/>)
                }
              </ul>
            }
            { getTagError && <div className={styles.erroMsg}>{getTagError.errorMsg || getTagError}</div>}
            {/* <div className={styles.more}>
              更多tag
            </div> */}
            {
              this.state.createTagOpen ?
              <TagCreate onCancelCreate={this.onCancelCreate}/>
              :
              <div className={styles.controls}>
                <NormalButton onClick={this.onShowCloseClick}>
                  关闭浏览
                </NormalButton>
                <NormalButton onClick={this.onCreateTagClick}>
                  新建标签
                </NormalButton>
              </div>
            }

          </div>
        }
        {serverError && <div className={styles.errorMsg}>{serverError.message || serverError}</div>}
      </div>
    );
  }
}
