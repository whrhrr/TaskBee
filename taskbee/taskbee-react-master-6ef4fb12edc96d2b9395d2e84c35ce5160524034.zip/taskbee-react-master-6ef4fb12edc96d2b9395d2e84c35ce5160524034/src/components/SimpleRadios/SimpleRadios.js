import React, {Component, PropTypes} from 'react';

export default class TextInput extends Component {
  static propTypes = {
    value: PropTypes.string,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.any,
  }

  render() {
    const styles = require('./SimpleRadios.scss');
    const { serverError, value, error, touched, active, ...others} = this.props;
    let outerClass = styles.simpleRadio;
    if (active) {
      outerClass = outerClass + ' ' + styles.active;
    }
    if (error && touched) {
      outerClass = outerClass + ' ' + styles.error;
    }
    return (
      <div className={outerClass}>
        <p>请点选后提交</p>
        <div className={styles.radio}>
           <input type="radio" id="sex-male" {...others} value="0" checked={value === '0'}/>
          <label htmlFor="sex-male" className={styles.radioLabel}>男</label>
        </div>
        <div className={styles.radio}>
          <input type="radio" id="sex-female" {...others} value="1" checked={value === '1'}/>
          <label htmlFor="sex-female" className={styles.radioLabel}>女</label>
        </div>
        {!serverError && error && touched && (others.dirty || !active) && <div className={styles.errorMsg}>{error}</div>}
      </div>
    );
  }
}
