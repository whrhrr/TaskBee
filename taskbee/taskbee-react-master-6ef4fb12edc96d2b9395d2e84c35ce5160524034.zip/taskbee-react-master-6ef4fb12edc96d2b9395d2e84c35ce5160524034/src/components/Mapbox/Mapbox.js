import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {locsOnMapSelector} from 'redux/modules/lists';
import equals from 'shallowequal';

const styles = require('./Mapbox.scss');
const defaultAvatar = require('../../../static/defaultAvatar.jpg');

const zoomTable = {
  0: 156412,
  1: 78206,
  2: 39103,
  3: 19551,
  4: 9776,
  5: 4888,
  6: 2444,
  7: 1222,
  8: 610.984,
  9: 305.492,
  10: 152.746,
  11: 76.373,
  12: 38.187,
  13: 19.093,
  14: 9.547,
  15: 4.773,
  16: 2.387,
  17: 1.193,
  18: 0.596,
  19: 0.298
};

// 生成一个stop数组
function meterToPixel(meter) {
  const stops = [];
  for (let index = 10; index < 20; index++) {
    stops.push([index, meter / zoomTable[index]]);
  }
  return stops;
}

@connect(locsOnMapSelector, {})
export default class Mapbox extends Component {
  static propTypes = {
    time: PropTypes.number,
    longitude: PropTypes.number,
    latitude: PropTypes.number,
    className: PropTypes.string,
    needCenter: PropTypes.bool,
    updateCenter: PropTypes.func,
    locations: PropTypes.array,
    pushState: PropTypes.func,
    onTaskClick: PropTypes.func,
    pollenLocations: PropTypes.array,
    deadPollenLocations: PropTypes.array,
    place: PropTypes.array,
  }

  state = {
    mapLoaded: false
  }

  componentDidMount() {
    console.log('mount map');
    const {longitude, latitude, locations, pollenLocations, deadPollenLocations, pushState} = this.props;
    if (pushState) {
      // 先暴露pushState到window中，记得防治内存泄露
      window.__pushState = pushState;
    }

    // 初始化地图
    const {mapboxgl} = window;
    // TODO min max zoom设定无效
    const config = {
      container: this.refs.mapAnchor,
      maxZoom: 18,
      minZoon: 12,
      minzoom: 12,
      maxzoom: 18,
      center: [longitude, latitude],
      zoom: 14,
      style: 'mapbox://styles/xiaobu/cijcd4giu00dgbkku5ymwdjy8',
    };
    mapboxgl.accessToken = 'pk.eyJ1IjoieGlhb2J1IiwiYSI6ImNpamNjcTVhajAwMXV2MW0wbDIwNmVoM2wifQ.K-QHYmExydp-t7z8YCqfKw';
    this.map = new mapboxgl.Map(config);

    // 定义我的位置数据
    this.myPos = new mapboxgl.GeoJSONSource({
      data: {
        type: 'Point',
        coordinates: [
          longitude || 121.2103,
          latitude || 31.299,
        ]
      }
    });
    // 定义任务数据源
    this.tasks = new mapboxgl.GeoJSONSource({
      data: {
        type: 'FeatureCollection',
        features: locations,
      }
    });

    // 定义花粉点数据源
    this.pollens = new mapboxgl.GeoJSONSource({
      data: {
        type: 'FeatureCollection',
        features: pollenLocations,
      }
    });

    this.deadPollens = new mapboxgl.GeoJSONSource({
      data: {
        type: 'FeatureCollection',
        features: deadPollenLocations,
      }
    });

    this.map.on('style.load', () => {
      // 载入完成
      console.log('style.load');
      this.setState({mapLoaded: true});

      // 标注我的位置和探测器范围
      this.map.addSource('myPos', this.myPos);
      this.map.addLayer({
        id: 'myPos-circle',
        type: 'circle',
        source: 'myPos',
        paint: {
          'circle-radius': {
            stops: meterToPixel(3000)
          },
          'circle-color': '#FEAC36',
          'circle-opacity': 0.08,
        }
      });
      this.map.addLayer({
        id: 'myPos-center',
        type: 'circle',
        source: 'myPos',
        paint: {
          'circle-radius': 5,
          'circle-color': '#FEAC36',
          'circle-opacity': 0.9
        }
      });

      // 地图常驻中心点标注
      if (this.props.needCenter) {
        this.map.on('move', ::this.onMove);
        this.centerPos = this.map.getCenter().toArray();
        this.centerPosSource = new mapboxgl.GeoJSONSource({
          data: {
            type: 'Point',
            coordinates: this.centerPos
          }
        });
        this.map.addSource('centerPosSource', this.centerPosSource);
        this.map.addLayer({
          id: 'centerPosSource',
          type: 'symbol',
          source: 'centerPosSource',
          layout: {
            'icon-image': 'marker-24',
          }
        });
        return;
      }

      if (this.props.place) {
        // 标注醒目地点
        this.place = new mapboxgl.GeoJSONSource({
          data: {
            type: 'Point',
            coordinates: this.props.place || [0, 0],
          }
        });
        this.map.addSource('place', this.place);
        this.map.addLayer({
          id: 'placeLayer',
          type: 'symbol',
          source: 'place',
          layout: {
            'icon-image': 'marker-24',
          }
        });
        return;
      }

      // 任务＋活动所有点，用marker表示
      this.map.addSource('tasks', this.tasks);

      // 任务圈圈
      this.map.addLayer({
        id: 'tasksMarker',
        type: 'circle',
        source: 'tasks',
        interactive: true,
        paint: {
          'circle-radius': {
            stops: [[6, 4], [20, 10]]
          },
          'circle-color': '#86C9EC',
          'circle-opacity': 0.6,
        },
        filter: [
          'any',
          [
            'all',
            ['==', 'aboutMe', true],
          ],
          [
            'all',
            ['==', 'state', 0],
          ],
        ]
      });

      this.map.addLayer({
        id: 'eventsCircle',
        type: 'symbol',
        source: 'tasks',
        interactive: true,
        layout: {
          'icon-image': 'marker-24',
        },
        filter: ['==', 'type', 1]
      });

      // 任务中心点标记
      this.map.addLayer({
        id: 'tasksMarkerCenter',
        type: 'circle',
        source: 'tasks',
        paint: {
          'circle-radius': {
            stops: [[6, 2], [20, 5]]
          },
          'circle-color': '#5BB05F',
          'circle-opacity': 0.9,
        },
        filter: [
          'all',
          ['==', 'aboutMe', false],
          ['==', 'state', 0],
          ['!=', 'type', 1],
        ],
      });

      // 特别标记我的任务
      this.map.addLayer({
        id: 'tasksMarkerMe',
        type: 'circle',
        source: 'tasks',
        interactive: true,
        paint: {
          'circle-radius': {
            stops: [[6, 3], [20, 6]]
          },
          'circle-color': '#FEB936',
          'circle-opacity': 1,
        },
        filter: [
          'all',
          ['==', 'aboutMe', true],
          ['!=', 'type', 1],
        ],
      });

      // 花粉点标注
      this.map.addSource('pollens', this.pollens);
      this.map.addSource('deadPollens', this.deadPollens);
      this.map.addLayer({
        id: 'littlePollens',
        type: 'circle',
        source: 'pollens',
        paint: {
          'circle-radius': {
            stops: [[6, 0.6], [20, 6]]
          },
          'circle-color': '#E6381F',
          'circle-opacity': 0.9,
        }
      });
      this.map.addLayer({
        id: 'littleDeadPollens',
        type: 'circle',
        source: 'deadPollens',
        paint: {
          'circle-radius': {
            stops: [[6, 0.2], [20, 4]]
          },
          'circle-color': '#FFF',
          'circle-opacity': 0.5,
        }
      });

    });

    this.map.on('click', (ev) => {
      this.map.featuresAt(ev.point, {layer: 'tasksMarker', radius: 10, includeGeometry: true}, (err, features) => {
        if (err || !features.length) return;
        const feature = features[0];
        if (this.props.onTaskClick) {
          this.props.onTaskClick(feature);
        }
        const totalTasks = features.length;
        const src = feature.properties.publisher.avatar;
        new mapboxgl.Popup()
            .setLngLat(feature.geometry.coordinates)
            .setHTML(`<div class=${styles.simpleTask} onclick="window.__pushState(null, '/tasks/${feature.properties.id}')">
              <img src="${src ? IMAGE_HOST + src + '?imageView2/1/w/42/h/42/format/jpg' : defaultAvatar}"/>
              <h3>${feature.properties.publisher.username}</h3>
              <p>${feature.properties.description}</p>
              ${totalTasks > 1 ? `<p>共${totalTasks}个任务</p>` : ''}
            </div>`)
            .addTo(this.map);
      });
    });

  }

  componentWillReceiveProps(nextProps) {
    if (equals(this.props, nextProps)) return; // 并没有用，需要immutableJS如果效率太差

    if (!this.panned && (this.map && (this.props.longitude !== nextProps.longitude) || (this.props.latitude !== nextProps.latitude))) {
      this.panned = true;
      this.map.panTo([nextProps.longitude, nextProps.latitude]);
    }
    if ((this.props.longitude !== nextProps.longitude) || (this.props.latitude !== nextProps.latitude)) {
      this.myPos.setData({
        type: 'Point',
        coordinates: [
          nextProps.longitude,
          nextProps.latitude,
        ]
      });
    }
    this.tasks.setData({
      type: 'FeatureCollection',
      features: nextProps.locations
    });

    this.pollens.setData({
      type: 'FeatureCollection',
      features: nextProps.pollenLocations
    });
    this.deadPollens.setData({
      type: 'FeatureCollection',
      features: nextProps.deadPollenLocations
    });
    if (nextProps.place) {
      this.place.setData({
        type: 'Point',
        coordinates: this.props.place,
      });
    }
  }

  componentWillUnmount() {
    this.map.remove();
    this.map = null;
    window.__pushState = null;
  }

  onMove() {
    // 防止rerender，存在this中
    this.centerPos = this.map.getCenter().toArray();
    this.centerPosSource.setData({
      type: 'Point',
      coordinates: this.centerPos,
    });
    if (this.props.updateCenter) {
      this.props.updateCenter(this.centerPos);
    }
  }

  onFindMeClick = () => {
    if (this.map) {
      const {longitude, latitude} = this.props;
      this.map.panTo([longitude, latitude]);
    }
  }

  render() {
    return (
      <div className={this.props.className}>
        <div ref="mapAnchor" className={styles.mapAnchor}></div>
        {this.state.mapLoaded ? (<div className={styles.findMe} onClick={this.onFindMeClick}>
            <span></span>
          </div>)
          : <div className={styles.loading}>
              <span>地图载入中</span>
            </div>

        }
      </div>
    );
  }
}
