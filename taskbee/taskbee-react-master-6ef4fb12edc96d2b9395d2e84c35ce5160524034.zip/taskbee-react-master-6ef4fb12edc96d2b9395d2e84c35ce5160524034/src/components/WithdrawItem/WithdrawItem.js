import React, {PropTypes} from 'react';
import moment from 'moment';
import {Ripple} from 'components';

const OrderItem = (props) => {
  const styles = require('./WithdrawItem.scss');
  const {realname, price, createdDate, email} = props;
  const date = moment(createdDate).format('MM/D HH:mm');

  return (
    <div className={styles.orderItem}>
      <div className={styles.clearfix}>
        <div className={styles.price}>¥{price}</div>
        <div className={styles.date}>{date}</div>
      </div>
      <div className={styles.clearfix}>
        <div className={styles.state}>支付宝账户：{email || '无'}</div>
        <div className={styles.email}>姓名{realname || '无'}</div>
      </div>
      <Ripple/>
    </div>
  );
};

OrderItem.propTypes = {
  price: PropTypes.number,
  createdDate: PropTypes.string,
  email: PropTypes.string,
  realname: PropTypes.string,
};


export default OrderItem;
