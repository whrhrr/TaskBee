import React, {Component, PropTypes} from 'react';
import {Modal} from 'components';
export default class ShareButton extends Component {
  static propTypes = {
    pathname: PropTypes.string.isRequired,
  }

  state = {
    shareOpen: false,
  }

  onShareClick = () => {
    this.setState({shareOpen: true});
  }

  onShareCloseClick = () => {
    this.setState({shareOpen: false});
  }

  onInputClick(event) {
    event.target.setSelectionRange(0, event.target.value.length);
  }

  render() {
    const styles = require('./ShareButton.scss');

    return (
      <div>
        <div className={styles.shareButton} onClick={this.onShareClick}>分享</div>
        <Modal isOpen={this.state.shareOpen} closeTimeoutMS={200} onRequestClose={this.onShareCloseClick}>
          <div className={styles.modal}>
            <div className={styles.modalInfo}>
            <h2>分享</h2>
            <p>如果在浏览器中<br/>可以使用浏览器的分享功能～</p>
            <p>或者可以将链接分享出去</p>
            <input onClick={this.onInputClick} type="text" value={'https://taskbee.cn' + this.props.pathname}/>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}
