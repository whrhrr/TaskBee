import React, {Component, PropTypes} from 'react';
import { ReplaceLink } from 'components';

export default class SubtleButtons extends Component {
  static propTypes = {
    leftText: PropTypes.any,
    leftTo: PropTypes.string,
    rightText: PropTypes.any,
    rightTo: PropTypes.string,
  }
  render() {
    const styles = require('./SubtleButtons.scss');
    const {leftText, leftTo, rightText, rightTo} = this.props;
    return (
      <div className={styles.subtleButtons}>
        {leftText && <ReplaceLink className={styles.left} to={leftTo}>{leftText}</ReplaceLink>}
        {rightText && <ReplaceLink className={styles.right} to={rightTo}>{rightText}</ReplaceLink>}
      </div>
    );
  }
}
