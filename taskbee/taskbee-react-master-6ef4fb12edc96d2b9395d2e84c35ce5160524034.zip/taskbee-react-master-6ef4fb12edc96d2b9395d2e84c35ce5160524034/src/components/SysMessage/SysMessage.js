import React, {PropTypes} from 'react';
import moment from 'moment';

const Message = (props) => {
  const styles = require('./SysMessage.scss');
  const {message, href, pushState, type} = props;
  const date = moment(props.createdAt).format('MM/D HH:mm');
  function onClick() {
    if (type === 'vote') {
      pushState(null, '/users/' + href);
    } else if (type === 'postComment') {
      pushState(null, '/pollens/' + href);
    } else if (type === 'friend') {
      pushState(null, '/chat/' + href);
    } else if (type === 'skillDetail') {
      pushState(null, '/skills/' + href);
    } else pushState(null, '/tasks/' + href);
  }
  return (
    <div className={styles.sysMessage} onClick={onClick}>
      <div className={styles.message}>{message}</div>
      <div className={styles.date}>{date}</div>
    </div>
  );
};

Message.propTypes = {
  type: PropTypes.string,
  href: PropTypes.string,
  createdAt: PropTypes.string,
  message: PropTypes.string.isRequired,
  pushState: PropTypes.func.isRequired,
};


export default Message;
