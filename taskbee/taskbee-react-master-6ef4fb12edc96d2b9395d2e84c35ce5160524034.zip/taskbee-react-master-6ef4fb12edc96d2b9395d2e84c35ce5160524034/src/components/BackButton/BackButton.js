import React, {Component, PropTypes} from 'react';
import { goBack, pushState } from 'redux-router';
import {connect} from 'react-redux';
import {Ripple} from 'components';

@connect(
  state => {
    return {
      lastLocation: state.misc.lastLocation,
      currentLocation: state.misc.currentLocation,
    };},
  {goBack, pushState})
export default class BackButton extends Component {
  static propTypes = {
    goBack: PropTypes.func.isRequired,
    pushState: PropTypes.func.isRequired,
    lastLocation: PropTypes.string,
    currentLocation: PropTypes.string,
    forceLocation: PropTypes.string,
  }

  componentDidMount() {
    window.addEventListener('keydown', this.onKeyDown);
  }

  componentWillUnmount() {
    window.removeEventListener('keydown', this.onKeyDown);
  }

  onKeyDown = (event) => {
    if (event.keyCode === 27 ) {
      this.onClick();
    }
  }

  onClick = () => {
    const {lastLocation, currentLocation, forceLocation} = this.props;
    if (forceLocation) {
      this.props.pushState(null, forceLocation);
    } else if (lastLocation === currentLocation) {
      this.props.pushState(null, '/');
    } else this.props.goBack();
  }

  render() {
    const styles = require('./BackButton.scss');
    return (
      <button type="button" className={styles.backButton + ' icon-chevron-left'} onClick={this.onClick}>
        <Ripple/>
      </button>
    );
  }
}
