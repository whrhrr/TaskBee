import React, {
  Component,
  PropTypes,
} from 'react';

import {Link} from 'react-router';

import {
 Avatar, Tag, Gender,
} from 'components'; // Tag,

import {Map} from 'immutable';

import {calcCrow} from 'utils/dataProcessor';

/*
const stylesA = {
  skillItemMain: {
    backgroundColor: '#fff',
    marginVertical: 4,
    marginHorizontal: config.normalPadding - 5,
    borderWidth: config.borderWidth,
    // borderBottomWidth: config.borderWidth,
    borderColor: config.colorVerySubtle,
    borderRadius: config.borderRadius,
  },
  user: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fcfcfc',
    paddingHorizontal: config.normalPadding,
    paddingVertical: 9,
  },
  userSection: {
    marginLeft: 9,
    flex: 1,
  },
  titleSection: {
    flexDirection: 'row',
    marginBottom: 3,
    alignSelf: 'stretch',
  },
  priceText: {
    color: config.brandRed,
    textAlign: 'right',
    flexWrap: 'nowrap',
  },
  realname: {
    color: config.colorMain,
  },
  signature: {
    fontSize: config.fontSmall,
  },
  content: {
    padding: config.normalPadding,
  },
  titleText: {
    fontSize: config.fontLarge,
    color: config.colorMain,
    flexDirection: 'column',
    flexWrap: 'wrap',
    flex: 1,
    fontWeight: '400',
  },
  descriptionText: {
    color: config.colorMain,
  },
  miscdiv: {
    paddingTop: 12,
  },
  miscTexts: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  misc: {
    fontSize: config.fontSmall,
    color: config.colorSubtle,
    marginRight: 9,
  },
  inlineIcon: {
    marginRight: 3,
  },
  fav: {
    marginLeft: 12,
    paddingHorizontal: 3,
    paddingVertical: 8,
  },
  favCount: {
    position: 'absolute',
    backgroundColor: '#fff',
    right: 0,
    top: 0,
    fontSize: 12,
  },
  actionIcons: {
    flexDirection:'row',
  },
  images: {
    flexDirection: 'row',
  },
  image: {
    width: 60,
    height: 60,
    marginRight: 3,
  },
  tagStyle: {
    backgroundColor: config.colorVerySubtle,
    marginRight: 9,
  },
  tagTextStyle: {
    color: config.colorMain,
  },
  faved: {
    color: config.brandRed,
  },
  special: {
    backgroundColor: config.colorBorder,
    borderRadius: config.borderRadius,
    padding: 3,
    marginRight: 3,
  },
  specialText: {
    color: config.colorMain,
  }
};
*/

export default class SkillItem extends Component {
  static propTypes = {
    _id: PropTypes.string,
    timeline: PropTypes.bool,
    nofav: PropTypes.bool,
    state: PropTypes.number,
    reward: PropTypes.number,
    dueTime: PropTypes.string,
    startTime: PropTypes.string,
    tags: PropTypes.array,
    description: PropTypes.string,
    publisher: PropTypes.object,
    meId: PropTypes.string,
    canVote: PropTypes.array,
    tasker: PropTypes.any,
    loc: PropTypes.object,
    myPos: PropTypes.array,
    imgs: PropTypes.array,
    favs: PropTypes.number,
    type: PropTypes.number,
    data: Map.isMap,
    long: PropTypes.number,
    lati: PropTypes.number,
    isSpecial: PropTypes.bool,
  };

  render() {
    const {data, long, lati} = this.props;
    const plainData = data ? data.toJS() : {};
    const styles = require('./SkillItem.scss');
    const {
       tag, title, price,
       unit,
       imgs, _id,
       description,
       loc,
       totalOrders,
       favs,
       publisher = {},
       state,
       isSpecial,
    } = plainData; // tags,
    const {_id: pubId, school, avatar, username, realname, signature, gender} = publisher;

    return (
      <div className={styles.container}>
        <Link to={'/skills/' + _id} className={styles.skillItemMain}>
          <div className={styles.content}>
            <div className={styles.titleSection}>
             {
                isSpecial && <div className={styles.special}>
                  <span className={styles.specialText}>特别篇</span>
                </div>
              }
             <span className={styles.titleText}>{title}</span>
              <span className={styles.priceText}>¥{price}/{unit}</span>
            </div>
            <div className={styles.description}>
              <span className={styles.descriptionText}>{description}</span>
              {
                imgs && imgs.length ? <div className={styles.images}>
                {imgs.map((img) => <img key={img.key} src={IMAGE_HOST + img.key + '?imageView2/1/w/60/h/60'}/>)}
              </div>
                 : null
              }
            </div>
            <div className={styles.miscdiv}>
              <div className={styles.miscTexts}>
                {
                  state === 1 && <Tag name="已下架" className={styles.tagStyle} textclassName={styles.tagTextStyle} />
                }

                <span className={styles.misc}>
                  {totalOrders}预约
                </span>
                <span className={styles.misc}>
                  {favs}收藏
                </span>
                <span className={styles.misc}>
                  {loc !== undefined ? Math.floor(calcCrow(loc.coordinates, [long, lati])) + 'm' : null}
                </span>
                <span className={styles.misc}>
                  {tag}
                </span>
              </div>
            </div>
          </div>
        </Link>

          <Link to={'/users/' + pubId} className={styles.user}>
            <Avatar size={36} src={avatar} username={username} />
            <div className={styles.userSection}>
              <p className={styles.realname}>{realname || '匿名'}<Gender gender={gender} /><Tag className={styles.school} name={school} /></p>
              <p className={styles.signature}>{signature || '暂无介绍'}</p>
            </div>
          </Link>


      </div>
    );
  }
}

