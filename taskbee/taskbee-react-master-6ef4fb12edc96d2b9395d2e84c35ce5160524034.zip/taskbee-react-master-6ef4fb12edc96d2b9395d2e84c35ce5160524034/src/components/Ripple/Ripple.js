import React, {Component} from 'react';
import ReactDOM from 'react-dom';
export default class Ripple extends Component {

  state = {
    ripples: {},
  }

  componentWillUnmount() {
    Object.keys(this.state.ripples).forEach((key) => clearTimeout(this.state.ripples[key]));
  }

  onMouseDown = (event) => {
    if (event.button === 0) this.startRipple(event);
    return true;
  }

  onTouchStart = (event) => {
    this.startRipple(event, true);
  }

  startRipple = (event, isTouchStart) => {
    if (isTouchStart) {
      this.startedByTouch = true;
    } else if (this.startedByTouch) {
      this.startedByTouch = false;
      return;
    }
    const isTouchEvent = event.touches && event.touches.length;
    const pageX = isTouchEvent ? event.touches[0].pageX : event.pageX;
    const pageY = isTouchEvent ? event.touches[0].pageY : event.pageY;
    const el = ReactDOM.findDOMNode(this);
    const rect = el.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2;
    const yy = pageY - rect.top - document.body.scrollTop - size / 2;
    const xx = pageX - rect.left - document.body.scrollLeft - size / 2;

    const next = ++this.nextRipple;

    // 删除ripple
    const deleteHandle = setTimeout(() => {
      const ripples = {...this.state.ripples};
      delete ripples[next];
      this.setState({
        ripples
      });
    }, 460);

    // 增加ripple
    this.setState({
      ripples: {
        ...this.state.ripples,
        [next]: deleteHandle,
      },
      size,
      xx, yy,
    });
  }

  nextRipple = 0

  render() {
    const {ripples, xx, yy, size} = this.state;
    const style = {
      left: xx,
      top: yy,
      width: size,
      height: size,
    };
    const {...props} = this.props;
    const styles = require('./Ripple.scss');
    return (
      <div className={styles.ripple} onMouseDown={this.onMouseDown} onTouchStart={this.onTouchStart}>
        {Object.keys(ripples).map( key => <span key={key} style={style}></span>)}
      </div>
    );
  }
}
