import React, {Component, PropTypes} from 'react';

export default class TextInput extends Component {
  static propTypes = {
    label: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    type: PropTypes.string,
    error: PropTypes.string,
    touched: PropTypes.bool,
    active: PropTypes.bool,
    serverError: PropTypes.string
  }

  render() {
    const styles = require('./TextInput.scss');
    const { serverError, type, label, placeholder, value, error, touched, active, ...others} = this.props;
    let outerClass = styles.textInput;
    if (active) {
      outerClass = outerClass + ' ' + styles.active;
    }
    if (error && touched) {
      outerClass = outerClass + ' ' + styles.error;
    }
    return (
      <div className={outerClass}>
        <label>{label}</label>
        <input type={type} value={value} placeholder={placeholder} {...others}/>
        {serverError && <div className={styles.errorMsg}>{serverError}</div>}
        {!serverError && error && touched && (others.dirty || !active) && <div className={styles.errorMsg}>{error}</div>}
      </div>
    );
  }
}
